"""Semantic contract for author-supplied material relationship transitions."""

from __future__ import annotations

from typing import Any

from culsma.common.diagnostics import Diagnostic
from culsma.common.source import Span
from culsma.pipeline.container_views import (
    resolve_materials_get,
    resolve_materials_index,
)
from culsma.pipeline.ir_nodes import IRArg, IRCall, IRIdentifier, IRList, IRMember
from culsma.pipeline.program_registry import resolve_program_output
from culsma.scientific_model.material import (
    AUTHOR_SETTABLE_MATERIAL_RELATIONS,
    COMPONENT_BOUND_MATERIAL_RELATIONS,
    MaterialRelation,
)

from .resolution import ExprResolver


def validate_material_transitions_contract(
    args: list[IRArg],
    *,
    expr_bindings: dict[str, Any],
    program_kind: str | None,
    node_id: str | None,
    span: Span | None,
) -> list[Diagnostic]:
    transition_arg = next((arg for arg in args if arg.name == "transitions"), None)
    if transition_arg is None:
        return []

    rules = ExprResolver.resolve_bound_expr(transition_arg.value, expr_bindings)
    if not isinstance(rules, IRList):
        return [
            _issue(
                "SEM_MATERIAL_TRANSITIONS_SHAPE_INVALID",
                "sep transitions must be a list",
                transition_arg.span or span,
                node_id,
            )
        ]

    sample_arg = next((arg for arg in args if arg.name == "sample"), None)
    sample_name = _identifier_name(sample_arg.value) if sample_arg is not None else None
    diagnostics: list[Diagnostic] = []
    for rule in rules.elements:
        if not isinstance(rule, IRCall) or rule.name != "transition":
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_TRANSITION_SHAPE_INVALID",
                    "each transitions item must be a transition(...) call",
                    getattr(rule, "span", None) or transition_arg.span or span,
                    node_id,
                )
            )
            continue

        named = {arg.name: arg for arg in rule.args}
        names = [arg.name for arg in rule.args]
        required_names = {"subject", "output", "to"}
        allowed_names = required_names | {"associated_with"}
        if (
            not required_names.issubset(names)
            or not set(names).issubset(allowed_names)
            or len(names) != len(set(names))
        ):
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_TRANSITION_ARGS_INVALID",
                    "transition requires subject, output, and to, with optional associated_with",
                    rule.span or transition_arg.span or span,
                    node_id,
                )
            )
            continue

        selector = resolve_materials_index(
            named["subject"].value,
            expr_bindings=expr_bindings,
        ) or resolve_materials_get(
            named["subject"].value,
            expr_bindings=expr_bindings,
        )
        if selector is None:
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_SELECTOR_INVALID",
                    "transition subject must be sample.materials[index] or "
                    "sample.materials.get(entry_id)",
                    named["subject"].span or rule.span or span,
                    node_id,
                )
            )
        else:
            selector_sample = _identifier_name(selector.container)
            if sample_name is None or selector_sample != sample_name:
                diagnostics.append(
                    _issue(
                        "SEM_MATERIAL_SELECTOR_CONTAINER_MISMATCH",
                        "transition subject container must be the same binding as sep sample",
                        named["subject"].span or rule.span or span,
                        node_id,
                    )
                )

        output_member = _enum_member(named["output"].value)
        if output_member is None or program_kind is None:
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_TRANSITION_OUTPUT_INVALID",
                    "transition output must be a member of the selected program's output enum",
                    named["output"].span or rule.span or span,
                    node_id,
                )
            )
        else:
            output_resolution = resolve_program_output(
                program_kind,
                output_member[0],
                output_member[1],
            )
            if output_resolution.output is None:
                diagnostics.append(
                    _issue(
                        "SEM_MATERIAL_TRANSITION_OUTPUT_INVALID",
                        output_resolution.message
                        or "transition output is not declared by the separation program",
                        named["output"].span or rule.span or span,
                        node_id,
                    )
                )

        target_relation: MaterialRelation | None = None
        target_member = _enum_member(named["to"].value)
        if target_member is not None and target_member[0] == "MaterialRelation":
            try:
                target_relation = MaterialRelation[target_member[1]]
            except KeyError:
                target_relation = None
        if target_relation not in AUTHOR_SETTABLE_MATERIAL_RELATIONS:
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_TRANSITION_TARGET_INVALID",
                    "transition to must be an author-settable MaterialRelation enum identifier",
                    named["to"].span or rule.span or span,
                    node_id,
                )
            )

        association_arg = named.get("associated_with")
        if target_relation in COMPONENT_BOUND_MATERIAL_RELATIONS:
            if association_arg is None:
                diagnostics.append(
                    _issue(
                        "SEM_MATERIAL_TRANSITION_ASSOCIATION_REQUIRED",
                        f"transition to {target_relation.value} requires "
                        "associated_with = sample.materials[index] or "
                        "sample.materials.get(entry_id)",
                        rule.span or transition_arg.span or span,
                        node_id,
                    )
                )
        elif association_arg is not None:
            diagnostics.append(
                _issue(
                    "SEM_MATERIAL_TRANSITION_ASSOCIATION_FORBIDDEN",
                    "associated_with is only valid for component-bound target relations",
                    association_arg.span or rule.span or span,
                    node_id,
                )
            )

        if association_arg is not None:
            association_selector = resolve_materials_index(
                association_arg.value,
                expr_bindings=expr_bindings,
            ) or resolve_materials_get(
                association_arg.value,
                expr_bindings=expr_bindings,
            )
            if association_selector is None:
                diagnostics.append(
                    _issue(
                        "SEM_MATERIAL_TRANSITION_ASSOCIATION_INVALID",
                        "associated_with must be sample.materials[index] or "
                        "sample.materials.get(entry_id)",
                        association_arg.span or rule.span or span,
                        node_id,
                    )
                )
            else:
                association_sample = _identifier_name(association_selector.container)
                if sample_name is None or association_sample != sample_name:
                    diagnostics.append(
                        _issue(
                            "SEM_MATERIAL_SELECTOR_CONTAINER_MISMATCH",
                            "associated_with container must be the same binding as sep sample",
                            association_arg.span or rule.span or span,
                            node_id,
                        )
                    )
    return diagnostics


def _enum_member(expr: Any) -> tuple[str, str] | None:
    if not isinstance(expr, IRMember) or not isinstance(expr.base, IRIdentifier):
        return None
    return expr.base.name, expr.member


def _identifier_name(expr: Any) -> str | None:
    return expr.name if isinstance(expr, IRIdentifier) else None


def _issue(
    code: str,
    message: str,
    span: Span | None,
    node_id: str | None,
) -> Diagnostic:
    return Diagnostic(code=code, message=message, span=span, node_id=node_id)
