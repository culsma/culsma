from __future__ import annotations

import ast
from pathlib import Path

import pytest

from culsma.pipeline.plan_nodes import PlanStep
from culsma.pipeline.program_registry import (
    CentrifugeProgramOutput,
    CentrifugalFiltrationProgramOutput,
    DisruptProgramOutput,
    FieldProgramOutput,
    FiltrationProgramOutput,
    MagneticProgramOutput,
    PhasePartitionProgramOutput,
    PrecipitationProgramOutput,
    SEPARATION_SLOT_CONTRACTS,
    SepProgramOutput,
    get_material_effect_kind,
    get_program_outputs,
    get_program_spec,
    resolve_program_output,
)
from culsma.runtime.material.compute import MaterialCompute
from culsma.runtime.material.contents_state import (
    ContentsPartitionTransition,
    ContentsPartSelection,
    MaterialIndexedPartsStateManager,
)
from culsma.runtime.material.result import MaterialUpdateResult
from culsma.runtime.material.state import MaterialStateChangePlan, MaterialStateManager
from culsma.runtime import material_compute as material_compute_compat
from culsma.runtime.material.partition import PartitionClass
from culsma.runtime.material.separation import (
    SCIENTIFIC_MODEL_SEPARATION_PROGRAMS,
    separation_slot_contract,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MATERIAL_DIR = PROJECT_ROOT / "src" / "culsma" / "runtime" / "material"
SCIENTIFIC_MODEL_DIR = PROJECT_ROOT / "src" / "culsma" / "scientific_model"


def _material_modules() -> list[Path]:
    return sorted(path for path in MATERIAL_DIR.glob("*.py") if path.name != "__init__.py")


def _contents_ref(name: str = "tube", slot: int = 1) -> dict[str, object]:
    return {
        "kind": "IRIndex",
        "base": {
            "kind": "IRMember",
            "base": {"kind": "IRIdentifier", "name": name, "span": None},
            "member": "contents",
            "span": None,
        },
        "index": {"kind": "IRQuantity", "value": float(slot), "unit": None, "span": None},
        "span": None,
    }


def _step(*, field: str | None = None) -> PlanStep:
    gate = {"env": {"field": field}} if field is not None else None
    return PlanStep(step_id="p0.s1", op="Mutation", args={}, deps=[], gate=gate, span=None)


def _material_step(op: str, *, step_id: str = "p0.s1") -> PlanStep:
    return PlanStep(step_id=step_id, op=op, args={}, deps=[], gate=None, span=None)


def test_pipeline_and_runtime_share_separation_output_meanings() -> None:
    assert {
        program_kind: separation_slot_contract(program_kind)
        for program_kind in SEPARATION_SLOT_CONTRACTS
    } == SEPARATION_SLOT_CONTRACTS


def test_each_separation_program_owns_one_closed_output_enum() -> None:
    expected = {
        "sep_program": SepProgramOutput,
        "centrifuge_program": CentrifugeProgramOutput,
        "magnetic_program": MagneticProgramOutput,
        "disrupt_program": DisruptProgramOutput,
        "field_program": FieldProgramOutput,
        "filtration_program": FiltrationProgramOutput,
        "centrifugal_filtration_program": CentrifugalFiltrationProgramOutput,
        "phase_partition_program": PhasePartitionProgramOutput,
        "precipitation_program": PrecipitationProgramOutput,
    }

    for program_kind, output_type in expected.items():
        outputs = get_program_outputs(program_kind)
        assert outputs == tuple(output_type)
        assert {output.part_id for output in outputs} == {"0", "1"}
        assert SEPARATION_SLOT_CONTRACTS[program_kind] == {
            output.part_id: output.semantic_role
            for output in outputs
        }
        spec = get_program_spec(program_kind)
        if spec is not None:
            assert spec.output_type is output_type


def test_program_output_resolution_rejects_cross_program_enum_members() -> None:
    accepted = resolve_program_output(
        "filtration_program",
        "FiltrationProgramOutput",
        "RETENTATE",
    )
    rejected = resolve_program_output(
        "filtration_program",
        "MagneticProgramOutput",
        "BOUND",
    )

    assert accepted.output is FiltrationProgramOutput.RETENTATE
    assert accepted.code is None
    assert rejected.output is None
    assert rejected.code == "PROGRAM_OUTPUT_ENUM_TYPE_MISMATCH"


def test_program_output_metadata_is_immutable() -> None:
    output = FiltrationProgramOutput.RETENTATE

    with pytest.raises(AttributeError):
        output.part_id = "9"
    with pytest.raises(AttributeError):
        output.semantic_role = "other"

    assert output.part_id == "1"
    assert output.semantic_role == "retentate"


def test_generic_sep_output_preserves_legacy_serialized_roles() -> None:
    assert SEPARATION_SLOT_CONTRACTS["sep_program"] == {
        "0": "fraction_0",
        "1": "fraction_1",
    }


def test_material_compute_rejects_quantity_change_without_movement_contract():
    class MissingMovementManager:
        def plan_material_state_change(self, *, step, state):
            return object()

        def apply_change(self, change_plan, state):
            state["containers"]["A"]["volume_uL"] -= 10.0
            state["containers"]["B"]["volume_uL"] += 10.0
            return MaterialUpdateResult(
                material_state=state,
                delta={
                    "op": "FutureTransfer",
                    "source": "A",
                    "destination": "B",
                    "moved_uL": 10.0,
                },
            )

    result = MaterialCompute(state_manager=MissingMovementManager()).apply_step(
        _material_step("FutureTransfer"),
        {
            "containers": {
                "A": {"volume_uL": 100.0, "mass_mg": 0.0},
                "B": {"volume_uL": 0.0, "mass_mg": 0.0},
            }
        },
    )

    assert not result.ok
    assert [diagnostic.code for diagnostic in result.diagnostics] == [
        "MAT_MOVEMENT_CONTRACT_MISSING"
    ]


def _partitioned_state(*, valid: bool = True, preservation_contract: bool = False) -> dict[str, object]:
    record = {
        "kind": "partitioned",
        "producer_op": "sep",
        "program_kind": "magnetic_program",
        "source": "Tube",
        "slot_contract": {"0": "retained", "1": "flowthrough"},
        "parts": {
            "0": {
                "volume_uL": 40.0,
                "mass_mg": 40.0,
                "components": {"beads": 20.0},
                "metadata": {},
            },
            "1": {
                "volume_uL": 160.0,
                "mass_mg": 160.0,
                "components": {"buffer": 160.0},
                "metadata": {},
            },
        },
        "valid": valid,
        "step_id": "p0.s0",
    }
    if preservation_contract:
        record["preservation_contract"] = {
            "kind": "field_retention",
            "field": "magnetic_rack",
            "retained_slot": "0",
            "default_incoming_slot": "1",
        }
    return {
        "bindings": {"tube": "Tube"},
        "containers": {
            "Tube": {
                "volume_uL": 200.0,
                "mass_mg": 200.0,
                "components": {"beads": 20.0, "buffer": 180.0},
                "metadata": {},
            }
        },
        "contents_states": {
            "Tube": record,
        },
    }


def test_material_support_module_removed() -> None:
    assert not (MATERIAL_DIR / "support.py").exists()


def test_material_modules_do_not_import_removed_support_module() -> None:
    offenders: list[str] = []
    for path in _material_modules():
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == "culsma.runtime.material.support":
                offenders.append(path.name)
            elif isinstance(node, ast.Import):
                offenders.extend(alias.name for alias in node.names if alias.name == "culsma.runtime.material.support")

    assert offenders == []


def test_material_modules_do_not_import_private_sibling_helpers() -> None:
    offenders: list[tuple[str, str, list[str]]] = []
    prefix = "culsma.runtime.material."
    for path in _material_modules():
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            if node.module is None or not node.module.startswith(prefix):
                continue
            private_names = [alias.name for alias in node.names if alias.name.startswith("_")]
            if private_names:
                offenders.append((path.name, node.module, private_names))

    assert offenders == []


def test_scientific_model_core_logic_has_no_private_functions() -> None:
    paths = sorted(SCIENTIFIC_MODEL_DIR.rglob("*.py")) + [
        MATERIAL_DIR / "component_entries.py",
        MATERIAL_DIR / "partition.py",
        MATERIAL_DIR / "separation.py",
        MATERIAL_DIR / "scientific_model_adapter.py",
    ]
    offenders: list[tuple[str, str]] = []
    for path in paths:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if node.name.startswith("_") and not node.name.startswith("__"):
                offenders.append((str(path.relative_to(PROJECT_ROOT)), node.name))

    assert offenders == []


def test_partition_does_not_construct_scientific_model_dependencies() -> None:
    path = MATERIAL_DIR / "partition.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    constructed_names = {
        node.func.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }

    assert "create_default_scientific_model_resolver" not in constructed_names
    assert "ScientificModelPartitionAdapter" not in constructed_names


def test_partition_is_not_the_scientific_model_boundary() -> None:
    path = MATERIAL_DIR / "partition.py"
    source = path.read_text(encoding="utf-8")

    assert "ScientificModelPartitionAdapter" not in source
    assert "ResolvedMaterialEffect" not in source
    assert "SCIENTIFIC_MODEL_SEPARATION_PROGRAMS" not in source
    assert ".resolve(" not in source


def test_separation_owns_the_scientific_model_application_boundary() -> None:
    path = MATERIAL_DIR / "separation.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    function_names = {
        node.name for node in tree.body if isinstance(node, ast.FunctionDef)
    }

    assert {
        "apply_separation_material",
        "project_resolved_material_effect",
        "commit_separation_candidate",
    }.issubset(function_names)


def test_component_entries_own_runtime_transfer_and_compatibility_projection() -> None:
    entry_source = (MATERIAL_DIR / "component_entries.py").read_text(encoding="utf-8")
    ledger_source = (MATERIAL_DIR / "ledger.py").read_text(encoding="utf-8")
    contents_source = (MATERIAL_DIR / "contents_state.py").read_text(encoding="utf-8")

    assert "def plan_component_entry_transfer(" in entry_source
    assert "def commit_component_entry_transfer(" in entry_source
    assert "def normalize_component_entries(" in entry_source
    assert "def project_component_entries(" in entry_source
    assert "relocate_component_entries(" in ledger_source
    assert "apply_material_movement(" in (MATERIAL_DIR / "movement.py").read_text(
        encoding="utf-8"
    )
    assert "transfer_scientific_model_relationships" not in ledger_source
    assert "target_components" not in contents_source


def test_relationship_refreshes_do_not_rewrite_authoritative_entries() -> None:
    suspension_source = (MATERIAL_DIR / "suspension.py").read_text(encoding="utf-8")
    contents_tree = ast.parse(
        (MATERIAL_DIR / "contents_state.py").read_text(encoding="utf-8")
    )
    refresh = next(
        node
        for node in contents_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "refresh_scientific_model_relationships"
    )
    refresh_calls = {
        node.func.id
        for node in ast.walk(refresh)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }

    assert "set_component_entry_relations" not in suspension_source
    assert "replace_component_entries" not in refresh_calls
    assert refresh_calls == {"isinstance", "project_component_entries"}


def test_separation_candidate_receives_output_container_identity_before_commit() -> None:
    separation_tree = ast.parse(
        (MATERIAL_DIR / "separation.py").read_text(encoding="utf-8")
    )
    projector = next(
        node
        for node in separation_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "project_resolved_material_effect"
    )
    commit = next(
        node
        for node in separation_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "commit_separation_candidate"
    )
    commit_calls = {
        node.func.id
        for node in ast.walk(commit)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
    }

    assert any(
        argument.arg == "output_ids_by_part"
        for argument in projector.args.kwonlyargs
    )
    assert "validate_separation_candidate" in commit_calls


def test_generic_entry_movement_does_not_own_material_classification() -> None:
    tree = ast.parse(
        (MATERIAL_DIR / "component_entries.py").read_text(encoding="utf-8")
    )
    transition = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "transition_entry_for_move"
    )
    string_literals = {
        node.value
        for node in ast.walk(transition)
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    }

    assert "pelletable_cells" not in string_literals


def test_runtime_movement_resolves_state_before_entry_commit() -> None:
    movement_tree = ast.parse(
        (MATERIAL_DIR / "movement.py").read_text(encoding="utf-8")
    )
    projector = next(
        node
        for node in movement_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "project_material_movement"
    )
    calls = [
        (
            node.func.attr
            if isinstance(node.func, ast.Attribute)
            else node.func.id
            if isinstance(node.func, ast.Name)
            else ""
        )
        for node in ast.walk(projector)
        if isinstance(node, ast.Call)
    ]

    assert "resolve_movement" in calls
    assert "plan_component_entry_transfer" in calls
    assert calls.index("resolve_movement") < calls.index("plan_component_entry_transfer")


def test_mutation_does_not_bypass_the_scientific_movement_boundary() -> None:
    mutation_source = (MATERIAL_DIR / "mutation.py").read_text(encoding="utf-8")

    assert "apply_material_movement(" in mutation_source
    assert "move_explicit(" not in mutation_source
    assert "move_ratio(" not in mutation_source


def test_runtime_operations_do_not_call_the_legacy_move_wrappers() -> None:
    offenders = [
        path.name
        for path in _material_modules()
        if path.name != "ledger.py"
        and (
            "move_explicit(" in path.read_text(encoding="utf-8")
            or "move_ratio(" in path.read_text(encoding="utf-8")
        )
    ]

    assert offenders == []


def test_entry_normalization_enforces_the_closed_relation_contract() -> None:
    entry_source = (MATERIAL_DIR / "component_entries.py").read_text(encoding="utf-8")

    assert "for candidate in MaterialRelation" in entry_source
    assert "ComponentEntryRelationError" in entry_source


def test_program_registry_declares_material_effect_kind() -> None:
    assert get_material_effect_kind("disrupt_program") == "disrupt"
    for program_kind in SEPARATION_SLOT_CONTRACTS:
        if program_kind == "sep_program":
            continue
        expected = "disrupt" if program_kind == "disrupt_program" else "separation_fate"
        assert get_material_effect_kind(program_kind) == expected


def test_runtime_separation_callers_do_not_bypass_separation_module() -> None:
    offenders: list[str] = []
    for filename in ("contents_state.py", "mutation.py"):
        path = MATERIAL_DIR / filename
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.ImportFrom)
                and node.module == "culsma.runtime.material.partition"
            ):
                offenders.append(filename)

    assert offenders == []


def test_partition_does_not_duplicate_program_slot_contracts() -> None:
    path = MATERIAL_DIR / "partition.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    duplicate_slot_contracts = []
    for class_node in (
        node for node in tree.body if isinstance(node, ast.ClassDef)
    ):
        for assignment in class_node.body:
            if not isinstance(assignment, (ast.Assign, ast.AnnAssign)):
                continue
            targets = (
                assignment.targets
                if isinstance(assignment, ast.Assign)
                else [assignment.target]
            )
            if any(
                isinstance(target, ast.Name) and target.id == "slot_contract"
                for target in targets
            ):
                duplicate_slot_contracts.append(assignment.lineno)

    assert duplicate_slot_contracts == []


def test_partition_retains_only_the_preexisting_python_compatibility_classes() -> None:
    path = MATERIAL_DIR / "partition.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    class_names = {
        node.name for node in tree.body if isinstance(node, ast.ClassDef)
    }

    assert {
        "PrecipitationPartitionStrategy",
        "MagneticPartitionStrategy",
        "PhasePartitionStrategy",
        "FieldPartitionStrategy",
        "DisruptPartitionStrategy",
    }.issubset(class_names)
    assert {
        "CentrifugePartitionStrategy",
        "FiltrationPartitionStrategy",
        "CentrifugalFiltrationPartitionStrategy",
    }.isdisjoint(class_names)


def test_every_registered_separation_program_uses_the_scientific_model_path() -> None:
    assert SCIENTIFIC_MODEL_SEPARATION_PROGRAMS == frozenset(
        SEPARATION_SLOT_CONTRACTS
    )


def test_legacy_partition_python_exports_remain_compatible() -> None:
    expected = {
        "PhasePartitionStrategy": (0.99, 0.01),
        "PrecipitationPartitionStrategy": (0.95, 0.05),
        "MagneticPartitionStrategy": (0.99, 0.01),
        "DisruptPartitionStrategy": (0.95, 0.05),
        "FieldPartitionStrategy": (0.95, 0.05),
    }

    actual = {
        name: getattr(material_compute_compat, name)().ratios(
            PartitionClass.MOLECULAR_TARGET
        )
        for name in expected
    }

    assert actual == expected


def test_material_compute_routes_material_changes_through_state_manager() -> None:
    class RecordingStateManager:
        def __init__(self) -> None:
            self.planned = False
            self.applied = False

        def plan_material_state_change(
            self,
            *,
            step: PlanStep,
            state: dict[str, object],
        ) -> MaterialStateChangePlan:
            self.planned = True
            return MaterialStateChangePlan(kind="partition_or_index", step=step)

        def apply_change(
            self,
            change_plan: MaterialStateChangePlan,
            state: dict[str, object],
        ) -> MaterialUpdateResult:
            self.applied = True
            return MaterialUpdateResult(material_state=state, diagnostics=[], delta={"mode": change_plan.kind})

    manager = RecordingStateManager()
    result = MaterialCompute(state_manager=manager).apply_step(_material_step("sep"), {"containers": {}})

    assert result.ok
    assert result.delta == {"mode": "partition_or_index"}
    assert manager.planned is True
    assert manager.applied is True


def test_material_compute_skips_state_apply_when_step_has_no_material_change() -> None:
    class RecordingStateManager:
        def __init__(self) -> None:
            self.planned = False
            self.applied = False

        def plan_material_state_change(
            self,
            *,
            step: PlanStep,
            state: dict[str, object],
        ) -> None:
            self.planned = True
            return None

        def apply_change(
            self,
            change_plan: MaterialStateChangePlan,
            state: dict[str, object],
        ) -> MaterialUpdateResult:
            self.applied = True
            raise AssertionError("state apply should not run without a material-state plan")

    manager = RecordingStateManager()
    result = MaterialCompute(state_manager=manager).apply_step(_material_step("Wait"), {"containers": {}})

    assert result.ok
    assert result.delta == {}
    assert manager.planned is True
    assert manager.applied is False


def test_material_handler_module_removed() -> None:
    assert not (MATERIAL_DIR / "handler.py").exists()


def test_material_organization_transform_module_removed() -> None:
    assert (MATERIAL_DIR / "separation.py").exists()
    assert not (MATERIAL_DIR / "organization.py").exists()


def test_mutation_dispatcher_does_not_handle_contents_state_sources_directly() -> None:
    path = MATERIAL_DIR / "mutation.py"
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    forbidden_classes = {"QuantifiedContentsStateHandler", "ContentsStateSourceHandler"}
    class_names = {node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)}

    assert forbidden_classes.isdisjoint(class_names)


def test_material_state_manager_plans_partition_changes_before_contents_manager() -> None:
    manager = MaterialStateManager()

    plan = manager.plan_material_state_change(step=_material_step("sep"), state={"containers": {}})

    assert isinstance(plan, MaterialStateChangePlan)
    assert plan.kind == "partition_or_index"


def test_indexed_parts_state_manager_resolves_indexed_part_without_material_mutation() -> None:
    state = _partitioned_state()
    manager = MaterialCompute().state_manager.indexed_parts_state_manager

    result = manager.resolve_indexed_part(step=_step(), state=state, contents_ref=_contents_ref(slot=1))

    assert isinstance(result, ContentsPartSelection)
    assert result.source_id == "Tube"
    assert result.slot == "1"
    assert result.part["volume_uL"] == 160.0
    assert state["containers"]["Tube"]["volume_uL"] == 200.0
    assert state["contents_states"]["Tube"]["parts"]["1"]["volume_uL"] == 160.0


def test_indexed_parts_state_manager_reports_stale_state_as_diagnostic() -> None:
    state = _partitioned_state(valid=False)
    manager = MaterialCompute().state_manager.indexed_parts_state_manager

    result = manager.resolve_indexed_part(step=_step(), state=state, contents_ref=_contents_ref(slot=1))

    assert isinstance(result, MaterialUpdateResult)
    assert not result.ok
    assert [diagnostic.code for diagnostic in result.diagnostics] == ["MAT_CONTENTS_STATE_NOT_INDEXED"]


def test_indexed_parts_state_manager_requires_preservation_context_for_indexed_part() -> None:
    state = _partitioned_state(preservation_contract=True)
    manager = MaterialIndexedPartsStateManager()

    result = manager.resolve_indexed_part(step=_step(), state=state, contents_ref=_contents_ref(slot=1))

    assert isinstance(result, MaterialUpdateResult)
    assert not result.ok
    assert [diagnostic.code for diagnostic in result.diagnostics] == ["MAT_CONTENTS_STATE_PRESERVATION_NOT_SATISFIED"]
    assert state["contents_states"]["Tube"]["valid"] is False
    assert state["contents_states"]["Tube"]["invalid_reason"] == "preservation_contract_not_satisfied"


def test_indexed_parts_state_manager_accepts_indexed_part_when_preservation_context_matches() -> None:
    state = _partitioned_state(preservation_contract=True)
    manager = MaterialIndexedPartsStateManager()

    result = manager.resolve_indexed_part(step=_step(field="magnetic_rack"), state=state, contents_ref=_contents_ref(slot=1))

    assert isinstance(result, ContentsPartSelection)
    assert result.source_id == "Tube"
    assert result.slot == "1"


def test_indexed_parts_state_manager_records_sep_transition() -> None:
    state = {
        "containers": {
            "Tube": {
                "volume_uL": 200.0,
                "mass_mg": 200.0,
                "components": {"beads": 20.0, "buffer": 180.0},
                "metadata": {},
            }
        },
        "content_registry": {
            "beads": {
                "content_kind": "particulate",
                "content_type": "beads",
                "content_attrs": {"bead_property": "magnetic"},
            },
            "buffer": {
                "content_kind": "formulation",
                "content_type": "buffer",
            },
        },
    }
    manager = MaterialIndexedPartsStateManager(
        material_effect_adapter=MaterialCompute().material_effect_adapter
    )

    result = manager.record_sep_transition(
        step=_material_step("sep"),
        state=state,
        source_id="Tube",
        program={"kind": "IRCall", "name": "magnetic_program", "args": []},
        keep_source=None,
        explicit_fates={},
    )

    assert isinstance(result, ContentsPartitionTransition)
    assert result.contents_state == {
        "source": "Tube",
        "kind": "partitioned",
        "program_kind": "magnetic_program",
        "slots": ["0", "1"],
    }
    assert result.partition["slot_contract"] == {"0": "bound", "1": "flowthrough"}
    assert result.partition["preservation_contract"]["field"] == "magnetic_rack"
    assert state["contents_states"]["Tube"]["kind"] == "partitioned"
    assert "p0.s1::0" not in state["containers"]
    assert "p0.s1::1" not in state["containers"]


def test_indexed_parts_state_manager_records_frac_transition() -> None:
    state = {
        "containers": {
            "Tube": {
                "volume_uL": 120.0,
                "mass_mg": 120.0,
                "components": {"S1": 120.0},
                "metadata": {},
            }
        },
    }
    manager = MaterialCompute().state_manager.indexed_parts_state_manager

    result = manager.record_frac_transition(
        step=_material_step("frac"),
        state=state,
        source_id="Tube",
        bins=3,
        program_kind="density_gradient_program",
    )

    assert isinstance(result, ContentsPartitionTransition)
    assert result.contents_state == {
        "source": "Tube",
        "kind": "fractionated",
        "program_kind": "density_gradient_program",
        "slots": ["0", "1", "2"],
    }
    assert result.slot_ids == {"0": "p0.s1::0", "1": "p0.s1::1", "2": "p0.s1::2"}
    assert result.split_ratio == 1.0 / 3
    assert state["contents_states"]["Tube"]["kind"] == "fractionated"
    assert state["contents_states"]["Tube"]["slot_contract"] == {
        "0": "fraction_0",
        "1": "fraction_1",
        "2": "fraction_2",
    }
    assert round(state["contents_states"]["Tube"]["parts"]["1"]["volume_uL"], 6) == 40.0
    assert "p0.s1::0" not in state["containers"]
    assert "p0.s1::1" not in state["containers"]
    assert "p0.s1::2" not in state["containers"]
