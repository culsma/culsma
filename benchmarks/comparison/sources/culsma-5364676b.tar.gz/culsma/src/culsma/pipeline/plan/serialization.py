"""Expression and environment serialization helpers for plan lowering."""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import StrEnum
from typing import Any

from culsma.common.content_contracts import CONTENT_ENUM_TYPES, serialize_content_enum

from culsma.pipeline.ir_nodes import (
    IRArg,
    IRAssign,
    IRCall,
    IRConditional,
    IRIdentifier,
    IRIndex,
    IRMember,
    IRRecord,
    IRRepeat,
    IRString,
    IRWithConstraint,
    IRWithEnv,
)
from culsma.pipeline.plan_nodes import PlanStep
from culsma.pipeline.program_registry import canonical_program_arg_name


class PlanExpressionSerializer:
    def contains_unresolved_identifier(self, value: Any) -> bool:
        if isinstance(value, dict):
            kind = value.get("kind")
            if kind == "IRIdentifier":
                return True
            return any(self.contains_unresolved_identifier(v) for v in value.values())
        if isinstance(value, list):
            return any(self.contains_unresolved_identifier(v) for v in value)
        return False

    def linearize_steps(self, steps: list[PlanStep]) -> list[PlanStep]:
        linearized: list[PlanStep] = []
        previous_step_id: str | None = None
        for step in steps:
            deps = [previous_step_id] if previous_step_id is not None else []
            linearized.append(
                PlanStep(
                    step_id=step.step_id,
                    op=step.op,
                    args=step.args,
                    deps=deps,
                    gate=step.gate,
                    span=step.span,
                )
            )
            previous_step_id = step.step_id
        return linearized

    def serialize_arg_list(self, args: list[IRArg], env: dict[str, Any]) -> dict[str, Any]:
        return {arg.name: self.serialize_expr(arg.value, env) for arg in args}

    def invalidate_local_env_names(self, env: dict[str, Any], statements: list[Any]) -> None:
        for name in self.assigned_local_names_ir(statements):
            env[name] = {"kind": "IRIdentifier", "name": name}

    def assigned_local_names_ir(self, statements: list[Any]) -> set[str]:
        names: set[str] = set()
        for stmt in statements:
            if isinstance(stmt, IRAssign):
                if isinstance(stmt.target, IRIdentifier):
                    names.add(stmt.target.name)
            elif isinstance(stmt, IRConditional):
                names.update(self.assigned_local_names_ir(stmt.then_statements))
                names.update(self.assigned_local_names_ir(stmt.else_statements))
            elif isinstance(stmt, IRWithEnv):
                names.update(self.assigned_local_names_ir(stmt.statements))
            elif isinstance(stmt, IRWithConstraint):
                names.update(self.assigned_local_names_ir(stmt.statements))
            elif isinstance(stmt, IRRepeat):
                names.update(self.assigned_local_names_ir(stmt.statements))
        return names

    def find_arg_by_name(self, args: list[IRArg], name: str) -> IRArg | None:
        for arg in args:
            if arg.name == name:
                return arg
        return None

    def load_content_ref_expr(self, call: IRCall, fallback_ref: str) -> Any:
        code_arg = self.find_arg_by_name(call.args, "code")
        if code_arg is not None:
            return code_arg.value
        name_arg = self.find_arg_by_name(call.args, "name")
        if name_arg is not None:
            return name_arg.value
        return IRString(value=fallback_ref, span=call.span)

    def serialize_expr(self, value: Any, env: dict[str, Any] | None = None) -> Any:
        """Serialize IR expression dataclass into JSON-friendly structure."""
        if isinstance(value, StrEnum) and type(value) in CONTENT_ENUM_TYPES.values():
            return serialize_content_enum(value)
        if isinstance(value, IRIdentifier) and env is not None and value.name in env:
            return env[value.name]
        if (isinstance(value, IRMember) and isinstance(value.base, IRIdentifier)
                and value.base.name in CONTENT_ENUM_TYPES and value.base.name not in (env or {})):
            return {"kind": "ContentEnum", "enum": value.base.name, "member": value.member}
        if isinstance(value, IRMember) and isinstance(value.base, IRIdentifier) and env is not None:
            base = env.get(value.base.name)
            if isinstance(base, dict) and value.member in base:
                return base[value.member]
        if isinstance(value, IRCall):
            value = IRCall(
                name=value.name,
                args=[
                    IRArg(
                        name=canonical_program_arg_name(value.name, arg.name),
                        value=arg.value,
                        span=arg.span,
                    )
                    for arg in value.args
                ],
                span=value.span,
            )
        if isinstance(value, IRIndex) and env is not None:
            base = self.serialize_expr(value.base, env)
            index = self.serialize_expr(value.index, env)
            static_index = self.static_nonnegative_index(index)
            elements = base.get("elements") if isinstance(base, dict) and base.get("kind") == "IRGroup" else None
            if static_index is not None and isinstance(elements, list) and static_index < len(elements):
                return elements[static_index]
            return {
                "base": base,
                "index": index,
                "span": self.serialize_expr(value.span, env),
                "kind": "IRIndex",
            }
        if isinstance(value, IRRecord):
            return {
                key: self.serialize_expr(record_value, env if isinstance(record_value, IRMember) else None)
                for key, record_value in value.entries.items()
            }
        if is_dataclass(value):
            payload = {field.name: getattr(value, field.name) for field in fields(value)}
            if value.__class__.__name__ != "Span":
                payload["kind"] = value.__class__.__name__
            return {k: self.serialize_expr(v, env) for k, v in payload.items()}
        if isinstance(value, list):
            return [self.serialize_expr(v, env) for v in value]
        if isinstance(value, dict):
            return {k: self.serialize_expr(v, env) for k, v in value.items()}
        return value

    @staticmethod
    def static_nonnegative_index(value: Any) -> int | None:
        if not isinstance(value, dict) or value.get("kind") != "IRQuantity" or value.get("unit") is not None:
            return None
        raw_value = value.get("value")
        if not isinstance(raw_value, (int, float)):
            return None
        numeric_value = float(raw_value)
        if not numeric_value.is_integer() or numeric_value < 0:
            return None
        return int(numeric_value)


DEFAULT_PLAN_EXPRESSION_SERIALIZER = PlanExpressionSerializer()
