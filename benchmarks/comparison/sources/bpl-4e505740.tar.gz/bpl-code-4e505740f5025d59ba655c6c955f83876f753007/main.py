"""Convenience entry point — equivalent to running ``bplc`` CLI."""

from bpl.cli.main import main

if __name__ == "__main__":
    main()
