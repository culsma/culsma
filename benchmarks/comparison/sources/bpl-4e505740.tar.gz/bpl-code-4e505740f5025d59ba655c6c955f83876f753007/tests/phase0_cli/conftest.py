"""Fixtures for phase0 CLI contract tests."""

from pathlib import Path

import pytest


@pytest.fixture
def phase0_cli_fixture_dir(fixtures_dir: Path) -> Path:
    """Root fixture directory for phase0 CLI artifacts."""
    return fixtures_dir / "phase0_cli"


@pytest.fixture
def phase0_cli_input_dir(phase0_cli_fixture_dir: Path) -> Path:
    """Input fixture directory for phase0 CLI tests."""
    return phase0_cli_fixture_dir / "inputs"


@pytest.fixture
def phase0_cli_golden_dir(phase0_cli_fixture_dir: Path) -> Path:
    """Golden artifact fixture directory for phase0 CLI tests."""
    return phase0_cli_fixture_dir / "golden"
