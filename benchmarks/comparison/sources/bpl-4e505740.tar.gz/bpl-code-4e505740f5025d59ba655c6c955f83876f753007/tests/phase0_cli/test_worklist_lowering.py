"""Regression tests for worklist-intent lowering and export integration."""

from __future__ import annotations

import json
from pathlib import Path

from bpl.cli.main import EXIT_SUCCESS, main
from bpl.lowering import Checkpoint, Dispense, Pause, WellRef
from bpl.orchestrator import run_pipeline_for_plan


def test_worklist_intents_lower_to_aspirate_dispense_pairs(tmp_path: Path):
    protocol_path = tmp_path / "worklist_intents.bpl"
    protocol_path.write_text(
        (
            "protocol WorklistLowering {\n"
            "  cherrypick(from: src_pick[A1, B2], to: dst_pick[C3, D4], volume: 2 uL)\n"
            "  stamp(from: src_stamp, to: dst_stamp, volume: 5 uL)\n"
            "}\n"
        ),
        encoding="utf-8",
    )

    pipeline = run_pipeline_for_plan(
        input_path=protocol_path,
        target="export",
        strict=False,
    )

    dispense_destinations: set[tuple[str, str]] = set()
    dispense_count = 0
    for step in pipeline.plan.steps.values():
        if not isinstance(step.primitive, Dispense):
            continue
        destination = step.primitive.destination
        assert isinstance(destination, WellRef)
        dispense_count += 1
        dispense_destinations.add((destination.plate_id, destination.well_id))

    # 2 cherrypick pairs + 96 stamp wells.
    assert dispense_count == 98
    assert ("dst_pick", "C3") in dispense_destinations
    assert ("dst_pick", "D4") in dispense_destinations
    assert ("dst_stamp", "A1") in dispense_destinations
    assert ("dst_stamp", "H12") in dispense_destinations


def test_export_csv_populates_rows_for_stamp(tmp_path: Path, capsys):
    protocol_path = tmp_path / "stamp_only.bpl"
    protocol_path.write_text(
        (
            "protocol StampExport {\n"
            "  stamp(from: src_plate, to: dst_plate, volume: 10 uL)\n"
            "}\n"
        ),
        encoding="utf-8",
    )
    output_path = tmp_path / "stamp_worklist.csv"

    exit_code = main(
        [
            "export",
            str(protocol_path),
            "--format",
            "csv",
            "--out",
            str(output_path),
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    manifest = json.loads(captured.out)
    assert manifest["row_count"] == 96
    assert output_path.exists()

    csv_lines = output_path.read_text(encoding="utf-8").strip().splitlines()
    assert len(csv_lines) == 97  # header + 96 rows
    assert "source_plate,source_well,destination_plate,destination_well,transfer_volume_uL" in csv_lines[0]
    assert any("src_plate,A1,dst_plate,A1,10.0" in line for line in csv_lines[1:])
    assert any("src_plate,H12,dst_plate,H12,10.0" in line for line in csv_lines[1:])


def test_biomek_pipeline_rewrites_unsupported_steps_to_manual_gates(
    phase0_cli_input_dir: Path,
):
    pipeline = run_pipeline_for_plan(
        input_path=phase0_cli_input_dir / "unsupported_primitive.bpl",
        target="biomek",
        strict=False,
    )

    primitives = [step.primitive for step in pipeline.plan.steps.values()]
    assert not any(primitive.__class__.__name__ == "HumanStep" for primitive in primitives)
    assert any(isinstance(primitive, Checkpoint) for primitive in primitives)
    assert any(isinstance(primitive, Pause) for primitive in primitives)
    assert any(diag.code == "CAPABILITY_BIOMEK_MANUAL_REWRITE" for diag in pipeline.warnings)
