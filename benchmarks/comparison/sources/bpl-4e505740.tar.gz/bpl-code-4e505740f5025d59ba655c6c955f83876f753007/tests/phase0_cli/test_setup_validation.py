"""Setup-aware validation gate tests."""

import json
from pathlib import Path

import pytest

from bpl.lowering import ExecutionPlan, PlanStep, SetTemperature
from bpl.orchestrator import OrchestrationError, run_pipeline_for_plan, run_setup_gate
from bpl.validation import parse_experiment_setup, validate_plan_against_setup


def _write_setup(tmp_path: Path, payload: dict[str, object]) -> Path:
    path = tmp_path / "setup.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    return path


def _write_bpl(tmp_path: Path, source: str, name: str = "protocol.bpl") -> Path:
    path = tmp_path / name
    path.write_text(source, encoding="utf-8")
    return path


def _base_setup_payload() -> dict[str, object]:
    return {
        "backend": "human",
        "labware": {
            "plate_1": {"capacity_ul": 200.0},
        },
        "initial_volumes": {
            "plate_1:A1": 100.0,
            "plate_1:A2": 0.0,
        },
        "pipettes": {
            "p200_single": {"min_volume_ul": 1.0, "max_volume_ul": 200.0},
        },
        "devices": {
            "thermocycler": False,
            "plate_reader": True,
        },
    }


def _extract_codes(exc: OrchestrationError) -> list[str]:
    return [diagnostic.code for diagnostic in exc.diagnostics]


def test_setup_schema_invalid_capacity(tmp_path: Path):
    payload = _base_setup_payload()
    payload["labware"] = {"plate_1": {"capacity_ul": -1.0}}
    setup_path = _write_setup(tmp_path, payload)

    with pytest.raises(OrchestrationError) as exc_info:
        run_setup_gate(setup_path)

    assert "SETUP_LABWARE_CONFIG_INVALID" in _extract_codes(exc_info.value)


def test_setup_missing_labware_reference(tmp_path: Path):
    setup_path = _write_setup(tmp_path, _base_setup_payload())
    protocol_path = _write_bpl(
        tmp_path,
        (
            "protocol MissingLabware {\n"
            '  transfer(from: "plate_missing:A1", to: "plate_1:A2", volume: 10 uL)\n'
            "}\n"
        ),
    )

    with pytest.raises(OrchestrationError) as exc_info:
        run_pipeline_for_plan(
            input_path=protocol_path,
            target="human",
            strict=False,
            setup_path=setup_path,
        )

    assert "SETUP_LABWARE_REFERENCE" in _extract_codes(exc_info.value)


def test_setup_source_insufficiency(tmp_path: Path):
    payload = _base_setup_payload()
    payload["initial_volumes"] = {"plate_1:A1": 5.0, "plate_1:A2": 0.0}
    setup_path = _write_setup(tmp_path, payload)
    protocol_path = _write_bpl(
        tmp_path,
        (
            "protocol SourceInsufficient {\n"
            '  transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 10 uL)\n'
            "}\n"
        ),
    )

    with pytest.raises(OrchestrationError) as exc_info:
        run_pipeline_for_plan(
            input_path=protocol_path,
            target="human",
            strict=False,
            setup_path=setup_path,
        )

    assert "SETUP_SOURCE_INSUFFICIENCY" in _extract_codes(exc_info.value)


def test_setup_destination_overflow(tmp_path: Path):
    payload = _base_setup_payload()
    payload["initial_volumes"] = {"plate_1:A1": 100.0, "plate_1:A2": 190.0}
    setup_path = _write_setup(tmp_path, payload)
    protocol_path = _write_bpl(
        tmp_path,
        (
            "protocol DestinationOverflow {\n"
            '  transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 20 uL)\n'
            "}\n"
        ),
    )

    with pytest.raises(OrchestrationError) as exc_info:
        run_pipeline_for_plan(
            input_path=protocol_path,
            target="human",
            strict=False,
            setup_path=setup_path,
        )

    assert "SETUP_DESTINATION_OVERFLOW" in _extract_codes(exc_info.value)


def test_setup_pipette_range_violation(tmp_path: Path):
    payload = _base_setup_payload()
    payload["pipettes"] = {"p20_single": {"min_volume_ul": 1.0, "max_volume_ul": 20.0}}
    setup_path = _write_setup(tmp_path, payload)
    protocol_path = _write_bpl(
        tmp_path,
        (
            "protocol PipetteRange {\n"
            '  transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 50 uL)\n'
            "}\n"
        ),
    )

    with pytest.raises(OrchestrationError) as exc_info:
        run_pipeline_for_plan(
            input_path=protocol_path,
            target="human",
            strict=False,
            setup_path=setup_path,
        )

    assert "SETUP_PIPETTE_RANGE" in _extract_codes(exc_info.value)


def test_setup_device_availability_validation():
    payload = _base_setup_payload()
    setup, diagnostics = parse_experiment_setup(payload)
    assert diagnostics == []
    assert setup is not None

    plan = ExecutionPlan(plan_id="device_plan")
    plan.add_step(
        PlanStep(
            step_id="step_1",
            primitive=SetTemperature(device_id="thermocycler", temperature_c=37.0),
        )
    )
    setup_diagnostics = validate_plan_against_setup(plan, setup)
    assert any(d.code == "SETUP_DEVICE_AVAILABILITY" for d in setup_diagnostics)
