"""CLI tests for workflow graph rendering."""

import json
from pathlib import Path

from bpl.cli.main import (
    EXIT_LOWERING_FAILURE,
    EXIT_SUCCESS,
    main,
)


def test_graph_from_plan_json_output_is_deterministic(
    phase0_cli_input_dir: Path,
    capsys,
):
    plan_path = phase0_cli_input_dir / "minimal_plan.json"

    first_exit = main(["graph", "--input-plan", str(plan_path), "--format", "json"])
    first_output = capsys.readouterr().out

    second_exit = main(["graph", "--input-plan", str(plan_path), "--format", "json"])
    second_output = capsys.readouterr().out

    assert first_exit == EXIT_SUCCESS
    assert second_exit == EXIT_SUCCESS
    assert first_output == second_output

    payload = json.loads(first_output)
    node_ids = [node["id"] for node in payload["nodes"]]
    assert node_ids == ["step_1", "step_2", "step_3"]
    assert payload["edges"] == [
        {"from": "step_1", "to": "step_2"},
        {"from": "step_1", "to": "step_3"},
        {"from": "step_2", "to": "step_3"},
    ]


def test_graph_from_bpl_input_mermaid(phase0_cli_input_dir: Path, capsys):
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"
    exit_code = main(["graph", str(bpl_path), "--format", "mermaid"])
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    assert captured.out.startswith("graph TD")
    assert "call_0001" in captured.out


def test_graph_from_plan_reactflow_html(phase0_cli_input_dir: Path, capsys):
    plan_path = phase0_cli_input_dir / "minimal_plan.json"
    exit_code = main(["graph", "--input-plan", str(plan_path), "--format", "reactflow-html"])
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    output = captured.out.lower()
    assert "<!doctype html>" in output
    assert "reactflow" in output


def test_graph_fails_on_missing_dependency(phase0_cli_input_dir: Path, capsys):
    plan_path = phase0_cli_input_dir / "missing_dependency_plan.json"
    exit_code = main(["graph", "--input-plan", str(plan_path), "--format", "json"])
    captured = capsys.readouterr()

    assert exit_code == EXIT_LOWERING_FAILURE
    assert "GRAPH_MISSING_DEPENDENCY" in captured.err


def test_graph_outputs_match_golden_artifacts(
    phase0_cli_input_dir: Path,
    phase0_cli_golden_dir: Path,
    tmp_path,
    capsys,
):
    plan_path = phase0_cli_input_dir / "minimal_plan.json"

    json_exit = main(["graph", "--input-plan", str(plan_path), "--format", "json"])
    json_output = capsys.readouterr().out
    assert json_exit == EXIT_SUCCESS
    assert json_output == (phase0_cli_golden_dir / "workflow_graph.json").read_text(
        encoding="utf-8"
    )

    mermaid_exit = main(["graph", "--input-plan", str(plan_path), "--format", "mermaid"])
    mermaid_output = capsys.readouterr().out
    assert mermaid_exit == EXIT_SUCCESS
    assert mermaid_output == (phase0_cli_golden_dir / "workflow_graph.mmd").read_text(
        encoding="utf-8"
    )

    out_path = tmp_path / "artifacts" / "workflow_graph.json"
    manifest_exit = main(
        [
            "graph",
            "--input-plan",
            str(plan_path),
            "--format",
            "json",
            "--out",
            str(out_path),
        ]
    )
    manifest_output = capsys.readouterr().out
    assert manifest_exit == EXIT_SUCCESS
    expected_manifest = json.loads(
        (phase0_cli_golden_dir / "manifest_graph.json").read_text(encoding="utf-8")
    )
    expected_manifest["graph"] = str(out_path)
    assert json.loads(manifest_output) == expected_manifest
