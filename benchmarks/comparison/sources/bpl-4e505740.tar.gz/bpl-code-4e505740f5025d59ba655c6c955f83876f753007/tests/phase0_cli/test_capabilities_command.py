"""CLI capability registry tests."""

import json
from pathlib import Path

from bpl.cli.main import EXIT_SUCCESS, main
from bpl.graph import load_execution_plan
from bpl.simulation.simulator import SimulationStatus, simulate


def test_capabilities_command_is_deterministic(capsys):
    first_exit = main(["capabilities", "--target", "simulation"])
    first_output = capsys.readouterr().out
    second_exit = main(["capabilities", "--target", "simulation"])
    second_output = capsys.readouterr().out

    assert first_exit == EXIT_SUCCESS
    assert second_exit == EXIT_SUCCESS
    assert first_output == second_output

    payload = json.loads(first_output)
    assert payload["target"] == "simulation"
    supported = payload["supported_primitives"]
    unsupported = payload["unsupported_primitives"]
    assert supported == sorted(supported)
    assert unsupported == sorted(unsupported)
    assert all(name == name.lower() for name in supported + unsupported)
    assert not set(supported).intersection(set(unsupported))


def test_capability_report_matches_strict_failure_set(
    phase0_cli_input_dir: Path,
    capsys,
):
    plan = load_execution_plan(phase0_cli_input_dir / "all_primitives_plan.json")

    exit_code = main(["capabilities", "--target", "biomek"])
    payload = json.loads(capsys.readouterr().out)
    assert exit_code == EXIT_SUCCESS

    result = simulate(
        plan=plan,
        validate=False,
        strict_capabilities=True,
        capability_target="biomek",
    )

    assert result.status == SimulationStatus.FAILED
    assert sorted(result.unsupported_primitives) == payload["unsupported_primitives"]
