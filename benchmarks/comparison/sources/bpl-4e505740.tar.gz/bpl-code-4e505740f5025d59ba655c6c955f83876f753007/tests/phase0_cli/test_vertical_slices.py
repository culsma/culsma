"""Vertical slice integration tests for implementation milestones."""

from __future__ import annotations

import json
from pathlib import Path
from typing import cast

import pytest

from bpl.cli.main import EXIT_STRICT_CAPABILITY_FAILURE, EXIT_SUCCESS, main
from bpl.orchestrator import run_pipeline_for_plan


def _read_manifest(capsys) -> dict[str, object]:
    output = capsys.readouterr().out
    return json.loads(output)


def _artifact(manifest: dict[str, object], name: str) -> str:
    artifacts = cast(dict[str, object], manifest["artifacts"])
    return str(artifacts[name])


def _write_setup(path: Path) -> Path:
    setup_path = path / "setup.json"
    setup_path.write_text(
        json.dumps(
            {
                "backend": "human",
                "labware": {
                    "plate_1": {"capacity_ul": 200.0},
                },
                "initial_volumes": {
                    "plate_1:A1": 100.0,
                    "plate_1:A2": 100.0,
                    "plate_1:B1": 0.0,
                    "plate_1:B2": 0.0,
                },
                "pipettes": {
                    "p200_single": {"min_volume_ul": 1.0, "max_volume_ul": 200.0},
                },
                "devices": {},
            }
        ),
        encoding="utf-8",
    )
    return setup_path


def test_vs0_minimal_protocol_end_to_end_cli(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.chdir(tmp_path)
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"

    assert main(["check", str(bpl_path)]) == EXIT_SUCCESS
    check_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(check_manifest, "diagnostics")).exists()

    assert main(["parse", str(bpl_path)]) == EXIT_SUCCESS
    parse_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(parse_manifest, "ast")).exists()

    assert main(["lower", str(bpl_path)]) == EXIT_SUCCESS
    lower_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(lower_manifest, "plan")).exists()

    assert main(["validate", str(bpl_path)]) == EXIT_SUCCESS
    validate_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(validate_manifest, "diagnostics")).exists()

    assert main(["simulate", str(bpl_path)]) == EXIT_SUCCESS
    simulate_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(simulate_manifest, "trace")).exists()

    assert main(["export", str(bpl_path), "--format", "csv"]) == EXIT_SUCCESS
    export_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(export_manifest, "worklist")).exists()

    assert main(["compose", str(bpl_path)]) == EXIT_SUCCESS
    compose_manifest = _read_manifest(capsys)
    assert (tmp_path / _artifact(compose_manifest, "markdown")).exists()


def test_vs1_strict_mode_reports_full_unsupported_set(
    phase0_cli_input_dir: Path,
    capsys,
):
    plan_path = phase0_cli_input_dir / "all_primitives_plan.json"

    assert main(["capabilities", "--target", "biomek"]) == EXIT_SUCCESS
    capabilities_payload = json.loads(capsys.readouterr().out)
    unsupported = capabilities_payload["unsupported_primitives"]

    exit_code = main(
        [
            "simulate",
            "--input-plan",
            str(plan_path),
            "--target",
            "biomek",
            "--strict",
            "--json-errors",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_STRICT_CAPABILITY_FAILURE
    error_payload = json.loads(captured.err)
    diagnostic = error_payload["diagnostics"][0]
    assert diagnostic["code"] == "CAPABILITY_UNSUPPORTED_SET"

    marker = "Strict capability failure for target 'biomek': "
    assert diagnostic["message"].startswith(marker)
    reported = diagnostic["message"][len(marker) :].split(", ")
    assert sorted(reported) == unsupported


def test_vs2_collection_lower_bound_with_canonical_well_validation(tmp_path: Path):
    setup_path = _write_setup(tmp_path)
    protocol_path = tmp_path / "collection_transfer.bpl"
    protocol_path.write_text(
        (
            "protocol CollectionCanonical {\n"
            '  transfer(from: ["plate_1:A01", "plate_1:A02"], '
            'to: ["plate_1:B01", "plate_1:B02"], volume: 5 uL)\n'
            "}\n"
        ),
        encoding="utf-8",
    )

    pipeline = run_pipeline_for_plan(
        input_path=protocol_path,
        target="human",
        strict=False,
        setup_path=setup_path,
    )
    assert len(pipeline.plan.steps) == 4
    assert pipeline.plan.steps["step_0003"].dependencies == ["step_0002"]


def test_vs3_graph_rendering_deterministic_from_lowered_plan(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.chdir(tmp_path)
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"
    plan_path = tmp_path / "minimal.plan.json"

    assert main(["lower", str(bpl_path), "--out", str(plan_path)]) == EXIT_SUCCESS
    capsys.readouterr()
    assert plan_path.exists()

    assert main(["graph", "--input-plan", str(plan_path), "--format", "json"]) == EXIT_SUCCESS
    json_graph_first = capsys.readouterr().out
    assert main(["graph", "--input-plan", str(plan_path), "--format", "json"]) == EXIT_SUCCESS
    json_graph_second = capsys.readouterr().out
    assert json_graph_first == json_graph_second

    assert main(["graph", "--input-plan", str(plan_path), "--format", "mermaid"]) == EXIT_SUCCESS
    mermaid_first = capsys.readouterr().out
    assert main(["graph", "--input-plan", str(plan_path), "--format", "mermaid"]) == EXIT_SUCCESS
    mermaid_second = capsys.readouterr().out
    assert mermaid_first == mermaid_second
