"""CLI tests for markdown composition from compiled plans."""

from __future__ import annotations

import json
from pathlib import Path

from bpl.cli.main import EXIT_SUCCESS, EXIT_USAGE_ERROR, main


def test_compose_from_plan_outputs_markdown_manifest(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
):
    plan_path = phase0_cli_input_dir / "minimal_plan.json"
    out_path = tmp_path / "artifacts" / "minimal_protocol.md"

    exit_code = main(
        [
            "compose",
            "--input-plan",
            str(plan_path),
            "--out",
            str(out_path),
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    manifest = json.loads(captured.out)
    assert manifest["command"] == "compose"
    assert manifest["artifacts"]["markdown"] == str(out_path)
    assert manifest["step_count"] == 3
    assert out_path.exists()

    markdown = out_path.read_text(encoding="utf-8")
    assert markdown.startswith("# MinimalProtocol - Execution Protocol")
    assert "## Step Index" in markdown
    assert "`WAIT`" in markdown
    assert "`ASPIRATE`" in markdown
    assert "`DISPENSE`" in markdown


def test_compose_from_bpl_writes_default_artifact(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
    monkeypatch,
):
    monkeypatch.chdir(tmp_path)
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"

    exit_code = main(["compose", str(bpl_path)])
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    manifest = json.loads(captured.out)
    expected_artifact = "artifacts/compose/minimal_protocol.protocol.md"
    assert manifest["artifacts"]["markdown"] == expected_artifact
    artifact_path = tmp_path / expected_artifact
    assert artifact_path.exists()

    markdown = artifact_path.read_text(encoding="utf-8")
    assert markdown.startswith("# MinimalProtocol - Execution Protocol")
    assert "## Primitive Distribution" in markdown
    assert "## Step Index" in markdown


def test_compose_rejects_conflicting_inputs(phase0_cli_input_dir: Path, capsys):
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"
    plan_path = phase0_cli_input_dir / "minimal_plan.json"

    exit_code = main(
        [
            "compose",
            "--input-plan",
            str(plan_path),
            "--input-bpl",
            str(bpl_path),
            "--json-errors",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_USAGE_ERROR
    payload = json.loads(captured.err)
    assert payload["diagnostics"][0]["code"] == "USAGE_COMPOSE_INPUT"


def test_compose_both_targets_from_bpl_outputs_single_markdown(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
):
    bpl_path = phase0_cli_input_dir / "unsupported_primitive.bpl"
    out_path = tmp_path / "artifacts" / "protocol.dual.md"

    exit_code = main(
        [
            "compose",
            "--input-bpl",
            str(bpl_path),
            "--both-targets",
            "--out",
            str(out_path),
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    manifest = json.loads(captured.out)
    assert manifest["command"] == "compose"
    assert manifest["target"] == "dual"
    assert manifest["artifacts"]["markdown"] == str(out_path)
    assert manifest["step_count_by_target"]["human"] >= 1
    assert manifest["step_count_by_target"]["biomek"] >= 1

    markdown = out_path.read_text(encoding="utf-8")
    assert markdown.startswith("# UnsupportedPrimitiveProtocol - Dual Target Execution Protocol")
    assert "## Interleaved Manual + Biomek Execution" in markdown
    assert "<summary>Block 1: Manual Interventions (" in markdown
    assert "Group 1: Manual + Biomek" not in markdown
    assert "## Human Steps" in markdown


def test_compose_both_targets_rejects_plan_input(phase0_cli_input_dir: Path, capsys):
    plan_path = phase0_cli_input_dir / "minimal_plan.json"

    exit_code = main(
        [
            "compose",
            "--input-plan",
            str(plan_path),
            "--both-targets",
            "--json-errors",
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_USAGE_ERROR
    payload = json.loads(captured.err)
    assert payload["diagnostics"][0]["code"] == "USAGE_COMPOSE_DUAL_TARGET"
