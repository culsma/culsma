"""Tests for SOP-to-BPL agentic workflow and CLI command."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Sequence

import pytest
from openpyxl import Workbook

from bpl.agentic import (
    SOPGenerationResult,
    SOPGenerationSettings,
    generate_bpl_from_sop,
)
from bpl.cli.main import EXIT_SEMANTIC_FAILURE, EXIT_SUCCESS, main
from bpl.orchestrator import Diagnostic


class StubGenerator:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)

    def generate_candidate(
        self,
        *,
        attempt: int,
        max_attempts: int,
        previous_bpl: str | None,
        diagnostics: Sequence[Diagnostic],
        sop,
        lab_catalog_context: str,
    ) -> str:
        assert attempt <= max_attempts
        assert sop.normalized_markdown
        assert isinstance(lab_catalog_context, str)
        if not self._responses:
            raise RuntimeError("Stub generator ran out of responses.")
        return self._responses.pop(0)


def _write_sop(path: Path, text: str | None = None) -> Path:
    sop_path = path / "sop.md"
    sop_path.write_text(
        text
        or (
            "# DNA Prep SOP\n\n"
            "1. Transfer sample from A1 to A2.\n"
            "2. Wait for 1 second.\n"
        ),
        encoding="utf-8",
    )
    return sop_path


def _settings(max_attempts: int) -> SOPGenerationSettings:
    return SOPGenerationSettings(
        model="mock-model",
        openrouter_api_key=None,
        max_attempts=max_attempts,
        default_target="human",
        model_retries=1,
        http_max_retries=0,
        http_retry_min_wait=0.0,
        http_retry_max_wait=0.0,
        http_timeout=5.0,
        http_connect_timeout=1.0,
    )


def _write_lab_catalog(path: Path) -> Path:
    workbook = Workbook()
    active_sheet = workbook.active
    if active_sheet is not None:
        workbook.remove(active_sheet)

    reagents = workbook.create_sheet("01_Reagents")
    reagents.append(["试剂ID*", "试剂名称*", "计量单位*", "用途/关键词", "供应商"])
    reagents.append(["reagent_id", "name", "reagent_type", "use_tags", "vendor"])
    reagents.append(["说明", "说明", "说明", "说明", "说明"])
    reagents.append(["R-0001", "Gibson Mix", "kit", "assembly", "NEB"])

    consumables = workbook.create_sheet("02_Consumables")
    consumables.append(["耗材ID*", "耗材名称*", "类别*", "规格/型号", "供应商"])
    consumables.append(["consumable_id", "name", "category", "spec", "vendor"])
    consumables.append(["说明", "说明", "说明", "说明", "说明"])
    consumables.append(["C-0001", "PCR Plate", "plates", "96-well", "A-Gen"])

    equipment = workbook.create_sheet("04_Equipment")
    equipment.append(["设备序号 ID*", "位置*", "设备名称*", "用途/关键词", "设备型号*"])
    equipment.append(["equipment_id", "location", "name", "use_tags", "model"])
    equipment.append(["说明", "说明", "说明", "说明", "说明"])
    equipment.append(["Equip-0001", "Lab-A", "Thermocycler", "PCR amplification", "TC-01"])

    catalog_path = path / "lab_inventory.xlsx"
    workbook.save(catalog_path)
    return catalog_path


def test_sop_workflow_pass_with_first_candidate(tmp_path: Path):
    sop_path = _write_sop(tmp_path)
    _write_lab_catalog(tmp_path)
    generator = StubGenerator(
        [
            (
                "protocol GeneratedFromSOP {\n"
                "  wait(duration: 1 s)\n"
                "}\n"
            )
        ]
    )

    result = generate_bpl_from_sop(
        sop_path=sop_path,
        include_graph=True,
        settings=_settings(max_attempts=3),
        generator=generator,
    )

    assert result.success is True
    assert result.final_bpl is not None
    assert result.final_bpl.startswith("protocol GeneratedFromSOP")
    assert result.graph_artifact is not None
    assert result.diagnostics_history == []
    assert result.generation_metadata["attempts_used"] == 1
    lab_catalog_meta = result.generation_metadata.get("lab_catalog")
    assert isinstance(lab_catalog_meta, dict)
    assert lab_catalog_meta.get("enabled") is True
    assert lab_catalog_meta.get("reagents_total") == 1


def test_sop_workflow_repair_succeeds_after_failed_validation(tmp_path: Path):
    sop_path = _write_sop(tmp_path)
    _write_lab_catalog(tmp_path)
    generator = StubGenerator(
        [
            (
                "protocol RetryProtocol {\n"
                '  transfer(from: "plate_1:A1", to: "plate_1:A2")\n'
                "}\n"
            ),
            (
                "protocol RetryProtocol {\n"
                "  wait(duration: 1 s)\n"
                "}\n"
            ),
        ]
    )

    result = generate_bpl_from_sop(
        sop_path=sop_path,
        settings=_settings(max_attempts=3),
        generator=generator,
    )

    assert result.success is True
    assert result.generation_metadata["attempts_used"] == 2
    assert len(result.diagnostics_history) == 1
    codes = [str(diag["code"]) for diag in result.diagnostics_history[0].diagnostics]
    assert any(code.startswith("SEMANTIC_") for code in codes)
    assert result.final_bpl is not None


def test_sop_workflow_retry_exhausted_returns_failure_diagnostics(tmp_path: Path):
    sop_path = _write_sop(tmp_path)
    _write_lab_catalog(tmp_path)
    invalid_candidate = (
        "protocol ExhaustedProtocol {\n"
        '  transfer(from: "plate_1:A1", to: "plate_1:A2")\n'
        "}\n"
    )
    generator = StubGenerator([invalid_candidate, invalid_candidate])

    result = generate_bpl_from_sop(
        sop_path=sop_path,
        settings=_settings(max_attempts=2),
        generator=generator,
    )

    assert result.success is False
    assert result.final_bpl is None
    assert len(result.diagnostics_history) == 2
    assert result.failure_diagnostics
    assert any(diag.code.startswith("SEMANTIC_") for diag in result.failure_diagnostics)


def test_sop_generate_cli_writes_structured_artifacts(
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    sop_path = _write_sop(tmp_path)
    out_path = tmp_path / "generated_protocol.bpl"
    graph_path = tmp_path / "generated_graph.json"

    fake_result = SOPGenerationResult(
        success=True,
        sop_title="DNA Prep SOP",
        final_bpl="protocol GeneratedFromSOP {\n  wait(duration: 1 s)\n}\n",
        diagnostics_history=[],
        validation_warnings=[],
        generation_metadata={"attempts_used": 1, "max_attempts": 3, "model": "mock-model"},
        graph_artifact='{"edges":[],"metadata":{},"nodes":[]}\n',
    )
    monkeypatch.setattr("bpl.cli.main.generate_bpl_from_sop", lambda **_: fake_result)

    exit_code = main(
        [
            "sop-generate",
            "--sop",
            str(sop_path),
            "--out",
            str(out_path),
            "--graph-out",
            str(graph_path),
        ]
    )
    captured = capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    assert out_path.read_text(encoding="utf-8") == fake_result.final_bpl
    metadata_payload = json.loads(out_path.with_suffix(".metadata.json").read_text("utf-8"))
    assert metadata_payload["validation_passed"] is True
    assert metadata_payload["generation_metadata"]["attempts_used"] == 1
    assert graph_path.read_text(encoding="utf-8") == fake_result.graph_artifact

    manifest = json.loads(captured.out)
    assert manifest["command"] == "sop-generate"
    assert manifest["artifacts"]["bpl"] == str(out_path)
    assert manifest["artifacts"]["metadata"] == str(out_path.with_suffix(".metadata.json"))
    assert manifest["artifacts"]["graph"] == str(graph_path)
    reactflow_path = graph_path.with_suffix(".reactflow.html")
    assert manifest["artifacts"]["graph_reactflow"] == str(reactflow_path)
    reactflow_html = reactflow_path.read_text(encoding="utf-8")
    assert "reactflow" in reactflow_html.lower()
    assert "<!doctype html>" in reactflow_html.lower()


def test_sop_generate_cli_maps_retry_exhaustion_to_semantic_failure(
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    sop_path = _write_sop(tmp_path)
    out_path = tmp_path / "failed_output.bpl"

    fake_result = SOPGenerationResult(
        success=False,
        sop_title="DNA Prep SOP",
        final_bpl=None,
        diagnostics_history=[],
        validation_warnings=[],
        generation_metadata={"attempts_used": 2, "max_attempts": 2, "model": "mock-model"},
        failure_diagnostics=[
            Diagnostic(
                code="SEMANTIC_MISSING_VOLUME",
                severity="error",
                message="`transfer` requires numeric `volume` argument.",
                location=None,
                hint="Example: volume: 10 uL",
            )
        ],
    )
    monkeypatch.setattr("bpl.cli.main.generate_bpl_from_sop", lambda **_: fake_result)

    exit_code = main(["sop-generate", "--sop", str(sop_path), "--out", str(out_path)])
    captured = capsys.readouterr()

    assert exit_code == EXIT_SEMANTIC_FAILURE
    assert "SEMANTIC_MISSING_VOLUME" in captured.err


def test_sop_generate_cli_accepts_lab_catalog_argument(
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    sop_path = _write_sop(tmp_path)
    lab_catalog = _write_lab_catalog(tmp_path)
    out_path = tmp_path / "generated_protocol.bpl"

    fake_result = SOPGenerationResult(
        success=True,
        sop_title="DNA Prep SOP",
        final_bpl="protocol GeneratedFromSOP {\n  wait(duration: 1 s)\n}\n",
        diagnostics_history=[],
        validation_warnings=[],
        generation_metadata={"attempts_used": 1, "max_attempts": 3, "model": "mock-model"},
        graph_artifact=None,
    )

    received: dict[str, object] = {}

    def _fake_generate(**kwargs):
        received.update(kwargs)
        return fake_result

    monkeypatch.setattr("bpl.cli.main.generate_bpl_from_sop", _fake_generate)

    exit_code = main(
        [
            "sop-generate",
            "--sop",
            str(sop_path),
            "--lab-catalog",
            str(lab_catalog),
            "--out",
            str(out_path),
        ]
    )
    capsys.readouterr()

    assert exit_code == EXIT_SUCCESS
    assert received["lab_catalog_path"] == lab_catalog
