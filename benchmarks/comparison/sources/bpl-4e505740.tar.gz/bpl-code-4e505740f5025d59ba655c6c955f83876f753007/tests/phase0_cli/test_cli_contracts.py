"""CLI contract tests for orchestrator-backed commands."""

import json
from pathlib import Path
from typing import Any, cast

import pytest

from bpl.cli.main import (
    EXIT_INTERNAL_ERROR,
    EXIT_LOWERING_FAILURE,
    EXIT_PARSE_FAILURE,
    EXIT_SEMANTIC_FAILURE,
    EXIT_SIMULATION_FAILURE,
    EXIT_STRICT_CAPABILITY_FAILURE,
    EXIT_SUCCESS,
    EXIT_USAGE_ERROR,
    main,
)


def _json_payloads(stderr_text: str) -> list[dict[str, Any]]:
    return [
        cast(dict[str, Any], json.loads(line))
        for line in stderr_text.splitlines()
        if line.strip()
    ]


def _first_diag_code(stderr_text: str) -> str:
    payloads = _json_payloads(stderr_text)
    return str(payloads[-1]["diagnostics"][0]["code"])


def test_lower_manifest_is_deterministic(
    phase0_cli_input_dir: Path,
    tmp_path: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.chdir(tmp_path)
    bpl_path = phase0_cli_input_dir / "minimal_protocol.bpl"

    first_exit = main(["lower", str(bpl_path)])
    first = capsys.readouterr().out

    second_exit = main(["lower", str(bpl_path)])
    second = capsys.readouterr().out

    assert first_exit == EXIT_SUCCESS
    assert second_exit == EXIT_SUCCESS
    assert first == second

    payload = json.loads(first)
    assert payload["artifacts"]["plan"] == "artifacts/lower/minimal_protocol.plan.json"
    assert (tmp_path / payload["artifacts"]["plan"]).exists()


def test_json_errors_schema_and_stream_split(phase0_cli_input_dir: Path, capsys):
    invalid = phase0_cli_input_dir / "invalid_syntax.bpl"
    exit_code = main(["check", str(invalid), "--json-errors"])
    captured = capsys.readouterr()

    assert exit_code == EXIT_PARSE_FAILURE
    assert captured.out == ""

    payload = json.loads(captured.err)
    diagnostic = payload["diagnostics"][0]
    assert set(diagnostic.keys()) == {"code", "hint", "location", "message", "severity"}
    assert diagnostic["severity"] == "error"
    assert isinstance(diagnostic["hint"], str)
    assert "expected" in diagnostic["hint"].lower()
    location = diagnostic["location"]
    assert set(location.keys()) == {"end", "file", "start"}
    assert set(location["start"].keys()) == {"col", "line", "offset"}
    assert set(location["end"].keys()) == {"col", "line", "offset"}


@pytest.mark.parametrize(
    ("argv", "expected"),
    [
        (["check", "minimal_protocol.bpl"], EXIT_SUCCESS),
        (["simulate"], EXIT_USAGE_ERROR),
        (["check", "invalid_syntax.bpl"], EXIT_PARSE_FAILURE),
        (["check", "invalid_volume.bpl"], EXIT_SEMANTIC_FAILURE),
        (["lower", "empty_protocol.bpl"], EXIT_LOWERING_FAILURE),
        (["simulate", "overflow_runtime.bpl"], EXIT_SIMULATION_FAILURE),
        (
            ["lower", "unsupported_primitive.bpl", "--target", "biomek", "--strict"],
            EXIT_STRICT_CAPABILITY_FAILURE,
        ),
    ],
)
def test_exit_code_map(
    argv: list[str],
    expected: int,
    phase0_cli_input_dir: Path,
    capsys,
):
    resolved = [str(phase0_cli_input_dir / arg) if arg.endswith(".bpl") else arg for arg in argv]
    exit_code = main(resolved)
    capsys.readouterr()
    assert exit_code == expected


def test_phase_scoped_diagnostic_namespaces(phase0_cli_input_dir: Path, capsys):
    missing_setup = phase0_cli_input_dir / "missing_setup.json"

    syntax_exit = main(
        ["check", str(phase0_cli_input_dir / "invalid_syntax.bpl"), "--json-errors"]
    )
    syntax_code = _first_diag_code(capsys.readouterr().err)
    assert syntax_exit == EXIT_PARSE_FAILURE
    assert syntax_code.startswith("SYNTAX_")

    semantic_exit = main(
        ["check", str(phase0_cli_input_dir / "invalid_volume.bpl"), "--json-errors"]
    )
    semantic_code = _first_diag_code(capsys.readouterr().err)
    assert semantic_exit == EXIT_SEMANTIC_FAILURE
    assert semantic_code.startswith("SEMANTIC_")

    plan_exit = main(
        ["lower", str(phase0_cli_input_dir / "empty_protocol.bpl"), "--json-errors"]
    )
    plan_code = _first_diag_code(capsys.readouterr().err)
    assert plan_exit == EXIT_LOWERING_FAILURE
    assert plan_code.startswith("PLAN_")

    setup_exit = main(
        [
            "validate",
            str(phase0_cli_input_dir / "minimal_protocol.bpl"),
            "--setup",
            str(missing_setup),
            "--json-errors",
        ]
    )
    setup_code = _first_diag_code(capsys.readouterr().err)
    assert setup_exit == EXIT_SEMANTIC_FAILURE
    assert setup_code.startswith("SETUP_")


def test_gate_order_short_circuits_at_semantic_before_setup(
    phase0_cli_input_dir: Path,
    capsys,
):
    missing_setup = phase0_cli_input_dir / "missing_setup.json"
    exit_code = main(
        [
            "validate",
            str(phase0_cli_input_dir / "invalid_volume.bpl"),
            "--setup",
            str(missing_setup),
            "--json-errors",
        ]
    )
    code = _first_diag_code(capsys.readouterr().err)

    assert exit_code == EXIT_SEMANTIC_FAILURE
    assert code.startswith("SEMANTIC_")


def test_internal_error_maps_to_99(
    phase0_cli_input_dir: Path,
    capsys,
    monkeypatch: pytest.MonkeyPatch,
):
    def _boom(_plan):
        raise RuntimeError("boom")

    monkeypatch.setattr("bpl.cli.main._plan_to_worklist_rows", _boom)
    exit_code = main(
        [
            "export",
            str(phase0_cli_input_dir / "minimal_plan.json"),
            "--json-errors",
        ]
    )
    code = _first_diag_code(capsys.readouterr().err)

    assert exit_code == EXIT_INTERNAL_ERROR
    assert code == "INTERNAL_UNHANDLED_ERROR"
