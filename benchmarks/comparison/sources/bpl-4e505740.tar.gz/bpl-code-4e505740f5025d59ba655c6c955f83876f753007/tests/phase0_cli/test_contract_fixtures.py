"""Contract fixture baselines for phase0 CLI tests."""

import json
from pathlib import Path

from bpl.graph import load_execution_plan
from bpl.parser import parse_file


def test_reusable_input_fixtures_parse_and_load(phase0_cli_input_dir: Path):
    for name in (
        "minimal_protocol.bpl",
        "collection_transfer.bpl",
        "unsupported_primitive.bpl",
        "invalid_volume.bpl",
    ):
        parsed = parse_file(phase0_cli_input_dir / name)
        assert parsed.declarations

    setup_payload = json.loads((phase0_cli_input_dir / "invalid_setup.json").read_text("utf-8"))
    assert "labware" in setup_payload
    assert "pipettes" in setup_payload

    plan = load_execution_plan(phase0_cli_input_dir / "minimal_plan.json")
    assert plan.plan_id == "fixture_minimal_plan"
    assert len(plan.steps) == 3

    all_primitives_plan = load_execution_plan(phase0_cli_input_dir / "all_primitives_plan.json")
    assert all_primitives_plan.plan_id == "fixture_all_primitives"


def test_golden_artifact_fixtures_are_well_formed(phase0_cli_golden_dir: Path):
    manifest = json.loads((phase0_cli_golden_dir / "manifest_graph.json").read_text("utf-8"))
    assert set(manifest.keys()) == {"format", "graph"}

    plan_payload = json.loads((phase0_cli_golden_dir / "plan.json").read_text("utf-8"))
    assert "plan_id" in plan_payload
    assert "steps" in plan_payload

    diagnostics_payload = json.loads(
        (phase0_cli_golden_dir / "diagnostics.json").read_text("utf-8")
    )
    assert diagnostics_payload["diagnostics"][0]["code"] == "GRAPH_MISSING_DEPENDENCY"

    trace_summary = json.loads(
        (phase0_cli_golden_dir / "simulation_trace_summary.json").read_text("utf-8")
    )
    assert "steps_executed" in trace_summary

    graph_payload = json.loads((phase0_cli_golden_dir / "workflow_graph.json").read_text("utf-8"))
    assert "nodes" in graph_payload and "edges" in graph_payload

    mermaid_text = (phase0_cli_golden_dir / "workflow_graph.mmd").read_text("utf-8")
    assert mermaid_text.startswith("graph TD")
