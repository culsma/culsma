"""
Tests for BPL volume constraints.
"""

from bpl.export import VolumeConstraints, VolumeTracker


class TestVolumeConstraints:
    """Test VolumeConstraints class."""

    def test_default_constraints(self):
        """Test default constraint values."""
        constraints = VolumeConstraints()
        assert constraints.minimum_volume_ul == 20.0
        assert constraints.tip_residual_coefficient == 0.2
        assert constraints.max_volume_per_well_ul == 160.0

    def test_custom_constraints(self):
        """Test custom constraint values."""
        constraints = VolumeConstraints(
            minimum_volume_ul=10.0,
            tip_residual_coefficient=0.1,
            max_volume_per_well_ul=300.0,
        )
        assert constraints.minimum_volume_ul == 10.0
        assert constraints.tip_residual_coefficient == 0.1
        assert constraints.max_volume_per_well_ul == 300.0

    def test_dead_volume(self):
        """Test dead volume calculation."""
        constraints = VolumeConstraints(minimum_volume_ul=20.0)
        assert constraints.dead_volume_ul == 20.0

    def test_required_source_volume(self):
        """Test required source volume calculation."""
        constraints = VolumeConstraints(
            minimum_volume_ul=20.0,
            tip_residual_coefficient=0.2,
        )
        # Required = dead_volume + (1 + residual) * transfer
        # = 20 + 1.2 * 100 = 20 + 120 = 140
        required = constraints.required_source_volume(100.0)
        assert required == 140.0

    def test_validate_transfer_success(self):
        """Test successful transfer validation."""
        constraints = VolumeConstraints()
        is_valid, error = constraints.validate_transfer(
            transfer_volume_ul=50.0,
            source_volume_ul=200.0,
            dest_current_volume_ul=0.0,
        )
        assert is_valid
        assert error is None

    def test_validate_transfer_below_minimum(self):
        """Test transfer below minimum volume."""
        constraints = VolumeConstraints(minimum_volume_ul=20.0)
        is_valid, error = constraints.validate_transfer(
            transfer_volume_ul=10.0,  # Below minimum
            source_volume_ul=200.0,
            dest_current_volume_ul=0.0,
        )
        assert not is_valid
        assert "below minimum" in error

    def test_validate_transfer_insufficient_source(self):
        """Test transfer with insufficient source volume."""
        constraints = VolumeConstraints()
        is_valid, error = constraints.validate_transfer(
            transfer_volume_ul=50.0,
            source_volume_ul=30.0,  # Not enough
            dest_current_volume_ul=0.0,
        )
        assert not is_valid
        assert "insufficient" in error

    def test_validate_transfer_destination_overflow(self):
        """Test transfer that would overflow destination."""
        constraints = VolumeConstraints(max_volume_per_well_ul=100.0)
        is_valid, error = constraints.validate_transfer(
            transfer_volume_ul=60.0,
            source_volume_ul=200.0,
            dest_current_volume_ul=50.0,  # 50 + 60 = 110 > 100
        )
        assert not is_valid
        assert "overflow" in error


class TestVolumeTracker:
    """Test VolumeTracker class."""

    def test_create_tracker(self):
        """Test creating volume tracker."""
        tracker = VolumeTracker()
        assert tracker.constraints is not None

    def test_create_tracker_with_constraints(self):
        """Test creating tracker with custom constraints."""
        constraints = VolumeConstraints(minimum_volume_ul=10.0)
        tracker = VolumeTracker(constraints)
        assert tracker.constraints.minimum_volume_ul == 10.0

    def test_set_initial_volume(self):
        """Test setting initial volume."""
        tracker = VolumeTracker()
        tracker.set_initial_volume("container1", 500.0)
        assert tracker.get_available_volume("container1") > 0

    def test_get_available_volume(self):
        """Test getting available volume."""
        constraints = VolumeConstraints(minimum_volume_ul=20.0)
        tracker = VolumeTracker(constraints)
        tracker.set_initial_volume("container1", 100.0)

        # Available = initial - used - dead_volume
        # = 100 - 0 - 20 = 80
        assert tracker.get_available_volume("container1") == 80.0

    def test_get_available_volume_unknown_container(self):
        """Test getting available volume for unknown container."""
        tracker = VolumeTracker()
        assert tracker.get_available_volume("unknown") == 0.0

    def test_can_transfer_success(self):
        """Test successful transfer check."""
        tracker = VolumeTracker()
        tracker.set_initial_volume("source", 500.0)
        tracker.set_initial_volume("dest", 0.0)

        is_valid, error = tracker.can_transfer("source", "dest", 50.0)
        assert is_valid
        assert error is None

    def test_can_transfer_insufficient(self):
        """Test transfer check with insufficient volume."""
        tracker = VolumeTracker()
        tracker.set_initial_volume("source", 30.0)
        tracker.set_initial_volume("dest", 0.0)

        is_valid, error = tracker.can_transfer("source", "dest", 50.0)
        assert not is_valid
        assert error is not None

    def test_record_transfer(self):
        """Test recording transfer."""
        constraints = VolumeConstraints(
            minimum_volume_ul=20.0,
            tip_residual_coefficient=0.2,
        )
        tracker = VolumeTracker(constraints)
        tracker.set_initial_volume("source", 500.0)
        tracker.set_initial_volume("dest", 0.0)

        # Initial available = 500 - 20 = 480
        initial_available = tracker.get_available_volume("source")

        # Record transfer of 100 uL
        tracker.record_transfer("source", "dest", 100.0)

        # Source should have less available
        # Used = 100 * 1.2 = 120
        # New available = 500 - 120 - 20 = 360
        new_available = tracker.get_available_volume("source")
        assert new_available < initial_available
        assert new_available == 360.0

    def test_reset(self):
        """Test resetting tracker."""
        tracker = VolumeTracker()
        tracker.set_initial_volume("container", 500.0)
        tracker.record_transfer("container", "other", 50.0)

        tracker.reset()

        assert tracker.get_available_volume("container") == 0.0

    def test_get_summary(self):
        """Test getting volume summary."""
        tracker = VolumeTracker()
        tracker.set_initial_volume("source", 500.0)
        tracker.set_initial_volume("dest", 0.0)
        tracker.record_transfer("source", "dest", 100.0)

        summary = tracker.get_summary()

        assert "source" in summary
        assert "dest" in summary
        assert summary["source"]["initial_ul"] == 500.0
        assert summary["source"]["used_ul"] > 0
        assert summary["dest"]["initial_ul"] == 100.0  # After transfer
