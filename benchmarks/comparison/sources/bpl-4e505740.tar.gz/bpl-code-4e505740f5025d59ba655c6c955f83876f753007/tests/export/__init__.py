"""Tests for BPL export module."""
