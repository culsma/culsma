"""
Tests for BPL worklist exporter.
"""

import pytest
from bpl.export import (
    TransferMode,
    WorklistExporter,
    WorklistConfig,
    WorklistFormat,
    VolumeConstraints,
    WellRef,
    WorklistRow,
    WorklistError,
)


class TestTransferMode:
    """Test TransferMode enum."""

    def test_transfer_mode_values(self):
        """Test transfer mode enum values."""
        assert TransferMode.ONE_TO_ONE is not None
        assert TransferMode.ONE_TO_MANY is not None
        assert TransferMode.MANY_TO_ONE is not None

    def test_from_string(self):
        """Test parsing transfer mode from string."""
        assert TransferMode.from_string("ONE_TO_ONE") == TransferMode.ONE_TO_ONE
        assert TransferMode.from_string("one_to_many") == TransferMode.ONE_TO_MANY
        assert TransferMode.from_string("MANY-TO-ONE") == TransferMode.MANY_TO_ONE

    def test_from_string_invalid(self):
        """Test invalid transfer mode string."""
        with pytest.raises(ValueError) as exc_info:
            TransferMode.from_string("INVALID")
        assert "Invalid transfer mode" in str(exc_info.value)

    def test_description(self):
        """Test transfer mode descriptions."""
        assert "paired" in TransferMode.ONE_TO_ONE.description
        assert "broadcast" in TransferMode.ONE_TO_MANY.description
        assert "pool" in TransferMode.MANY_TO_ONE.description


class TestWorklistExporter:
    """Test WorklistExporter class."""

    def test_create_exporter(self):
        """Test creating exporter with default config."""
        exporter = WorklistExporter()
        assert exporter.config.format == WorklistFormat.CSV

    def test_create_exporter_with_config(self):
        """Test creating exporter with custom config."""
        config = WorklistConfig(format=WorklistFormat.EXCEL)
        exporter = WorklistExporter(config)
        assert exporter.config.format == WorklistFormat.EXCEL

    def test_register_labware(self):
        """Test registering labware metadata."""
        exporter = WorklistExporter()
        exporter.register_labware("plate1", barcode="BC001", set_identifier="Set1")

        assert exporter.get_plate_barcode("plate1") == "BC001"
        assert exporter.get_set_identifier("plate1") == "Set1"

    def test_get_plate_barcode_fallback(self):
        """Test barcode fallback to plate_id."""
        exporter = WorklistExporter()
        assert exporter.get_plate_barcode("unregistered_plate") == "unregistered_plate"

    def test_get_set_identifier_unregistered(self):
        """Test set_identifier for unregistered plate."""
        exporter = WorklistExporter()
        assert exporter.get_set_identifier("unregistered_plate") is None

    def test_export_well_ref_normalization_and_canonical_adapter(self):
        """WellRef normalizes zero-padded wells and round-trips with canonical DTO."""
        ref = WellRef("plate1", "a01")
        assert ref.well == "A1"

        canonical = ref.to_canonical(plate_format="plate_96")
        assert canonical.labware_id == "plate1"
        assert canonical.well == "A1"
        assert canonical.row == 0
        assert canonical.col == 0

        roundtrip = WellRef.from_canonical(canonical)
        assert roundtrip == WellRef("plate1", "A1")


class TestExportWithMode:
    """Test export_with_mode method."""

    def test_one_to_one(self):
        """Test ONE_TO_ONE transfer mode."""
        exporter = WorklistExporter()
        sources = [WellRef("plate1", "A1"), WellRef("plate1", "A2")]
        destinations = [WellRef("plate2", "B1"), WellRef("plate2", "B2")]

        rows = exporter.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=50.0,
            mode=TransferMode.ONE_TO_ONE,
        )

        assert len(rows) == 2
        assert rows[0].source_well == "A1"
        assert rows[0].destination_well == "B1"
        assert rows[1].source_well == "A2"
        assert rows[1].destination_well == "B2"
        assert all(r.transfer_volume_ul == 50.0 for r in rows)

    def test_one_to_one_mismatched_counts(self):
        """Test ONE_TO_ONE with mismatched counts raises error."""
        exporter = WorklistExporter()
        sources = [WellRef("plate1", "A1")]
        destinations = [WellRef("plate2", "B1"), WellRef("plate2", "B2")]

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=sources,
                destinations=destinations,
                volume_ul=50.0,
                mode=TransferMode.ONE_TO_ONE,
            )
        assert "equal source/dest counts" in str(exc_info.value)

    def test_one_to_many(self):
        """Test ONE_TO_MANY transfer mode."""
        exporter = WorklistExporter()
        sources = [WellRef("plate1", "A1")]
        destinations = [
            WellRef("plate2", "A1"),
            WellRef("plate2", "A2"),
            WellRef("plate2", "A3"),
        ]

        rows = exporter.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=25.0,
            mode=TransferMode.ONE_TO_MANY,
        )

        assert len(rows) == 3
        assert all(r.source_well == "A1" for r in rows)
        assert rows[0].destination_well == "A1"
        assert rows[1].destination_well == "A2"
        assert rows[2].destination_well == "A3"

    def test_one_to_many_multiple_sources_error(self):
        """Test ONE_TO_MANY with multiple sources raises error."""
        exporter = WorklistExporter()
        sources = [WellRef("plate1", "A1"), WellRef("plate1", "A2")]
        destinations = [WellRef("plate2", "B1")]

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=sources,
                destinations=destinations,
                volume_ul=50.0,
                mode=TransferMode.ONE_TO_MANY,
            )
        assert "exactly 1 source" in str(exc_info.value)

    def test_many_to_one(self):
        """Test MANY_TO_ONE transfer mode."""
        exporter = WorklistExporter()
        sources = [
            WellRef("plate1", "A1"),
            WellRef("plate1", "A2"),
            WellRef("plate1", "A3"),
        ]
        destinations = [WellRef("plate2", "H12")]

        rows = exporter.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=10.0,
            mode=TransferMode.MANY_TO_ONE,
        )

        assert len(rows) == 3
        assert all(r.destination_well == "H12" for r in rows)
        assert rows[0].source_well == "A1"
        assert rows[1].source_well == "A2"
        assert rows[2].source_well == "A3"

    def test_many_to_one_multiple_destinations_error(self):
        """Test MANY_TO_ONE with multiple destinations raises error."""
        exporter = WorklistExporter()
        sources = [WellRef("plate1", "A1")]
        destinations = [WellRef("plate2", "B1"), WellRef("plate2", "B2")]

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=sources,
                destinations=destinations,
                volume_ul=50.0,
                mode=TransferMode.MANY_TO_ONE,
            )
        assert "exactly 1 destination" in str(exc_info.value)

    def test_export_rejects_non_positive_volume(self):
        """Test export rejects non-positive transfer volume."""
        exporter = WorklistExporter()

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=[WellRef("plate1", "A1")],
                destinations=[WellRef("plate2", "A1")],
                volume_ul=0.0,
                mode=TransferMode.ONE_TO_ONE,
            )
        assert "must be positive" in str(exc_info.value)

    def test_export_applies_volume_constraints(self):
        """Test export validates volume constraints when configured."""
        config = WorklistConfig(
            volume_constraints=VolumeConstraints(minimum_volume_ul=20.0),
        )
        exporter = WorklistExporter(config)

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=[WellRef("plate1", "A1")],
                destinations=[WellRef("plate2", "A1")],
                volume_ul=10.0,
                mode=TransferMode.ONE_TO_ONE,
            )
        assert "volume validation failed" in str(exc_info.value)

    def test_export_applies_destination_overflow_constraints(self):
        """Test export rejects cumulative destination overflow."""
        config = WorklistConfig(
            volume_constraints=VolumeConstraints(
                minimum_volume_ul=1.0,
                max_volume_per_well_ul=100.0,
            ),
        )
        exporter = WorklistExporter(config)

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=[WellRef("plate1", "A1"), WellRef("plate1", "A2")],
                destinations=[WellRef("plate2", "A1"), WellRef("plate2", "A1")],
                volume_ul=60.0,
                mode=TransferMode.ONE_TO_ONE,
            )
        assert "overflow" in str(exc_info.value)

    def test_export_applies_configured_source_volumes(self):
        """Test export rejects transfer when configured source volume is insufficient."""
        config = WorklistConfig(
            volume_constraints=VolumeConstraints(minimum_volume_ul=20.0),
            initial_volumes_ul={"plate1:A1": 50.0, "plate2:A1": 0.0},
        )
        exporter = WorklistExporter(config)

        with pytest.raises(WorklistError) as exc_info:
            exporter.export_with_mode(
                sources=[WellRef("plate1", "A1")],
                destinations=[WellRef("plate2", "A1")],
                volume_ul=40.0,
                mode=TransferMode.ONE_TO_ONE,
            )
        assert "insufficient" in str(exc_info.value)


class TestExportStamp:
    """Test stamp export."""

    def test_stamp_basic(self):
        """Test basic stamp export."""
        exporter = WorklistExporter()
        result = exporter.export_stamp(
            source_plate="source_plate",
            dest_plate="dest_plate",
            volume_ul=10.0,
        )

        assert result.success
        assert result.row_count == 1
        assert "source_plate" in result.content
        assert "dest_plate" in result.content
        assert "10.0" in result.content or "10" in result.content

    def test_stamp_with_barcode(self):
        """Test stamp export uses registered barcodes."""
        exporter = WorklistExporter()
        exporter.register_labware("src", barcode="SRC001")
        exporter.register_labware("dst", barcode="DST001")

        result = exporter.export_stamp(
            source_plate="src",
            dest_plate="dst",
            volume_ul=10.0,
        )

        assert "SRC001" in result.content
        assert "DST001" in result.content

    def test_stamp_with_set_identifier(self):
        """Test stamp export includes set_identifier."""
        exporter = WorklistExporter()
        result = exporter.export_stamp(
            source_plate="source",
            dest_plate="dest",
            volume_ul=10.0,
            set_identifier="BatchA",
        )

        assert "BatchA" in result.content


class TestExportCherrypick:
    """Test cherrypick export."""

    def test_cherrypick_basic(self):
        """Test basic cherrypick export."""
        exporter = WorklistExporter()
        result = exporter.export_cherrypick(
            source_plate="template",
            source_wells=["A1", "B3", "C5"],
            dest_plate="pcr_plate",
            dest_wells=["A1", "A2", "A3"],
            volume_ul=2.0,
        )

        assert result.success
        assert result.row_count == 3
        assert "A1" in result.content
        assert "B3" in result.content
        assert "C5" in result.content

    def test_cherrypick_csv_format(self):
        """Test cherrypick CSV format."""
        exporter = WorklistExporter()
        result = exporter.export_cherrypick(
            source_plate="src",
            source_wells=["A1", "A2"],
            dest_plate="dst",
            dest_wells=["B1", "B2"],
            volume_ul=5.0,
        )

        lines = result.content.strip().split("\n")
        assert len(lines) == 3  # header + 2 data rows

        # Check header
        header = lines[0]
        assert "source_plate" in header
        assert "source_well" in header
        assert "destination_plate" in header
        assert "destination_well" in header
        assert "transfer_volume_uL" in header


class TestExportSerialDilution:
    """Test serial dilution export."""

    def test_serial_dilution_basic(self):
        """Test basic serial dilution export."""
        exporter = WorklistExporter()
        results = exporter.export_serial_dilution(
            source_plate="growth",
            dest_plates=["dilution1", "dilution2", "dilution3"],
            volume_ul=20.0,
            well_count=96,
        )

        assert len(results) == 3
        assert all(r.success for r in results)

        # Each step should have 96 rows (one per well)
        assert results[0].row_count == 96
        assert results[1].row_count == 96
        assert results[2].row_count == 96

    def test_serial_dilution_chaining(self):
        """Test serial dilution chains correctly."""
        exporter = WorklistExporter()
        results = exporter.export_serial_dilution(
            source_plate="source",
            dest_plates=["d1", "d2"],
            volume_ul=10.0,
            well_count=96,
        )

        # First step: source → d1
        assert "source" in results[0].content
        assert "d1" in results[0].content

        # Second step: d1 → d2
        assert "d1" in results[1].content
        assert "d2" in results[1].content


class TestExportDistribute:
    """Test distribute export."""

    def test_distribute_basic(self):
        """Test basic distribute export."""
        exporter = WorklistExporter()
        result = exporter.export_distribute(
            source_plate="reservoir",
            source_well="A1",
            dest_plate="pcr_plate",
            dest_wells=["A1", "A2", "A3", "A4"],
            volume_ul=15.0,
        )

        assert result.success
        assert result.row_count == 4

        # All rows should have same source well
        lines = result.content.strip().split("\n")[1:]  # skip header
        for line in lines:
            assert "A1" in line.split(",")[1]  # source_well column


class TestExportPool:
    """Test pool export."""

    def test_pool_basic(self):
        """Test basic pool export."""
        exporter = WorklistExporter()
        result = exporter.export_pool(
            source_plate="samples",
            source_wells=["A1", "A2", "A3", "A4"],
            dest_plate="pool_plate",
            dest_well="H12",
            volume_ul=10.0,
        )

        assert result.success
        assert result.row_count == 4

        # All rows should have same destination well
        lines = result.content.strip().split("\n")[1:]  # skip header
        for line in lines:
            assert "H12" in line


class TestWorklistRow:
    """Test WorklistRow dataclass."""

    def test_to_dict(self):
        """Test conversion to dictionary."""
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
            set_identifier="Set1",
        )

        d = row.to_dict()
        assert d["source_plate"] == "src"
        assert d["source_well"] == "A1"
        assert d["destination_plate"] == "dst"
        assert d["destination_well"] == "B1"
        assert d["transfer_volume_uL"] == 50.0
        assert d["set_identifier"] == "Set1"

    def test_to_dict_without_set_id(self):
        """Test conversion without set_identifier."""
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
        )

        d = row.to_dict(include_set_id=False)
        assert "set_identifier" not in d
