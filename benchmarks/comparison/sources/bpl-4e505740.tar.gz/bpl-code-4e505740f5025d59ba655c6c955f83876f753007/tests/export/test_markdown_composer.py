"""Tests for compiled-plan markdown composition."""

from __future__ import annotations

import pytest

from bpl.export import compose_dual_target_markdown, compose_plan_payload_markdown


def test_compose_plan_payload_markdown_with_primitive_details():
    payload = {
        "plan_id": "test_plan",
        "protocol_name": "ComposedProtocol",
        "target": "human",
        "steps": [
            {
                "step_id": "step_0001",
                "primitive_type": "ASPIRATE",
                "dependencies": [],
                "source_intent": "transfer",
                "primitive": {
                    "__type__": "Aspirate",
                    "source": {
                        "__type__": "WellRef",
                        "plate_id": "source_plate",
                        "well_id": "A1",
                    },
                    "volume_ul": 10.0,
                },
            },
            {
                "step_id": "step_0002",
                "primitive_type": "DISPENSE",
                "dependencies": ["step_0001"],
                "source_intent": "transfer",
                "primitive": {
                    "__type__": "Dispense",
                    "destination": {
                        "__type__": "WellRef",
                        "plate_id": "dest_plate",
                        "well_id": "B1",
                    },
                    "volume_ul": 10.0,
                },
            },
        ],
    }

    markdown = compose_plan_payload_markdown(payload)

    assert markdown.startswith("# ComposedProtocol - Execution Protocol")
    assert "| Plan ID | `test_plan` |" in markdown
    assert "| Total Steps | 2 |" in markdown
    assert "## Step Index" in markdown
    assert "Aspirate 10 uL from source_plate:A1" in markdown
    assert "Dispense 10 uL into dest_plate:B1" in markdown
    assert "`step_0002`" in markdown
    assert "## Plate Map View" in markdown
    assert "| Source Plate | Destination Plate | Transfer Count | Total Volume (uL) |" in markdown
    assert "`source_plate`" in markdown
    assert "`dest_plate`" in markdown


def test_compose_plan_payload_markdown_falls_back_to_intent_without_primitive():
    payload = {
        "plan_id": "minimal",
        "protocol_name": "MinimalProtocol",
        "target": "human",
        "steps": [
            {
                "step_id": "step_1",
                "primitive_type": "WAIT",
                "dependencies": [],
                "source_intent": "wait",
            },
        ],
    }

    markdown = compose_plan_payload_markdown(payload)

    assert "Execute 'wait'" in markdown
    assert "`WAIT`" in markdown
    assert "| # | Step ID | Primitive | Intent | Action | Source | Destination | Volume | Depends On |" in markdown
    assert "## Plate Map View" not in markdown


def test_compose_plan_payload_markdown_rejects_invalid_steps_shape():
    with pytest.raises(ValueError, match="steps"):
        compose_plan_payload_markdown(
            {
                "plan_id": "invalid",
                "protocol_name": "InvalidProtocol",
                "target": "human",
                "steps": "not-a-list",
            }
        )


def test_compose_plan_payload_markdown_segregates_biomek_manual_interventions():
    payload = {
        "plan_id": "biomek_plan",
        "protocol_name": "BiomekProtocol",
        "target": "biomek",
        "steps": [
            {
                "step_id": "step_0001__manual_checkpoint",
                "primitive_type": "CHECKPOINT",
                "dependencies": [],
                "source_intent": "vortex",
                "annotations": {
                    "manual_intervention": {
                        "instruction": "Vortex sample tube for 30 s",
                        "original_primitive": "HUMAN_STEP",
                        "original_step_id": "step_0001",
                    }
                },
                "primitive": {
                    "__type__": "Checkpoint",
                    "checkpoint_id": "manual_step_0001",
                },
            },
            {
                "step_id": "step_0001__manual_pause",
                "primitive_type": "PAUSE",
                "dependencies": ["step_0001__manual_checkpoint"],
                "source_intent": "vortex",
                "annotations": {
                    "manual_intervention": {
                        "instruction": "Vortex sample tube for 30 s",
                        "original_primitive": "HUMAN_STEP",
                        "original_step_id": "step_0001",
                    }
                },
                "primitive": {
                    "__type__": "Pause",
                    "reason": "Manual intervention required for step_0001: Vortex sample tube for 30 s",
                },
            },
            {
                "step_id": "step_0002",
                "primitive_type": "ASPIRATE",
                "dependencies": ["step_0001__manual_pause"],
                "source_intent": "transfer",
                "primitive": {
                    "__type__": "Aspirate",
                    "source": {
                        "__type__": "WellRef",
                        "plate_id": "source_plate",
                        "well_id": "A1",
                    },
                    "volume_ul": 10.0,
                },
            },
        ],
    }

    markdown = compose_plan_payload_markdown(payload)

    assert "## Interleaved Manual + Biomek Execution" in markdown
    assert "<summary>Block 1: Manual Interventions (1 item(s))</summary>" in markdown
    assert "<summary>Block 2: Biomek Automated Steps (1 step(s))</summary>" in markdown
    assert "Group 1: Manual + Biomek" not in markdown
    assert "Vortex sample tube for 30 s." in markdown
    assert "`step_0002`" in markdown
    assert "`ASPIRATE`" in markdown
    # Checkpoint/pause pair should be merged into one manual group.
    assert markdown.count("`step_0001` (`HUMAN_STEP`)") == 1


def test_compose_dual_target_markdown_contains_both_targets_and_manual_section():
    human_payload = {
        "plan_id": "human_plan",
        "protocol_name": "DualProtocol",
        "target": "human",
        "steps": [
            {
                "step_id": "step_0001",
                "primitive_type": "HUMAN_STEP",
                "dependencies": [],
                "source_intent": "vortex",
                "primitive": {
                    "__type__": "HumanStep",
                    "instruction": "Vortex sample tube for 30 s",
                },
            }
        ],
    }
    biomek_payload = {
        "plan_id": "biomek_plan",
        "protocol_name": "DualProtocol",
        "target": "biomek",
        "steps": [
            {
                "step_id": "step_0001__manual_checkpoint",
                "primitive_type": "CHECKPOINT",
                "dependencies": [],
                "source_intent": "vortex",
                "annotations": {
                    "manual_intervention": {
                        "instruction": "Vortex sample tube for 30 s",
                        "original_primitive": "HUMAN_STEP",
                        "original_step_id": "step_0001",
                    }
                },
                "primitive": {
                    "__type__": "Checkpoint",
                    "checkpoint_id": "manual_step_0001",
                },
            },
            {
                "step_id": "step_0001__manual_pause",
                "primitive_type": "PAUSE",
                "dependencies": ["step_0001__manual_checkpoint"],
                "source_intent": "vortex",
                "annotations": {
                    "manual_intervention": {
                        "instruction": "Vortex sample tube for 30 s",
                        "original_primitive": "HUMAN_STEP",
                        "original_step_id": "step_0001",
                    }
                },
                "primitive": {
                    "__type__": "Pause",
                    "reason": "Manual intervention required",
                },
            },
            {
                "step_id": "step_0002",
                "primitive_type": "ASPIRATE",
                "dependencies": ["step_0001__manual_pause"],
                "source_intent": "transfer",
                "primitive": {
                    "__type__": "Aspirate",
                    "source": {
                        "__type__": "WellRef",
                        "plate_id": "source_plate",
                        "well_id": "A1",
                    },
                    "volume_ul": 10.0,
                },
            },
        ],
    }

    markdown = compose_dual_target_markdown(
        human_payload=human_payload,
        biomek_payload=biomek_payload,
    )

    assert markdown.startswith("# DualProtocol - Dual Target Execution Protocol")
    assert "## Interleaved Manual + Biomek Execution" in markdown
    assert "## Human Steps" in markdown
    assert "<details>" in markdown
    assert "<summary>Block 1: Manual Interventions (1 item(s))</summary>" in markdown
    assert "<summary>Block 2: Biomek Automated Steps (1 step(s))</summary>" in markdown
    assert "Group 1: Manual + Biomek" not in markdown
    assert "<summary>Human Steps (" in markdown
    assert "Vortex sample tube for 30 s." in markdown
    assert markdown.count("`step_0001` (`HUMAN_STEP`)") == 1
