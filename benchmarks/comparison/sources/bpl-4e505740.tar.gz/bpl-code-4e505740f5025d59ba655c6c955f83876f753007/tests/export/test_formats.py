"""
Tests for BPL worklist formatters.
"""

import pytest
from bpl.export import (
    CSVConfig,
    CSVFormatter,
    ExcelConfig,
    FormatConfig,
    WorklistRow,
    get_formatter,
    is_excel_available,
)


class TestCSVFormatter:
    """Test CSVFormatter class."""

    def test_create_formatter(self):
        """Test creating CSV formatter."""
        formatter = CSVFormatter()
        assert formatter is not None

    def test_get_extension(self):
        """Test CSV extension."""
        formatter = CSVFormatter()
        assert formatter.get_extension() == ".csv"

    def test_format_empty_rows(self):
        """Test formatting empty list."""
        formatter = CSVFormatter()
        result = formatter.format([])
        assert result == b""

    def test_format_single_row(self):
        """Test formatting single row."""
        formatter = CSVFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
        )
        result = formatter.format([row])
        content = result.decode("utf-8")
        assert "source_plate" in content
        assert "source_well" in content
        assert "src" in content
        assert "A1" in content
        assert "50.0" in content

    def test_format_multiple_rows(self):
        """Test formatting multiple rows."""
        formatter = CSVFormatter()
        rows = [
            WorklistRow(
                source_plate="src",
                source_well=f"A{i}",
                destination_plate="dst",
                destination_well=f"B{i}",
                transfer_volume_ul=10.0,
            )
            for i in range(1, 4)
        ]
        result = formatter.format(rows)
        content = result.decode("utf-8")
        lines = content.strip().split("\n")
        assert len(lines) == 4  # header + 3 data rows

    def test_format_with_set_identifier(self):
        """Test formatting with set identifier."""
        formatter = CSVFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
            set_identifier="Set1",
        )
        config = CSVConfig(include_set_identifier=True)
        result = formatter.format([row], config)
        content = result.decode("utf-8")
        assert "set_identifier" in content
        assert "Set1" in content

    def test_format_without_wells(self):
        """Test formatting without wells (stamp mode)."""
        formatter = CSVFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well=None,
            destination_plate="dst",
            destination_well=None,
            transfer_volume_ul=10.0,
        )
        config = CSVConfig(include_wells=False)
        result = formatter.format([row], config)
        content = result.decode("utf-8")
        assert "source_well" not in content
        assert "destination_well" not in content
        assert "source_plate" in content
        assert "destination_plate" in content

    def test_format_custom_delimiter(self):
        """Test formatting with custom delimiter."""
        formatter = CSVFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
        )
        config = CSVConfig(delimiter="\t")
        result = formatter.format([row], config)
        content = result.decode("utf-8")
        assert "\t" in content

    def test_format_with_metadata(self):
        """Test formatting with metadata."""
        formatter = CSVFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
            metadata={"barcode_src": "BC001", "barcode_dst": "BC002"},
        )
        result = formatter.format([row])
        content = result.decode("utf-8")
        assert "barcode_src" in content
        assert "BC001" in content


class TestGetFormatter:
    """Test get_formatter function."""

    def test_get_csv_formatter(self):
        """Test getting CSV formatter."""
        formatter = get_formatter("csv")
        assert isinstance(formatter, CSVFormatter)

    def test_get_csv_formatter_text(self):
        """Test getting CSV formatter with 'text' alias."""
        formatter = get_formatter("text")
        assert isinstance(formatter, CSVFormatter)

    def test_get_csv_formatter_case_insensitive(self):
        """Test case insensitivity."""
        formatter = get_formatter("CSV")
        assert isinstance(formatter, CSVFormatter)

    def test_get_unknown_format(self):
        """Test unknown format raises error."""
        with pytest.raises(ValueError) as exc_info:
            get_formatter("unknown")
        assert "Unknown format type" in str(exc_info.value)


class TestIsExcelAvailable:
    """Test is_excel_available function."""

    def test_is_excel_available_returns_bool(self):
        """Test that is_excel_available returns a boolean."""
        result = is_excel_available()
        assert isinstance(result, bool)


class TestFormatConfig:
    """Test FormatConfig class."""

    def test_default_config(self):
        """Test default configuration."""
        config = FormatConfig()
        assert config.include_set_identifier is True
        assert config.include_wells is True

    def test_custom_config(self):
        """Test custom configuration."""
        config = FormatConfig(
            include_set_identifier=False,
            include_wells=False,
        )
        assert config.include_set_identifier is False
        assert config.include_wells is False


class TestCSVConfig:
    """Test CSVConfig class."""

    def test_default_csv_config(self):
        """Test default CSV configuration."""
        config = CSVConfig()
        assert config.delimiter == ","
        assert config.encoding == "utf-8"

    def test_custom_csv_config(self):
        """Test custom CSV configuration."""
        config = CSVConfig(
            delimiter=";",
            encoding="latin-1",
            include_set_identifier=False,
        )
        assert config.delimiter == ";"
        assert config.encoding == "latin-1"
        assert config.include_set_identifier is False


class TestExcelConfig:
    """Test ExcelConfig class."""

    def test_default_excel_config(self):
        """Test default Excel configuration."""
        config = ExcelConfig()
        assert config.sheet_name == "Worklist"
        assert config.header_style == "bold"
        assert config.auto_column_width is True

    def test_custom_excel_config(self):
        """Test custom Excel configuration."""
        config = ExcelConfig(
            sheet_name="Transfers",
            header_style="none",
            auto_column_width=False,
        )
        assert config.sheet_name == "Transfers"
        assert config.header_style == "none"
        assert config.auto_column_width is False


class TestExcelFormatter:
    """Test ExcelFormatter class (only if openpyxl is available)."""

    @pytest.mark.skipif(
        not is_excel_available(),
        reason="openpyxl not installed"
    )
    def test_create_excel_formatter(self):
        """Test creating Excel formatter."""
        from bpl.export import ExcelFormatter
        formatter = ExcelFormatter()
        assert formatter is not None

    @pytest.mark.skipif(
        not is_excel_available(),
        reason="openpyxl not installed"
    )
    def test_excel_get_extension(self):
        """Test Excel extension."""
        from bpl.export import ExcelFormatter
        formatter = ExcelFormatter()
        assert formatter.get_extension() == ".xlsx"

    @pytest.mark.skipif(
        not is_excel_available(),
        reason="openpyxl not installed"
    )
    def test_excel_format_single_row(self):
        """Test formatting single row to Excel."""
        from bpl.export import ExcelFormatter
        formatter = ExcelFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
        )
        result = formatter.format([row])
        assert isinstance(result, bytes)
        # Check for Excel file signature (PK header for zip)
        assert result[:2] == b"PK"

    @pytest.mark.skipif(
        not is_excel_available(),
        reason="openpyxl not installed"
    )
    def test_get_excel_formatter(self):
        """Test getting Excel formatter."""
        formatter = get_formatter("excel")
        from bpl.export import ExcelFormatter
        assert isinstance(formatter, ExcelFormatter)

    @pytest.mark.skipif(
        not is_excel_available(),
        reason="openpyxl not installed"
    )
    def test_get_xlsx_formatter(self):
        """Test getting Excel formatter with xlsx alias."""
        formatter = get_formatter("xlsx")
        from bpl.export import ExcelFormatter
        assert isinstance(formatter, ExcelFormatter)


class TestExcelFormatterNotInstalled:
    """Test ExcelFormatter behavior when openpyxl is not installed."""

    @pytest.mark.skipif(
        is_excel_available(),
        reason="openpyxl is installed"
    )
    def test_excel_format_raises_import_error(self):
        """Test that Excel formatting raises ImportError when openpyxl missing."""
        from bpl.export import ExcelFormatter
        formatter = ExcelFormatter()
        row = WorklistRow(
            source_plate="src",
            source_well="A1",
            destination_plate="dst",
            destination_well="B1",
            transfer_volume_ul=50.0,
        )
        with pytest.raises(ImportError) as exc_info:
            formatter.format([row])
        assert "openpyxl" in str(exc_info.value)
