"""Tests for the chromatography column catalog and method conversion engine."""

from __future__ import annotations

import math

import pytest

from bpl.agentic.column_catalog import (
    ColumnMethodProfile,
    ColumnSpec,
    DetectionMode,
    GradientStep,
    MethodParams,
    PackingType,
    PoreCategory,
    StationaryPhase,
    build_column_catalog_prompt_context,
    convert_method,
    estimate_relative_backpressure,
    get_all_columns,
    get_all_profiles,
    get_column,
    get_profile,
    register_column,
    register_column_profile,
    tool_convert_column_method,
    tool_create_custom_column,
    tool_estimate_backpressure,
    tool_get_column_method,
    tool_get_phase_info,
    tool_list_columns,
    _custom_columns,
    _custom_profiles,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_custom_registry():
    """Clear custom registrations between tests."""
    _custom_columns.clear()
    _custom_profiles.clear()
    yield
    _custom_columns.clear()
    _custom_profiles.clear()


def _make_column(**overrides) -> ColumnSpec:
    defaults = dict(
        column_id="test-col",
        name="Test Column",
        stationary_phase=StationaryPhase.C18,
        inner_diameter_mm=4.6,
        length_mm=250,
        particle_size_um=5.0,
        pore_size_angstrom=100,
        packing_type=PackingType.FULLY_POROUS,
    )
    defaults.update(overrides)
    return ColumnSpec(**defaults)


def _make_method(**overrides) -> MethodParams:
    defaults = dict(
        flow_rate_ml_min=1.0,
        injection_volume_ul=10.0,
        column_temp_c=30.0,
        detection_wavelengths_nm=(254.0,),
        detection_mode=DetectionMode.UV,
        mobile_phase_a="Water",
        mobile_phase_b="Acetonitrile",
        gradient_table=(
            GradientStep(0.0, 5.0),
            GradientStep(20.0, 95.0),
            GradientStep(25.0, 5.0),
        ),
        is_gradient=True,
    )
    defaults.update(overrides)
    return MethodParams(**defaults)


def _make_profile(column=None, method=None, **overrides) -> ColumnMethodProfile:
    return ColumnMethodProfile(
        column=column or _make_column(),
        method=method or _make_method(),
        target_analytes=("Analyte A", "Analyte B"),
        **overrides,
    )


# ---------------------------------------------------------------------------
# Enum tests
# ---------------------------------------------------------------------------


class TestEnums:
    def test_stationary_phases(self):
        assert StationaryPhase.C18.value == "C18"
        assert StationaryPhase.HILIC.value == "HILIC"
        assert StationaryPhase.PFP.value == "PFP"
        assert len(StationaryPhase) >= 17

    def test_packing_types(self):
        assert PackingType.FULLY_POROUS.value == "fully_porous"
        assert PackingType.SUPERFICIALLY_POROUS.value == "superficially_porous"

    def test_detection_modes(self):
        assert DetectionMode.DAD.value == "DAD"
        assert DetectionMode.MS.value == "MS"


# ---------------------------------------------------------------------------
# ColumnSpec tests
# ---------------------------------------------------------------------------


class TestColumnSpec:
    def test_l_over_dp(self):
        col = _make_column(length_mm=250, particle_size_um=5.0)
        assert col.l_over_dp == pytest.approx(50000.0)

    def test_l_over_dp_uhplc(self):
        col = _make_column(length_mm=50, particle_size_um=1.7)
        assert col.l_over_dp == pytest.approx(50000 / 1.7, rel=0.01)

    def test_cross_section(self):
        col = _make_column(inner_diameter_mm=4.6)
        expected = math.pi * (4.6 / 2) ** 2
        assert col.cross_section_mm2 == pytest.approx(expected)

    def test_column_volume(self):
        col = _make_column(inner_diameter_mm=4.6, length_mm=250)
        # pi/4 * 4.6^2 * 250
        expected = math.pi * (4.6 / 2) ** 2 * 250
        assert col.column_volume_ul == pytest.approx(expected, rel=0.001)

    def test_void_volume_fully_porous(self):
        col = _make_column(packing_type=PackingType.FULLY_POROUS)
        assert col.void_volume_ul == pytest.approx(col.column_volume_ul * 0.65)

    def test_void_volume_core_shell(self):
        col = _make_column(packing_type=PackingType.SUPERFICIALLY_POROUS)
        assert col.void_volume_ul == pytest.approx(col.column_volume_ul * 0.55)

    def test_pore_category_small_molecule(self):
        assert _make_column(pore_size_angstrom=100).pore_category == PoreCategory.SMALL_MOLECULE

    def test_pore_category_peptide(self):
        assert _make_column(pore_size_angstrom=150).pore_category == PoreCategory.PEPTIDE

    def test_pore_category_protein(self):
        assert _make_column(pore_size_angstrom=300).pore_category == PoreCategory.PROTEIN

    def test_to_dict(self):
        col = _make_column()
        d = col.to_dict()
        assert d["column_id"] == "test-col"
        assert d["stationary_phase"] == "C18"
        assert "L_over_dp" in d
        assert "column_volume_ul" in d
        assert "void_volume_ul" in d


# ---------------------------------------------------------------------------
# MethodParams tests
# ---------------------------------------------------------------------------


class TestMethodParams:
    def test_run_time(self):
        m = _make_method()
        assert m.run_time_min == 25.0

    def test_run_time_empty_gradient(self):
        m = _make_method(gradient_table=())
        assert m.run_time_min == 0.0

    def test_to_dict(self):
        m = _make_method()
        d = m.to_dict()
        assert d["detection_mode"] == "UV"
        assert d["run_time_min"] == 25.0
        assert len(d["gradient_table"]) == 3


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------


class TestRegistry:
    def test_builtin_columns_not_empty(self):
        columns = get_all_columns()
        assert len(columns) >= 10  # We registered 11 built-in columns

    def test_builtin_profiles_exist(self):
        profiles = get_all_profiles()
        assert "kinetex-c18-2.1x50-1.7um" in profiles
        assert "valuelab-c18-4.6x250-5um" in profiles

    def test_get_column_by_id(self):
        col = get_column("kinetex-c18-2.1x50-1.7um")
        assert col is not None
        assert col.stationary_phase == StationaryPhase.C18

    def test_get_column_not_found(self):
        assert get_column("nonexistent") is None

    def test_register_custom_column(self):
        col = _make_column(column_id="custom-1")
        register_column(col)
        assert get_column("custom-1") is not None

    def test_register_custom_profile(self):
        profile = _make_profile(
            column=_make_column(column_id="profile-1"),
        )
        register_column_profile(profile)
        assert get_profile("profile-1") is not None
        assert get_column("profile-1") is not None

    def test_columns_include_diverse_phases(self):
        columns = get_all_columns()
        phases = {c.stationary_phase for c in columns.values()}
        assert StationaryPhase.C18 in phases
        assert StationaryPhase.PHENYL in phases
        assert StationaryPhase.AMIDE in phases
        assert StationaryPhase.PFP in phases
        assert StationaryPhase.C8 in phases
        assert StationaryPhase.BIPHENYL in phases
        assert StationaryPhase.C4 in phases
        assert StationaryPhase.SCX in phases


# ---------------------------------------------------------------------------
# Conversion engine tests
# ---------------------------------------------------------------------------


class TestMethodConversion:
    def test_identity_conversion(self):
        """Converting to the same column should produce identical parameters."""
        col = _make_column()
        method = _make_method()
        profile = _make_profile(column=col, method=method)
        result = convert_method(profile, col)

        assert result.converted_method.flow_rate_ml_min == pytest.approx(method.flow_rate_ml_min)
        assert result.converted_method.injection_volume_ul == pytest.approx(method.injection_volume_ul)
        assert result.speed_factor == pytest.approx(1.0)
        assert result.solvent_saving_percent == pytest.approx(0.0, abs=0.1)

    def test_flow_rate_scaling_by_diameter(self):
        """Halving the inner diameter should scale flow by (0.5)^2 = 0.25 (at same dp)."""
        src = _make_column(inner_diameter_mm=4.6, particle_size_um=5.0)
        tgt = _make_column(
            column_id="narrow",
            inner_diameter_mm=2.1,
            particle_size_um=5.0,
            length_mm=250,
        )
        profile = _make_profile(column=src, method=_make_method(flow_rate_ml_min=1.0))
        result = convert_method(profile, tgt)

        # F2 = F1 × (dc2²/dc1²) × (dp1/dp2) = 1.0 × (2.1²/4.6²) × 1
        expected_flow = 1.0 * (2.1 / 4.6) ** 2
        assert result.converted_method.flow_rate_ml_min == pytest.approx(expected_flow, rel=0.01)

    def test_flow_rate_scaling_by_particle_size(self):
        """Reducing particle size from 5 to 1.7 should increase flow proportionally."""
        src = _make_column(particle_size_um=5.0, inner_diameter_mm=2.1)
        tgt = _make_column(
            column_id="uhplc",
            particle_size_um=1.7,
            inner_diameter_mm=2.1,
            length_mm=250,
        )
        profile = _make_profile(column=src, method=_make_method(flow_rate_ml_min=0.3))
        result = convert_method(profile, tgt)

        expected_flow = 0.3 * (5.0 / 1.7)
        assert result.converted_method.flow_rate_ml_min == pytest.approx(expected_flow, rel=0.01)

    def test_injection_volume_scaling(self):
        """Injection scales by (L2×dc2²)/(L1×dc1²)."""
        src = _make_column(inner_diameter_mm=4.6, length_mm=250)
        tgt = _make_column(
            column_id="small",
            inner_diameter_mm=2.1,
            length_mm=100,
        )
        profile = _make_profile(column=src, method=_make_method(injection_volume_ul=20.0))
        result = convert_method(profile, tgt)

        expected_inj = 20.0 * (100 * 2.1**2) / (250 * 4.6**2)
        assert result.converted_method.injection_volume_ul == pytest.approx(expected_inj, rel=0.01)

    def test_gradient_time_scaling(self):
        """Gradient times should scale proportionally."""
        src = _make_column(inner_diameter_mm=4.6, length_mm=250, particle_size_um=5.0)
        tgt = _make_column(
            column_id="fast",
            inner_diameter_mm=2.1,
            length_mm=50,
            particle_size_um=1.7,
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        # All gradient steps should be shorter
        for orig, conv in zip(profile.method.gradient_table, result.converted_method.gradient_table):
            if orig.time_min > 0:
                assert conv.time_min < orig.time_min
            # %B should be unchanged
            assert conv.percent_b == orig.percent_b

    def test_ldp_warning_too_low(self):
        """L/dp ratio below -25% should produce warning."""
        src = _make_column(length_mm=250, particle_size_um=5.0)  # L/dp = 50000
        tgt = _make_column(
            column_id="short",
            length_mm=30,
            particle_size_um=5.0,  # L/dp = 6000, well below 75% of 50000
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        ldp_warnings = [w for w in result.warnings if w.parameter == "L/dp" and w.severity == "warning"]
        assert len(ldp_warnings) > 0

    def test_ldp_warning_too_high(self):
        """L/dp ratio above +50% should produce warning."""
        src = _make_column(length_mm=50, particle_size_um=5.0)  # L/dp = 10000
        tgt = _make_column(
            column_id="long",
            length_mm=300,
            particle_size_um=1.7,  # L/dp = 176470, way above 150% of 10000
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        ldp_warnings = [w for w in result.warnings if w.parameter == "L/dp" and w.severity == "warning"]
        assert len(ldp_warnings) > 0

    def test_phase_change_warning(self):
        """Changing stationary phase should warn."""
        src = _make_column(stationary_phase=StationaryPhase.C18)
        tgt = _make_column(
            column_id="phenyl",
            stationary_phase=StationaryPhase.PHENYL,
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        phase_warns = [w for w in result.warnings if w.parameter == "stationary_phase"]
        assert len(phase_warns) == 1

    def test_packing_type_change_warning(self):
        src = _make_column(packing_type=PackingType.FULLY_POROUS)
        tgt = _make_column(
            column_id="core-shell",
            packing_type=PackingType.SUPERFICIALLY_POROUS,
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        packing_warns = [w for w in result.warnings if w.parameter == "packing_type"]
        assert len(packing_warns) == 1

    def test_detection_wavelength_immutable(self):
        profile = _make_profile()
        result = convert_method(profile, _make_column(column_id="t"))
        wl_warns = [w for w in result.warnings if w.parameter == "detection_wavelength"]
        assert len(wl_warns) >= 1
        assert result.converted_method.detection_wavelengths_nm == profile.method.detection_wavelengths_nm

    def test_ms_flow_warning(self):
        """High flow with MS detection should warn."""
        src = _make_column(inner_diameter_mm=4.6)
        method = _make_method(
            flow_rate_ml_min=1.0,
            detection_mode=DetectionMode.MS,
        )
        profile = _make_profile(column=src, method=method)
        result = convert_method(profile, src)

        ms_warns = [w for w in result.warnings if w.parameter == "detection" and "MS" in w.message]
        assert len(ms_warns) >= 1

    def test_rid_gradient_error(self):
        """RID + gradient should produce error."""
        method = _make_method(detection_mode=DetectionMode.RID, is_gradient=True)
        profile = _make_profile(method=method)
        result = convert_method(profile, _make_column(column_id="t"))

        errors = [w for w in result.warnings if w.severity == "error" and w.parameter == "detection"]
        assert len(errors) >= 1

    def test_ph_out_of_range_error(self):
        """pH outside column range should error."""
        tgt = _make_column(column_id="acidic", ph_range=(3.0, 7.0))
        method = _make_method(mobile_phase_ph=1.5)
        profile = _make_profile(method=method)
        result = convert_method(profile, tgt)

        ph_errors = [w for w in result.warnings if w.parameter == "pH" and w.severity == "error"]
        assert len(ph_errors) == 1

    def test_temp_exceeds_column_max(self):
        tgt = _make_column(column_id="low-temp", max_temp_c=40)
        method = _make_method(column_temp_c=60)
        profile = _make_profile(method=method)
        result = convert_method(profile, tgt)

        temp_errors = [w for w in result.warnings if w.parameter == "column_temp" and w.severity == "error"]
        assert len(temp_errors) == 1

    def test_speed_and_solvent(self):
        """HPLC to UHPLC should show speedup and solvent savings."""
        src = _make_column(inner_diameter_mm=4.6, length_mm=250, particle_size_um=5.0)
        tgt = _make_column(
            column_id="uhplc",
            inner_diameter_mm=2.1,
            length_mm=50,
            particle_size_um=1.7,
        )
        profile = _make_profile(column=src)
        result = convert_method(profile, tgt)

        assert result.speed_factor > 1.0
        assert result.solvent_saving_percent > 0

    def test_builtin_profile_conversion(self):
        """Convert between the two built-in profiles."""
        src = get_profile("kinetex-c18-2.1x50-1.7um")
        tgt = get_column("valuelab-c18-4.6x250-5um")
        assert src is not None
        assert tgt is not None

        result = convert_method(src, tgt)
        assert result.converted_method.flow_rate_ml_min > 0
        assert result.converted_method.injection_volume_ul > 0
        assert len(result.converted_method.gradient_table) == len(src.method.gradient_table)


# ---------------------------------------------------------------------------
# Backpressure estimation tests
# ---------------------------------------------------------------------------


class TestBackpressure:
    def test_identity_pressure(self):
        col = _make_column()
        ratio = estimate_relative_backpressure(col, col, 1.0, 1.0)
        assert ratio == pytest.approx(1.0)

    def test_smaller_particle_higher_pressure(self):
        src = _make_column(particle_size_um=5.0)
        tgt = _make_column(column_id="fine", particle_size_um=1.7)
        # Same column dimensions and proportional flow
        dc_sq = (tgt.inner_diameter_mm / src.inner_diameter_mm) ** 2
        dp_inv = src.particle_size_um / tgt.particle_size_um
        tgt_flow = 1.0 * dc_sq * dp_inv  # scaled flow
        ratio = estimate_relative_backpressure(src, tgt, 1.0, tgt_flow)
        assert ratio > 1.0  # pressure should increase

    def test_shorter_column_lower_pressure(self):
        src = _make_column(length_mm=250)
        tgt = _make_column(column_id="short", length_mm=50)
        ratio = estimate_relative_backpressure(src, tgt, 1.0, 1.0)
        assert ratio < 1.0  # shorter = less pressure at same flow


# ---------------------------------------------------------------------------
# Tool function tests
# ---------------------------------------------------------------------------


class TestToolFunctions:
    def test_tool_list_columns(self):
        result = tool_list_columns()
        assert "C18" in result
        assert "kinetex-c18-2.1x50-1.7um" in result
        assert "valuelab-c18-4.6x250-5um" in result
        assert "Phenyl" in result

    def test_tool_get_column_method_with_profile(self):
        result = tool_get_column_method("kinetex-c18-2.1x50-1.7um")
        assert "Phenomenex" in result
        assert "0.6 mL/min" in result or "0.6" in result
        assert "Gradient" in result

    def test_tool_get_column_method_without_profile(self):
        result = tool_get_column_method("beh-c18-2.1x100-1.7um")
        assert "Waters" in result
        # Should still show specs but no method section
        assert "Phase" in result

    def test_tool_get_column_method_not_found(self):
        result = tool_get_column_method("nonexistent")
        assert "not found" in result

    def test_tool_convert_column_method(self):
        result = tool_convert_column_method(
            "kinetex-c18-2.1x50-1.7um",
            "valuelab-c18-4.6x250-5um",
        )
        assert "Method Conversion" in result
        assert "Flow" in result
        assert "Gradient" in result or "gradient" in result

    def test_tool_convert_source_no_profile(self):
        result = tool_convert_column_method("beh-c18-2.1x100-1.7um", "valuelab-c18-4.6x250-5um")
        assert "no method profile" in result

    def test_tool_convert_target_not_found(self):
        result = tool_convert_column_method("kinetex-c18-2.1x50-1.7um", "nonexistent")
        assert "not found" in result

    def test_tool_create_custom_column(self):
        result = tool_create_custom_column(
            column_id="my-c18",
            name="My Custom C18",
            stationary_phase="C18",
            inner_diameter_mm=3.0,
            length_mm=150,
            particle_size_um=3.5,
            pore_size_angstrom=120,
            packing_type="fully_porous",
        )
        assert "Registered" in result
        assert get_column("my-c18") is not None

    def test_tool_create_custom_column_invalid_phase(self):
        result = tool_create_custom_column(
            column_id="bad",
            name="Bad",
            stationary_phase="InvalidPhase",
            inner_diameter_mm=2.1,
            length_mm=100,
            particle_size_um=1.7,
            pore_size_angstrom=100,
            packing_type="fully_porous",
        )
        assert "Invalid phase" in result

    def test_tool_create_custom_column_invalid_packing(self):
        result = tool_create_custom_column(
            column_id="bad2",
            name="Bad2",
            stationary_phase="C18",
            inner_diameter_mm=2.1,
            length_mm=100,
            particle_size_um=1.7,
            pore_size_angstrom=100,
            packing_type="bad_packing",
        )
        assert "Invalid packing" in result

    def test_tool_get_phase_info(self):
        result = tool_get_phase_info("C18")
        assert "hydrophob" in result.lower()
        assert "reversed-phase" in result.lower()

    def test_tool_get_phase_info_hilic(self):
        result = tool_get_phase_info("HILIC")
        assert "polar" in result.lower()

    def test_tool_get_phase_info_invalid(self):
        result = tool_get_phase_info("UnknownPhase")
        assert "Unknown phase" in result

    def test_tool_estimate_backpressure(self):
        result = tool_estimate_backpressure(
            "kinetex-c18-2.1x50-1.7um",
            "valuelab-c18-4.6x250-5um",
        )
        assert "Pressure ratio" in result or "pressure" in result.lower()

    def test_tool_estimate_backpressure_not_found(self):
        result = tool_estimate_backpressure("nonexistent", "valuelab-c18-4.6x250-5um")
        assert "not found" in result


# ---------------------------------------------------------------------------
# Prompt context tests
# ---------------------------------------------------------------------------


class TestPromptContext:
    def test_prompt_context_not_empty(self):
        ctx = build_column_catalog_prompt_context()
        assert "chromatography" in ctx.lower() or "column" in ctx.lower()
        assert "kinetex" in ctx.lower()

    def test_prompt_context_shows_all_phases(self):
        ctx = build_column_catalog_prompt_context()
        assert "C18" in ctx
        assert "Phenyl" in ctx
        assert "PFP" in ctx


# ---------------------------------------------------------------------------
# Conversion result serialization
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_conversion_result_to_dict(self):
        profile = _make_profile()
        result = convert_method(profile, _make_column(column_id="target"))
        d = result.to_dict()
        assert "source_column" in d
        assert "target_column" in d
        assert "converted_method" in d
        assert "warnings" in d
        assert "speed_factor" in d
        assert "estimated_pressure_ratio" in d

    def test_column_method_profile_to_dict(self):
        profile = _make_profile(application="pharma", description="Test method")
        d = profile.to_dict()
        assert d["application"] == "pharma"
        assert d["description"] == "Test method"
        assert "column" in d
        assert "method" in d
