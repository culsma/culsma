"""Smoke + unit tests for tools/bpl_eval/.

Covers only the offline parts of the evaluation pipeline:

* loading the frozen artifacts shipped under ``tools/bpl_eval/data/``,
* parsing the consistency report,
* computing structural features,
* running ``compute_determinism`` and asserting the figure-3 headline
  numbers match the paper's claim,
* verifying the eight publication figures ship as PDF + PNG.

The API-driven stages (``generate_digests``, ``generate_variants``,
``compile_bpl``, ``compare_variants``) are imported but not executed —
they require ``OPENROUTER_API_KEY`` and the raw corpus. End-to-end
figure regeneration is exercised by ``scripts/reproduce_paper.py``.
"""

from __future__ import annotations

import asyncio
import importlib
import json
import sys
import types
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
EVAL_DIR = REPO_ROOT / "tools" / "bpl_eval"
DATA_DIR = EVAL_DIR / "data"
REDRAW_OUT_DIR = EVAL_DIR / "figures" / "publication_redraw"

EXPECTED_PAPER_FIGURES = (
    "fig1_pipeline_architecture",
    "fig2_benchmark_validation",
    "fig2a_llm_validation_scores",
    "fig3_structural_determinism",
    "fig4_compiler_diagnostics",
    "fig5_wetlab_validation",
    "fig6_language_design",
    "fig7_corpus_quality_assurance",
)


@pytest.fixture(scope="module", autouse=True)
def _eval_path():
    """Make ``tools/bpl_eval/`` importable without polluting other tests."""
    str_path = str(EVAL_DIR)
    if str_path not in sys.path:
        sys.path.insert(0, str_path)
    yield
    if sys.path and sys.path[0] == str_path:
        sys.path.pop(0)
    for name in (
        "config",
        "llm_client",
        "prompts",
        "compare_prompts",
        "figure_style_system",
        "generate_figures",
        "redraw_publication_figures",
        "compute_determinism",
    ):
        sys.modules.pop(name, None)


# ─────────────────────────────────────────────────────────────────────
# Module imports + frozen artifact presence
# ─────────────────────────────────────────────────────────────────────


def test_pipeline_modules_import():
    for module_name in (
        "config",
        "llm_client",
        "prompts",
        "compare_prompts",
        "figure_style_system",
        "compute_determinism",
    ):
        importlib.import_module(module_name)


def test_frozen_artifacts_present():
    assert (DATA_DIR / "variant_comparisons" / "variant_report.json").is_file()
    assert (DATA_DIR / "variant_comparisons" / "per_paper").is_dir()
    assert (DATA_DIR / "consistency_report.md").is_file()
    assert (DATA_DIR / "structural_features.json").is_file()
    assert (DATA_DIR / "determinism_results.json").is_file()


def test_llm_client_does_not_send_openrouter_attribution(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")
    monkeypatch.setenv("BPL_EVAL_HTTP_REFERER", "https://localhost/bpl")
    sys.modules.pop("config", None)
    sys.modules.pop("llm_client", None)
    llm_client = importlib.import_module("llm_client")
    captured = {}

    class FakeClient:
        async def post(self, url, *, headers, json, timeout):  # noqa: ANN001, A002
            captured["url"] = url
            captured["headers"] = headers
            captured["json"] = json
            captured["timeout"] = timeout
            return types.SimpleNamespace(
                status_code=200,
                raise_for_status=lambda: None,
                json=lambda: {
                    "choices": [{"message": {"content": "ok"}}],
                },
                text='{"choices":[{"message":{"content":"ok"}}]}',
            )

    result = asyncio.run(
        llm_client.call_llm(
            FakeClient(),
            [{"role": "user", "content": "hi"}],
            "openai/test",
            0.0,
        )
    )

    assert result == "ok"
    assert captured["headers"] == {
        "Authorization": "Bearer test-key",
        "Content-Type": "application/json",
    }
    assert "HTTP-Referer" not in captured["headers"]
    assert "X-Title" not in captured["headers"]
    assert "X-OpenRouter-Title" not in captured["headers"]
    assert "X-OpenRouter-Categories" not in captured["headers"]


# ─────────────────────────────────────────────────────────────────────
# Loaders — exact-shape assertions for the shipped paper data
# ─────────────────────────────────────────────────────────────────────


def test_load_variant_report_offline():
    import generate_figures

    papers, flat_variants = generate_figures.load_variant_report()
    # Frozen paper-grade dataset shape — protect against silent drift.
    assert len(papers) == 300, f"expected 300 papers, got {len(papers)}"
    assert all("paper_name" in p for p in papers)
    assert all("variants" in p for p in papers)
    assert len(flat_variants) == 2992, f"expected 2992 flat variants, got {len(flat_variants)}"
    sample = flat_variants[0]
    assert {"paper", "version", "overall", "exp_match", "validity", "phase"} <= set(
        sample
    )


def test_load_consistency_rows_offline():
    import generate_figures

    rows = generate_figures.load_consistency_rows()
    # consistency_report.md was generated over 301 papers.
    assert len(rows) == 301, f"expected 301 rows, got {len(rows)}"
    expected_keys = {
        "paper",
        "digest",
        "mean",
        "min",
        "max",
        "range",
        "std",
        "match",
        "variants",
    }
    assert expected_keys <= set(rows[0])


def test_load_text_features_uses_frozen_json():
    import generate_figures

    features = generate_figures.load_text_features()
    assert len(features) == 301, f"expected 301 papers, got {len(features)}"
    inner = next(iter(next(iter(features.values())).values()))
    assert {
        "word_count",
        "line_count",
        "step_count",
        "bold_count",
        "schema_markers",
    } <= set(inner)


# ─────────────────────────────────────────────────────────────────────
# Pure-function unit tests (no I/O)
# ─────────────────────────────────────────────────────────────────────


def test_extract_structural_features_counts():
    import generate_figures

    sample = (
        "Objective: demonstrate every counted feature.\n"
        "Materials and setup: reagent A, reagent B.\n"
        "## Step 1\n"
        "Mix **reagent A** with **reagent B**.\n"
        "CRITICAL: temperature must be 25 degC.\n"
        "- bullet one\n"
        "- bullet two\n"
        "## Step 2\n"
        "Centrifuge.\n"
    )
    features = generate_figures.extract_structural_features(sample)
    assert features["word_count"] > 0
    assert features["line_count"] == sample.count("\n")
    assert features["step_count"] == 2  # "Step 1" and "Step 2"
    assert features["bold_count"] == 2  # **reagent A** and **reagent B**
    assert features["critical_count"] == 1
    assert features["dash_bullets"] == 2
    assert features["md_headers"] == 2
    # Schema markers: objective, materials, critical, step heading.
    assert features["schema_markers"] >= 4


def test_count_step_patterns_handles_all_formats():
    """Cover the three step-numbering patterns generate_figures parses."""
    import generate_figures

    # Format 1: ## Step N heading
    assert generate_figures.count_step_patterns("## Step 1\n## Step 2\n## Step 3\n") == 3
    # Format 2: bold-marked Step N
    assert generate_figures.count_step_patterns("**Step 1.** do thing\n**Step 2.** do other\n") == 2
    # Format 3: bare numbered list at line start
    assert generate_figures.count_step_patterns("1. first\n2. second\n3. third\n") == 3
    # Mixed: numbers from any pattern deduplicate by step number.
    mixed = "## Step 1\n**Step 2.** rewrite\n3. legacy\n"
    assert generate_figures.count_step_patterns(mixed) == 3


def test_parse_consistency_rows_handles_match_percentage_format():
    from compute_determinism import parse_consistency_rows

    md = (
        "preamble\n\n"
        "| Paper | Digest | Mean | Min | Max | Range | Std | Match% | Variants |\n"
        "|---|---|---|---|---|---|---|---|---|\n"
        "| Sample paper one | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |\n"
        "| Sample paper two | 21 | 17 | 0 | 21 | 21 | 8.1 | 80% | 10 |\n"
        "\n"
        "trailing prose\n"
    )
    rows = parse_consistency_rows(md)
    assert len(rows) == 2
    assert rows[0]["paper"] == "Sample paper one"
    assert rows[0]["range"] == 0
    assert rows[0]["match_pct"] == 100.0
    assert rows[1]["match_pct"] == 80.0


def test_compute_determinism_headline_matches_paper_claim(tmp_path):
    """Verify the figure-3 headline numbers re-derive cleanly from the
    shipped consistency report and per_paper data, and match the paper's
    prose claim (≥98% identical, ≥99% match, mean range < 1).

    This is the canonical guard-rail against any future drift between the
    shipped data, the figure label, and the manuscript text.
    """
    import compute_determinism

    out_path = tmp_path / "determinism_results.json"
    result = compute_determinism.compute_determinism(out_path=out_path)
    summary = result["summary"]

    assert summary["n_papers"] == 301
    assert summary["identical_all_runs_pct"] >= 98.0
    assert summary["mean_match_vs_digest_pct"] >= 99.0
    assert summary["mean_step_count_range"] < 1.0
    assert summary["coverage"]["n_papers"] == 300
    # The shipped per_paper/*.json files cover 2991 LLM-judged variants
    # (three papers have fewer than 10 variants — see
    # data/variant_comparisons/variant_report.json's papers_with_nonstandard
    # field). The aggregated variant_report.json reports 2992 because of an
    # historical 1-variant discrepancy between the per-paper records and the
    # rolled-up report; neither is hidden, both are tested.
    assert summary["coverage"]["total_scored_variants"] == 2991
    assert len(summary["coverage"]["papers_with_nonstandard_variant_count"]) == 3

    written = json.loads(out_path.read_text())
    assert written["summary"]["n_papers"] == 301


# ─────────────────────────────────────────────────────────────────────
# Projection + shipped figures
# ─────────────────────────────────────────────────────────────────────


def test_structural_projection_shape_and_split():
    import generate_figures

    features = generate_figures.load_text_features()
    projection = generate_figures.build_structural_projection(features)
    assert {"records", "projected", "pca", "is_raw"} <= set(projection)
    projected = projection["projected"]
    assert hasattr(projected, "shape") and projected.shape[1] == 2  # type: ignore[attr-defined]

    # Each paper should contribute one v00 + ten v01..v10 = 11 records, with
    # very small drop rate from the regex parser. Allow a small tolerance.
    is_raw = projection["is_raw"]
    n_total = len(is_raw)
    n_raw = int(is_raw.sum())  # type: ignore[attr-defined]
    assert n_total >= 3000, f"expected ≥3000 records, got {n_total}"
    assert n_raw >= 295, f"expected ≥295 raw v00 records, got {n_raw}"


def test_publication_figures_shipped():
    """Every paper figure ships in both PDF and PNG form."""
    for stem in EXPECTED_PAPER_FIGURES:
        for ext in ("pdf", "png"):
            path = REDRAW_OUT_DIR / f"{stem}.{ext}"
            assert path.is_file(), f"missing shipped figure: {path}"
            assert path.stat().st_size > 0


def test_compute_determinism_rejects_missing_consistency_report(tmp_path):
    """compute_determinism should fail loudly when the consistency report is absent."""
    import compute_determinism

    missing = tmp_path / "consistency_report.md"
    out_path = tmp_path / "out.json"
    with pytest.raises(SystemExit, match=r"(?i)missing consistency report"):
        compute_determinism.compute_determinism(
            consistency_report=missing,
            per_paper_dir=DATA_DIR / "variant_comparisons" / "per_paper",
            out_path=out_path,
        )


def test_compute_determinism_rejects_empty_table(tmp_path):
    """Markdown with no per-paper rows should fail before writing any output."""
    import compute_determinism

    bad_report = tmp_path / "consistency_report.md"
    bad_report.write_text(
        "# Variant Consistency Analysis\n\nNo table here.\n",
        encoding="utf-8",
    )
    out_path = tmp_path / "out.json"
    with pytest.raises(SystemExit, match=r"(?i)rows are empty"):
        compute_determinism.compute_determinism(
            consistency_report=bad_report,
            per_paper_dir=DATA_DIR / "variant_comparisons" / "per_paper",
            out_path=out_path,
        )
    assert not out_path.exists(), "output should not be written on failure"


def test_compute_determinism_rejects_missing_per_paper_dir(tmp_path):
    """Empty per_paper_dir should fail loudly so coverage drift is caught."""
    import compute_determinism

    empty = tmp_path / "per_paper"
    empty.mkdir()
    out_path = tmp_path / "out.json"
    with pytest.raises(SystemExit, match=r"(?i)no paper files found"):
        compute_determinism.compute_determinism(
            consistency_report=DATA_DIR / "consistency_report.md",
            per_paper_dir=empty,
            out_path=out_path,
        )


def test_shipped_determinism_matches_recomputed_summary(tmp_path):
    """The committed determinism_results.json must agree with a fresh recomputation.

    This guards against the failure mode the round-2 review caught: shipped
    artifact stale relative to the script that produced it.
    """
    import compute_determinism

    fresh_out = tmp_path / "fresh.json"
    fresh = compute_determinism.compute_determinism(out_path=fresh_out)
    shipped = json.loads((DATA_DIR / "determinism_results.json").read_text())

    fresh_summary = fresh["summary"]
    shipped_summary = shipped["summary"]
    for key in (
        "n_papers",
        "identical_all_runs_count",
        "max_step_count_range",
    ):
        assert shipped_summary[key] == fresh_summary[key], (
            f"shipped determinism_results.json key {key} drifted from a fresh recomputation"
        )
    for key in (
        "identical_all_runs_pct",
        "mean_step_count_range",
        "mean_step_count_std",
        "mean_match_vs_digest_pct",
    ):
        assert abs(shipped_summary[key] - fresh_summary[key]) < 1e-6, (
            f"shipped determinism_results.json key {key} drifted from a fresh recomputation"
        )


def test_pdf_metadata_is_deterministic():
    """Shipped PDFs must have static metadata (no CreationDate) so consecutive
    redraws produce byte-stable files.
    """
    sample_pdf = REDRAW_OUT_DIR / "fig3_structural_determinism.pdf"
    raw = sample_pdf.read_bytes()
    # Raw PDF metadata-stream check: no live CreationDate / ModDate value.
    # We allow the keys to appear (matplotlib may write them as null) as long
    # as they are followed by a null marker, an empty string, or a 1970/1990
    # epoch placeholder rather than a fresh timestamp.
    assert b"D:2025" not in raw and b"D:2026" not in raw, (
        "PDF contains live CreationDate metadata; figure is not byte-stable"
    )


# ─────────────────────────────────────────────────────────────────────
# Paper-experiment reproducers — Methods §103, §137, §47, §41
# ─────────────────────────────────────────────────────────────────────


def test_method_translation_matches_paper(tmp_path):
    """Fig 5 HPLC→UHPLC translation must match the paper's claimed numbers.

    Paper claims (Methods §137, §142):
      flow rate = 0.613 mL/min
      run time = 2.1 min (rounded; raw 2.18)
      4 compliance warnings (L/dp, packing_type, pore_size, backpressure)
    """
    import method_translation

    out = tmp_path / "translation.json"
    summary = method_translation.write_translation(out_path=out)

    # Flow rate must round to the paper's 0.613 within 1 mL/min/1000.
    flow = summary["translation"]["flow_rate_ml_min"]
    assert abs(flow - 0.613) < 1e-3, f"flow {flow} ≠ paper 0.613"

    # Run time scales by ~14.7×; recomputed value rounds to 2.18 (paper 2.1).
    run = summary["translation"]["run_time_min"]
    assert 2.0 < run < 2.3, f"run time {run} outside [2.0, 2.3]"
    assert summary["reduction"]["run_time_factor"] >= 14.0

    # 4 compliance warnings (L/dp, packing_type, pore_size, backpressure).
    assert summary["warning_count"] == method_translation.PAPER_CLAIM_WARNING_COUNT
    warned_params = {
        w["parameter"] for w in summary["warnings"] if w["severity"] == "warning"
    }
    assert {"L/dp", "packing_type", "pore_size", "backpressure"} <= warned_params


def test_sensitivity_analysis_reproduces_insensitivity_claim(tmp_path):
    """Methods §103 sensitivity analysis must reproduce the paper's bounds.

    Paper claims (Methods §106):
      mean variant overall ∈ [93.9, 96.6]
      median ∈ [96.0, 97.3]
      fraction ≥ 80 ∈ [97.4 %, 98.5 %]
      mean per-paper s.d. ∈ [2.85, 3.71]

    The recomputed grid (44 triplets vs paper's 47) reproduces the
    insensitivity conclusion within ±1.0 of every reported bound.
    """
    import sensitivity_analysis

    out = tmp_path / "sensitivity.json"
    result = sensitivity_analysis.run_sensitivity(out_path=out)
    m = result["summary"]["metrics"]
    p = result["summary"]["paper_claimed_bounds"]

    # Mean overall: recomputed range overlaps paper's [93.9, 96.6] within ±1.
    assert m["mean_overall"]["min"] >= p["mean_overall_min"] - 1.0
    assert m["mean_overall"]["max"] <= p["mean_overall_max"] + 1.0

    # Median: within ±1 of paper bounds.
    assert m["median_overall"]["min"] >= p["median_overall_min"] - 1.0
    assert m["median_overall"]["max"] <= p["median_overall_max"] + 1.0

    # Fraction ≥ 80: paper says [97.4, 98.5]. Recomputed must stay ≥ 97.0.
    assert m["frac_ge_80_pct"]["min"] >= 97.0
    assert m["frac_ge_80_pct"]["max"] <= 99.0

    # Mean per-paper std: recomputed should be in [2.5, 4.0].
    assert 2.5 <= m["mean_paper_std"]["min"] <= 4.0
    assert 2.5 <= m["mean_paper_std"]["max"] <= 4.0


def test_pcr_amplification_csv_matches_paper():
    """Fig 5b PCR amplification dataset must encode the paper's exact values.

    Paper Results §48: 11/11 inserts both workflows; vector backbones
    11/11 (manual) vs 10/11 first-attempt (automated) → 11/11 after
    one-cycle repeat.
    """
    csv_path = DATA_DIR / "wetlab" / "pcr_amplification.csv"
    rows: dict[tuple[str, str, str], int] = {}
    for line in csv_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "fragment,")):
            continue
        frag, wf, stage, total, succ = line.split(",")
        assert int(total) == 11
        rows[(frag, wf, stage)] = int(succ)
    assert rows[("insert", "manual", "initial")] == 11
    assert rows[("insert", "automated", "initial")] == 11
    assert rows[("vector", "manual", "initial")] == 11
    assert rows[("vector", "automated", "initial")] == 10
    assert rows[("vector", "automated", "rescue")] == 11


def test_compiler_diagnostic_counts_match_paper():
    """Fig 4a diagnostic categories must encode the paper's exact counts.

    Paper Results §41: 343 total diagnostics; 142 dimension, 87 capacity,
    64 undeclared, 38 state, 12 trust.
    """
    diag = json.loads(
        (DATA_DIR / "diagnostics" / "diagnostic_categories.json").read_text()
    )
    assert diag["total_diagnostics"] == 343
    assert diag["corpus_size_protocols"] == 302
    counts = {c["code"]: c["occurrences"] for c in diag["categories"]}
    assert counts["DIMENSION_MISMATCH"] == 142
    assert counts["CAPACITY_VIOLATION"] == 87
    assert counts["UNDECLARED_IDENTIFIER"] == 64
    assert counts["STATE_CONFLICT"] == 38
    assert counts["TRUST_VIOLATION"] == 12
    assert sum(counts.values()) == diag["total_diagnostics"]


def test_hplc_uhplc_retention_times_match_paper():
    """Fig 5 retention-time table must encode the paper's claimed values.

    Paper Methods §137 / §142: HPLC RTs (retinol 10.67, retinal 10.84,
    retinyl acetate 11.46, lycopene 18.65, β-carotene 25.11 min) and
    UHPLC RTs (0.724, 0.809, 0.954, 1.407, 1.686 min). Elution order
    preserved; retinol/retinal Rs=1.2 on UHPLC.
    """
    csv_path = DATA_DIR / "method_translation" / "retention_times.csv"
    rows: dict[str, dict[str, float]] = {}
    for line in csv_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "compound,")):
            continue
        compound, hplc_rt, uhplc_rt, det, _note = line.split(",", 4)
        rows[compound] = {
            "hplc_rt": float(hplc_rt),
            "uhplc_rt": float(uhplc_rt),
            "det": float(det),
        }
    expected_hplc = {
        "Retinol": 10.67, "Retinal": 10.84, "Retinyl acetate": 11.46,
        "Lycopene": 18.65, "beta-Carotene": 25.11,
    }
    expected_uhplc = {
        "Retinol": 0.724, "Retinal": 0.809, "Retinyl acetate": 0.954,
        "Lycopene": 1.407, "beta-Carotene": 1.686,
    }
    for compound, hplc_rt in expected_hplc.items():
        assert rows[compound]["hplc_rt"] == hplc_rt
    for compound, uhplc_rt in expected_uhplc.items():
        assert rows[compound]["uhplc_rt"] == uhplc_rt
    # Elution order preserved on both methods.
    order = sorted(rows, key=lambda c: rows[c]["uhplc_rt"])
    assert order == ["Retinol", "Retinal", "Retinyl acetate", "Lycopene", "beta-Carotene"]


def test_repair_loop_outcomes_match_paper():
    """Fig 4b repair-loop outcome percentages must encode the paper's claim.

    Paper Results §42: 82.3% first-attempt, 12.1% one-iteration, 4.2%
    two-or-more iterations, 1.4% unresolved. The figure panel collapses
    the multi-iteration buckets into 'first-attempt' / 'repair-loop' /
    'unresolved' summing to ~100%.
    """
    repair = json.loads(
        (DATA_DIR / "diagnostics" / "repair_loop_outcomes.json").read_text()
    )
    raw = repair["outcomes_pct"]
    assert raw["first_attempt_success"] == 82.3
    assert raw["one_iteration_repair"] == 12.1
    assert raw["two_or_more_iterations_repair"] == 4.2
    assert raw["unresolved"] == 1.4
    panel = {seg["label"]: float(seg["pct"]) for seg in repair["panel_segments_pct"]}
    assert abs(panel["First attempt"] + panel["Repair loop"] + panel["Unresolved"] - 100.0) < 0.1
    assert panel["First attempt"] == 82.3
    assert panel["Unresolved"] == 1.4
