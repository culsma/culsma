protocol CollectionTransferProtocol {
  transfer(from: [source_1, source_2], to: [dest_1, dest_2], volume: 5 uL)
}
