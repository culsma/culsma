protocol EmptyProtocol {
}

