protocol InvalidVolumeProtocol {
  transfer(from: source, to: dest, volume: 0 uL)
}
