protocol UnsupportedPrimitiveProtocol {
  vortex(target: tube_1, duration: 30 s)
}
