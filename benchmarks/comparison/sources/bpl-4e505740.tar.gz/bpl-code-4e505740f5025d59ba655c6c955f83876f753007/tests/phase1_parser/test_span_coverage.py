"""Span propagation and coverage gate tests."""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from typing import Iterator, Sequence

from bpl.ast.base import ASTNode
from bpl.ast.declarations import Declaration, ProtocolDecl
from bpl.ast.expressions import BinaryExpr, Expression
from bpl.ast.statements import Statement
from bpl.parser import parse

_COVERAGE_SOURCE = """
protocol SpanCoverage(dna: DNA, volume: Volume = 10 uL) {
    let x: Number = (1 + 2) * 3
    let wells = [A1, A2]
    transfer(from: source, to: dest, volume: 10 uL)
    if x > 0 {
        wait(duration: 1 s)
    } else {
        wait(duration: 2 s)
    }
    for well in wells {
        wait(duration: 3 s)
    }
    while x < 5 {
        x = x + 1
    }
}

reagent NaCl {
    physical_form: Solid
    MW: 58.44 g/mol
}

labware Plate96 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
}

target HumanTarget {
    capabilities: [transfer, wait]
    NOT: [vortex]
}

resource Incubator1 {
    capacity: 1
    booking_required: true
    cooldown: 10 s
}

function helper(a: Number, b: Number) -> Number {
    return a + b
}

intent move(from: WellRef, to: WellRef) -> Number
primitive aspirate(from: WellRef, volume: Volume) -> Number
"""


def _walk_ast_nodes(value: object) -> Iterator[ASTNode]:
    if isinstance(value, ASTNode):
        yield value
        for field in fields(value):
            if field.name == "span":
                continue
            yield from _walk_ast_nodes(getattr(value, field.name))
        return

    if isinstance(value, list):
        for item in value:
            yield from _walk_ast_nodes(item)
        return

    if isinstance(value, tuple):
        for item in value:
            yield from _walk_ast_nodes(item)
        return

    if isinstance(value, dict):
        for item in value.values():
            yield from _walk_ast_nodes(item)
        return

    if is_dataclass(value):
        for field in fields(value):
            yield from _walk_ast_nodes(getattr(value, field.name))


def _coverage(nodes: Sequence[ASTNode]) -> float:
    if not nodes:
        return 1.0
    with_span = sum(1 for node in nodes if node.span is not None)
    return with_span / len(nodes)


def test_span_coverage_thresholds():
    program = parse(_COVERAGE_SOURCE)
    nodes = list(_walk_ast_nodes(program))

    declaration_nodes = [node for node in nodes if isinstance(node, Declaration)]
    statement_nodes = [node for node in nodes if isinstance(node, Statement)]
    expression_nodes = [node for node in nodes if isinstance(node, Expression)]

    declaration_coverage = _coverage(declaration_nodes)
    statement_coverage = _coverage(statement_nodes)
    expression_coverage = _coverage(expression_nodes)

    assert declaration_coverage >= 0.8
    assert statement_coverage >= 0.8
    assert expression_coverage >= 0.5


def test_synthesized_binary_expr_spans_bound_children():
    program = parse(
        """
        protocol SpanSynthesis {
            let x = 1 + 2 + 3
        }
        """
    )
    protocol = next(
        declaration for declaration in program.declarations if isinstance(declaration, ProtocolDecl)
    )
    let_stmt = protocol.body[0]
    expr = let_stmt.value

    assert isinstance(expr, BinaryExpr)
    assert expr.span is not None
    assert isinstance(expr.left, BinaryExpr)
    assert expr.left.span is not None
    assert expr.right is not None and expr.right.span is not None

    assert expr.span.start_line <= expr.left.span.start_line
    assert expr.span.start_col <= expr.left.span.start_col
    assert expr.span.end_line >= expr.right.span.end_line
    assert expr.span.end_col >= expr.right.span.end_col
