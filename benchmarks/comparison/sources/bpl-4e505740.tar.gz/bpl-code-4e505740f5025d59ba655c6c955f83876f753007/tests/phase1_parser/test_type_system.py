"""
Tests for BPL Type System.

Tests unit arithmetic, concentration derivation, and type compatibility.
"""

import pytest
from bpl.types import (
    # Dimensions
    DimensionVector, Dimension,
    MASS, VOLUME, TIME,
    MASS_CONCENTRATION, MOLAR_CONCENTRATION,
    # Unit engine
    Unit, UnitCategory, UnitDimensionError,
    get_unit, create_quantity, are_compatible, derive_unit_from_operation,
    get_registry,
    # Types
    VOLUME_TYPE, MASS_TYPE, CONCENTRATION_TYPE,
    MASS_CONCENTRATION_TYPE, MOLAR_CONCENTRATION_TYPE,
    NUMBER, STRING, BOOLEAN,
    get_type,
    # Concentration
    ConcentrationType,
    create_concentration, derive_concentration_from_division,
    calculate_mass_from_molar, calculate_moles_from_mass,
)


class TestDimensions:
    """Test dimension arithmetic."""

    def test_dimensionless(self):
        """Test dimensionless dimension."""
        d = DimensionVector()
        assert d.is_dimensionless

    def test_mass_dimension(self):
        """Test mass dimension."""
        assert not MASS.is_dimensionless
        assert MASS == DimensionVector({Dimension.MASS: 1})

    def test_dimension_multiplication(self):
        """Test dimension multiplication."""
        # Mass * Volume = Mass * Volume
        result = MASS * VOLUME
        assert not result.is_dimensionless
        expected = DimensionVector({Dimension.MASS: 1, Dimension.VOLUME: 1})
        assert result == expected

    def test_dimension_division(self):
        """Test dimension division."""
        # Mass / Volume = Mass * Volume^-1 (concentration)
        result = MASS / VOLUME
        assert result == MASS_CONCENTRATION

    def test_same_dimension_division(self):
        """Test division of same dimensions gives dimensionless."""
        result = VOLUME / VOLUME
        assert result.is_dimensionless


class TestUnitEngine:
    """Test unit parsing and arithmetic."""

    def test_get_simple_unit(self):
        """Test getting a simple unit."""
        unit = get_unit("mL")
        assert unit.name == "mL"
        assert unit.dimension == VOLUME

    def test_get_compound_unit(self):
        """Test getting a compound unit."""
        unit = get_unit("mg/mL")
        assert unit.name == "mg/mL"
        assert unit.dimension == MASS_CONCENTRATION

    def test_get_molar_unit(self):
        """Test getting a molar concentration unit."""
        unit = get_unit("mM")
        assert unit.name == "mM"
        assert unit.dimension == MOLAR_CONCENTRATION

    def test_create_quantity(self):
        """Test creating a quantity."""
        q = create_quantity(10.0, "mL")
        assert q.value == 10.0
        assert q.unit.name == "mL"

    def test_quantity_conversion(self):
        """Test converting between compatible units."""
        q = create_quantity(1.0, "mL")
        q2 = q.to(get_unit("uL"))
        assert q2.value == pytest.approx(1000.0)
        assert q2.unit.name == "uL"

    def test_quantity_conversion_fail(self):
        """Test that incompatible units raise error."""
        q = create_quantity(10.0, "mL")
        with pytest.raises(TypeError):
            q.to(get_unit("g"))

    def test_quantity_addition(self):
        """Test adding quantities with same dimension."""
        q1 = create_quantity(10.0, "mL")
        q2 = create_quantity(5.0, "mL")
        result = q1 + q2
        assert result.value == 15.0
        assert result.unit.name == "mL"

    def test_quantity_addition_different_units(self):
        """Test adding quantities with different but compatible units."""
        q1 = create_quantity(1.0, "mL")
        q2 = create_quantity(100.0, "uL")
        result = q1 + q2
        assert result.value == pytest.approx(1.1)
        assert result.unit.name == "mL"

    def test_quantity_addition_fail(self):
        """Test that adding incompatible dimensions raises error."""
        q1 = create_quantity(10.0, "mL")
        q2 = create_quantity(5.0, "g")
        with pytest.raises(TypeError):
            _ = q1 + q2

    def test_quantity_multiplication_scalar(self):
        """Test multiplying quantity by scalar."""
        q = create_quantity(10.0, "mL")
        result = q * 2
        assert result.value == 20.0
        assert result.unit.name == "mL"

    def test_quantity_division_scalar(self):
        """Test dividing quantity by scalar."""
        q = create_quantity(10.0, "mL")
        result = q / 2
        assert result.value == 5.0
        assert result.unit.name == "mL"

    def test_quantity_division_quantity(self):
        """Test dividing quantity by quantity."""
        mass = create_quantity(10.0, "g")
        volume = create_quantity(100.0, "mL")
        result = mass / volume
        # Should produce a concentration-like dimension
        assert result.unit.dimension == MASS_CONCENTRATION

    def test_quantity_multiplication_uses_derived_category(self):
        """Test multiplication no longer uses unrelated placeholder categories."""
        volume = create_quantity(2.0, "mL")
        duration = create_quantity(3.0, "s")
        result = volume * duration
        assert result.unit.dimension == VOLUME * TIME
        assert result.unit.category == UnitCategory.DERIVED

    def test_reducible_derived_expression_simplifies_to_canonical_unit(self):
        """Test derived expressions simplify deterministically when reducible."""
        speed_like = create_quantity(10.0, "m") / create_quantity(2.0, "s")
        restored_length = speed_like * create_quantity(2.0, "s")
        assert restored_length.unit.name == "m"
        assert restored_length.unit.category == UnitCategory.LENGTH
        assert restored_length.unit.dimension == get_unit("m").dimension


class TestUnitCompatibility:
    """Test unit compatibility checking."""

    def test_same_unit_compatible(self):
        """Test that same units are compatible."""
        u1 = get_unit("mL")
        u2 = get_unit("mL")
        assert are_compatible(u1, u2)

    def test_same_dimension_compatible(self):
        """Test that same dimension units are compatible."""
        u1 = get_unit("mL")
        u2 = get_unit("uL")
        assert are_compatible(u1, u2)

    def test_different_dimension_incompatible(self):
        """Test that different dimensions are incompatible."""
        u1 = get_unit("mL")
        u2 = get_unit("g")
        assert not are_compatible(u1, u2)

    def test_compatibility_is_dimension_first(self):
        """Test compatibility uses dimension vectors, not category labels."""
        volume_with_wrong_category = Unit(
            name="volume_alias",
            dimension=VOLUME,
            scale=1e-3,
            category=UnitCategory.MASS,
        )
        assert are_compatible(get_unit("mL"), volume_with_wrong_category)

    def test_incompatible_arithmetic_emits_deterministic_diagnostic(self):
        """Test incompatible arithmetic emits stable diagnostic metadata."""
        q1 = create_quantity(1.0, "mL")
        q2 = create_quantity(1.0, "g")
        with pytest.raises(UnitDimensionError) as exc_info:
            _ = q1 + q2
        error = exc_info.value
        assert error.code == "UNIT_DIMENSION_MISMATCH_ARITHMETIC"
        assert error.operation == "+"
        assert str(error) == (
            "[UNIT_DIMENSION_MISMATCH_ARITHMETIC] incompatible dimensions for '+': "
            "VOLUME vs MASS"
        )

    def test_incompatible_derivation_emits_deterministic_diagnostic(self):
        """Test derive operation incompatibility emits deterministic diagnostics."""
        with pytest.raises(UnitDimensionError) as exc_info:
            derive_unit_from_operation(get_unit("mL"), "+", get_unit("g"))
        error = exc_info.value
        assert error.code == "UNIT_DIMENSION_MISMATCH_ARITHMETIC"
        assert error.operation == "+"


class TestConcentration:
    """Test concentration handling."""

    def test_create_mass_concentration(self):
        """Test creating a mass concentration."""
        conc = create_concentration(50.0, "mg/mL")
        assert conc.value == 50.0
        assert conc.concentration_type == ConcentrationType.MASS

    def test_create_molar_concentration(self):
        """Test creating a molar concentration."""
        conc = create_concentration(1.0, "mM")
        assert conc.value == 1.0
        assert conc.concentration_type == ConcentrationType.MOLAR

    def test_mass_to_molar_requires_mw(self):
        """Test that converting mass to molar requires MW."""
        conc = create_concentration(58.44, "g/L")
        with pytest.raises(TypeError):
            conc.to_molar_concentration()

    def test_mass_to_molar_with_mw(self):
        """Test converting mass to molar with MW."""
        conc = create_concentration(58.44, "g/L")
        mw = create_quantity(58.44, "g/mol")
        result = conc.to_molar_concentration(mw)
        assert result.concentration_type == ConcentrationType.MOLAR
        assert result.value == pytest.approx(1.0)

    def test_molar_to_mass_with_mw(self):
        """Test converting molar to mass with MW."""
        conc = create_concentration(1.0, "M")
        mw = create_quantity(58.44, "g/mol")
        result = conc.to_mass_concentration(mw)
        assert result.concentration_type == ConcentrationType.MASS
        assert result.value == pytest.approx(58.44)

    def test_derive_concentration_mass_over_volume(self):
        """Test deriving concentration from mass / volume."""
        mass = create_quantity(10.0, "g")
        volume = create_quantity(1.0, "L")
        result = derive_concentration_from_division(mass, volume)
        assert result is not None
        value, conc_type = result
        assert conc_type == ConcentrationType.MASS
        assert value == pytest.approx(10.0)

    def test_derive_concentration_moles_over_volume(self):
        """Test deriving concentration from moles / volume."""
        moles = create_quantity(1.0, "mol")
        volume = create_quantity(1.0, "L")
        result = derive_concentration_from_division(moles, volume)
        assert result is not None
        value, conc_type = result
        assert conc_type == ConcentrationType.MOLAR
        assert value == pytest.approx(1.0)


class TestMWCalculations:
    """Test molecular weight calculations."""

    def test_calculate_mass_from_molar(self):
        """Test calculating mass from moles and MW."""
        moles = create_quantity(1.0, "mol")
        mw = create_quantity(58.44, "g/mol")
        mass = calculate_mass_from_molar(moles, mw)
        assert mass.value == pytest.approx(58.44)
        assert mass.unit.name == "g"

    def test_calculate_moles_from_mass(self):
        """Test calculating moles from mass and MW."""
        mass = create_quantity(58.44, "g")
        mw = create_quantity(58.44, "g/mol")
        moles = calculate_moles_from_mass(mass, mw)
        assert moles.value == pytest.approx(1.0)
        assert moles.unit.name == "mol"


class TestBuiltinTypes:
    """Test builtin type definitions."""

    def test_primitive_types(self):
        """Test primitive type existence."""
        assert NUMBER is not None
        assert STRING is not None
        assert BOOLEAN is not None

    def test_quantity_types(self):
        """Test quantity type existence."""
        assert VOLUME_TYPE is not None
        assert MASS_TYPE is not None
        assert CONCENTRATION_TYPE is not None

    def test_get_type_by_name(self):
        """Test looking up types by name."""
        volume = get_type("Volume")
        assert volume == VOLUME_TYPE

        mass = get_type("Mass")
        assert mass == MASS_TYPE

    def test_concentration_is_sum_type(self):
        """Test that Concentration is a sum of mass and molar concentration."""
        from bpl.types import SumType
        assert isinstance(CONCENTRATION_TYPE, SumType)
        assert MASS_CONCENTRATION_TYPE in CONCENTRATION_TYPE.variants
        assert MOLAR_CONCENTRATION_TYPE in CONCENTRATION_TYPE.variants

    def test_quantity_type_allowed_units(self):
        """Test that quantity types have allowed units."""
        assert VOLUME_TYPE.allowed_units is not None
        assert MASS_TYPE.allowed_units is not None
        assert "mL" in VOLUME_TYPE.allowed_units
        assert "L" in VOLUME_TYPE.allowed_units
        assert "g" in MASS_TYPE.allowed_units
        assert "mg" in MASS_TYPE.allowed_units


class TestUnitNormalization:
    """Test unit normalization for display."""

    def test_normalize_small_volume(self):
        """Test normalizing small volumes to uL."""
        registry = get_registry()
        q = create_quantity(0.001, "mL")  # 1 uL
        normalized = registry.normalize(q)
        assert normalized.value == pytest.approx(1.0)
        assert normalized.unit.name == "uL"

    def test_normalize_large_volume(self):
        """Test normalizing large volumes to mL."""
        registry = get_registry()
        q = create_quantity(1000.0, "uL")  # 1 mL
        normalized = registry.normalize(q)
        assert normalized.value == pytest.approx(1.0)
        assert normalized.unit.name == "mL"
