"""
Tests for BPL declaration parsing.
"""

from bpl.parser import parse
from bpl.ast import (
    ProtocolDecl, ReagentDecl, StockDecl, LabwareDecl,
    DeckModelDecl, TargetDecl, ResourceDecl, TypeDecl,
    FunctionDecl, IntentDecl, PrimitiveDecl, ImportDecl,
    ModuleDecl, RecoveryDecl, InvariantDecl,
    PhysicalForm, Footprint, LabwareCategory,
)


class TestProtocolDecl:
    """Test protocol declaration parsing."""

    def test_simple_protocol(self):
        """Test simple protocol declaration."""
        ast = parse("""
            protocol SimpleTest {
                let x = 10 mL
            }
        """)
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        assert decl.name == "SimpleTest"
        assert len(decl.body) == 1

    def test_protocol_with_parameters(self):
        """Test protocol with parameters."""
        ast = parse("""
            protocol Test(dna: DNA, volume: Volume = 10 uL) {
                add(dna, volume: volume)
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.parameters) == 2
        assert decl.parameters[0].name == "dna"
        assert decl.parameters[1].default_value is not None

    def test_protocol_with_settings(self):
        """Test protocol with protocol settings."""
        ast = parse("""
            protocol Test {
                @default_compliance: Research
                @error_policy: Stop
                let x = 10
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.settings) == 2
        assert decl.settings[0].name == "default_compliance"

    def test_protocol_with_annotations(self):
        """Test protocol with annotations."""
        ast = parse("""
            @version("1.0")
            @author(name: "Test")
            protocol Test {
                let x = 10
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.annotations) == 2


class TestReagentDecl:
    """Test reagent declaration parsing."""

    def test_simple_reagent(self):
        """Test simple reagent declaration."""
        ast = parse("""
            reagent NaCl {
                physical_form: Solid
                MW: 58.44 g/mol
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ReagentDecl)
        assert decl.name == "NaCl"
        assert decl.physical_form == PhysicalForm.SOLID
        assert decl.mw is not None

    def test_reagent_liquid(self):
        """Test liquid reagent."""
        ast = parse("""
            reagent Water {
                physical_form: Liquid
                MW: 18.015 g/mol
            }
        """)
        decl = ast.declarations[0]
        assert decl.physical_form == PhysicalForm.LIQUID

    def test_reagent_with_fields(self):
        """Test reagent with custom fields."""
        ast = parse("""
            reagent Test {
                physical_form: Solid
                MW: 100 g/mol
                purity: 99.9
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.fields) == 1
        assert decl.fields[0].name == "purity"


class TestStockDecl:
    """Test stock declaration parsing."""

    def test_simple_stock(self):
        """Test simple stock declaration."""
        ast = parse("""
            stock Kanamycin_1000X {
                reagent: Kanamycin
                concentration: 50 mg/mL
                solvent: Water
                fold: 1000X
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, StockDecl)
        assert decl.name == "Kanamycin_1000X"
        assert decl.reagent == "Kanamycin"
        assert decl.solvent == "Water"
        assert decl.fold is not None


class TestLabwareDecl:
    """Test labware declaration parsing."""

    def test_simple_labware(self):
        """Test simple labware declaration."""
        ast = parse("""
            labware DeepWellPlate_96 {
                footprint: SBS_Standard
                well_count: 96
                well_volume: 2.2 mL
                category: Plate_96
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, LabwareDecl)
        assert decl.name == "DeepWellPlate_96"
        assert decl.footprint == Footprint.SBS_STANDARD
        assert decl.well_count == 96
        assert decl.category == LabwareCategory.PLATE_96

    def test_labware_all_categories(self):
        """Test all labware categories."""
        for cat in ["Plate_96", "Plate_384", "TipRack", "Reservoir", "Tube"]:
            ast = parse(f"""
                labware Test {{
                    footprint: SBS_Standard
                    well_count: 1
                    well_volume: 1 mL
                    category: {cat}
                }}
            """)
            assert ast.declarations[0].category is not None

    def test_labware_with_barcode(self):
        """Test labware with barcode field."""
        ast = parse("""
            labware pcr_plate {
                footprint: SBS_Standard
                well_count: 96
                well_volume: 200 uL
                category: Plate_96
                barcode: "PCRP001"
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, LabwareDecl)
        assert decl.barcode == "PCRP001"

    def test_labware_with_set_identifier(self):
        """Test labware with set_identifier field."""
        ast = parse("""
            labware sample_plate {
                footprint: SBS_Standard
                well_count: 96
                well_volume: 200 uL
                category: Plate_96
                set_identifier: "Set1"
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, LabwareDecl)
        assert decl.set_identifier == "Set1"

    def test_labware_with_barcode_and_set_identifier(self):
        """Test labware with both barcode and set_identifier fields."""
        ast = parse("""
            labware pcr_plate_1 {
                footprint: SBS_Standard
                well_count: 96
                well_volume: 200 uL
                category: Plate_96
                barcode: "PCRP001"
                set_identifier: "BatchA"
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, LabwareDecl)
        assert decl.name == "pcr_plate_1"
        assert decl.footprint == Footprint.SBS_STANDARD
        assert decl.well_count == 96
        assert decl.category == LabwareCategory.PLATE_96
        assert decl.barcode == "PCRP001"
        assert decl.set_identifier == "BatchA"

    def test_labware_without_barcode_and_set_identifier(self):
        """Test that barcode and set_identifier are optional."""
        ast = parse("""
            labware simple_plate {
                footprint: SBS_Standard
                well_count: 96
                well_volume: 200 uL
                category: Plate_96
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, LabwareDecl)
        assert decl.barcode is None
        assert decl.set_identifier is None


class TestDeckModelDecl:
    """Test deck model declaration parsing."""

    def test_simple_deck(self):
        """Test simple deck model."""
        ast = parse("""
            deck_model Biomek_i7 {
                positions: [
                    { id: "P1", accepts: [SBS_Standard] },
                    { id: "Waste", is_waste: true }
                ]
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, DeckModelDecl)
        assert decl.name == "Biomek_i7"
        assert len(decl.positions) == 2
        assert decl.positions[0].id == "P1"
        assert decl.positions[1].is_waste is True


class TestTargetDecl:
    """Test target declaration parsing."""

    def test_simple_target(self):
        """Test simple target declaration."""
        ast = parse("""
            target Biomek_i7 {
                capabilities: [aspirate, dispense, pick_tips, drop_tips]
                NOT: [vortex, weigh]
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, TargetDecl)
        assert decl.name == "Biomek_i7"
        assert "aspirate" in decl.capabilities
        assert "vortex" in decl.not_capabilities


class TestResourceDecl:
    """Test resource declaration parsing (v2.4)."""

    def test_simple_resource(self):
        """Test simple resource declaration."""
        ast = parse("""
            resource Centrifuge_1 {
                capacity: 1
                booking_required: true
                cooldown: 30 s
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ResourceDecl)
        assert decl.name == "Centrifuge_1"
        assert decl.capacity == 1
        assert decl.booking_required is True
        assert decl.cooldown is not None


class TestTypeDecl:
    """Test type declaration parsing."""

    def test_type_alias(self):
        """Test simple type alias."""
        ast = parse("type Concentration = MassConcentration")
        decl = ast.declarations[0]
        assert isinstance(decl, TypeDecl)
        assert decl.name == "Concentration"

    def test_sum_type(self):
        """Test sum type (union)."""
        ast = parse("type Concentration = MassConcentration | MolarConcentration")
        decl = ast.declarations[0]
        assert isinstance(decl, TypeDecl)


class TestFunctionDecl:
    """Test function declaration parsing."""

    def test_simple_function(self):
        """Test simple function."""
        ast = parse("""
            function calculate_volume(conc: Concentration, mass: Mass) -> Volume {
                return mass / conc
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, FunctionDecl)
        assert decl.name == "calculate_volume"
        assert len(decl.parameters) == 2
        assert decl.return_type is not None
        assert decl.body is not None


class TestIntentPrimitiveDecl:
    """Test intent and primitive declaration parsing."""

    def test_intent(self):
        """Test intent declaration."""
        ast = parse("intent add(source: Source, to: Destination, volume: Volume) -> StateTransition")
        decl = ast.declarations[0]
        assert isinstance(decl, IntentDecl)
        assert decl.name == "add"
        assert len(decl.parameters) == 3

    def test_primitive(self):
        """Test primitive declaration."""
        ast = parse("primitive aspirate(from: WellRef, volume: Volume, speed: VolumeRate)")
        decl = ast.declarations[0]
        assert isinstance(decl, PrimitiveDecl)
        assert decl.name == "aspirate"


class TestImportDecl:
    """Test import declaration parsing."""

    def test_simple_import(self):
        """Test simple import."""
        ast = parse('import stdlib.reagents version "1.0"')
        decl = ast.declarations[0]
        assert isinstance(decl, ImportDecl)
        assert decl.path == ["stdlib", "reagents"]

    def test_import_with_alias(self):
        """Test import with alias."""
        ast = parse("import stdlib.reagents as reagents")
        decl = ast.declarations[0]
        assert decl.alias == "reagents"

    def test_from_import(self):
        """Test from ... import."""
        ast = parse('from stdlib.media version "2.1" import LB, YPD')
        decl = ast.declarations[0]
        assert isinstance(decl, ImportDecl)
        assert len(decl.names) == 2


class TestModuleDecl:
    """Test module declaration parsing."""

    def test_simple_module(self):
        """Test simple module."""
        ast = parse("""
            module stdlib.reagents {
                reagent Water {
                    physical_form: Liquid
                    MW: 18.015 g/mol
                }
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ModuleDecl)
        assert decl.qualified_name == ["stdlib", "reagents"]
        assert len(decl.members) == 1


class TestRecoveryDecl:
    """Test recovery declaration parsing (v2.4)."""

    def test_simple_recovery(self):
        """Test simple recovery procedure."""
        ast = parse("""
            @for_error(TipClog)
            recovery TipClogRecovery {
                drop_tips(to: Waste)
                pick_tips(type: Standard)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, RecoveryDecl)
        assert decl.name == "TipClogRecovery"
        assert len(decl.body) == 2


class TestInvariantDecl:
    """Test invariant declaration parsing (v2.4)."""

    def test_simple_invariant(self):
        """Test simple invariant."""
        ast = parse("""
            invariant "cell_viability" {
                check: cells.viability > 0.9
                after: [centrifuge, resuspend]
                on_violation: AlertAndContinue
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, InvariantDecl)
        assert decl.name == "cell_viability"
        assert decl.check is not None
        assert len(decl.after) == 2


class TestPcrProfileDecl:
    """Test PCR profile declaration parsing."""

    def test_simple_pcr_profile(self):
        """Test simple PCR profile declaration."""
        from bpl.ast import PcrProfileDecl

        ast = parse("""
            pcr_profile Q5_Standard {
                initial: 98 degC for 30 s
                cycles: 34 {
                    denature: 98 degC for 10 s
                    anneal: 60 degC for 30 s
                    extend: 72 degC for 20 s
                }
                final: 72 degC for 2 min
                hold: 4 degC
            }
        """)
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, PcrProfileDecl)
        assert decl.name == "Q5_Standard"

    def test_pcr_profile_initial_step(self):
        """Test PCR profile initial denaturation step."""
        from bpl.ast import PcrProfileDecl

        ast = parse("""
            pcr_profile Test {
                initial: 98 degC for 30 s
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, PcrProfileDecl)
        assert decl.initial_temp is not None
        assert decl.initial_temp.value.value == 98.0
        assert decl.initial_duration is not None
        assert decl.initial_duration.value.value == 30.0

    def test_pcr_profile_cycles(self):
        """Test PCR profile cycling steps."""
        from bpl.ast import PcrProfileDecl

        ast = parse("""
            pcr_profile Test {
                cycles: 30 {
                    denature: 98 degC for 10 s
                    anneal: 55 degC for 30 s
                    extend: 72 degC for 60 s
                }
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, PcrProfileDecl)
        assert decl.cycle_count == 30
        assert len(decl.cycle_steps) == 3

        # Check cycle step details
        assert decl.cycle_steps[0].name == "denature"
        assert decl.cycle_steps[0].temperature.value.value == 98.0
        assert decl.cycle_steps[0].duration.value.value == 10.0

        assert decl.cycle_steps[1].name == "anneal"
        assert decl.cycle_steps[1].temperature.value.value == 55.0

        assert decl.cycle_steps[2].name == "extend"
        assert decl.cycle_steps[2].temperature.value.value == 72.0

    def test_pcr_profile_final_extension(self):
        """Test PCR profile final extension step."""

        ast = parse("""
            pcr_profile Test {
                final: 72 degC for 5 min
            }
        """)
        decl = ast.declarations[0]
        assert decl.final_temp is not None
        assert decl.final_temp.value.value == 72.0
        assert decl.final_duration is not None
        assert decl.final_duration.value.value == 5.0

    def test_pcr_profile_hold(self):
        """Test PCR profile hold step."""

        ast = parse("""
            pcr_profile Test {
                hold: 4 degC
            }
        """)
        decl = ast.declarations[0]
        assert decl.hold_temp is not None
        assert decl.hold_temp.value.value == 4.0

    def test_pcr_profile_lid_temp(self):
        """Test PCR profile lid temperature."""

        ast = parse("""
            pcr_profile Test {
                lid_temp: 105 degC
            }
        """)
        decl = ast.declarations[0]
        assert decl.lid_temp is not None
        assert decl.lid_temp.value.value == 105.0

    def test_complete_pcr_profile(self):
        """Test complete PCR profile with all steps."""
        from bpl.ast import PcrProfileDecl

        ast = parse("""
            pcr_profile Q5_HotStart {
                initial: 98 degC for 30 s
                cycles: 35 {
                    denature: 98 degC for 10 s
                    anneal: 62 degC for 20 s
                    extend: 72 degC for 30 s
                }
                final: 72 degC for 2 min
                hold: 4 degC
                lid_temp: 105 degC
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, PcrProfileDecl)
        assert decl.name == "Q5_HotStart"
        assert decl.initial_temp is not None
        assert decl.cycle_count == 35
        assert len(decl.cycle_steps) == 3
        assert decl.final_temp is not None
        assert decl.hold_temp is not None
        assert decl.lid_temp is not None

    def test_pcr_profile_two_step_cycling(self):
        """Test two-step PCR cycling (combined annealing/extension)."""

        ast = parse("""
            pcr_profile TwoStep {
                initial: 95 degC for 2 min
                cycles: 30 {
                    denature: 95 degC for 15 s
                    anneal_extend: 68 degC for 60 s
                }
                final: 68 degC for 5 min
                hold: 4 degC
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.cycle_steps) == 2
        assert decl.cycle_steps[1].name == "anneal_extend"
