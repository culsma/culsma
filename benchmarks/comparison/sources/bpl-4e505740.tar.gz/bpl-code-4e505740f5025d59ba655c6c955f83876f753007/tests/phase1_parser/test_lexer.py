"""
Tests for BPL lexer - token recognition.
"""

import pytest
from bpl.parser import parse, BPLSyntaxError
from bpl.ast import QuantityExpr


class TestCompoundUnits:
    """Test that compound units are recognized correctly."""

    def test_mg_per_ml(self):
        """Test mg/mL is recognized as compound unit, not division."""
        ast = parse("protocol Test { let x = 50 mg/mL }")
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt.value, QuantityExpr)
        assert stmt.value.unit.text == "mg/mL"

    def test_g_per_l(self):
        """Test g/L is recognized as compound unit."""
        ast = parse("protocol Test { let x = 10 g/L }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "g/L"

    def test_ug_per_ml(self):
        """Test ug/mL is recognized as compound unit."""
        ast = parse("protocol Test { let x = 100 ug/mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "ug/mL"

    def test_mol_per_l(self):
        """Test mol/L is recognized as compound unit."""
        ast = parse("protocol Test { let x = 1 mol/L }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "mol/L"

    def test_ul_per_s(self):
        """Test uL/s is recognized as compound unit."""
        ast = parse("protocol Test { let x = 5 uL/s }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "uL/s"

    def test_g_per_mol(self):
        """Test g/mol is recognized as compound unit."""
        ast = parse("reagent NaCl { MW: 58.44 g/mol }")
        decl = ast.declarations[0]
        assert decl.mw.unit.text == "g/mol"


class TestSimpleUnits:
    """Test simple unit recognition."""

    def test_volume_units(self):
        """Test volume units: mL, uL, nL, L."""
        for unit in ["mL", "uL", "nL", "L"]:
            ast = parse(f"protocol Test {{ let x = 10 {unit} }}")
            stmt = ast.declarations[0].body[0]
            assert stmt.value.unit.text == unit

    def test_mass_units(self):
        """Test mass units: kg, mg, ug, ng, pg, g."""
        for unit in ["kg", "mg", "ug", "ng", "pg", "g"]:
            ast = parse(f"protocol Test {{ let x = 10 {unit} }}")
            stmt = ast.declarations[0].body[0]
            assert stmt.value.unit.text == unit

    def test_time_units(self):
        """Test time units: min, ms, s, h."""
        for unit in ["min", "ms", "s", "h"]:
            ast = parse(f"protocol Test {{ let x = 10 {unit} }}")
            stmt = ast.declarations[0].body[0]
            assert stmt.value.unit.text == unit

    def test_temperature(self):
        """Test temperature unit: degC."""
        ast = parse("protocol Test { let x = 37 degC }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "degC"

    def test_rpm(self):
        """Test rpm unit."""
        ast = parse("protocol Test { let x = 3000 rpm }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "rpm"


class TestMolarUnits:
    """Test molar concentration units."""

    def test_molar_M(self):
        """Test M (molar) unit."""
        ast = parse("protocol Test { let x = 1 M }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "M"

    def test_millimolar(self):
        """Test mM (millimolar) unit."""
        ast = parse("protocol Test { let x = 10 mM }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "mM"

    def test_micromolar(self):
        """Test uM (micromolar) unit."""
        ast = parse("protocol Test { let x = 100 uM }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "uM"

    def test_nanomolar(self):
        """Test nM (nanomolar) unit."""
        ast = parse("protocol Test { let x = 50 nM }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "nM"


class TestPercentLiterals:
    """Test percent literal recognition."""

    def test_percent_with_space(self):
        """Test percent with space: 50 %."""
        ast = parse("protocol Test { let x = 50 % }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "%"
        assert stmt.value.value.value == 50.0

    def test_percent_literal(self):
        """Test percent literal: 50%."""
        ast = parse("protocol Test { let x = 50% }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.unit.text == "%"
        assert stmt.value.value.value == 50.0


class TestFoldUnits:
    """Test fold factor units."""

    def test_fold_unit(self):
        """Test fold factor: 1000X."""
        ast = parse("""
            stock Test {
                reagent: Something
                concentration: 50 mg/mL
                solvent: Water
                fold: 1000X
            }
        """)
        decl = ast.declarations[0]
        assert decl.fold.unit.text == "X"
        assert decl.fold.value.value == 1000.0


class TestComments:
    """Test that comments are properly ignored."""

    def test_line_comment(self):
        """Test single-line comments are ignored."""
        ast = parse("""
            // This is a comment
            protocol Test {
                // Another comment
                let x = 10 mL
            }
        """)
        assert len(ast.declarations) == 1

    def test_block_comment(self):
        """Test block comments are ignored."""
        ast = parse("""
            /* This is a
               block comment */
            protocol Test {
                let x = 10 mL
            }
        """)
        assert len(ast.declarations) == 1


class TestKeywords:
    """Test keyword recognition."""

    def test_keywords_not_identifiers(self):
        """Keywords should not be usable as identifiers."""
        keywords = ["protocol", "let", "if", "else", "for", "while", "return"]
        for kw in keywords:
            with pytest.raises(BPLSyntaxError):
                parse(f"protocol Test {{ let {kw} = 10 }}")


class TestNumbers:
    """Test number literal recognition."""

    def test_integer(self):
        """Test integer literals."""
        ast = parse("protocol Test { let x = 42 mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.value.value == 42.0

    def test_float(self):
        """Test float literals."""
        ast = parse("protocol Test { let x = 3.14 mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.value.value == 3.14

    def test_scientific(self):
        """Test scientific notation."""
        ast = parse("protocol Test { let x = 1e6 mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.value.value == 1e6

    def test_scientific_negative_exp(self):
        """Test scientific notation with negative exponent."""
        ast = parse("protocol Test { let x = 1.5e-3 mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value.value.value == 1.5e-3
