"""
Tests for BPL worklist intent parsing (v2.5).
"""

from bpl.parser import parse
from bpl.ast import (
    ProtocolDecl,
    StampStmt,
    CherrypickStmt,
    SerialDiluteStmt,
)


class TestStampStmt:
    """Test stamp statement parsing."""

    def test_simple_stamp(self):
        """Test simple stamp statement."""
        ast = parse("""
            protocol test {
                stamp(from: source_plate, to: dest_plate, volume: 10 uL)
            }
        """)
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        assert len(decl.body) == 1

        stmt = decl.body[0]
        assert isinstance(stmt, StampStmt)
        assert stmt.source_plate == "source_plate"
        assert stmt.dest_plate == "dest_plate"
        assert stmt.volume is not None
        assert stmt.volume.value.value == 10.0

    def test_stamp_with_microliters(self):
        """Test stamp with uL unit."""
        ast = parse("""
            protocol test {
                stamp(from: pcr_plate, to: cleanup_plate, volume: 5 uL)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, StampStmt)
        assert stmt.volume.value.value == 5.0


class TestCherrypickStmt:
    """Test cherrypick statement parsing."""

    def test_simple_cherrypick(self):
        """Test simple cherrypick statement."""
        ast = parse("""
            protocol test {
                cherrypick(from: template[A1, B3], to: pcr_plate[A1, A2], volume: 2 uL)
            }
        """)
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        assert len(decl.body) == 1

        stmt = decl.body[0]
        assert isinstance(stmt, CherrypickStmt)
        assert stmt.source_plate == "template"
        assert stmt.source_wells == ["A1", "B3"]
        assert stmt.dest_plate == "pcr_plate"
        assert stmt.dest_wells == ["A1", "A2"]
        assert stmt.volume.value.value == 2.0

    def test_cherrypick_multiple_wells(self):
        """Test cherrypick with multiple wells."""
        ast = parse("""
            protocol test {
                cherrypick(from: inventory[A1, B2, C3, D4], to: setup[A1, A2, A3, A4], volume: 5 uL)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, CherrypickStmt)
        assert len(stmt.source_wells) == 4
        assert len(stmt.dest_wells) == 4
        assert stmt.source_wells == ["A1", "B2", "C3", "D4"]
        assert stmt.dest_wells == ["A1", "A2", "A3", "A4"]

    def test_cherrypick_accepts_multi_letter_rows_pre_semantic(self):
        """Parser accepts generalized multi-letter row notation before semantic checks."""
        ast = parse(
            """
            protocol test {
                cherrypick(from: source[AA01, AB12], to: dest[AA1, AB12], volume: 2 uL)
            }
            """
        )
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, CherrypickStmt)
        assert stmt.source_wells == ["AA1", "AB12"]
        assert stmt.dest_wells == ["AA1", "AB12"]

    def test_cherrypick_accepts_out_of_bounds_tokens_pre_semantic(self):
        """Parser accepts broad well tokens; semantic layer enforces plate bounds."""
        ast = parse(
            """
            protocol test {
                cherrypick(from: source[Z99], to: dest[Z99], volume: 2 uL)
            }
            """
        )
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, CherrypickStmt)
        assert stmt.source_wells == ["Z99"]
        assert stmt.dest_wells == ["Z99"]


class TestSerialDiluteStmt:
    """Test serial_dilute statement parsing."""

    def test_simple_serial_dilute(self):
        """Test simple serial dilute statement."""
        ast = parse("""
            protocol test {
                serial_dilute(source: growth_plate, destinations: [d1, d2, d3, d4], volume: 20 uL, steps: 4)
            }
        """)
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        assert len(decl.body) == 1

        stmt = decl.body[0]
        assert isinstance(stmt, SerialDiluteStmt)
        assert stmt.source_plate == "growth_plate"
        assert stmt.dest_plates == ["d1", "d2", "d3", "d4"]
        assert stmt.volume.value.value == 20.0
        assert stmt.dilution_steps == 4

    def test_serial_dilute_twelve_steps(self):
        """Test serial dilute with 12 steps."""
        ast = parse("""
            protocol test {
                serial_dilute(source: stock, destinations: [a, b, c, d, e, f, g, h, i, j, k, l], volume: 10 uL, steps: 12)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, SerialDiluteStmt)
        assert len(stmt.dest_plates) == 12
        assert stmt.dilution_steps == 12


class TestWorklistIntentIntegration:
    """Integration tests for worklist intents."""

    def test_combined_protocol(self):
        """Test protocol with multiple worklist intents."""
        ast = parse("""
            protocol pcr_workflow {
                stamp(from: pcr_reaction_plate, to: cleanup_plate, volume: 10 uL)

                cherrypick(from: template_inventory[A1, B3, C5], to: pcr_setup[A1, A2, A3], volume: 2 uL)

                serial_dilute(source: growth, destinations: [d1, d2, d3, d4], volume: 20 uL, steps: 4)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        assert len(decl.body) == 3

        assert isinstance(decl.body[0], StampStmt)
        assert isinstance(decl.body[1], CherrypickStmt)
        assert isinstance(decl.body[2], SerialDiluteStmt)

    def test_worklist_with_annotations(self):
        """Test worklist intents with annotations."""
        ast = parse("""
            protocol annotated_workflow {
                @checkpoint("stamp_complete")
                stamp(from: source, to: dest, volume: 10 uL)
            }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl, ProtocolDecl)
        stmt = decl.body[0]
        assert isinstance(stmt, StampStmt)
        assert len(stmt.annotations) == 1
        assert stmt.annotations[0].name == "checkpoint"
