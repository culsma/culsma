"""
Tests for BPL statement parsing.
"""

from bpl.parser import parse
from bpl.ast import (
    LetStmt, AssignStmt, CallStmt, IfStmt,
    ForStmt, WhileStmt, ReturnStmt, ParallelBlock, SequenceBlock,
)


class TestLetStatement:
    """Test let statement parsing."""

    def test_simple_let(self):
        """Test simple let statement."""
        ast = parse("protocol T { let x = 10 }")
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, LetStmt)
        assert stmt.name == "x"

    def test_let_with_type(self):
        """Test let with type annotation."""
        ast = parse("protocol T { let x: Volume = 10 mL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.type_annotation is not None

    def test_let_quantity(self):
        """Test let with quantity."""
        ast = parse("protocol T { let volume = 50 uL }")
        stmt = ast.declarations[0].body[0]
        assert stmt.value is not None


class TestAssignStatement:
    """Test reassignment statement parsing."""

    def test_simple_reassign(self):
        """Test simple reassignment."""
        ast = parse("protocol T { x = 20 }")
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, AssignStmt)
        assert stmt.target == "x"


class TestCallStatement:
    """Test call statement parsing."""

    def test_simple_call(self):
        """Test simple function call."""
        ast = parse("protocol T { transfer(from: source, to: dest) }")
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, CallStmt)
        assert stmt.name == "transfer"

    def test_call_with_named_args(self):
        """Test call with named arguments."""
        ast = parse("protocol T { add(Water, volume: 10 mL, to: tube) }")
        stmt = ast.declarations[0].body[0]
        assert len(stmt.arguments) == 3


class TestIfStatement:
    """Test if statement parsing."""

    def test_simple_if(self):
        """Test simple if statement."""
        ast = parse("""
            protocol T {
                if x > 10 {
                    foo()
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, IfStmt)
        assert stmt.then_block is not None
        assert stmt.else_block is None

    def test_if_else(self):
        """Test if-else statement."""
        ast = parse("""
            protocol T {
                if x > 10 {
                    foo()
                } else {
                    bar()
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.else_block is not None

    def test_if_else_if(self):
        """Test if-else if-else chain."""
        ast = parse("""
            protocol T {
                if x > 10 {
                    foo()
                } else if x > 5 {
                    bar()
                } else {
                    baz()
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert len(stmt.else_ifs) == 1
        assert stmt.else_block is not None


class TestForStatement:
    """Test for statement parsing."""

    def test_simple_for(self):
        """Test simple for loop."""
        ast = parse("""
            protocol T {
                for well in plate.wells {
                    transfer(from: source, to: well)
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, ForStmt)
        assert stmt.variable == "well"

    def test_for_with_range(self):
        """Test for loop with range."""
        ast = parse("""
            protocol T {
                for i in 1..10 {
                    foo(i)
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, ForStmt)


class TestWhileStatement:
    """Test while statement parsing."""

    def test_simple_while(self):
        """Test simple while loop."""
        ast = parse("""
            protocol T {
                while temperature < 37 {
                    wait(1 min)
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, WhileStmt)
        assert stmt.condition is not None
        assert stmt.body is not None


class TestReturnStatement:
    """Test return statement parsing."""

    def test_return_value(self):
        """Test return with value."""
        ast = parse("""
            function test() -> Number {
                return 42
            }
        """)
        stmt = ast.declarations[0].body.statements[0]
        assert isinstance(stmt, ReturnStmt)
        assert stmt.value is not None

    def test_return_empty(self):
        """Test return without value."""
        ast = parse("""
            function test() {
                return
            }
        """)
        stmt = ast.declarations[0].body.statements[0]
        assert isinstance(stmt, ReturnStmt)
        assert stmt.value is None


class TestParallelBlock:
    """Test parallel block parsing (v2.4)."""

    def test_simple_parallel(self):
        """Test simple parallel block."""
        ast = parse("""
            protocol T {
                parallel {
                    incubate(plate1, 37 degC, 1 h)
                    incubate(plate2, 37 degC, 1 h)
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, ParallelBlock)
        assert len(stmt.statements) == 2


class TestSequenceBlock:
    """Test sequence block parsing (v2.4)."""

    def test_simple_sequence(self):
        """Test simple sequence block."""
        ast = parse("""
            protocol T {
                sequence {
                    step1()
                    step2()
                    step3()
                }
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, SequenceBlock)
        assert len(stmt.statements) == 3


class TestNestedControlFlow:
    """Test nested control flow structures."""

    def test_nested_if_for(self):
        """Test nested if inside for."""
        ast = parse("""
            protocol T {
                for well in plate.wells {
                    if well.volume > 0 {
                        transfer(from: well, to: dest)
                    }
                }
            }
        """)
        for_stmt = ast.declarations[0].body[0]
        assert isinstance(for_stmt, ForStmt)
        if_stmt = for_stmt.body.statements[0]
        assert isinstance(if_stmt, IfStmt)

    def test_nested_for_while(self):
        """Test nested for inside while."""
        ast = parse("""
            protocol T {
                while not done {
                    for i in 1..10 {
                        process(i)
                    }
                }
            }
        """)
        while_stmt = ast.declarations[0].body[0]
        assert isinstance(while_stmt, WhileStmt)
        for_stmt = while_stmt.body.statements[0]
        assert isinstance(for_stmt, ForStmt)


class TestAnnotatedStatements:
    """Test statement annotations."""

    def test_statement_with_annotation(self):
        """Test statement with annotation."""
        ast = parse("""
            protocol T {
                @timeout(5 min)
                incubate(plate, 37 degC, 1 h)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert isinstance(stmt, CallStmt)
        assert len(stmt.annotations) == 1

    def test_multiple_annotations(self):
        """Test statement with multiple annotations."""
        ast = parse("""
            protocol T {
                @critical
                @log_level(Debug)
                transfer(from: source, to: dest)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert len(stmt.annotations) == 2
