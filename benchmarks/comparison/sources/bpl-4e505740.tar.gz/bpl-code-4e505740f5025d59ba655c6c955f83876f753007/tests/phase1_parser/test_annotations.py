"""
Tests for BPL annotation parsing.
"""

from bpl.parser import parse


class TestAnnotationSyntax:
    """Test basic annotation syntax."""

    def test_simple_annotation(self):
        """Test simple annotation without arguments."""
        ast = parse("""
            @critical
            protocol Test {
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.annotations) == 1
        assert decl.annotations[0].name == "critical"

    def test_annotation_with_value(self):
        """Test annotation with single value."""
        ast = parse("""
            @version("1.0")
            protocol Test {
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.annotations) == 1
        assert len(decl.annotations[0].arguments) == 1

    def test_annotation_with_named_args(self):
        """Test annotation with named arguments."""
        ast = parse("""
            @author(name: "Test", email: "test@example.com")
            protocol Test {
                foo()
            }
        """)
        decl = ast.declarations[0]
        ann = decl.annotations[0]
        assert len(ann.arguments) == 2
        assert ann.arguments[0].name == "name"


class TestProtocolSettings:
    """Test protocol-level settings (@name: value)."""

    def test_compliance_setting(self):
        """Test compliance setting."""
        ast = parse("""
            protocol Test {
                @default_compliance: Research
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.settings) == 1
        assert decl.settings[0].name == "default_compliance"

    def test_error_policy_setting(self):
        """Test error policy setting."""
        ast = parse("""
            protocol Test {
                @error_policy: Stop
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert decl.settings[0].name == "error_policy"

    def test_multiple_settings(self):
        """Test multiple protocol settings."""
        ast = parse("""
            protocol Test {
                @default_compliance: GLP
                @error_policy: Retry
                @log_level: Debug
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.settings) == 3


class TestStepAnnotations:
    """Test step-level annotations."""

    def test_timeout_annotation(self):
        """Test @timeout annotation."""
        ast = parse("""
            protocol Test {
                @timeout(5 min)
                incubate(plate, 37 degC, 1 h)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert len(stmt.annotations) == 1
        assert stmt.annotations[0].name == "timeout"

    def test_expected_time_annotation(self):
        """Test @expected_time annotation."""
        ast = parse("""
            protocol Test {
                @expected_time(30 s)
                transfer(from: source, to: dest)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "expected_time"

    def test_checkpoint_annotation(self):
        """Test @checkpoint annotation."""
        ast = parse("""
            protocol Test {
                @checkpoint
                add(reagent, to: tube)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "checkpoint"


class TestErrorPolicyAnnotation:
    """Test @on_error annotation."""

    def test_simple_on_error(self):
        """Test simple @on_error."""
        ast = parse("""
            protocol Test {
                @on_error(Retry)
                transfer(from: source, to: dest)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "on_error"

    def test_on_error_with_count(self):
        """Test @on_error with retry count."""
        ast = parse("""
            protocol Test {
                @on_error(Retry, max_attempts: 3)
                transfer(from: source, to: dest)
            }
        """)
        stmt = ast.declarations[0].body[0]
        ann = stmt.annotations[0]
        assert len(ann.arguments) == 2


class TestSemanticsAnnotation:
    """Test @semantics annotation."""

    def test_zip_semantics(self):
        """Test @semantics(Zip)."""
        ast = parse("""
            protocol Test {
                @semantics(Zip)
                transfer(from: sources, to: dests)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "semantics"

    def test_broadcast_semantics(self):
        """Test @semantics(Broadcast)."""
        ast = parse("""
            protocol Test {
                @semantics(Broadcast)
                add(reagent, to: wells)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "semantics"


class TestComplianceAnnotation:
    """Test @compliance annotation."""

    def test_gxp_compliance(self):
        """Test @compliance(GxP)."""
        ast = parse("""
            @compliance(GxP)
            protocol Test {
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert decl.annotations[0].name == "compliance"

    def test_part11_compliance(self):
        """Test @compliance(Part11)."""
        ast = parse("""
            @compliance(Part11)
            protocol Test {
                @signature_required
                critical_step()
            }
        """)
        decl = ast.declarations[0]
        assert decl.annotations[0].name == "compliance"


class TestAssertAnnotation:
    """Test @assert and @static_assert annotations."""

    def test_assert(self):
        """Test @assert annotation."""
        ast = parse("""
            protocol Test {
                @assert(volume > 0)
                transfer(from: source, to: dest, volume: volume)
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "assert"

    def test_static_assert(self):
        """Test @static_assert annotation."""
        ast = parse("""
            protocol Test {
                @static_assert(MAX_VOLUME > 0)
                foo()
            }
        """)
        stmt = ast.declarations[0].body[0]
        assert stmt.annotations[0].name == "static_assert"
