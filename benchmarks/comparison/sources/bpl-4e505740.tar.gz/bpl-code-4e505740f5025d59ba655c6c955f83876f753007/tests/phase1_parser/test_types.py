"""
Tests for BPL type expression parsing.
"""

from bpl.parser import parse
from bpl.ast import (
    ParameterizedTypeExpr, SumTypeExpr,
    ProductTypeExpr, ConstrainedTypeExpr, TypeVariant,
)


class TestSimpleTypes:
    """Test simple type parsing."""

    def test_simple_type(self):
        """Test simple type reference."""
        ast = parse("type MyType = Volume")
        decl = ast.declarations[0]
        assert decl.name == "MyType"

    def test_parameter_type_annotation(self):
        """Test type in parameter annotation."""
        ast = parse("""
            protocol Test(x: Volume, y: Temperature) {
                foo()
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.parameters) == 2


class TestParameterizedTypes:
    """Test parameterized (generic) type parsing."""

    def test_single_param(self):
        """Test type with single parameter."""
        ast = parse("type MyList = List<Number>")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, ParameterizedTypeExpr)
        assert decl.type_expr.name == "List"
        assert len(decl.type_expr.type_params) == 1

    def test_multiple_params(self):
        """Test type with multiple parameters."""
        ast = parse("type MyMap = Map<String, Number>")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, ParameterizedTypeExpr)
        assert len(decl.type_expr.type_params) == 2


class TestSumTypes:
    """Test sum type (union) parsing."""

    def test_simple_sum(self):
        """Test simple sum type."""
        ast = parse("type Concentration = MassConcentration | MolarConcentration")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, SumTypeExpr)
        assert len(decl.type_expr.variants) == 2

    def test_three_way_sum(self):
        """Test three-way sum type."""
        ast = parse("type Result = Success | Failure | Pending")
        decl = ast.declarations[0]
        assert len(decl.type_expr.variants) == 3

    def test_sum_with_fields(self):
        """Test sum type variants with fields."""
        ast = parse("""
            type Result = Success { value: Number } | Failure { message: String }
        """)
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, SumTypeExpr)
        # Check variants have fields
        for variant in decl.type_expr.variants:
            assert isinstance(variant, TypeVariant)


class TestProductTypes:
    """Test product type (record) parsing."""

    def test_simple_product(self):
        """Test simple product type."""
        ast = parse("type Point = { x: Number, y: Number }")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, ProductTypeExpr)
        assert len(decl.type_expr.fields) == 2

    def test_optional_fields(self):
        """Test product type with optional fields."""
        ast = parse("type Config = { required: Number, optional: String? }")
        decl = ast.declarations[0]
        assert len(decl.type_expr.fields) == 2
        # Second field should be optional
        assert decl.type_expr.fields[1].optional is True


class TestConstrainedTypes:
    """Test constrained type parsing."""

    def test_range_constraint(self):
        """Test number with range constraint."""
        ast = parse("type Percentage = Number constrained [0, 100] with is_percentage")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, ConstrainedTypeExpr)
        assert decl.type_expr.min_value == 0
        assert decl.type_expr.max_value == 100

    def test_validator_only(self):
        """Test number with validator only."""
        ast = parse("type PositiveNumber = Number with is_positive")
        decl = ast.declarations[0]
        assert isinstance(decl.type_expr, ConstrainedTypeExpr)
        assert decl.type_expr.validator == "is_positive"


class TestTypeFields:
    """Test type field parsing."""

    def test_required_field(self):
        """Test required field."""
        ast = parse("type Point = { x: Number }")
        decl = ast.declarations[0]
        field = decl.type_expr.fields[0]
        assert field.name == "x"
        assert field.optional is False

    def test_optional_field(self):
        """Test optional field with ?."""
        ast = parse("type Config = { value: Number? }")
        decl = ast.declarations[0]
        field = decl.type_expr.fields[0]
        assert field.optional is True


class TestFunctionTypes:
    """Test function type annotations."""

    def test_return_type(self):
        """Test function return type."""
        ast = parse("""
            function calc(x: Number) -> Volume {
                return x * 1 mL
            }
        """)
        decl = ast.declarations[0]
        assert decl.return_type is not None

    def test_parameter_types(self):
        """Test function parameter types."""
        ast = parse("""
            function calc(x: Volume, y: Mass) -> Concentration {
                return y / x
            }
        """)
        decl = ast.declarations[0]
        assert len(decl.parameters) == 2
        assert decl.parameters[0].type_annotation is not None
        assert decl.parameters[1].type_annotation is not None


class TestIntentPrimitiveTypes:
    """Test intent and primitive return types."""

    def test_intent_return_type(self):
        """Test intent with return type."""
        ast = parse("intent add(source: Source, to: Destination) -> StateTransition")
        decl = ast.declarations[0]
        assert decl.return_type is not None

    def test_primitive_no_return(self):
        """Test primitive without return type."""
        ast = parse("primitive aspirate(from: WellRef, volume: Volume)")
        decl = ast.declarations[0]
        assert decl.return_type is None
