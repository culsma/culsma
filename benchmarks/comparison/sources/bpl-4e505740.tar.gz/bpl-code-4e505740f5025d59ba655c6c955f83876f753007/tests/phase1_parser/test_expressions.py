"""
Tests for BPL expression parsing.
"""

from bpl.parser import parse
from bpl.ast import (
    BinaryExpr, UnaryExpr, ConditionalExpr, RangeExpr,
    FieldAccessExpr, MethodCallExpr, IndexExpr, QuantityExpr, IdentifierExpr, ListExpr, MapExpr, LambdaExpr,
)


class TestOperatorPrecedence:
    """Test operator precedence is correctly parsed."""

    def test_mul_before_add(self):
        """Multiplication has higher precedence than addition."""
        ast = parse("protocol T { let x = 1 + 2 * 3 }")
        expr = ast.declarations[0].body[0].value
        # Should be: 1 + (2 * 3)
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "+"
        assert isinstance(expr.right, BinaryExpr)
        assert expr.right.op == "*"

    def test_parentheses_override(self):
        """Parentheses override precedence."""
        ast = parse("protocol T { let x = (1 + 2) * 3 }")
        expr = ast.declarations[0].body[0].value
        # Should be: (1 + 2) * 3
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "*"
        assert isinstance(expr.left, BinaryExpr)
        assert expr.left.op == "+"

    def test_comparison_precedence(self):
        """Comparison operators have lower precedence than arithmetic."""
        ast = parse("protocol T { let x = a + b < c * d }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "<"

    def test_logical_and_or_precedence(self):
        """AND has higher precedence than OR."""
        ast = parse("protocol T { let x = a || b && c }")
        expr = ast.declarations[0].body[0].value
        # Should be: a || (b && c)
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "||"
        assert isinstance(expr.right, BinaryExpr)
        assert expr.right.op == "&&"

    def test_unary_highest_precedence(self):
        """Unary operators have highest precedence."""
        ast = parse("protocol T { let x = -a * b }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "*"
        assert isinstance(expr.left, UnaryExpr)
        assert expr.left.op == "-"


class TestQuantityExpressions:
    """Test quantity (number + unit) expressions."""

    def test_simple_quantity(self):
        """Test simple quantity with unit."""
        ast = parse("protocol T { let x = 10 mL }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, QuantityExpr)
        assert expr.value.value == 10.0
        assert expr.unit.text == "mL"

    def test_compound_quantity(self):
        """Test compound unit quantity."""
        ast = parse("protocol T { let x = 50 mg/mL }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, QuantityExpr)
        assert expr.value.value == 50.0
        assert expr.unit.text == "mg/mL"

    def test_quantity_in_arithmetic(self):
        """Test quantities in arithmetic expressions."""
        ast = parse("protocol T { let x = 10 mL + 5 mL }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, BinaryExpr)
        assert expr.op == "+"
        assert isinstance(expr.left, QuantityExpr)
        assert isinstance(expr.right, QuantityExpr)


class TestListLiterals:
    """Test list literal parsing."""

    def test_empty_list(self):
        """Test empty list."""
        ast = parse("protocol T { let x = [] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, ListExpr)
        assert len(expr.elements) == 0

    def test_number_list(self):
        """Test list of numbers."""
        ast = parse("protocol T { let x = [1, 2, 3] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, ListExpr)
        assert len(expr.elements) == 3

    def test_trailing_comma(self):
        """Test trailing comma is allowed."""
        ast = parse("protocol T { let x = [1, 2, 3,] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, ListExpr)
        assert len(expr.elements) == 3

    def test_nested_list(self):
        """Test nested lists."""
        ast = parse("protocol T { let x = [[1, 2], [3, 4]] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, ListExpr)
        assert len(expr.elements) == 2
        assert isinstance(expr.elements[0], ListExpr)


class TestMapLiterals:
    """Test map literal parsing."""

    def test_empty_map(self):
        """Test empty map."""
        ast = parse("protocol T { let x = {} }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MapExpr)
        assert len(expr.entries) == 0

    def test_simple_map(self):
        """Test simple map with identifier keys."""
        ast = parse("protocol T { let x = {a: 1, b: 2} }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MapExpr)
        assert len(expr.entries) == 2

    def test_string_key_map(self):
        """Test map with string keys."""
        ast = parse('protocol T { let x = {"key": 1} }')
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MapExpr)


class TestLambdaExpressions:
    """Test lambda expression parsing."""

    def test_simple_lambda(self):
        """Test simple lambda with one expression."""
        ast = parse("protocol T { let f = |x| x + 1 }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, LambdaExpr)
        assert len(expr.parameters) == 1
        assert isinstance(expr.body, BinaryExpr)

    def test_lambda_no_params(self):
        """Test lambda with no parameters."""
        ast = parse("protocol T { let f = || 42 }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, LambdaExpr)
        assert len(expr.parameters) == 0

    def test_lambda_multiple_params(self):
        """Test lambda with multiple parameters."""
        ast = parse("protocol T { let f = |x, y| x + y }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, LambdaExpr)
        assert len(expr.parameters) == 2


class TestMethodChains:
    """Test method call chaining."""

    def test_field_access(self):
        """Test simple field access."""
        ast = parse("protocol T { let x = obj.field }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, FieldAccessExpr)
        assert expr.field == "field"

    def test_method_call(self):
        """Test method call."""
        ast = parse("protocol T { let x = obj.method() }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MethodCallExpr)
        assert expr.method == "method"

    def test_method_with_args(self):
        """Test method call with arguments."""
        ast = parse("protocol T { let x = obj.method(1, 2) }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MethodCallExpr)
        assert len(expr.arguments) == 2

    def test_chain(self):
        """Test chained method calls."""
        ast = parse("protocol T { let x = a.b.c() }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, MethodCallExpr)
        assert isinstance(expr.object, FieldAccessExpr)


class TestIndexAccess:
    """Test index/subscript access."""

    def test_simple_index(self):
        """Test simple index access."""
        ast = parse("protocol T { let x = arr[0] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, IndexExpr)

    def test_chained_index(self):
        """Test chained index access."""
        ast = parse("protocol T { let x = arr[0][1] }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, IndexExpr)
        assert isinstance(expr.object, IndexExpr)


class TestConditionalExpr:
    """Test ternary conditional expression."""

    def test_simple_conditional(self):
        """Test simple conditional."""
        ast = parse("protocol T { let x = a ? b : c }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, ConditionalExpr)
        assert isinstance(expr.condition, IdentifierExpr)


class TestRangeExpr:
    """Test range expressions."""

    def test_simple_range(self):
        """Test simple range."""
        ast = parse("protocol T { let x = 1..10 }")
        expr = ast.declarations[0].body[0].value
        assert isinstance(expr, RangeExpr)


class TestFunctionCalls:
    """Test function call expressions."""

    def test_simple_call(self):
        """Test simple function call."""
        ast = parse("protocol T { foo() }")
        stmt = ast.declarations[0].body[0]
        assert stmt.name == "foo"

    def test_call_with_named_args(self):
        """Test function call with named arguments."""
        ast = parse("protocol T { foo(x: 1, y: 2) }")
        stmt = ast.declarations[0].body[0]
        assert len(stmt.arguments) == 2
        assert stmt.arguments[0].name == "x"

    def test_call_mixed_args(self):
        """Test function call with mixed positional and named args."""
        ast = parse("protocol T { foo(1, x: 2) }")
        stmt = ast.declarations[0].body[0]
        assert len(stmt.arguments) == 2
        assert stmt.arguments[0].name is None
        assert stmt.arguments[1].name == "x"
