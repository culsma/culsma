"""
Tests for BPL Scheduler.

Tests cover:
- Resource management
- Greedy scheduling
- Time-window scheduling
- Deck state management
- Tip optimization
- Deadlock detection
"""

import pytest
from datetime import datetime, timedelta

from bpl.scheduler import (
    # Resource manager
    ResourceType, ResourceState, Resource, ResourceManager,
    ResourceConflictError,
    # Deck state
    Footprint, DeckPosition, LabwareInstance, DeckStateManager,
    DeckPositionError, create_standard_deck,
    # Tip optimizer
    TipSize, TipReuseStrategy, TipRack, TipWaste, TipOptimizer, TipError,
    # Scheduler
    SchedulingStrategy, ScheduledStep, ScheduleResult, Scheduler, create_scheduler,
    # Deadlock
    DeadlockState, DeadlockDetector, prevent_deadlock,
)
from bpl.lowering import ExecutionPlan, PlanStep, Wait, Aspirate, WellRef


class TestResourceManager:
    """Test resource manager."""

    def test_register_resource(self):
        """Register a resource."""
        manager = ResourceManager()
        resource = Resource(
            resource_id="pipette_1",
            resource_type=ResourceType.PIPETTE_CHANNEL
        )
        manager.register_resource(resource)

        assert "pipette_1" in manager.resources

    def test_acquire_resource(self):
        """Acquire an available resource."""
        manager = ResourceManager()
        manager.register_resource(Resource(
            resource_id="pipette_1",
            resource_type=ResourceType.PIPETTE_CHANNEL
        ))

        booking = manager.acquire("pipette_1", "step_1")

        assert booking is not None
        assert "step_1" in manager.resources["pipette_1"].current_users

    def test_acquire_unavailable_raises(self):
        """Acquiring unavailable resource raises error."""
        manager = ResourceManager()
        manager.register_resource(Resource(
            resource_id="pipette_1",
            resource_type=ResourceType.PIPETTE_CHANNEL,
            capacity=1
        ))

        manager.acquire("pipette_1", "step_1")

        with pytest.raises(ResourceConflictError):
            manager.acquire("pipette_1", "step_2")

    def test_release_resource(self):
        """Release a resource."""
        manager = ResourceManager()
        manager.register_resource(Resource(
            resource_id="pipette_1",
            resource_type=ResourceType.PIPETTE_CHANNEL
        ))

        manager.acquire("pipette_1", "step_1")
        manager.release("pipette_1", "step_1")

        assert manager.is_available("pipette_1")

    def test_resource_capacity(self):
        """Resource with capacity > 1 allows multiple users."""
        manager = ResourceManager()
        manager.register_resource(Resource(
            resource_id="shaker_1",
            resource_type=ResourceType.SHAKER,
            capacity=4  # 4 plates can shake at once
        ))

        for i in range(4):
            manager.acquire("shaker_1", f"step_{i}")

        assert not manager.is_available("shaker_1")

    def test_acquire_all_atomic(self):
        """Acquire all resources atomically."""
        manager = ResourceManager()
        manager.register_resource(Resource("r1", ResourceType.PIPETTE_CHANNEL))
        manager.register_resource(Resource("r2", ResourceType.GRIPPER))

        bookings = manager.acquire_all(["r1", "r2"], "step_1")

        assert len(bookings) == 2
        assert not manager.is_available("r1")
        assert not manager.is_available("r2")

    def test_reserve_resource(self):
        """Reserve a resource for future use."""
        manager = ResourceManager()
        manager.register_resource(Resource("r1", ResourceType.INCUBATOR))

        manager.reserve("r1", "step_1")

        assert manager.resources["r1"].state == ResourceState.RESERVED
        assert not manager.is_available("r1")


class TestDeckStateManager:
    """Test deck state manager."""

    def test_add_position(self):
        """Add deck position."""
        manager = DeckStateManager()
        pos = DeckPosition(position_id="slot_1", x=0, y=0, z=0)
        manager.add_position(pos)

        assert "slot_1" in manager.positions

    def test_place_labware(self):
        """Place labware at position."""
        manager = DeckStateManager()
        manager.add_position(DeckPosition("slot_1", 0, 0, 0))
        manager.register_labware(LabwareInstance(
            labware_id="plate_1",
            labware_type="96_well",
            footprint=Footprint.SBS_STANDARD
        ))

        manager.place_labware("plate_1", "slot_1")

        assert manager.positions["slot_1"].is_occupied
        assert manager.labware["plate_1"].position_id == "slot_1"

    def test_place_occupied_raises(self):
        """Placing at occupied position raises error."""
        manager = DeckStateManager()
        manager.add_position(DeckPosition("slot_1", 0, 0, 0))
        manager.register_labware(LabwareInstance("plate_1", "96_well", Footprint.SBS_STANDARD))
        manager.register_labware(LabwareInstance("plate_2", "96_well", Footprint.SBS_STANDARD))

        manager.place_labware("plate_1", "slot_1")

        with pytest.raises(DeckPositionError, match="occupied"):
            manager.place_labware("plate_2", "slot_1")

    def test_move_labware(self):
        """Move labware to new position."""
        manager = DeckStateManager()
        manager.add_position(DeckPosition("slot_1", 0, 0, 0))
        manager.add_position(DeckPosition("slot_2", 100, 0, 0))
        manager.register_labware(LabwareInstance("plate_1", "96_well", Footprint.SBS_STANDARD))

        manager.place_labware("plate_1", "slot_1")
        manager.move_labware("plate_1", "slot_2")

        assert not manager.positions["slot_1"].is_occupied
        assert manager.positions["slot_2"].occupied_by == "plate_1"

    def test_footprint_compatibility(self):
        """Position only accepts compatible footprints."""
        manager = DeckStateManager()
        manager.add_position(DeckPosition(
            "slot_1", 0, 0, 0,
            accepts=[Footprint.TIP_RACK]  # Only tip racks
        ))
        manager.register_labware(LabwareInstance("plate_1", "96_well", Footprint.SBS_STANDARD))

        with pytest.raises(DeckPositionError, match="does not accept"):
            manager.place_labware("plate_1", "slot_1")

    def test_get_deck_layout(self):
        """Get current deck layout."""
        manager = DeckStateManager()
        manager.add_position(DeckPosition("slot_1", 0, 0, 0))
        manager.add_position(DeckPosition("slot_2", 100, 0, 0))
        manager.register_labware(LabwareInstance("plate_1", "96_well", Footprint.SBS_STANDARD))
        manager.place_labware("plate_1", "slot_1")

        layout = manager.get_deck_layout()

        assert layout["slot_1"] == "plate_1"
        assert layout["slot_2"] is None

    def test_create_standard_deck(self):
        """Create standard deck with positions."""
        manager = create_standard_deck(12)

        assert len(manager.positions) == 12
        assert "slot_1" in manager.positions
        assert "slot_12" in manager.positions


class TestTipOptimizer:
    """Test tip optimizer."""

    def test_add_tip_rack(self):
        """Add tip rack."""
        optimizer = TipOptimizer()
        rack = TipRack(rack_id="tips_1", tip_size=TipSize.P200)
        optimizer.add_tip_rack(rack)

        assert "tips_1" in optimizer.tip_racks

    def test_pick_tips(self):
        """Pick tips from rack."""
        optimizer = TipOptimizer()
        optimizer.add_tip_rack(TipRack("tips_1", TipSize.P200))

        rack_id, positions = optimizer.pick_tips("step_1", count=1)

        assert rack_id == "tips_1"
        assert len(positions) == 1
        assert optimizer.tip_racks["tips_1"].tips_remaining == 95

    def test_pick_tips_insufficient(self):
        """Error when not enough tips."""
        optimizer = TipOptimizer()
        optimizer.add_tip_rack(TipRack("tips_1", TipSize.P200, tips_remaining=2))

        with pytest.raises(TipError, match="Not enough"):
            optimizer.pick_tips("step_1", count=5)

    def test_find_rack_for_volume(self):
        """Find appropriate rack for volume."""
        optimizer = TipOptimizer()
        optimizer.add_tip_rack(TipRack("tips_20", TipSize.P20))
        optimizer.add_tip_rack(TipRack("tips_200", TipSize.P200))
        optimizer.add_tip_rack(TipRack("tips_1000", TipSize.P1000))

        rack = optimizer.find_rack_for_volume(50.0)

        assert rack.tip_size == TipSize.P200  # Smallest suitable

    def test_drop_tips_to_waste(self):
        """Drop tips to waste."""
        optimizer = TipOptimizer()
        optimizer.add_tip_rack(TipRack("tips_1", TipSize.P200))
        optimizer.set_waste(TipWaste("waste_1"))

        optimizer.pick_tips("step_1", count=1)
        optimizer.drop_tips()

        assert optimizer.tip_waste.current_count == 1

    def test_tip_reuse_strategy(self):
        """Tip reuse based on strategy."""
        optimizer = TipOptimizer(strategy=TipReuseStrategy.SAME_SOURCE)
        optimizer.add_tip_rack(TipRack("tips_1", TipSize.P200))

        optimizer.pick_tips("step_1", count=1)
        optimizer.set_current_source("source_1")

        # Same source should reuse
        assert optimizer.should_reuse_tip("source_1") is True
        # Different source should not reuse
        assert optimizer.should_reuse_tip("source_2") is False

    def test_check_sufficient_tips(self):
        """Check if sufficient tips available."""
        optimizer = TipOptimizer()
        optimizer.add_tip_rack(TipRack("tips_1", TipSize.P200, tips_remaining=50))
        optimizer.add_tip_rack(TipRack("tips_2", TipSize.P200, tips_remaining=50))

        # 100 tips available total
        is_sufficient, msg = optimizer.check_sufficient_tips(80)
        assert is_sufficient is True

        is_sufficient, msg = optimizer.check_sufficient_tips(120)
        assert is_sufficient is False


class TestScheduler:
    """Test scheduler."""

    def test_create_scheduler(self):
        """Create scheduler with strategy."""
        scheduler = create_scheduler("greedy")
        assert scheduler.strategy == SchedulingStrategy.GREEDY

    def test_schedule_simple_plan(self):
        """Schedule a simple plan."""
        plan = ExecutionPlan(plan_id="plan_1")
        plan.add_step(PlanStep(step_id="s1", primitive=Wait(duration_s=5.0)))
        plan.add_step(PlanStep(step_id="s2", primitive=Wait(duration_s=5.0), dependencies=["s1"]))

        scheduler = Scheduler()
        result = scheduler.schedule(plan)

        assert result.success is True
        assert len(result.scheduled_steps) == 2

    def test_schedule_greedy_order(self):
        """Greedy scheduler respects dependencies."""
        plan = ExecutionPlan(plan_id="plan_1")
        plan.add_step(PlanStep(step_id="s1", primitive=Wait(duration_s=1.0)))
        plan.add_step(PlanStep(step_id="s2", primitive=Wait(duration_s=1.0), dependencies=["s1"]))
        plan.add_step(PlanStep(step_id="s3", primitive=Wait(duration_s=1.0), dependencies=["s2"]))

        scheduler = Scheduler(strategy=SchedulingStrategy.GREEDY)
        result = scheduler.schedule_greedy(plan)

        # Check order
        step_ids = [s.step.step_id for s in result.scheduled_steps]
        assert step_ids.index("s1") < step_ids.index("s2")
        assert step_ids.index("s2") < step_ids.index("s3")

    def test_schedule_time_window(self):
        """Time-window scheduler allows parallelism."""
        plan = ExecutionPlan(plan_id="plan_1")
        # Two independent steps
        plan.add_step(PlanStep(step_id="s1", primitive=Wait(duration_s=5.0)))
        plan.add_step(PlanStep(step_id="s2", primitive=Wait(duration_s=5.0)))

        scheduler = Scheduler(strategy=SchedulingStrategy.TIME_WINDOW)
        result = scheduler.schedule_time_window(plan)

        # Both can start at same time
        assert result.scheduled_steps[0].scheduled_start == result.scheduled_steps[1].scheduled_start

    def test_estimate_duration(self):
        """Estimate step duration."""
        scheduler = Scheduler()

        wait_step = PlanStep(step_id="s1", primitive=Wait(duration_s=10.0))
        duration = scheduler.estimate_duration(wait_step)

        assert duration == 10.0

    def test_get_required_resources(self):
        """Get resources required by step."""
        scheduler = Scheduler()

        asp_step = PlanStep(
            step_id="s1",
            primitive=Aspirate(source=WellRef("p1", "A1"), volume_ul=100.0)
        )
        resources = scheduler.get_required_resources(asp_step)

        assert "pipette_channel_1" in resources

    def test_validate_schedule_dependency_order_violation(self):
        """Dependency validation fails when dependent starts too early."""
        scheduler = Scheduler()
        now = datetime.now()

        dep_step = PlanStep(step_id="s1", primitive=Wait(duration_s=10.0))
        dependent = PlanStep(step_id="s2", primitive=Wait(duration_s=5.0), dependencies=["s1"])
        result = ScheduleResult(
            success=True,
            scheduled_steps=[
                ScheduledStep(
                    step=dependent,
                    scheduled_start=now,
                    scheduled_end=now + timedelta(seconds=5),
                    estimated_duration_s=5.0,
                    required_resources=[],
                ),
                ScheduledStep(
                    step=dep_step,
                    scheduled_start=now + timedelta(seconds=1),
                    scheduled_end=now + timedelta(seconds=11),
                    estimated_duration_s=10.0,
                    required_resources=[],
                ),
            ],
            total_estimated_time_s=11.0,
            parallel_opportunities=0,
        )

        is_valid, issues = scheduler.validate_schedule(result)
        assert is_valid is False
        assert any("SCHEDULE_DEPENDENCY_ORDER_VIOLATION" in issue for issue in issues)

    def test_validate_schedule_resource_overlap_conflict(self):
        """Validation reports overlapping use of exclusive resources."""
        scheduler = Scheduler()
        now = datetime.now()
        result = ScheduleResult(
            success=True,
            scheduled_steps=[
                ScheduledStep(
                    step=PlanStep(step_id="s1", primitive=Wait(duration_s=4.0)),
                    scheduled_start=now,
                    scheduled_end=now + timedelta(seconds=4),
                    estimated_duration_s=4.0,
                    required_resources=["pipette_channel_1"],
                ),
                ScheduledStep(
                    step=PlanStep(step_id="s2", primitive=Wait(duration_s=4.0)),
                    scheduled_start=now + timedelta(seconds=1),
                    scheduled_end=now + timedelta(seconds=5),
                    estimated_duration_s=4.0,
                    required_resources=["pipette_channel_1"],
                ),
            ],
            total_estimated_time_s=5.0,
            parallel_opportunities=0,
        )

        is_valid, issues = scheduler.validate_schedule(result)
        assert is_valid is False
        assert any("SCHEDULE_RESOURCE_OVERLAP_CONFLICT" in issue for issue in issues)

    def test_validate_schedule_deadlock_risk_diagnostic(self):
        """Validation reports deadlock risk from conflicting resource order."""
        scheduler = Scheduler()
        now = datetime.now()
        result = ScheduleResult(
            success=True,
            scheduled_steps=[
                ScheduledStep(
                    step=PlanStep(step_id="s1", primitive=Wait(duration_s=6.0)),
                    scheduled_start=now,
                    scheduled_end=now + timedelta(seconds=6),
                    estimated_duration_s=6.0,
                    required_resources=["r1", "r2"],
                ),
                ScheduledStep(
                    step=PlanStep(step_id="s2", primitive=Wait(duration_s=6.0)),
                    scheduled_start=now + timedelta(seconds=1),
                    scheduled_end=now + timedelta(seconds=7),
                    estimated_duration_s=6.0,
                    required_resources=["r2", "r1"],
                ),
            ],
            total_estimated_time_s=7.0,
            parallel_opportunities=0,
        )

        is_valid, issues = scheduler.validate_schedule(result)
        assert is_valid is False
        assert any("SCHEDULE_DEADLOCK_RISK" in issue for issue in issues)


class TestDeadlockDetector:
    """Test deadlock detector."""

    def test_no_deadlock(self):
        """No deadlock in simple case."""
        detector = DeadlockDetector()

        detector.register_acquisition("step_1", "resource_a")

        state, info = detector.check_deadlock()
        assert state == DeadlockState.SAFE

    def test_detect_simple_deadlock(self):
        """Detect simple two-step deadlock."""
        detector = DeadlockDetector()

        # Step 1 holds A, wants B
        detector.resource_holders["resource_a"] = "step_1"
        detector.register_wait(
            "step_1",
            waiting_for={"resource_b"},
            holding={"resource_a"}
        )

        # Step 2 holds B, wants A
        detector.resource_holders["resource_b"] = "step_2"
        detector.register_wait(
            "step_2",
            waiting_for={"resource_a"},
            holding={"resource_b"}
        )

        state, info = detector.check_deadlock()

        assert state == DeadlockState.DEADLOCKED
        assert info is not None
        assert len(info.cycle) == 2

    def test_ordered_acquisition_valid(self):
        """Valid ordered acquisition."""
        detector = DeadlockDetector()
        detector.set_resource_order(["r1", "r2", "r3"])

        is_valid, error = detector.validate_acquisition_order(
            "step_1",
            ["r1", "r2"]  # Correct order
        )

        assert is_valid is True

    def test_ordered_acquisition_invalid(self):
        """Invalid ordered acquisition detected."""
        detector = DeadlockDetector()
        detector.set_resource_order(["r1", "r2", "r3"])

        is_valid, error = detector.validate_acquisition_order(
            "step_1",
            ["r2", "r1"]  # Wrong order
        )

        assert is_valid is False
        assert "out of order" in error

    def test_timeout_detection(self):
        """Detect timed-out waits."""
        detector = DeadlockDetector(default_timeout_s=0.01)

        detector.register_wait("step_1", {"resource_a"}, set())

        import time
        time.sleep(0.02)

        timed_out = detector.check_timeout()
        assert "step_1" in timed_out

    def test_prevent_deadlock_helper(self):
        """Test prevent_deadlock helper function."""
        detector = DeadlockDetector()
        detector.set_resource_order(["r1", "r2"])

        is_safe, warning = prevent_deadlock(
            "step_1",
            ["r1", "r2"],
            detector
        )

        assert is_safe is True


class TestIntegration:
    """Integration tests for scheduler components."""

    def test_full_scheduling_workflow(self):
        """Test complete scheduling workflow."""
        # Create resources
        resource_manager = ResourceManager()
        resource_manager.register_resource(Resource(
            "pipette_channel_1", ResourceType.PIPETTE_CHANNEL
        ))
        resource_manager.register_resource(Resource(
            "plate_reader", ResourceType.PLATE_READER
        ))

        # Create deck
        deck_manager = create_standard_deck(6)
        deck_manager.register_labware(LabwareInstance(
            "plate_1", "96_well", Footprint.SBS_STANDARD
        ))
        deck_manager.place_labware("plate_1", "slot_1")

        # Create scheduler
        scheduler = Scheduler(
            resource_manager=resource_manager,
            deck_manager=deck_manager,
            strategy=SchedulingStrategy.GREEDY
        )

        # Create plan
        plan = ExecutionPlan(plan_id="test_plan")
        plan.add_step(PlanStep(step_id="aspirate_1", primitive=Aspirate(
            source=WellRef("plate_1", "A1"),
            volume_ul=50.0
        )))
        plan.add_step(PlanStep(step_id="wait_1", primitive=Wait(duration_s=60.0),
            dependencies=["aspirate_1"]))

        # Schedule
        result = scheduler.schedule(plan)

        assert result.success is True
        assert len(result.scheduled_steps) == 2

    def test_tip_optimized_protocol(self):
        """Test protocol with tip optimization."""
        optimizer = TipOptimizer(strategy=TipReuseStrategy.SAME_SOURCE)
        optimizer.add_tip_rack(TipRack("tips_200", TipSize.P200))
        optimizer.set_waste(TipWaste("waste_1"))

        # Simulate a series of transfers
        for i in range(8):
            # Pick tips for each transfer
            rack_id, positions = optimizer.pick_tips(f"transfer_{i}", count=1)

            # Set source
            optimizer.set_current_source("source_plate")

            # Check if we should reuse
            if i > 0 and optimizer.should_reuse_tip("source_plate"):
                # Would reuse in real execution
                pass

            optimizer.drop_tips()

        assert optimizer.get_total_tips_used() == 8
        assert optimizer.tip_waste.current_count == 8
