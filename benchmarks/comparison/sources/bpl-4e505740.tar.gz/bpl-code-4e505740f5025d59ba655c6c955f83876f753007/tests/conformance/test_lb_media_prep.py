"""
Conformance Test 1: LB Media Preparation Protocol.

Tests end-to-end parsing and type-checking of a complete LB media prep protocol.
Based on SOP-RD-013 LB培养基的配置.
"""

import pytest
from bpl.parser.bpl_parser import BPLParser
from bpl.ast.program import Program
from bpl.ast.declarations import ProtocolDecl, ReagentDecl, LabwareDecl


# Complete LB Media Prep protocol in BPL - Simplified for grammar compliance
LB_MEDIA_PREP_PROTOCOL = '''
// LB Media Preparation Protocol
// Based on SOP-RD-013

// Reagent declarations with molecular weights where applicable
reagent Tryptone {
    physical_form: Solid
    description: "Oxoid Tryptone"
    cas: "91079-40-2"
}

reagent YeastExtract {
    physical_form: Solid
    description: "Yeast Extract Powder"
    cas: "8013-01-2"
}

reagent NaCl {
    physical_form: Solid
    MW: 58.44 g/mol
    description: "Sodium Chloride"
    cas: "7647-14-5"
}

reagent Agar {
    physical_form: Solid
    description: "Bacteriological Agar"
    cas: "9002-18-0"
}

reagent ROWater {
    physical_form: Liquid
    description: "Reverse Osmosis Water"
}

// Labware definitions
labware Beaker1L {
    footprint: Custom
    well_volume: 1200 mL
}

labware GlassBottle1L {
    footprint: Custom
    well_volume: 1000 mL
}

labware StirBar {
    footprint: Custom
}

// Stock solution definitions
stock LB_Base {
    reagent: Tryptone
    concentration: 10 g/L
    solvent: ROWater
}

stock LB_Agar {
    reagent: Agar
    concentration: 16 g/L
    solvent: ROWater
}

// Main LB Media Preparation Protocol
@target(human)
@expected_time(2 h)
protocol PrepareLBMedia(final_volume: Volume = 1000 mL) {
    // Step 1: Prepare beaker with water
    @step(1, "Add RO water to beaker")
    add_reagent(ROWater, volume: 800 mL, to: Beaker1L)

    // Step 2: Add components one at a time
    @step(2, "Add Tryptone")
    let tryptone_mass = 10 g
    add_reagent(Tryptone, mass: tryptone_mass, to: Beaker1L)

    @step(3, "Add Yeast Extract")
    let yeast_mass = 5 g
    add_reagent(YeastExtract, mass: yeast_mass, to: Beaker1L)

    @step(4, "Add NaCl")
    let nacl_mass = 10 g
    add_reagent(NaCl, mass: nacl_mass, to: Beaker1L)

    // Step 5: Adjust volume
    @step(5, "Adjust volume")
    add_reagent(ROWater, volume: 200 mL, to: Beaker1L)

    // Step 6: Transfer to bottle
    @step(6, "Transfer to bottle")
    transfer(from: Beaker1L, volume: final_volume, to: GlassBottle1L)

    // Step 7: Autoclave
    @step(7, "Autoclave")
    incubate(target: GlassBottle1L, temperature: 121 degC, time: 20 min)
}

// LB Agar variant
@target(human)
protocol PrepareLBAgar(final_volume: Volume = 1000 mL) {
    // Step 1: Prepare LB base
    @step(1, "Prepare LB base")
    add_reagent(ROWater, volume: 800 mL, to: Beaker1L)
    add_reagent(Tryptone, mass: 10 g, to: Beaker1L)
    add_reagent(YeastExtract, mass: 5 g, to: Beaker1L)
    add_reagent(NaCl, mass: 10 g, to: Beaker1L)

    // Step 2: Add Agar
    @step(2, "Add Agar")
    let agar_mass = 16 g
    add_reagent(Agar, mass: agar_mass, to: Beaker1L)

    // Step 3: Transfer and autoclave
    @step(3, "Transfer and autoclave")
    transfer(from: Beaker1L, volume: final_volume, to: GlassBottle1L)
    incubate(target: GlassBottle1L, temperature: 121 degC, time: 20 min)
}
'''


class TestLBMediaPrepParsing:
    """Test parsing of the LB Media Prep protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_complete_protocol(self, parser):
        """Test that the complete protocol parses without errors."""
        # This tests the parser can handle a real-world protocol
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)
        assert isinstance(ast, Program)

    def test_reagent_declarations_parsed(self, parser):
        """Test that reagent declarations are correctly parsed."""
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        # Find reagent declarations
        reagents = [d for d in ast.declarations if isinstance(d, ReagentDecl)]
        reagent_names = [r.name for r in reagents]

        assert "Tryptone" in reagent_names
        assert "YeastExtract" in reagent_names
        assert "NaCl" in reagent_names
        assert "Agar" in reagent_names
        assert "ROWater" in reagent_names

    def test_labware_declarations_parsed(self, parser):
        """Test that labware declarations are correctly parsed."""
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        labware = [d for d in ast.declarations if isinstance(d, LabwareDecl)]
        labware_names = [decl.name for decl in labware]

        assert "Beaker1L" in labware_names
        assert "GlassBottle1L" in labware_names

    def test_protocol_declarations_parsed(self, parser):
        """Test that protocol declarations are correctly parsed."""
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]
        protocol_names = [p.name for p in protocols]

        assert "PrepareLBMedia" in protocol_names
        assert "PrepareLBAgar" in protocol_names

    def test_protocol_has_steps(self, parser):
        """Test that protocol body contains steps."""
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]
        main_protocol = next(p for p in protocols if p.name == "PrepareLBMedia")

        # Protocol should have statements in its body (body is a list)
        assert main_protocol.body is not None
        assert len(main_protocol.body) > 0

    def test_annotations_parsed(self, parser):
        """Test that annotations are correctly parsed."""
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]
        main_protocol = next(p for p in protocols if p.name == "PrepareLBMedia")

        # Check for @target and @expected_time annotations
        annotation_names = [a.name for a in main_protocol.annotations]
        assert "target" in annotation_names
        assert "expected_time" in annotation_names


class TestLBMediaPrepUnits:
    """Test unit handling in the LB Media Prep protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_volume_units_parsed(self, parser):
        """Test that volume units are correctly parsed."""
        source = '''
        protocol Test {
            let v1 = 1000 mL
            let v2 = 1 L
            let v3 = 800 mL
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_mass_units_parsed(self, parser):
        """Test that mass units are correctly parsed."""
        source = '''
        protocol Test {
            let m1 = 10 g
            let m2 = 5 g
            let m3 = 16 g
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_concentration_units_parsed(self, parser):
        """Test that concentration units are correctly parsed."""
        source = '''
        reagent Tryptone { physical_form: Solid }
        reagent Water { physical_form: Liquid }

        stock LB {
            reagent: Tryptone
            concentration: 10 g/L
            solvent: Water
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_temperature_units_parsed(self, parser):
        """Test that temperature units are correctly parsed."""
        source = '''
        protocol Test {
            let temp = 121 degC
            let room_temp = 25 degC
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_time_units_parsed(self, parser):
        """Test that time units are correctly parsed."""
        source = '''
        protocol Test {
            let duration = 20 min
            let long_time = 24 h
            let quick_time = 30 s
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_molecular_weight_parsed(self, parser):
        """Test that molecular weight units are correctly parsed."""
        source = '''
        reagent NaCl {
            mw: 58.44 g/mol
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestLBMediaPrepManualSteps:
    """Test manual step handling in the LB Media Prep protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_manual_step_basic(self, parser):
        """Test basic manual step call."""
        source = '''
        protocol Test {
            manual("Add water to beaker")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_manual_step_with_annotation(self, parser):
        """Test manual step with annotation."""
        source = '''
        protocol Test {
            @step(1, "Add water")
            manual("Add water to beaker")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_add_reagent_call(self, parser):
        """Test add_reagent function call."""
        source = '''
        reagent Water { physical_form: Liquid }
        labware Beaker { footprint: Custom }

        protocol Test {
            add_reagent(Water, volume: 100 mL, to: Beaker)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestLBMediaPrepStockSolutions:
    """Test stock solution handling."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_stock_with_reagent_and_concentration(self, parser):
        """Test stock solution with reagent and concentration."""
        source = '''
        reagent A { physical_form: Solid }
        reagent Water { physical_form: Liquid }

        stock MyStock {
            reagent: A
            concentration: 10 g/L
            solvent: Water
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_stock_with_molar_concentration(self, parser):
        """Test stock with molar concentration units."""
        source = '''
        reagent Drug { MW: 500 g/mol }
        reagent Buffer { physical_form: Liquid }

        stock DrugStock {
            reagent: Drug
            concentration: 1 mM
            solvent: Buffer
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestLBMediaPrepIntegration:
    """Integration tests for the complete protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_and_check_complete_protocol(self, parser):
        """Test complete parse and type check."""
        # Parse the protocol
        ast = parser.parse(LB_MEDIA_PREP_PROTOCOL)

        # Basic structure validation
        assert isinstance(ast, Program)
        assert len(ast.declarations) > 0

        # Count declaration types
        reagent_count = sum(1 for d in ast.declarations if isinstance(d, ReagentDecl))
        labware_count = sum(1 for d in ast.declarations if isinstance(d, LabwareDecl))
        protocol_count = sum(1 for d in ast.declarations if isinstance(d, ProtocolDecl))

        assert reagent_count == 5  # Tryptone, YeastExtract, NaCl, Agar, ROWater
        assert labware_count >= 2  # Beaker1L, GlassBottle1L, StirBar
        assert protocol_count == 2  # PrepareLBMedia, PrepareLBAgar

    def test_protocol_parameters(self, parser):
        """Test that protocol parameters are parsed."""
        source = '''
        protocol Test(volume: Volume = 1000 mL, temperature: Temperature = 25 degC) {
            let x = volume
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_incubate_statement(self, parser):
        """Test incubate statement parsing."""
        source = '''
        labware Bottle { footprint: Custom }

        protocol Test {
            incubate(target: Bottle, temperature: 121 degC, time: 20 min)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)
