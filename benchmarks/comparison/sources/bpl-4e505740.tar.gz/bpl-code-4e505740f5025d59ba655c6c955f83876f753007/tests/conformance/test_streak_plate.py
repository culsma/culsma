"""
Conformance Test 4: Streak Plate Protocol.

Tests manual() steps with SafetyTag, RecordField, and human step rendering.
"""

import pytest
from bpl.parser.bpl_parser import BPLParser
from bpl.ast.program import Program
from bpl.runtime.human import (
    StepType,
    HumanExecutionStep,
    HumanExecutionPlan,
    StepRenderer,
    RenderFormat,
    DataField,
    FieldType,
    DataCapture,
    SignatureType,
    SignatureManager,
    create_standard_policy,
)


# Streak Plate Protocol - Simplified for grammar compliance
STREAK_PLATE_PROTOCOL = '''
// Streak Plate Protocol for Bacterial Isolation
// Manual technique for isolating single colonies

reagent BacterialCulture {
    physical_form: Liquid
    description: "Overnight bacterial culture"
}

reagent LBAgarPlate {
    physical_form: Solid
    description: "LB Agar plate"
}

reagent Ethanol70 {
    physical_form: Liquid
    description: "70% Ethanol"
    hazard: "flammable"
}

labware InoculationLoop {
    footprint: Custom
    material: "nichrome"
}

labware BunsenBurner {
    footprint: Custom
    hazard: "fire"
}

labware PetriDish {
    footprint: SBS_Standard
    category: Plate_96
}

@target(human)
@compliance(GLP)
protocol StreakPlate(quadrant_count: Number = 4) {
    // Step 1: Prepare workspace
    @step(1, "Prepare workspace")
    manual("Set up a clean, sterile workspace near the Bunsen burner")

    // Step 2: Label plate
    @step(2, "Label plate")
    manual("Label the bottom of the agar plate with sample ID and date")

    // Step 3: Sterilize loop
    @step(3, "Sterilize inoculation loop")
    @critical
    manual("Hold the inoculation loop in the Bunsen burner flame until red hot")

    // Step 4: Cool loop
    @step(4, "Cool loop")
    manual("Allow the loop to cool for 10-15 seconds")

    // Step 5: Get culture
    @step(5, "Obtain culture sample")
    manual("Dip the cooled loop into the bacterial culture")

    // Step 6: First quadrant
    @step(6, "Streak first quadrant")
    manual("Open the plate lid slightly and streak the first quadrant in a zigzag pattern")

    // Step 7: Sterilize between quadrants
    @step(7, "Sterilize loop again")
    manual("Flame sterilize the loop before the next quadrant")

    // Step 8: Second quadrant
    @step(8, "Streak second quadrant")
    manual("Cool the loop and drag through previous streak, then streak second quadrant")

    // Step 9: Repeat for remaining quadrants
    for q in [3, 4] {
        manual("Sterilize loop, cool, drag through previous streak, streak quadrant")
    }

    // Step 10: Final sterilization
    @step(10, "Final loop sterilization")
    manual("Flame sterilize the loop before putting it away")

    // Step 11: Close and invert plate
    @step(11, "Prepare for incubation")
    manual("Close the plate and invert, agar side up")

    // Step 12: Incubate
    @step(12, "Incubate plate")
    incubate(target: PetriDish, temperature: 37 degC, time: 16 h)

    // Step 13: Evaluate results
    @step(13, "Evaluate plate")
    manual("Examine plate for isolated colonies")
}
'''


class TestStreakPlateParsing:
    """Test parsing of the Streak Plate protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_complete_protocol(self, parser):
        """Test complete protocol parsing."""
        ast = parser.parse(STREAK_PLATE_PROTOCOL)
        assert isinstance(ast, Program)

    def test_manual_step_parsed(self, parser):
        """Test manual steps are parsed."""
        source = '''
        protocol Test {
            manual("Dangerous step, wear gloves")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_manual_with_step_annotation(self, parser):
        """Test manual step with @step annotation."""
        source = '''
        protocol Test {
            @step(1, "Setup")
            manual("Equipment ready, reagents thawed")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_critical_annotation(self, parser):
        """Test @critical annotation."""
        source = '''
        protocol Test {
            @critical
            manual("Critical technical step")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestManualStepFields:
    """Test manual step data fields."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_let_with_number(self, parser):
        """Test let with various data types."""
        source = '''
        protocol Test {
            let count = 10
            let volume = 100 uL
            let temperature = 37 degC
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_manual_basic(self, parser):
        """Test basic manual step."""
        source = '''
        protocol Test {
            manual("Follow pattern carefully")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_let_with_time(self, parser):
        """Test let with time value."""
        source = '''
        protocol Test {
            let expected_time = 30 s
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestStateTracking:
    """Test state tracking in protocols."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_let_boolean(self, parser):
        """Test let with boolean value."""
        source = '''
        protocol Test {
            let is_ready = false
            manual("Prepare")
            let is_ready = true
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_conditional_annotation(self, parser):
        """Test annotation with conditional."""
        source = '''
        protocol Test {
            @requires(sterile)
            manual("Use sterile loop")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHumanStepRendering:
    """Test human step rendering."""

    def test_render_simple_step(self):
        """Test rendering a simple step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,  # Use valid StepType
            instruction="Perform the task carefully"
        )

        renderer = StepRenderer()
        text = renderer.render_step(step, RenderFormat.TEXT)

        assert "Step 1" in text or "1" in text
        assert "Perform the task" in text or "task" in text.lower()

    def test_render_step_with_warnings(self):
        """Test rendering step with safety warnings."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Handle with care",
            warnings=["Wear gloves", "Work in fume hood"]
        )

        renderer = StepRenderer()
        renderer.render_step(step, RenderFormat.TEXT)

        # Check that warnings are included somehow
        assert len(step.warnings) == 2

    def test_render_step_as_markdown(self):
        """Test rendering step as markdown."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Sterilize the loop"
        )

        renderer = StepRenderer()
        md = renderer.render_step(step, RenderFormat.MARKDOWN)

        # Markdown output should be a string
        assert isinstance(md, str)
        assert len(md) > 0

    def test_render_step_as_html(self):
        """Test rendering step as HTML."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Add reagent"
        )

        renderer = StepRenderer()
        html = renderer.render_step(step, RenderFormat.HTML)

        # HTML output should contain markup
        assert isinstance(html, str)
        assert len(html) > 0


class TestDataCapture:
    """Test data capture for manual steps."""

    def test_create_data_capture(self):
        """Test creating data capture."""
        capture = DataCapture(capture_id="cap_1", step_id="step_1")

        data_field = DataField(
            field_id="colony_count",
            name="Colony Count",
            field_type=FieldType.INTEGER,
        )
        capture.add_field(data_field)

        assert "colony_count" in capture.fields

    def test_capture_numeric_value(self):
        """Test capturing numeric value."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(DataField(
            field_id="count",
            name="Count",
            field_type=FieldType.INTEGER,
        ))

        result = capture.capture("count", 42, captured_by="operator1")
        assert result.value == 42

    def test_capture_text_value(self):
        """Test capturing text value."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(DataField(
            field_id="morphology",
            name="Morphology",
            field_type=FieldType.TEXT,
        ))

        result = capture.capture("morphology", "round, smooth, white")
        assert "round" in result.value

    def test_capture_boolean_value(self):
        """Test capturing boolean value."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(DataField(
            field_id="contaminated",
            name="Contamination Observed",
            field_type=FieldType.BOOLEAN,
        ))

        result = capture.capture("contaminated", False)
        assert result.value is False


class TestSignatures:
    """Test signature handling for manual steps."""

    def test_create_signature_request(self):
        """Test creating signature request."""
        manager = SignatureManager()
        request = manager.create_request(
            signature_type=SignatureType.INITIALS,
            reason="Colony observation",
            step_id="step_16"
        )

        assert request is not None
        assert request.reason == "Colony observation"

    def test_sign_step(self):
        """Test signing a step."""
        manager = SignatureManager()
        request = manager.create_request(
            signature_type=SignatureType.INITIALS,
            reason="Verify observation"
        )

        sig = manager.sign(
            request_id=request.request_id,
            signer_id="operator1",
            signer_name="John Smith"
        )

        assert sig is not None
        assert sig.signer_name == "John Smith"

    def test_policy_check(self):
        """Test policy check after signing."""
        manager = SignatureManager()
        manager.add_policy(create_standard_policy())

        request = manager.create_request(
            signature_type=SignatureType.INITIALS,
            reason="Verify step",
            step_id="step_1"
        )
        manager.sign(request.request_id, "user1", "John Doe")

        passed, issues = manager.check_policy("standard", "step_1")
        assert passed


class TestStreakPlateIntegration:
    """Integration tests for Streak Plate protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_full_protocol_structure(self, parser):
        """Test complete protocol structure."""
        ast = parser.parse(STREAK_PLATE_PROTOCOL)

        from bpl.ast.declarations import ReagentDecl, LabwareDecl, ProtocolDecl

        reagents = [d for d in ast.declarations if isinstance(d, ReagentDecl)]
        labware = [d for d in ast.declarations if isinstance(d, LabwareDecl)]
        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]

        assert len(reagents) == 3  # BacterialCulture, LBAgarPlate, Ethanol70
        assert len(labware) == 3  # InoculationLoop, BunsenBurner, PetriDish
        assert len(protocols) == 1  # StreakPlate

    def test_hazard_field(self, parser):
        """Test hazard field in reagents/labware."""
        source = '''
        reagent Ethanol {
            physical_form: Liquid
            hazard: "flammable"
        }

        labware Burner {
            footprint: Custom
            hazard: "fire"
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_for_loop_in_protocol(self, parser):
        """Test for loop for repeated steps."""
        source = '''
        protocol Test {
            for q in [3, 4] {
                manual("Process quadrant")
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_signature_annotation(self, parser):
        """Test @signature annotation."""
        source = '''
        protocol Test {
            @signature(required)
            manual("Critical observation")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_human_execution_workflow(self):
        """Test complete human execution workflow."""
        # Create a simple execution plan
        plan = HumanExecutionPlan(
            plan_id="streak_plate_1",
            protocol_name="Streak Plate"
        )

        # Add steps using valid StepType
        for i in range(5):
            step = HumanExecutionStep(
                step_id=f"step_{i+1}",
                step_number=i + 1,
                step_type=StepType.PIPETTE,  # Use valid StepType
                instruction=f"Step {i+1} instruction"
            )
            plan.add_step(step)

        assert plan.total_steps == 5

        # Execute steps
        plan.start()
        for step_id in plan.step_order:
            step = plan.steps[step_id]
            step.start()
            step.complete()
            plan.advance()

        plan.complete()
        assert plan.is_complete
        assert plan.progress_percent == 100.0
