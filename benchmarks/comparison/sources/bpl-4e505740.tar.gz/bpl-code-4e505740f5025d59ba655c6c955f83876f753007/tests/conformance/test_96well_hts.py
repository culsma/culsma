"""
Conformance Test 3: 96-Well High-Throughput Screening Protocol.

Tests complex WellSet operations with correct collection semantics.
"""

import pytest
from bpl.parser.bpl_parser import BPLParser
from bpl.ast.program import Program
from bpl.lowering.collection_semantics import (
    apply_zip_semantics,
    apply_broadcast_semantics,
    apply_product_semantics,
    CollectionSemanticsError,
)


# 96-Well HTS Protocol - Simplified for grammar compliance
HTS_96WELL_PROTOCOL = '''
// 96-Well High-Throughput Screening Protocol

reagent AssayBuffer {
    physical_form: Liquid
    description: "Assay Buffer Solution"
}

reagent Substrate {
    physical_form: Solid
    MW: 350.4 g/mol
    description: "Fluorogenic substrate"
}

reagent DMSO {
    physical_form: Liquid
    description: "Dimethyl sulfoxide"
}

reagent StopSolution {
    physical_form: Liquid
    description: "Assay stop solution"
}

labware SourcePlate96 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
}

labware AssayPlate96 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
}

labware CompoundPlate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
}

labware TipRack200 {
    footprint: SBS_Standard
    category: TipRack
    well_count: 96
}

deck_model HTSDeck {
    positions: [
        { id: "P1", accepts: [SBS_Standard] },
        { id: "P2", accepts: [SBS_Standard] },
        { id: "P3", accepts: [SBS_Standard] },
        { id: "P4", accepts: [SBS_Standard] },
        { id: "P5", accepts: [SBS_Standard] }
    ]
}

@target(biomek_i7)
@deck(HTSDeck)
protocol HTS96WellScreen(compound_volume: Volume = 1 uL, buffer_volume: Volume = 99 uL, substrate_volume: Volume = 50 uL, incubation_time: Time = 30 min, read_wavelength: Length = 450 nm) {
    // Step 1: Add buffer to all wells
    @step(1, "Add assay buffer")
    distribute(AssayBuffer, volume: buffer_volume, to: AssayPlate96)

    // Step 2: Transfer compounds
    @step(2, "Transfer compounds")
    transfer(from: CompoundPlate, volume: compound_volume, to: AssayPlate96)

    // Step 3: Add DMSO to controls
    @step(3, "Add DMSO to controls")
    distribute(DMSO, volume: compound_volume, to: AssayPlate96)

    // Step 4: Mix all wells
    @step(4, "Mix wells")
    mix(target: AssayPlate96, volume: 50 uL, cycles: 3)

    // Step 5: Incubate
    @step(5, "Pre-incubation")
    incubate(target: AssayPlate96, temperature: 37 degC, time: 10 min)

    // Step 6: Add substrate
    @step(6, "Add substrate")
    distribute(Substrate, volume: substrate_volume, to: AssayPlate96)

    // Step 7: Mix after substrate
    @step(7, "Mix after substrate")
    mix(target: AssayPlate96, volume: 50 uL, cycles: 2)

    // Step 8: Incubate for reaction
    @step(8, "Reaction incubation")
    incubate(target: AssayPlate96, temperature: 37 degC, time: incubation_time)

    // Step 9: Add stop solution
    @step(9, "Stop reaction")
    distribute(StopSolution, volume: 25 uL, to: AssayPlate96)

    // Step 10: Read plate
    @step(10, "Read absorbance")
    let results = read_absorbance(plate: AssayPlate96, wavelength: read_wavelength)

    // Step 11: Calculate Z-prime
    @step(11, "Calculate statistics")
    let pos_mean = 100.0
    let pos_std = 5.0
    let neg_mean = 20.0
    let neg_std = 3.0
    let z_prime = 1 - (3 * (pos_std + neg_std) / abs(pos_mean - neg_mean))
}
'''


class TestHTS96Parsing:
    """Test parsing of the 96-well HTS protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_complete_protocol(self, parser):
        """Test complete protocol parsing."""
        ast = parser.parse(HTS_96WELL_PROTOCOL)
        assert isinstance(ast, Program)

    def test_well_range_parsing(self, parser):
        """Test well-related syntax."""
        # Note: Well range syntax like Plate[A1:H12] is not currently supported
        # Test simple labware reference instead
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            let plate_ref = Plate
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_well_concatenation(self, parser):
        """Test addition operations."""
        source = '''
        protocol Test {
            let a = 1
            let b = 2
            let combined = a + b
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_semantics_annotation(self, parser):
        """Test @semantics annotation parsing."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        reagent Buffer { physical_form: Liquid }

        protocol Test {
            @semantics(broadcast)
            distribute(Buffer, volume: 100 uL, to: Plate)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestCollectionSemantics:
    """Test collection semantics operations."""

    def test_zip_equal_length(self):
        """Test zip semantics with equal length collections."""
        sources = ["A1", "A2", "A3"]
        destinations = ["B1", "B2", "B3"]

        pairs = apply_zip_semantics(sources, destinations, "src_plate", "dest_plate")

        assert len(pairs) == 3
        assert pairs[0].source_well == "A1" and pairs[0].dest_well == "B1"
        assert pairs[1].source_well == "A2" and pairs[1].dest_well == "B2"
        assert pairs[2].source_well == "A3" and pairs[2].dest_well == "B3"

    def test_zip_unequal_length_error(self):
        """Test zip with unequal lengths raises error."""
        sources = ["A1", "A2", "A3"]
        destinations = ["B1", "B2"]

        with pytest.raises(CollectionSemanticsError):
            apply_zip_semantics(sources, destinations, "src_plate", "dest_plate")

    def test_broadcast_single_to_many(self):
        """Test broadcast from single source to multiple destinations."""
        sources = ["A1"]
        destinations = ["B1", "B2", "B3", "B4"]

        pairs = apply_broadcast_semantics(sources, destinations, "src_plate", "dest_plate")

        assert len(pairs) == 4
        assert all(p.source_well == "A1" for p in pairs)

    def test_broadcast_many_sources_single_dest(self):
        """Test broadcast from multiple sources to single destination."""
        sources = ["A1", "A2", "A3"]
        destinations = ["B1"]

        pairs = apply_broadcast_semantics(sources, destinations, "src_plate", "dest_plate")

        assert len(pairs) == 3
        assert all(p.dest_well == "B1" for p in pairs)

    def test_product_semantics(self):
        """Test product (cartesian) semantics."""
        sources = ["A1", "A2"]
        destinations = ["B1", "B2", "B3"]

        pairs = apply_product_semantics(sources, destinations, "src_plate", "dest_plate")

        # Should have 2 * 3 = 6 pairs
        assert len(pairs) == 6

        # Check all combinations exist
        expected_wells = [
            ("A1", "B1"), ("A1", "B2"), ("A1", "B3"),
            ("A2", "B1"), ("A2", "B2"), ("A2", "B3"),
        ]
        actual_wells = [(p.source_well, p.dest_well) for p in pairs]
        for expected in expected_wells:
            assert expected in actual_wells


class TestHTSWellSets:
    """Test well set handling with BPL's range and iteration syntax."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_range_expression_for_columns(self, parser):
        """Test range expression syntax using '..' operator for column iteration."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        reagent Buffer { physical_form: Liquid }

        protocol Test {
            // BPL uses '..' for ranges - represents column indices 1-8
            let column_count = 8
            for col in 1..column_count {
                distribute(Buffer, volume: 10 uL, to: Plate)
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_row_iteration_with_list(self, parser):
        """Test iterating over row data using lists."""
        source = '''
        labware Plate1 { footprint: SBS_Standard }
        labware Plate2 { footprint: SBS_Standard }

        protocol Test {
            // Process rows as list of row identifiers (simulated as indices)
            let row_volumes = [10 uL, 20 uL, 30 uL, 40 uL, 50 uL, 60 uL, 70 uL, 80 uL]
            for vol in row_volumes {
                transfer(from: Plate1, to: Plate2, volume: vol)
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_quadrant_processing_with_nested_loops(self, parser):
        """Test processing plate quadrants using nested loop constructs."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        reagent Buffer { physical_form: Liquid }

        protocol Test {
            // Process plate in 4 quadrants using loop iteration
            let quadrants = [1, 2, 3, 4]
            for q in quadrants {
                let quad_volume = 25 uL
                distribute(Buffer, volume: quad_volume, to: Plate)
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_index_access_for_data_arrays(self, parser):
        """Test index access with bracket notation for result processing."""
        source = '''
        protocol Test {
            // Index access for accessing specific elements
            let readings = [0.5, 1.2, 0.8, 1.5, 0.9, 1.1]
            let first_reading = readings[0]
            let last_reading = readings[5]
            let average = (first_reading + last_reading) / 2
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHTSDistribute:
    """Test distribute operations."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_distribute_to_wellset(self, parser):
        """Test distribute to labware."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        reagent Buffer { physical_form: Liquid }

        protocol Test {
            distribute(Buffer, volume: 100 uL, to: Plate)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_distribute_with_tip_policy(self, parser):
        """Test distribute with annotation."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        reagent Buffer { physical_form: Liquid }

        protocol Test {
            @tip_policy(reuse_source)
            distribute(Buffer, volume: 100 uL, to: Plate)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHTSReading:
    """Test plate reading operations."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_read_absorbance(self, parser):
        """Test absorbance reading with wavelength specification."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            // Read absorbance at specified wavelength
            let results = read_absorbance(plate: Plate, wavelength: 450 nm)

            // Store reading for analysis
            let absorbance_value = results
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_read_fluorescence(self, parser):
        """Test fluorescence reading with excitation and emission wavelengths."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            // Read fluorescence with dual wavelengths
            let results = read_fluorescence(plate: Plate, excitation: 485 nm, emission: 535 nm)

            // Calculate fluorescence ratio
            let baseline = 100.0
            let ratio = results / baseline
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_kinetic_reading(self, parser):
        """Test kinetic (time-series) reading."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            // Kinetic reading loop
            let time_points = [0, 10, 20, 30, 40, 50, 60]
            for t in time_points {
                let reading = read_absorbance(plate: Plate, wavelength: 600 nm)
                wait(time: 10 min)
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHTSStatistics:
    """Test statistical calculations."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_mean_calculation(self, parser):
        """Test mean calculation."""
        source = '''
        protocol Test {
            let values = [1.0, 2.0, 3.0, 4.0, 5.0]
            let avg = mean(values)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_std_calculation(self, parser):
        """Test standard deviation calculation."""
        source = '''
        protocol Test {
            let values = [1.0, 2.0, 3.0]
            let deviation = std(values)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_z_prime_formula(self, parser):
        """Test Z-prime formula parsing."""
        source = '''
        protocol Test {
            let pos_mean = 100
            let pos_std = 5
            let neg_mean = 20
            let neg_std = 3
            let z_prime = 1 - (3 * (pos_std + neg_std) / abs(pos_mean - neg_mean))
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHTSIntegration:
    """Integration tests for HTS protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_full_protocol_structure(self, parser):
        """Test complete protocol structure."""
        ast = parser.parse(HTS_96WELL_PROTOCOL)

        from bpl.ast.declarations import (
            ReagentDecl, LabwareDecl, ProtocolDecl, DeckModelDecl
        )

        reagents = [d for d in ast.declarations if isinstance(d, ReagentDecl)]
        labware = [d for d in ast.declarations if isinstance(d, LabwareDecl)]
        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]
        deck_models = [d for d in ast.declarations if isinstance(d, DeckModelDecl)]

        assert len(reagents) == 4
        assert len(labware) == 4  # SourcePlate96, AssayPlate96, CompoundPlate, TipRack200
        assert len(protocols) == 1
        assert len(deck_models) == 1

    def test_target_annotation(self, parser):
        """Test @target annotation for robot."""
        ast = parser.parse(HTS_96WELL_PROTOCOL)

        from bpl.ast.declarations import ProtocolDecl
        protocol = next(d for d in ast.declarations if isinstance(d, ProtocolDecl))

        annotation_names = [a.name for a in protocol.annotations]
        assert "target" in annotation_names

    def test_deck_annotation(self, parser):
        """Test @deck annotation."""
        ast = parser.parse(HTS_96WELL_PROTOCOL)

        from bpl.ast.declarations import ProtocolDecl
        protocol = next(d for d in ast.declarations if isinstance(d, ProtocolDecl))

        annotation_names = [a.name for a in protocol.annotations]
        assert "deck" in annotation_names
