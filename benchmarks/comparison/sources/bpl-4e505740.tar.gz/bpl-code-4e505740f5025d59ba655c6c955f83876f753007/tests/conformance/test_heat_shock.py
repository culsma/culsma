"""
Conformance Test 2: Heat Shock Transformation Protocol.

Tests full state tracking through a bacterial transformation protocol.
"""

import pytest
from bpl.parser.bpl_parser import BPLParser
from bpl.ast.program import Program
from bpl.state.state_model import (
    PlateContents,
    WellContents,
)
from bpl.state.trust import (
    ConfidenceLevel,
    ProtocolContext,
    Declared,
    TrustSource,
)


# Heat shock transformation protocol - Simplified for grammar compliance
HEAT_SHOCK_PROTOCOL = '''
// Heat Shock Transformation Protocol

reagent CompetentCells {
    physical_form: Liquid
    description: "Chemically competent E. coli DH5alpha"
    storage_temp: -80 degC
}

reagent PlasmidDNA {
    physical_form: Liquid
    description: "Purified plasmid DNA"
}

reagent SOCMedia {
    physical_form: Liquid
    description: "Super Optimal broth with Catabolite repression"
}

reagent LBAgarKan {
    physical_form: Solid
    description: "LB Agar with Kanamycin"
}

labware MicrofugeTube {
    footprint: Custom
    well_volume: 1500 uL
}

labware WaterBath42C {
    footprint: Custom
    temperature: 42 degC
}

labware IceBucket {
    footprint: Custom
    temperature: 0 degC
}

labware LBPlate {
    footprint: SBS_Standard
    category: Plate_96
}

@target(human)
@compliance(GLP)
protocol HeatShockTransform(dna_volume: Volume = 1 uL, cell_volume: Volume = 50 uL, recovery_time: Time = 1 h) {
    // Step 1: Thaw cells on ice
    @step(1, "Thaw competent cells")
    @checkpoint("cells_thawed")
    transfer(from: CompetentCells, volume: cell_volume, to: MicrofugeTube)

    // Step 2: Add DNA
    @step(2, "Add plasmid DNA")
    transfer(from: PlasmidDNA, volume: dna_volume, to: MicrofugeTube)

    // Step 3: Incubate on ice
    @step(3, "Incubate on ice")
    incubate(target: MicrofugeTube, temperature: 0 degC, time: 30 min)

    // Step 4: Heat shock
    @step(4, "Heat shock")
    @critical
    incubate(target: MicrofugeTube, temperature: 42 degC, time: 45 s)

    // Step 5: Ice recovery
    @step(5, "Return to ice")
    incubate(target: MicrofugeTube, temperature: 0 degC, time: 2 min)

    // Step 6: Add recovery media
    @step(6, "Add SOC media")
    transfer(from: SOCMedia, volume: 950 uL, to: MicrofugeTube)

    // Step 7: Recovery incubation
    @step(7, "Recovery incubation")
    incubate(target: MicrofugeTube, temperature: 37 degC, time: recovery_time)

    // Step 8: Plate transformation
    @step(8, "Plate cells")
    transfer(from: MicrofugeTube, volume: 100 uL, to: LBPlate)

    // Step 9: Incubate plates
    @step(9, "Incubate plates")
    incubate(target: LBPlate, temperature: 37 degC, time: 16 h)

    // Step 10: Calculate efficiency
    @step(10, "Calculate efficiency")
    let colony_count = 100
    let efficiency = colony_count * 10
}
'''


class TestHeatShockParsing:
    """Test parsing of the Heat Shock protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_complete_protocol(self, parser):
        """Test complete protocol parsing."""
        ast = parser.parse(HEAT_SHOCK_PROTOCOL)
        assert isinstance(ast, Program)

    def test_compliance_annotation(self, parser):
        """Test @compliance annotation is parsed."""
        source = '''
        @compliance(GLP)
        protocol Test {
            let x = 1
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_critical_annotation(self, parser):
        """Test @critical annotation is parsed."""
        source = '''
        labware Tube { footprint: Custom }

        protocol Test {
            @critical
            incubate(target: Tube, temperature: 42 degC, time: 45 s)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_checkpoint_annotation(self, parser):
        """Test @checkpoint annotation is parsed."""
        source = '''
        protocol Test {
            @checkpoint("step_complete")
            let x = 1
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHeatShockStateTracking:
    """Test state tracking through the protocol."""

    def test_create_plate_contents(self):
        """Test creating plate contents."""
        plate = PlateContents(
            plate_id="tube_1",
            rows=1,
            cols=1,
        )
        assert plate.plate_id == "tube_1"

    def test_well_contents_creation(self):
        """Test creating well contents."""
        # WellContents uses StateProperty for volume, not plain numbers
        contents = WellContents(
            components={"competent_cells": 50.0},
        )
        assert "competent_cells" in contents.components

    def test_state_after_addition(self):
        """Test state changes after adding reagent."""
        # Create well contents with component tracking
        initial = WellContents(
            components={"competent_cells": 50.0},
        )

        # Add 1 uL DNA - components track amounts
        dna_addition = WellContents(
            components={"plasmid_dna": 1.0},
        )

        # Combined state would merge components
        combined_components = {**initial.components, **dna_addition.components}
        assert "competent_cells" in combined_components
        assert "plasmid_dna" in combined_components

    def test_state_after_soc_addition(self):
        """Test state after adding SOC media."""
        # After DNA addition: 51 uL
        # Add 950 uL SOC
        final_volume = 51.0 + 950.0
        assert final_volume == 1001.0

    def test_trust_level_types(self):
        """Test trust level types."""
        # Declared trust (lowest) - takes TrustSource enum
        declared = Declared(source=TrustSource.USER)
        assert declared.confidence == ConfidenceLevel.LOW

    def test_confidence_levels(self):
        """Test confidence level ordering."""
        # Lower confidence levels should be less than higher ones
        assert ConfidenceLevel.LOW.value < ConfidenceLevel.HIGH.value

    def test_protocol_context(self):
        """Test protocol context values."""
        # Different protocol contexts have different requirements
        glp_context = ProtocolContext.GLP
        research_context = ProtocolContext.RESEARCH

        assert glp_context != research_context


class TestHeatShockTemperature:
    """Test temperature handling in the protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_temperature_values(self, parser):
        """Test parsing temperature values."""
        source = '''
        protocol Test {
            let ice_temp = 0 degC
            let heat_shock = 42 degC
            let growth = 37 degC
            let storage = -80 degC
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_incubate_with_temperature(self, parser):
        """Test incubate statement with temperature."""
        source = '''
        labware Tube { footprint: Custom }

        protocol Test {
            incubate(target: Tube, temperature: 42 degC, time: 45 s)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_temperature_transitions(self):
        """Test temperature state transitions."""
        # Track temperature through protocol
        temperatures = [
            (-80, "Storage"),
            (0, "Thawing on ice"),
            (0, "DNA addition"),
            (0, "Ice incubation"),
            (42, "Heat shock"),
            (0, "Ice recovery"),
            (37, "Recovery incubation"),
            (37, "Growth"),
        ]

        # Verify heat shock transition
        heat_shock_idx = 4
        assert temperatures[heat_shock_idx][0] == 42
        assert temperatures[heat_shock_idx - 1][0] == 0  # From ice
        assert temperatures[heat_shock_idx + 1][0] == 0  # Back to ice


class TestHeatShockTiming:
    """Test timing handling in the protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_time_values(self, parser):
        """Test parsing various time units."""
        source = '''
        protocol Test {
            let thaw_time = 15 min
            let ice_incubation = 30 min
            let heat_shock = 45 s
            let ice_recovery = 2 min
            let recovery_time = 1 h
            let growth = 16 h
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_incubate_with_time(self, parser):
        """Test incubate statement with time."""
        source = '''
        labware Tube { footprint: Custom }

        protocol Test {
            incubate(target: Tube, temperature: 42 degC, time: 45 s)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHeatShockDataCapture:
    """Test data capture in the protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_manual_step(self, parser):
        """Test basic manual step."""
        source = '''
        protocol Test {
            manual("Count colonies")
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_calculated_efficiency(self, parser):
        """Test efficiency calculation."""
        source = '''
        protocol Test {
            let colony_count = 100
            let dna_ng = 10
            let efficiency = colony_count / dna_ng
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestHeatShockIntegration:
    """Integration tests for the Heat Shock protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_full_protocol_structure(self, parser):
        """Test complete protocol structure."""
        ast = parser.parse(HEAT_SHOCK_PROTOCOL)

        # Should have reagents, labware, and protocol
        from bpl.ast.declarations import ReagentDecl, LabwareDecl, ProtocolDecl

        reagents = [d for d in ast.declarations if isinstance(d, ReagentDecl)]
        labware = [d for d in ast.declarations if isinstance(d, LabwareDecl)]
        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]

        assert len(reagents) == 4  # CompetentCells, PlasmidDNA, SOCMedia, LBAgarKan
        assert len(labware) == 4  # MicrofugeTube, WaterBath42C, IceBucket, LBPlate
        assert len(protocols) == 1  # HeatShockTransform

    def test_protocol_steps(self, parser):
        """Test that protocol has expected number of steps."""
        ast = parser.parse(HEAT_SHOCK_PROTOCOL)

        from bpl.ast.declarations import ProtocolDecl
        protocol = next(d for d in ast.declarations if isinstance(d, ProtocolDecl))

        # Protocol body should have statements (body is a list)
        assert protocol.body is not None
        assert len(protocol.body) > 0

    def test_for_loop_parsing(self, parser):
        """Test for loop in plating step."""
        source = '''
        labware Plate { footprint: SBS_Standard }
        labware Tube { footprint: Custom }

        protocol Test {
            let volumes = [10 uL, 100 uL]
            for vol in volumes {
                transfer(from: Tube, volume: vol, to: Plate)
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)
