"""
Conformance Test 5: Multi-Resource Workflow.

Tests parallel incubation, resource scheduling, error recovery, and checkpoints.
"""

import pytest
from bpl.parser.bpl_parser import BPLParser
from bpl.ast.program import Program
from bpl.scheduler.resource_manager import (
    ResourceManager,
    Resource,
    ResourceType,
)
from bpl.errors.error_policy import (
    ErrorPolicy,
    ErrorAction,
)
from bpl.simulation.checkpoint import (
    CheckpointManager,
    CheckpointType,
)


# Multi-Resource Workflow Protocol - Simplified for grammar compliance
MULTI_RESOURCE_PROTOCOL = '''
// Multi-Resource Workflow Protocol
// Demonstrates parallel operations and resource scheduling

reagent Cells {
    physical_form: Liquid
    description: "Cell suspension"
}

reagent Media {
    physical_form: Liquid
    description: "Growth media"
}

reagent Substrate {
    physical_form: Liquid
    description: "Assay substrate"
}

labware DeepWellPlate {
    footprint: SBS_Standard
    category: Plate_96
    well_volume: 2000 uL
}

labware AssayPlate {
    footprint: SBS_Standard
    category: Plate_96
    well_volume: 200 uL
}

labware TipRack200 {
    footprint: SBS_Standard
    category: TipRack
}

labware TipRack1000 {
    footprint: SBS_Standard
    category: TipRack
}

// Shared resources
resource Incubator37 {
    capacity: 8
    booking_required: true
}

resource Shaker {
    capacity: 4
    booking_required: true
}

resource PlateReader {
    capacity: 1
    booking_required: true
}

resource Pipettor {
    capacity: 1
    booking_required: false
}

deck_model MultiResourceDeck {
    positions: [
        { id: "P1", accepts: [SBS_Standard] },
        { id: "P2", accepts: [SBS_Standard] },
        { id: "P3", accepts: [SBS_Standard] },
        { id: "P4", accepts: [SBS_Standard] },
        { id: "P5", accepts: [SBS_Standard] },
        { id: "P6", accepts: [SBS_Standard] }
    ]
}

@target(biomek_i7)
@deck(MultiResourceDeck)
protocol MultiResourceWorkflow(growth_time: Time = 4 h, assay_time: Time = 30 min, read_count: Number = 3) {
    // Step 1: Prepare cell plates
    @step(1, "Seed cells")
    @checkpoint("cells_seeded")
    distribute(Cells, volume: 100 uL, to: DeepWellPlate)

    // Step 2: Add media
    @step(2, "Add growth media")
    distribute(Media, volume: 900 uL, to: DeepWellPlate)

    // Step 3: Growth incubation
    @step(3, "Growth incubation")
    @parallel
    incubate(target: DeepWellPlate, temperature: 37 degC, time: growth_time)

    // Step 4: Prepare assay plate
    @step(4, "Prepare assay plate")
    distribute(Substrate, volume: 50 uL, to: AssayPlate)

    // Step 5: Transfer cells to assay plate
    @step(5, "Transfer to assay")
    @checkpoint("pre_transfer")
    transfer(from: DeepWellPlate, volume: 10 uL, to: AssayPlate)

    // Step 6: Assay incubation
    @step(6, "Assay incubation")
    incubate(target: AssayPlate, temperature: 37 degC, time: assay_time)

    // Step 7: Read plate
    @step(7, "Read plate")
    let reading = read_absorbance(plate: AssayPlate, wavelength: 600 nm)

    // Step 8: Calculate growth rates
    @step(8, "Calculate results")
    let growth_rate = reading * 10
}
'''


class TestMultiResourceParsing:
    """Test parsing of the Multi-Resource protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_parse_complete_protocol(self, parser):
        """Test complete protocol parsing."""
        ast = parser.parse(MULTI_RESOURCE_PROTOCOL)
        assert isinstance(ast, Program)

    def test_resource_declaration(self, parser):
        """Test resource declarations."""
        source = '''
        resource Incubator {
            type: incubator
            temperature: 37 degC
            capacity: 8
            shared: true
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_parallel_annotation(self, parser):
        """Test @parallel annotation."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            @parallel
            incubate(target: Plate, temperature: 37 degC, time: 1 h)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_parallel_with_annotation(self, parser):
        """Test @parallel_with annotation."""
        source = '''
        protocol Test {
            @step(1, "Long step")
            wait(time: 1 h)

            @step(2, "Concurrent step")
            @parallel_with(step: 1)
            let x = 1
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_after_annotation(self, parser):
        """Test @after dependency annotation."""
        source = '''
        protocol Test {
            @step(1, "First")
            let a = 1

            @step(2, "Second")
            @after(step: 1)
            let b = 2
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)


class TestResourceManagement:
    """Test resource management."""

    def test_create_resource(self):
        """Test creating a resource."""
        resource = Resource(
            resource_id="incubator_1",
            resource_type=ResourceType.INCUBATOR,
            capacity=8,
        )
        assert resource.capacity == 8
        assert resource.is_available is True

    def test_resource_manager_booking(self):
        """Test resource booking."""
        manager = ResourceManager()

        # Register resource (not add_resource)
        manager.register_resource(Resource(
            resource_id="reader_1",
            resource_type=ResourceType.PLATE_READER,
            capacity=1,
        ))

        # Acquire resource (not book)
        booking = manager.acquire(
            resource_id="reader_1",
            step_id="step_7",
        )

        assert booking is not None
        assert booking.resource_id == "reader_1"

    def test_resource_conflict_detection(self):
        """Test detecting resource conflicts."""
        from bpl.scheduler.resource_manager import ResourceConflictError

        manager = ResourceManager()

        manager.register_resource(Resource(
            resource_id="reader_1",
            resource_type=ResourceType.PLATE_READER,
            capacity=1,
        ))

        # First acquisition
        manager.acquire("reader_1", "step_1")

        # Conflicting acquisition should raise error
        with pytest.raises(ResourceConflictError):
            manager.acquire("reader_1", "step_2")

    def test_shared_resource_capacity(self):
        """Test shared resource respects capacity."""
        from bpl.scheduler.resource_manager import ResourceConflictError

        manager = ResourceManager()

        manager.register_resource(Resource(
            resource_id="incubator_1",
            resource_type=ResourceType.INCUBATOR,
            capacity=2,
        ))

        # Book first slot
        b1 = manager.acquire("incubator_1", "step_1")
        assert b1 is not None

        # Book second slot - should work (capacity 2)
        b2 = manager.acquire("incubator_1", "step_2")
        assert b2 is not None

        # Book third slot - should fail (over capacity)
        with pytest.raises(ResourceConflictError):
            manager.acquire("incubator_1", "step_3")


class TestScheduling:
    """Test scheduling functionality."""

    def test_scheduler_creation(self):
        """Test creating a scheduler."""
        from bpl.scheduler.scheduler import Scheduler, SchedulingStrategy

        scheduler = Scheduler(strategy=SchedulingStrategy.GREEDY)
        assert scheduler.strategy == SchedulingStrategy.GREEDY

    def test_scheduler_time_window(self):
        """Test time window strategy."""
        from bpl.scheduler.scheduler import Scheduler, SchedulingStrategy

        scheduler = Scheduler(strategy=SchedulingStrategy.TIME_WINDOW)
        assert scheduler.strategy == SchedulingStrategy.TIME_WINDOW

    def test_scheduler_critical_path(self):
        """Test critical path strategy."""
        from bpl.scheduler.scheduler import Scheduler, SchedulingStrategy

        scheduler = Scheduler(strategy=SchedulingStrategy.CRITICAL_PATH)
        assert scheduler.strategy == SchedulingStrategy.CRITICAL_PATH

    def test_scheduler_with_resource_manager(self):
        """Test scheduler with resource manager."""
        from bpl.scheduler.scheduler import Scheduler, SchedulingStrategy

        resource_manager = ResourceManager()
        scheduler = Scheduler(
            resource_manager=resource_manager,
            strategy=SchedulingStrategy.GREEDY
        )
        assert scheduler.resource_manager is resource_manager


class TestErrorPolicy:
    """Test error policy handling."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_error_policy_annotation(self, parser):
        """Test @error_policy annotation."""
        source = '''
        @error_policy(default: retry(3))
        protocol Test {
            let x = 1
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_on_error_annotation(self, parser):
        """Test @on_error annotation."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            @on_error(TipClog)
            transfer(from: Plate, to: Plate, volume: 100 uL)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_policy_action_retry(self):
        """Test retry policy action using factory method."""
        policy = ErrorPolicy.retry(max_attempts=3)

        assert policy.action == ErrorAction.RETRY
        assert policy.retry_config is not None
        assert policy.retry_config.max_attempts == 3

    def test_policy_action_skip(self):
        """Test skip policy action using factory method."""
        policy = ErrorPolicy.skip()

        assert policy.action == ErrorAction.SKIP

    def test_policy_creation(self):
        """Test policy creation using factory methods."""
        policy1 = ErrorPolicy.retry(max_attempts=2)
        policy2 = ErrorPolicy.stop()

        assert policy1.action == ErrorAction.RETRY
        assert policy2.action == ErrorAction.STOP

    def test_policy_alert_and_continue(self):
        """Test alert-and-continue policy."""
        policy = ErrorPolicy.alert_and_continue("Warning message")

        assert policy.action == ErrorAction.ALERT_AND_CONTINUE
        assert policy.message_template == "Warning message"


class TestCheckpoints:
    """Test checkpoint functionality."""

    def test_create_checkpoint(self):
        """Test creating a checkpoint via manager."""
        manager = CheckpointManager()

        checkpoint = manager.create_checkpoint(
            step_id="step_1",
            checkpoint_type=CheckpointType.MILESTONE,
            deck_state_hash="hash1",
            execution_state_hash="hash2",
            description="Cells seeded"
        )

        assert checkpoint is not None
        assert checkpoint.checkpoint_type == CheckpointType.MILESTONE
        assert checkpoint.step_id == "step_1"

    def test_checkpoint_manager(self):
        """Test checkpoint manager basics."""
        manager = CheckpointManager()

        # Create checkpoint
        cp = manager.create_checkpoint(
            step_id="step_5",
            checkpoint_type=CheckpointType.MILESTONE,
            deck_state_hash="hash1",
            execution_state_hash="hash2"
        )
        assert cp is not None

        # Get checkpoint
        retrieved = manager.get_checkpoint(cp.checkpoint_id)
        assert retrieved is not None
        assert retrieved.step_id == "step_5"

    def test_checkpoint_annotation(self):
        """Test @checkpoint annotation parsing."""
        parser = BPLParser()
        source = '''
        protocol Test {
            @checkpoint("step_complete")
            let x = 1
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_checkpoint_chain(self):
        """Test checkpoint chain tracking."""
        manager = CheckpointManager()

        # Create multiple checkpoints
        cp1 = manager.create_checkpoint("step_1", CheckpointType.MILESTONE, "h1", "h2")
        manager.create_checkpoint("step_5", CheckpointType.MILESTONE, "h3", "h4")
        cp3 = manager.create_checkpoint("step_7", CheckpointType.MILESTONE, "h5", "h6")

        # Check chain
        chain = manager.get_checkpoint_chain()
        assert len(chain) == 3
        assert chain[0].checkpoint_id == cp1.checkpoint_id
        assert chain[2].checkpoint_id == cp3.checkpoint_id

    def test_checkpoint_integrity(self):
        """Test checkpoint integrity verification."""
        manager = CheckpointManager()

        cp = manager.create_checkpoint("step_1", CheckpointType.MILESTONE, "h1", "h2")

        # Verify integrity
        assert cp.verify_integrity() is True

    def test_latest_checkpoint(self):
        """Test getting latest checkpoint."""
        manager = CheckpointManager()

        manager.create_checkpoint("step_1", CheckpointType.MILESTONE, "h1", "h2")
        manager.create_checkpoint("step_5", CheckpointType.MILESTONE, "h3", "h4")
        cp3 = manager.create_checkpoint("step_7", CheckpointType.MILESTONE, "h5", "h6")

        latest = manager.get_latest_checkpoint()
        assert latest is not None
        assert latest.checkpoint_id == cp3.checkpoint_id


class TestMultiResourceIntegration:
    """Integration tests for Multi-Resource protocol."""

    @pytest.fixture
    def parser(self):
        return BPLParser()

    def test_full_protocol_structure(self, parser):
        """Test complete protocol structure."""
        ast = parser.parse(MULTI_RESOURCE_PROTOCOL)

        from bpl.ast.declarations import (
            ReagentDecl, LabwareDecl, ProtocolDecl
        )

        reagents = [d for d in ast.declarations if isinstance(d, ReagentDecl)]
        labware = [d for d in ast.declarations if isinstance(d, LabwareDecl)]
        protocols = [d for d in ast.declarations if isinstance(d, ProtocolDecl)]

        assert len(reagents) == 3
        assert len(labware) == 4
        assert len(protocols) == 1

    def test_kinetic_reading_loop(self, parser):
        """Test kinetic reading for loop."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            for i in [1, 2, 3] {
                let reading = read_absorbance(plate: Plate, wavelength: 600 nm)
                if i < 3 {
                    wait(time: 10 min)
                }
            }
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_resource_annotation(self, parser):
        """Test @resource annotation."""
        source = '''
        resource Reader { capacity: 1 }
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            @resource(Reader)
            let data = read_absorbance(plate: Plate, wavelength: 450 nm)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_transfer_basic(self, parser):
        """Test basic transfer."""
        source = '''
        labware Plate { footprint: SBS_Standard }

        protocol Test {
            transfer(from: Plate, to: Plate, volume: 10 uL)
        }
        '''
        ast = parser.parse(source)
        assert isinstance(ast, Program)

    def test_complete_workflow_simulation(self):
        """Test simulating complete workflow with resource management."""
        from bpl.scheduler.scheduler import Scheduler, SchedulingStrategy

        # Create resource manager with shared resources
        resource_manager = ResourceManager()
        resource_manager.register_resource(Resource(
            resource_id="incubator",
            resource_type=ResourceType.INCUBATOR,
            capacity=4,
        ))
        resource_manager.register_resource(Resource(
            resource_id="plate_reader",
            resource_type=ResourceType.PLATE_READER,
            capacity=1,
        ))

        # Create scheduler with resource awareness
        scheduler = Scheduler(
            resource_manager=resource_manager,
            strategy=SchedulingStrategy.TIME_WINDOW
        )

        # Verify scheduler setup
        assert scheduler.resource_manager is not None
        assert scheduler.strategy == SchedulingStrategy.TIME_WINDOW

        # Test resource availability
        assert resource_manager.is_available("incubator")
        assert resource_manager.is_available("plate_reader")
