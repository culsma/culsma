"""
Tests for the BPL Trust System.

Tests cover:
- Trust level creation and attributes
- Trust level comparison and ordering
- Trust propagation rules
- Context-based trust requirements
- Trust upgrades (Declared → Calibrated → Verified)
"""

import pytest
from datetime import datetime

from bpl.state.trust import (
    # Enums
    ConfidenceLevel,
    TrustSource,
    CalibrationMethod,
    ProtocolContext,
    CriticalProperty,
    # Trust levels
    Declared,
    Calibrated,
    Verified,
    ComplianceSignature,
    # Functions
    compare_trust,
    min_trust,
    max_trust,
    meets_minimum_trust,
    get_minimum_trust_for_context,
    validate_trust_for_context,
    upgrade_to_calibrated,
    upgrade_to_verified,
    create_signature,
)


class TestTrustLevelCreation:
    """Test creating trust levels."""

    def test_declared_user_source(self):
        """Declared trust from user input."""
        trust = Declared(source=TrustSource.USER)
        assert trust.source == TrustSource.USER
        assert trust.confidence == ConfidenceLevel.LOW

    def test_declared_compiler_source(self):
        """Declared trust from compiler inference."""
        trust = Declared(source=TrustSource.COMPILER)
        assert trust.source == TrustSource.COMPILER
        assert trust.confidence == ConfidenceLevel.LOW

    def test_calibrated_balance(self):
        """Calibrated trust from balance measurement."""
        ts = datetime(2024, 1, 15, 10, 30)
        trust = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        assert trust.method == CalibrationMethod.BALANCE
        assert trust.timestamp == ts
        assert trust.confidence == ConfidenceLevel.MEDIUM

    def test_calibrated_plate_reader(self):
        """Calibrated trust from plate reader."""
        ts = datetime.now()
        trust = Calibrated(method=CalibrationMethod.PLATE_READER, timestamp=ts)
        assert trust.method == CalibrationMethod.PLATE_READER
        assert trust.confidence == ConfidenceLevel.MEDIUM

    def test_verified(self):
        """Verified trust with signature."""
        ts = datetime.now()
        calibration = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        signature = ComplianceSignature(
            signer_id="operator_001",
            meaning="Approval",
            timestamp=ts,
            signature_hash="abc123"
        )
        trust = Verified(
            calibration=calibration,
            verified_by="operator_001",
            signature=signature
        )
        assert trust.verified_by == "operator_001"
        assert trust.calibration == calibration
        assert trust.signature == signature
        assert trust.confidence == ConfidenceLevel.HIGH

    def test_trust_levels_are_frozen(self):
        """Trust levels should be immutable."""
        trust = Declared(source=TrustSource.USER)
        with pytest.raises(Exception):  # FrozenInstanceError
            trust.source = TrustSource.COMPILER


class TestTrustLevelComparison:
    """Test comparing trust levels."""

    def test_compare_declared_vs_calibrated(self):
        """Declared < Calibrated."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        assert compare_trust(declared, calibrated) == -1
        assert compare_trust(calibrated, declared) == 1

    def test_compare_calibrated_vs_verified(self):
        """Calibrated < Verified."""
        ts = datetime.now()
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        signature = ComplianceSignature(
            signer_id="op1", meaning="Approval", timestamp=ts, signature_hash="xyz"
        )
        verified = Verified(
            calibration=calibrated,
            verified_by="op1",
            signature=signature
        )

        assert compare_trust(calibrated, verified) == -1
        assert compare_trust(verified, calibrated) == 1

    def test_compare_declared_vs_verified(self):
        """Declared < Verified."""
        declared = Declared(source=TrustSource.USER)
        ts = datetime.now()
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        signature = ComplianceSignature(
            signer_id="op1", meaning="Approval", timestamp=ts, signature_hash="xyz"
        )
        verified = Verified(
            calibration=calibrated,
            verified_by="op1",
            signature=signature
        )

        assert compare_trust(declared, verified) == -1
        assert compare_trust(verified, declared) == 1

    def test_compare_same_level(self):
        """Same level compares equal."""
        declared1 = Declared(source=TrustSource.USER)
        declared2 = Declared(source=TrustSource.COMPILER)

        # Same confidence level even with different sources
        assert compare_trust(declared1, declared2) == 0


class TestTrustPropagation:
    """Test trust propagation through calculations."""

    def test_min_trust_single(self):
        """Min of single trust is itself."""
        declared = Declared(source=TrustSource.USER)
        assert min_trust(declared) == declared

    def test_min_trust_declared_calibrated(self):
        """Min of Declared and Calibrated is Declared."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        result = min_trust(declared, calibrated)
        assert result == declared
        assert result.confidence == ConfidenceLevel.LOW

    def test_min_trust_multiple(self):
        """Min of multiple trust levels."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())
        ts = datetime.now()
        signature = ComplianceSignature(
            signer_id="op1", meaning="Approval", timestamp=ts, signature_hash="xyz"
        )
        verified = Verified(
            calibration=calibrated,
            verified_by="op1",
            signature=signature
        )

        result = min_trust(verified, calibrated, declared)
        assert result == declared

    def test_max_trust(self):
        """Max of multiple trust levels."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        result = max_trust(declared, calibrated)
        assert result == calibrated

    def test_min_trust_empty_raises(self):
        """Min of empty collection raises."""
        with pytest.raises(ValueError, match="At least one"):
            min_trust()


class TestMeetsMinimumTrust:
    """Test meets_minimum_trust helper."""

    def test_calibrated_meets_declared(self):
        """Calibrated meets Declared requirement."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        assert meets_minimum_trust(calibrated, declared) is True

    def test_declared_does_not_meet_calibrated(self):
        """Declared doesn't meet Calibrated requirement."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        assert meets_minimum_trust(declared, calibrated) is False

    def test_same_level_meets(self):
        """Same level meets requirement."""
        declared = Declared(source=TrustSource.USER)
        assert meets_minimum_trust(declared, declared) is True


class TestContextBasedTrust:
    """Test context-based trust requirements."""

    def test_research_minimum_is_declared(self):
        """Research context accepts Declared."""
        min_class = get_minimum_trust_for_context(ProtocolContext.RESEARCH)
        assert min_class == Declared

    def test_glp_critical_requires_calibrated(self):
        """GLP context requires Calibrated for critical properties."""
        min_class = get_minimum_trust_for_context(
            ProtocolContext.GLP,
            CriticalProperty.VOLUME
        )
        assert min_class == Calibrated

    def test_glp_non_critical_accepts_declared(self):
        """GLP context accepts Declared for non-critical properties."""
        min_class = get_minimum_trust_for_context(ProtocolContext.GLP, None)
        assert min_class == Declared

    def test_gmp_requires_verified(self):
        """GMP context requires Verified for all."""
        min_class = get_minimum_trust_for_context(ProtocolContext.GMP)
        assert min_class == Verified


class TestValidateTrustForContext:
    """Test validate_trust_for_context."""

    def test_research_accepts_declared(self):
        """Research context accepts Declared trust."""
        declared = Declared(source=TrustSource.USER)
        is_valid, error = validate_trust_for_context(
            declared,
            ProtocolContext.RESEARCH
        )
        assert is_valid is True
        assert error is None

    def test_glp_rejects_declared_for_volume(self):
        """GLP rejects Declared for volume."""
        declared = Declared(source=TrustSource.USER)
        is_valid, error = validate_trust_for_context(
            declared,
            ProtocolContext.GLP,
            CriticalProperty.VOLUME
        )
        assert is_valid is False
        assert "requires Calibrated" in error

    def test_glp_accepts_calibrated_for_volume(self):
        """GLP accepts Calibrated for volume."""
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())
        is_valid, error = validate_trust_for_context(
            calibrated,
            ProtocolContext.GLP,
            CriticalProperty.VOLUME
        )
        assert is_valid is True
        assert error is None

    def test_gmp_rejects_calibrated(self):
        """GMP rejects Calibrated (requires Verified)."""
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())
        is_valid, error = validate_trust_for_context(
            calibrated,
            ProtocolContext.GMP
        )
        assert is_valid is False
        assert "requires Verified" in error


class TestTrustUpgrade:
    """Test upgrading trust levels."""

    def test_upgrade_declared_to_calibrated(self):
        """Upgrade Declared → Calibrated."""
        declared = Declared(source=TrustSource.USER)
        ts = datetime(2024, 1, 15, 10, 30)

        calibrated = upgrade_to_calibrated(
            declared,
            method=CalibrationMethod.BALANCE,
            timestamp=ts
        )

        assert isinstance(calibrated, Calibrated)
        assert calibrated.method == CalibrationMethod.BALANCE
        assert calibrated.timestamp == ts
        assert calibrated.confidence == ConfidenceLevel.MEDIUM

    def test_upgrade_calibrated_to_verified(self):
        """Upgrade Calibrated → Verified."""
        ts = datetime.now()
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        signature = create_signature(
            signer_id="operator_001",
            meaning="Approval",
            data_hash="abc123"
        )

        verified = upgrade_to_verified(
            calibrated,
            verified_by="operator_001",
            signature=signature
        )

        assert isinstance(verified, Verified)
        assert verified.verified_by == "operator_001"
        assert verified.calibration == calibrated
        assert verified.confidence == ConfidenceLevel.HIGH


class TestComplianceSignature:
    """Test compliance signature creation."""

    def test_create_signature(self):
        """Create a compliance signature."""
        signature = create_signature(
            signer_id="operator_001",
            meaning="Approval",
            data_hash="abc123"
        )

        assert signature.signer_id == "operator_001"
        assert signature.meaning == "Approval"
        assert signature.timestamp is not None
        assert len(signature.signature_hash) == 64  # SHA-256 hex

    def test_signature_is_deterministic(self):
        """Same inputs at same time produce same signature."""
        ts = datetime(2024, 1, 15, 10, 30, 0)

        sig1 = create_signature(
            signer_id="op1",
            meaning="Approval",
            data_hash="abc",
            timestamp=ts
        )
        sig2 = create_signature(
            signer_id="op1",
            meaning="Approval",
            data_hash="abc",
            timestamp=ts
        )

        assert sig1.signature_hash == sig2.signature_hash

    def test_different_inputs_produce_different_signatures(self):
        """Different inputs produce different signatures."""
        ts = datetime.now()

        sig1 = create_signature("op1", "Approval", "abc", ts)
        sig2 = create_signature("op2", "Approval", "abc", ts)
        sig3 = create_signature("op1", "Review", "abc", ts)

        assert sig1.signature_hash != sig2.signature_hash
        assert sig1.signature_hash != sig3.signature_hash


class TestTrustLevelStringRepresentation:
    """Test string representation of trust levels."""

    def test_declared_str(self):
        """Declared string representation."""
        trust = Declared(source=TrustSource.USER)
        s = str(trust)
        assert "Declared" in s
        assert "USER" in s

    def test_calibrated_str(self):
        """Calibrated string representation."""
        trust = Calibrated(
            method=CalibrationMethod.BALANCE,
            timestamp=datetime(2024, 1, 15, 10, 30)
        )
        s = str(trust)
        assert "Calibrated" in s
        assert "BALANCE" in s

    def test_verified_str(self):
        """Verified string representation."""
        ts = datetime.now()
        calibration = Calibrated(method=CalibrationMethod.BALANCE, timestamp=ts)
        signature = ComplianceSignature(
            signer_id="op1", meaning="Approval", timestamp=ts, signature_hash="xyz"
        )
        trust = Verified(
            calibration=calibration,
            verified_by="op1",
            signature=signature
        )
        s = str(trust)
        assert "Verified" in s
        assert "op1" in s


class TestCalibrationMethods:
    """Test all calibration methods are defined."""

    def test_all_calibration_methods(self):
        """All calibration methods should be accessible."""
        methods = [
            CalibrationMethod.BALANCE,
            CalibrationMethod.PIPETTE,
            CalibrationMethod.PLATE_READER,
            CalibrationMethod.PH_METER,
            CalibrationMethod.TEMPERATURE_PROBE,
            CalibrationMethod.CELL_COUNTER,
            CalibrationMethod.SPECTROPHOTOMETER,
            CalibrationMethod.VISUAL,
        ]
        assert len(methods) == 8

        # All should work in Calibrated
        for method in methods:
            calibrated = Calibrated(method=method, timestamp=datetime.now())
            assert calibrated.method == method


class TestCriticalProperties:
    """Test critical property definitions."""

    def test_glp_critical_properties(self):
        """Volume, Concentration, CellCount are critical in GLP."""
        critical_in_glp = [
            CriticalProperty.VOLUME,
            CriticalProperty.CONCENTRATION,
            CriticalProperty.CELL_COUNT,
        ]

        for prop in critical_in_glp:
            min_class = get_minimum_trust_for_context(ProtocolContext.GLP, prop)
            assert min_class == Calibrated, f"{prop} should require Calibrated in GLP"

    def test_mass_is_not_critical_in_glp(self):
        """Mass without specific role is not critical in GLP."""
        # Note: This might be changed based on protocol requirements
        min_class = get_minimum_trust_for_context(ProtocolContext.GLP, CriticalProperty.MASS)
        # Mass is not in the critical set, so defaults to Declared
        assert min_class == Declared
