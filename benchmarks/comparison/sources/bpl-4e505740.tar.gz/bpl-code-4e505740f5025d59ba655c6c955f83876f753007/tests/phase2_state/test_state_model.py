"""
Tests for the BPL State Model.

Tests cover:
- StateProperty creation and methods
- Uncertainty propagation (add, subtract, multiply, divide)
- WellContents and ContainerContents
- PlateContents sparse representation
- State deltas (WellDelta, ContainerDelta, StateDelta)
- StateTransition and hash chain
- StateHistory and audit trail
"""

import pytest
import math
from datetime import datetime

from bpl.state.state_model import (
    # State properties
    StateProperty,
    propagate_uncertainty_add,
    propagate_uncertainty_subtract,
    propagate_uncertainty_multiply,
    propagate_uncertainty_divide,
    combine_state_properties,
    # Contents
    WellContents,
    ContainerContents,
    PlateContents,
    # Deltas
    WellDelta,
    ContainerDelta,
    StateDelta,
    # Transitions
    StateTransition,
    StateHistory,
)
from bpl.state.trust import (
    Declared,
    Calibrated,
    TrustSource,
    CalibrationMethod,
    ConfidenceLevel,
)


class TestStateProperty:
    """Test StateProperty creation and methods."""

    def test_create_basic_property(self):
        """Create a basic state property."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(
            value=500.0,
            unit="uL",
            trust=trust
        )
        assert prop.value == 500.0
        assert prop.unit == "uL"
        assert prop.trust == trust
        assert prop.uncertainty is None
        assert prop.last_updated is not None

    def test_create_with_uncertainty(self):
        """Create property with uncertainty."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(
            value=500.0,
            unit="uL",
            trust=trust,
            uncertainty=50.0
        )
        assert prop.value == 500.0
        assert prop.uncertainty == 50.0

    def test_with_uncertainty(self):
        """Update uncertainty using with_uncertainty."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=500.0, unit="uL", trust=trust)

        updated = prop.with_uncertainty(25.0)

        # Original unchanged
        assert prop.uncertainty is None
        # New copy has uncertainty
        assert updated.uncertainty == 25.0
        assert updated.value == 500.0
        assert updated.unit == "uL"

    def test_with_trust(self):
        """Update trust level using with_trust."""
        trust1 = Declared(source=TrustSource.USER)
        trust2 = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        prop = StateProperty(value=500.0, unit="uL", trust=trust1)
        updated = prop.with_trust(trust2)

        # Original unchanged
        assert prop.trust.confidence == ConfidenceLevel.LOW
        # New copy has higher trust
        assert updated.trust.confidence == ConfidenceLevel.MEDIUM
        assert updated.value == 500.0

    def test_update_value_and_trust(self):
        """Update value and trust together."""
        trust1 = Declared(source=TrustSource.USER)
        trust2 = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        prop = StateProperty(value=500.0, unit="uL", trust=trust1)
        updated = prop.update(value=450.0, trust=trust2)

        assert updated.value == 450.0
        assert updated.trust == trust2

    def test_relative_uncertainty(self):
        """Calculate relative uncertainty."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=10.0)

        assert prop.relative_uncertainty == 0.1  # 10%

    def test_relative_uncertainty_none_when_missing(self):
        """Relative uncertainty is None when uncertainty not set."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=100.0, unit="uL", trust=trust)

        assert prop.relative_uncertainty is None

    def test_relative_uncertainty_none_when_zero_value(self):
        """Relative uncertainty is None when value is zero."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=0.0, unit="uL", trust=trust, uncertainty=10.0)

        assert prop.relative_uncertainty is None

    def test_has_high_uncertainty(self):
        """Check high uncertainty detection."""
        trust = Declared(source=TrustSource.USER)

        # 10% uncertainty - not high
        prop1 = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=10.0)
        assert prop1.has_high_uncertainty() is False

        # 25% uncertainty - high (default threshold 20%)
        prop2 = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=25.0)
        assert prop2.has_high_uncertainty() is True

    def test_has_high_uncertainty_custom_threshold(self):
        """Check high uncertainty with custom threshold."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=15.0)

        # 15% is not high with 20% threshold
        assert prop.has_high_uncertainty(threshold=0.2) is False
        # 15% is high with 10% threshold
        assert prop.has_high_uncertainty(threshold=0.1) is True

    def test_repr(self):
        """Test string representation."""
        trust = Declared(source=TrustSource.USER)
        prop = StateProperty(value=500.0, unit="uL", trust=trust, uncertainty=50.0)

        s = repr(prop)
        assert "500.0" in s
        assert "50.0" in s
        assert "uL" in s


class TestUncertaintyPropagation:
    """Test uncertainty propagation through arithmetic."""

    def test_add_uncertainty(self):
        """Propagate uncertainty through addition."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=3.0)
        b = StateProperty(value=200.0, unit="uL", trust=trust, uncertainty=4.0)

        result = propagate_uncertainty_add(a, b)

        # sqrt(3^2 + 4^2) = sqrt(9 + 16) = sqrt(25) = 5
        assert result == pytest.approx(5.0)

    def test_subtract_uncertainty(self):
        """Propagate uncertainty through subtraction (same as add)."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=200.0, unit="uL", trust=trust, uncertainty=3.0)
        b = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=4.0)

        result = propagate_uncertainty_subtract(a, b)

        # Same as addition: sqrt(3^2 + 4^2) = 5
        assert result == pytest.approx(5.0)

    def test_multiply_uncertainty(self):
        """Propagate uncertainty through multiplication."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=10.0, unit="g", trust=trust, uncertainty=1.0)  # 10%
        b = StateProperty(value=5.0, unit="mL", trust=trust, uncertainty=0.5)   # 10%

        result = propagate_uncertainty_multiply(a, b)

        # result = 50, rel_uncertainty = sqrt(0.1^2 + 0.1^2) = sqrt(0.02) ≈ 0.1414
        # absolute = 50 * 0.1414 ≈ 7.07
        expected = 50.0 * math.sqrt(0.01 + 0.01)
        assert result == pytest.approx(expected)

    def test_divide_uncertainty(self):
        """Propagate uncertainty through division."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="g", trust=trust, uncertainty=10.0)  # 10%
        b = StateProperty(value=20.0, unit="mL", trust=trust, uncertainty=2.0)   # 10%

        result = propagate_uncertainty_divide(a, b)

        # result = 5, rel_uncertainty = sqrt(0.1^2 + 0.1^2) ≈ 0.1414
        # absolute = 5 * 0.1414 ≈ 0.707
        expected = 5.0 * math.sqrt(0.01 + 0.01)
        assert result == pytest.approx(expected)

    def test_uncertainty_none_when_missing(self):
        """Uncertainty propagation returns None if input missing."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=10.0)
        b = StateProperty(value=100.0, unit="uL", trust=trust)  # No uncertainty

        assert propagate_uncertainty_add(a, b) is None
        assert propagate_uncertainty_subtract(a, b) is None
        assert propagate_uncertainty_multiply(a, b) is None
        assert propagate_uncertainty_divide(a, b) is None

    def test_multiply_divide_none_when_zero(self):
        """Multiply/divide returns None if value is zero."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=0.0, unit="uL", trust=trust, uncertainty=10.0)
        b = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=10.0)

        assert propagate_uncertainty_multiply(a, b) is None
        assert propagate_uncertainty_divide(a, b) is None


class TestCombineStateProperties:
    """Test combining state properties through operations."""

    def test_combine_add(self):
        """Combine properties through addition."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=3.0)
        b = StateProperty(value=200.0, unit="uL", trust=trust, uncertainty=4.0)

        result = combine_state_properties(a, b, "+", "uL")

        assert result.value == 300.0
        assert result.unit == "uL"
        assert result.uncertainty == pytest.approx(5.0)

    def test_combine_subtract(self):
        """Combine properties through subtraction."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=200.0, unit="uL", trust=trust, uncertainty=3.0)
        b = StateProperty(value=50.0, unit="uL", trust=trust, uncertainty=4.0)

        result = combine_state_properties(a, b, "-", "uL")

        assert result.value == 150.0
        assert result.uncertainty == pytest.approx(5.0)

    def test_combine_multiply(self):
        """Combine properties through multiplication."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=10.0, unit="g", trust=trust, uncertainty=1.0)
        b = StateProperty(value=5.0, unit="mL", trust=trust, uncertainty=0.5)

        result = combine_state_properties(a, b, "*", "g*mL")

        assert result.value == 50.0
        assert result.unit == "g*mL"

    def test_combine_divide(self):
        """Combine properties through division."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="g", trust=trust, uncertainty=10.0)
        b = StateProperty(value=20.0, unit="mL", trust=trust, uncertainty=2.0)

        result = combine_state_properties(a, b, "/", "g/mL")

        assert result.value == pytest.approx(5.0)
        assert result.unit == "g/mL"

    def test_combine_propagates_min_trust(self):
        """Combine propagates minimum trust level."""
        declared = Declared(source=TrustSource.USER)
        calibrated = Calibrated(method=CalibrationMethod.BALANCE, timestamp=datetime.now())

        a = StateProperty(value=100.0, unit="g", trust=calibrated, uncertainty=1.0)
        b = StateProperty(value=50.0, unit="g", trust=declared, uncertainty=1.0)

        result = combine_state_properties(a, b, "+", "g")

        # Should have the lower trust (Declared)
        assert result.trust.confidence == ConfidenceLevel.LOW

    def test_combine_division_by_zero(self):
        """Division by zero raises ValueError."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="g", trust=trust)
        b = StateProperty(value=0.0, unit="mL", trust=trust)

        with pytest.raises(ValueError, match="Division by zero"):
            combine_state_properties(a, b, "/", "g/mL")

    def test_combine_unknown_operation(self):
        """Unknown operation raises ValueError."""
        trust = Declared(source=TrustSource.USER)
        a = StateProperty(value=100.0, unit="g", trust=trust)
        b = StateProperty(value=50.0, unit="g", trust=trust)

        with pytest.raises(ValueError, match="Unknown operation"):
            combine_state_properties(a, b, "^", "g")


class TestWellContents:
    """Test WellContents dataclass."""

    def test_create_empty_well(self):
        """Create empty well contents."""
        well = WellContents()
        assert well.volume is None
        assert well.concentration is None
        assert well.components == {}

    def test_create_with_volume(self):
        """Create well with volume."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)

        well = WellContents(volume=volume)

        assert well.volume.value == 100.0
        assert well.volume.unit == "uL"

    def test_copy_well_contents(self):
        """Copy well contents."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)

        well = WellContents(volume=volume, components={"reagent1": 50.0})
        copy = well.copy()

        # Modify original
        well.components["reagent2"] = 25.0

        # Copy should not be affected
        assert "reagent2" not in copy.components
        assert copy.volume.value == 100.0

    def test_to_dict(self):
        """Convert well contents to dict."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)

        well = WellContents(volume=volume, components={"reagent1": 50.0})
        d = well.to_dict()

        assert d["volume"]["value"] == 100.0
        assert d["volume"]["unit"] == "uL"
        assert d["components"]["reagent1"] == 50.0


class TestContainerContents:
    """Test ContainerContents dataclass."""

    def test_create_container(self):
        """Create container contents."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=1000.0, unit="uL", trust=trust)

        container = ContainerContents(
            container_id="tube_1",
            volume=volume
        )

        assert container.container_id == "tube_1"
        assert container.volume.value == 1000.0

    def test_to_dict(self):
        """Convert container to dict."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=1000.0, unit="uL", trust=trust)
        mass = StateProperty(value=1.0, unit="g", trust=trust)

        container = ContainerContents(
            container_id="tube_1",
            volume=volume,
            mass=mass
        )
        d = container.to_dict()

        assert d["id"] == "tube_1"
        assert d["volume"]["value"] == 1000.0
        assert d["mass"]["value"] == 1.0


class TestPlateContents:
    """Test PlateContents sparse representation."""

    def test_create_plate(self):
        """Create a plate."""
        plate = PlateContents(plate_id="plate_1")

        assert plate.plate_id == "plate_1"
        assert plate.rows == 8
        assert plate.cols == 12
        assert plate.well_count == 96
        assert plate.default_contents is None
        assert plate.well_overrides == {}

    def test_create_384_plate(self):
        """Create a 384-well plate."""
        plate = PlateContents(plate_id="plate_384", rows=16, cols=24)

        assert plate.well_count == 384

    def test_get_well_id(self):
        """Convert row/col to well ID."""
        plate = PlateContents(plate_id="plate_1")

        assert plate.get_well_id(0, 0) == "A1"
        assert plate.get_well_id(0, 11) == "A12"
        assert plate.get_well_id(7, 0) == "H1"
        assert plate.get_well_id(7, 11) == "H12"

    def test_get_well_id_invalid(self):
        """Invalid row/col raises ValueError."""
        plate = PlateContents(plate_id="plate_1")

        with pytest.raises(ValueError):
            plate.get_well_id(8, 0)  # Row out of range

        with pytest.raises(ValueError):
            plate.get_well_id(0, 12)  # Col out of range

    def test_parse_well_id(self):
        """Parse well ID to row/col."""
        plate = PlateContents(plate_id="plate_1")

        assert plate.parse_well_id("A1") == (0, 0)
        assert plate.parse_well_id("A12") == (0, 11)
        assert plate.parse_well_id("H1") == (7, 0)
        assert plate.parse_well_id("H12") == (7, 11)
        assert plate.parse_well_id("a1") == (0, 0)  # Case insensitive

    def test_parse_well_id_invalid(self):
        """Invalid well ID raises ValueError."""
        plate = PlateContents(plate_id="plate_1")

        with pytest.raises(ValueError):
            plate.parse_well_id("I1")  # Row out of range

        with pytest.raises(ValueError):
            plate.parse_well_id("A13")  # Col out of range

        with pytest.raises(ValueError):
            plate.parse_well_id("A")  # Too short

    def test_get_well_default(self):
        """Get well returns default when no override."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)
        default = WellContents(volume=volume)

        plate = PlateContents(plate_id="plate_1", default_contents=default)

        well = plate.get_well("A1")
        assert well.volume.value == 100.0

    def test_get_well_override(self):
        """Get well returns override when present."""
        trust = Declared(source=TrustSource.USER)
        default_vol = StateProperty(value=100.0, unit="uL", trust=trust)
        override_vol = StateProperty(value=200.0, unit="uL", trust=trust)

        default = WellContents(volume=default_vol)
        override = WellContents(volume=override_vol)

        plate = PlateContents(
            plate_id="plate_1",
            default_contents=default,
            well_overrides={"A1": override}
        )

        assert plate.get_well("A1").volume.value == 200.0
        assert plate.get_well("A2").volume.value == 100.0  # Default

    def test_set_well(self):
        """Set well adds override."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=150.0, unit="uL", trust=trust)
        contents = WellContents(volume=volume)

        plate = PlateContents(plate_id="plate_1")
        plate.set_well("B3", contents)

        assert "B3" in plate.well_overrides
        assert plate.get_well("B3").volume.value == 150.0

    def test_set_well_removes_override_if_matches_default(self):
        """Setting well to default value removes override."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)
        default = WellContents(volume=volume)

        # Same contents as default
        same_as_default = WellContents(volume=volume)

        plate = PlateContents(
            plate_id="plate_1",
            default_contents=default,
            well_overrides={"A1": WellContents()}  # Some override
        )

        # Set A1 to match default
        plate.set_well("A1", same_as_default)

        # Override should be removed
        assert "A1" not in plate.well_overrides

    def test_set_default(self):
        """Set default contents."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=50.0, unit="uL", trust=trust)
        default = WellContents(volume=volume)

        plate = PlateContents(plate_id="plate_1")
        plate.set_default(default)

        assert plate.default_contents.volume.value == 50.0
        assert plate.get_well("A1").volume.value == 50.0

    def test_get_all_wells(self):
        """Get all wells expands sparse representation."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)
        default = WellContents(volume=volume)

        plate = PlateContents(plate_id="plate_1", default_contents=default)

        all_wells = plate.get_all_wells()

        assert len(all_wells) == 96
        assert all_wells["A1"].volume.value == 100.0
        assert all_wells["H12"].volume.value == 100.0

    def test_get_modified_wells(self):
        """Get only modified wells."""
        trust = Declared(source=TrustSource.USER)
        default_vol = StateProperty(value=100.0, unit="uL", trust=trust)
        override_vol = StateProperty(value=200.0, unit="uL", trust=trust)

        default = WellContents(volume=default_vol)
        override = WellContents(volume=override_vol)

        plate = PlateContents(
            plate_id="plate_1",
            default_contents=default,
            well_overrides={"A1": override, "B2": override}
        )

        modified = plate.get_modified_wells()

        assert len(modified) == 2
        assert "A1" in modified
        assert "B2" in modified

    def test_compute_hash(self):
        """Compute hash of plate state."""
        trust = Declared(source=TrustSource.USER)
        volume = StateProperty(value=100.0, unit="uL", trust=trust)
        default = WellContents(volume=volume)

        plate = PlateContents(plate_id="plate_1", default_contents=default)

        hash1 = plate.compute_hash()
        assert len(hash1) == 64  # SHA-256 hex

        # Same state = same hash
        hash2 = plate.compute_hash()
        assert hash1 == hash2

        # Different state = different hash
        plate.metadata["key"] = "value"
        hash3 = plate.compute_hash()
        assert hash1 != hash3

    def test_repr(self):
        """Test string representation."""
        plate = PlateContents(
            plate_id="plate_1",
            well_overrides={"A1": WellContents(), "B2": WellContents()}
        )

        s = repr(plate)
        assert "plate_1" in s
        assert "8x12" in s
        assert "2 modified" in s


class TestWellDelta:
    """Test WellDelta."""

    def test_create_well_delta(self):
        """Create a well delta."""
        trust = Declared(source=TrustSource.USER)
        before_vol = StateProperty(value=100.0, unit="uL", trust=trust)
        after_vol = StateProperty(value=80.0, unit="uL", trust=trust)

        before = WellContents(volume=before_vol)
        after = WellContents(volume=after_vol)

        delta = WellDelta(
            plate_id="plate_1",
            well_id="A1",
            before=before,
            after=after
        )

        assert delta.plate_id == "plate_1"
        assert delta.well_id == "A1"
        assert delta.volume_change == -20.0

    def test_volume_change_with_none(self):
        """Volume change handles None values."""
        trust = Declared(source=TrustSource.USER)
        after_vol = StateProperty(value=100.0, unit="uL", trust=trust)

        # Before is empty, after has volume
        delta = WellDelta(
            plate_id="plate_1",
            well_id="A1",
            before=WellContents(),
            after=WellContents(volume=after_vol)
        )

        assert delta.volume_change == 100.0

    def test_to_dict(self):
        """Convert well delta to dict."""
        trust = Declared(source=TrustSource.USER)
        vol = StateProperty(value=100.0, unit="uL", trust=trust)

        delta = WellDelta(
            plate_id="plate_1",
            well_id="A1",
            before=None,
            after=WellContents(volume=vol)
        )

        d = delta.to_dict()
        assert d["plate_id"] == "plate_1"
        assert d["well_id"] == "A1"
        assert d["before"] is None
        assert d["after"]["volume"]["value"] == 100.0


class TestContainerDelta:
    """Test ContainerDelta."""

    def test_create_container_delta(self):
        """Create a container delta."""
        trust = Declared(source=TrustSource.USER)
        before_vol = StateProperty(value=1000.0, unit="uL", trust=trust)
        after_vol = StateProperty(value=900.0, unit="uL", trust=trust)

        before = ContainerContents(container_id="tube_1", volume=before_vol)
        after = ContainerContents(container_id="tube_1", volume=after_vol)

        delta = ContainerDelta(
            container_id="tube_1",
            before=before,
            after=after
        )

        assert delta.container_id == "tube_1"
        assert delta.volume_change == -100.0

    def test_to_dict(self):
        """Convert container delta to dict."""
        trust = Declared(source=TrustSource.USER)
        vol = StateProperty(value=1000.0, unit="uL", trust=trust)

        delta = ContainerDelta(
            container_id="tube_1",
            before=None,
            after=ContainerContents(container_id="tube_1", volume=vol)
        )

        d = delta.to_dict()
        assert d["container_id"] == "tube_1"
        assert d["before"] is None


class TestStateDelta:
    """Test StateDelta."""

    def test_create_empty_delta(self):
        """Create empty state delta."""
        delta = StateDelta()

        assert delta.is_empty is True
        assert delta.containers_modified == []
        assert delta.wells_modified == []

    def test_create_with_changes(self):
        """Create delta with changes."""
        well_delta = WellDelta(
            plate_id="plate_1",
            well_id="A1",
            before=None,
            after=WellContents()
        )

        delta = StateDelta(
            wells_modified=[well_delta],
            description="Added contents to A1"
        )

        assert delta.is_empty is False
        assert len(delta.wells_modified) == 1
        assert delta.description == "Added contents to A1"

    def test_to_dict(self):
        """Convert state delta to dict."""
        delta = StateDelta(description="Test delta")
        d = delta.to_dict()

        assert d["containers"] == []
        assert d["wells"] == []
        assert d["description"] == "Test delta"
        assert "timestamp" in d

    def test_compute_hash(self):
        """Compute hash of delta."""
        delta = StateDelta(description="Test delta")

        hash1 = delta.compute_hash()
        assert len(hash1) == 64  # SHA-256 hex


class TestStateTransition:
    """Test StateTransition."""

    def test_create_transition(self):
        """Create a state transition."""
        delta = StateDelta(description="Transfer step")

        transition = StateTransition(
            step_index=0,
            before_hash="abc123",
            after_hash="def456",
            delta=delta,
            action_description="Transfer 100 uL from source to dest"
        )

        assert transition.step_index == 0
        assert transition.before_hash == "abc123"
        assert transition.after_hash == "def456"
        assert transition.action_description == "Transfer 100 uL from source to dest"

    def test_to_dict(self):
        """Convert transition to dict."""
        delta = StateDelta(description="Test")
        transition = StateTransition(
            step_index=1,
            before_hash="aaa",
            after_hash="bbb",
            delta=delta
        )

        d = transition.to_dict()
        assert d["step_index"] == 1
        assert d["before_hash"] == "aaa"
        assert d["after_hash"] == "bbb"
        assert "delta" in d

    def test_compute_chain_hash(self):
        """Compute chain hash for transition."""
        delta = StateDelta()
        transition = StateTransition(
            step_index=0,
            before_hash="initial",
            after_hash="after",
            delta=delta
        )

        chain_hash = transition.compute_chain_hash()
        assert len(chain_hash) == 64  # SHA-256 hex

    def test_verify_hashes(self):
        """Verify transition hashes."""
        delta = StateDelta()
        transition = StateTransition(
            step_index=0,
            before_hash="abc",
            after_hash="def",
            delta=delta
        )

        assert transition.verify_hashes("abc", "def") is True
        assert transition.verify_hashes("abc", "xyz") is False
        assert transition.verify_hashes("xyz", "def") is False


class TestStateHistory:
    """Test StateHistory audit trail."""

    def test_create_history(self):
        """Create state history."""
        history = StateHistory(initial_hash="initial_state_hash")

        assert history.initial_hash == "initial_state_hash"
        assert history.current_hash == "initial_state_hash"
        assert history.get_step_count() == 0

    def test_add_transition(self):
        """Add transition to history."""
        history = StateHistory(initial_hash="hash_0")

        delta = StateDelta(description="Step 1")
        transition = StateTransition(
            step_index=0,
            before_hash="hash_0",
            after_hash="hash_1",
            delta=delta
        )

        history.add_transition(transition)

        assert history.get_step_count() == 1
        assert history.current_hash == "hash_1"

    def test_add_transition_checks_continuity(self):
        """Adding transition with wrong before_hash fails."""
        history = StateHistory(initial_hash="hash_0")

        delta = StateDelta()
        transition = StateTransition(
            step_index=0,
            before_hash="wrong_hash",
            after_hash="hash_1",
            delta=delta
        )

        with pytest.raises(ValueError, match="doesn't match"):
            history.add_transition(transition)

    def test_chain_hash(self):
        """Chain hash changes with each transition."""
        history = StateHistory(initial_hash="hash_0")

        initial_chain = history.chain_hash

        # Add transition
        delta = StateDelta()
        transition = StateTransition(
            step_index=0,
            before_hash="hash_0",
            after_hash="hash_1",
            delta=delta
        )
        history.add_transition(transition)

        new_chain = history.chain_hash
        assert new_chain != initial_chain

    def test_verify_chain_empty(self):
        """Verify empty chain is valid."""
        history = StateHistory(initial_hash="hash_0")

        is_valid, error = history.verify_chain()
        assert is_valid is True
        assert error is None

    def test_verify_chain_valid(self):
        """Verify valid chain."""
        history = StateHistory(initial_hash="hash_0")

        # Add two transitions
        delta1 = StateDelta(description="Step 1")
        t1 = StateTransition(step_index=0, before_hash="hash_0", after_hash="hash_1", delta=delta1)
        history.add_transition(t1)

        delta2 = StateDelta(description="Step 2")
        t2 = StateTransition(step_index=1, before_hash="hash_1", after_hash="hash_2", delta=delta2)
        history.add_transition(t2)

        is_valid, error = history.verify_chain()
        assert is_valid is True
        assert error is None

    def test_verify_chain_detects_break(self):
        """Verify chain detects tampering."""
        history = StateHistory(initial_hash="hash_0")

        # Add valid transition
        delta = StateDelta()
        t = StateTransition(step_index=0, before_hash="hash_0", after_hash="hash_1", delta=delta)
        history.add_transition(t)

        # Manually break the chain by modifying the transition
        history.transitions[0] = StateTransition(
            step_index=0,
            before_hash="wrong_initial",  # This doesn't match initial_hash
            after_hash="hash_1",
            delta=delta
        )

        is_valid, error = history.verify_chain()
        assert is_valid is False
        assert "initial hash" in error

    def test_get_transition(self):
        """Get transition by step index."""
        history = StateHistory(initial_hash="hash_0")

        delta = StateDelta(description="Step 0")
        t = StateTransition(step_index=0, before_hash="hash_0", after_hash="hash_1", delta=delta)
        history.add_transition(t)

        found = history.get_transition(0)
        assert found is not None
        assert found.delta.description == "Step 0"

        not_found = history.get_transition(5)
        assert not_found is None

    def test_export_audit_trail(self):
        """Export audit trail."""
        history = StateHistory(initial_hash="hash_0")

        delta = StateDelta(description="Initial setup")
        t = StateTransition(step_index=0, before_hash="hash_0", after_hash="hash_1", delta=delta)
        history.add_transition(t)

        trail = history.export_audit_trail()

        assert trail["initial_hash"] == "hash_0"
        assert trail["step_count"] == 1
        assert len(trail["transitions"]) == 1
        assert "chain_hash" in trail


class TestIntegration:
    """Integration tests for state model."""

    def test_transfer_workflow(self):
        """Test a complete transfer workflow with state tracking."""
        trust = Declared(source=TrustSource.USER)

        # Initial source with volume
        source_vol = StateProperty(value=1000.0, unit="uL", trust=trust, uncertainty=50.0)
        source = ContainerContents(container_id="source_tube", volume=source_vol)

        # Empty destination plate
        plate = PlateContents(plate_id="dest_plate")

        # Record initial state
        initial_hash = plate.compute_hash()
        history = StateHistory(initial_hash=initial_hash)

        # Transfer 100 uL to A1
        transfer_vol = 100.0
        new_source_vol = StateProperty(
            value=source.volume.value - transfer_vol,
            unit="uL",
            trust=trust,
            uncertainty=source_vol.uncertainty  # Propagated
        )
        well_vol = StateProperty(value=transfer_vol, unit="uL", trust=trust, uncertainty=10.0)

        # Update source
        source = ContainerContents(container_id="source_tube", volume=new_source_vol)

        # Update plate
        plate.set_well("A1", WellContents(volume=well_vol))

        # Record transition
        well_delta = WellDelta(
            plate_id="dest_plate",
            well_id="A1",
            before=None,
            after=WellContents(volume=well_vol)
        )
        container_delta = ContainerDelta(
            container_id="source_tube",
            before=ContainerContents(container_id="source_tube", volume=source_vol),
            after=source
        )

        delta = StateDelta(
            containers_modified=[container_delta],
            wells_modified=[well_delta],
            description="Transfer 100 uL from source to A1"
        )

        after_hash = plate.compute_hash()
        transition = StateTransition(
            step_index=0,
            before_hash=initial_hash,
            after_hash=after_hash,
            delta=delta,
            action_description="Transfer step 1"
        )

        history.add_transition(transition)

        # Verify state
        assert source.volume.value == 900.0
        assert plate.get_well("A1").volume.value == 100.0
        assert history.get_step_count() == 1

        # Verify chain
        is_valid, error = history.verify_chain()
        assert is_valid is True

        # Export audit trail
        trail = history.export_audit_trail()
        assert trail["step_count"] == 1
        assert trail["initial_hash"] == initial_hash

    def test_uncertainty_through_dilution(self):
        """Test uncertainty propagation through a dilution calculation."""
        trust = Declared(source=TrustSource.USER)

        # Stock: 1000 uL at 100 mM ± 5%
        StateProperty(value=1000.0, unit="uL", trust=trust, uncertainty=50.0)
        stock_conc = StateProperty(value=100.0, unit="mM", trust=trust, uncertainty=5.0)

        # Add 100 uL of stock
        aliquot = StateProperty(value=100.0, unit="uL", trust=trust, uncertainty=10.0)

        # Add 900 uL of diluent
        diluent = StateProperty(value=900.0, unit="uL", trust=trust, uncertainty=45.0)

        # Total volume = aliquot + diluent
        total_vol = combine_state_properties(aliquot, diluent, "+", "uL")

        assert total_vol.value == pytest.approx(1000.0)
        # Uncertainty: sqrt(10^2 + 45^2) ≈ 46.1
        assert total_vol.uncertainty == pytest.approx(math.sqrt(100 + 2025), rel=0.01)

        # Final concentration = stock_conc * (aliquot / total_vol)
        # = 100 mM * (100 uL / 1000 uL) = 10 mM
        dilution_factor = combine_state_properties(aliquot, total_vol, "/", "")
        final_conc_value = stock_conc.value * dilution_factor.value

        assert final_conc_value == pytest.approx(10.0)  # 10x dilution
