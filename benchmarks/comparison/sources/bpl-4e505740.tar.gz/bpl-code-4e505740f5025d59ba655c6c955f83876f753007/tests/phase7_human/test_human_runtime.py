"""Tests for human runtime components."""

import pytest
from datetime import datetime, timedelta
import time

from bpl.runtime.human import (
    # Execution IR
    StepType,
    StepStatus,
    StepLocation,
    StepParameters,
    HumanExecutionStep,
    StepGroup,
    HumanExecutionPlan,
    # Step Renderer
    RenderFormat,
    RenderOptions,
    StepRenderer,
    # Timer
    TimerStatus,
    TimerType,
    TimerState,
    TimerEvent,
    TimerManager,
    format_duration,
    create_countdown_timer,
    create_stopwatch,
    # Data Capture
    FieldType,
    ValidationStatus,
    FieldConstraint,
    DataField,
    CapturedValue,
    DataCapture,
    DataCaptureManager,
    create_volume_field,
    create_temperature_field,
    create_text_field,
    create_choice_field,
    # Signatures
    SignatureType,
    SignatureStatus,
    SignatureRequest,
    Signature,
    SignaturePolicy,
    SignatureManager,
    require_initials,
    require_approval,
    create_standard_policy,
    create_gmp_policy,
    # Checkpoint UI
    CheckpointType,
    CheckpointAction,
    CheckpointOption,
    CheckpointState,
    CheckpointUI,
    CheckpointUIGenerator,
    CheckpointManager,
    create_pause_checkpoint,
    create_confirmation_checkpoint,
    # Protocol Generator
    ConversionOptions,
    PlanToHumanConverter,
)

from bpl.lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    StepStatus as PlanStepStatus,
    PrimitiveType,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    DropTips,
    Wait,
    MoveLabware,
    WellRef,
    TipRackRef,
)


class TestStepLocation:
    """Tests for step location."""

    def test_well_location(self):
        """Test well location formatting."""
        loc = StepLocation(labware_id="plate_1", well_id="A1")
        assert "plate_1" in str(loc)
        assert "A1" in str(loc)

    def test_position_location(self):
        """Test position location formatting."""
        loc = StepLocation(labware_id="plate_1", position="deck_1")
        assert "plate_1" in str(loc)
        assert "deck_1" in str(loc)

    def test_labware_only_location(self):
        """Test labware-only location."""
        loc = StepLocation(labware_id="plate_1")
        assert str(loc) == "plate_1"


class TestStepParameters:
    """Tests for step parameters."""

    def test_format_volume(self):
        """Test volume formatting."""
        params = StepParameters(volume_ul=100.0)
        assert "100" in params.format_volume()
        assert "µL" in params.format_volume()

    def test_format_volume_ml(self):
        """Test large volume formatting."""
        params = StepParameters(volume_ul=2500.0)
        assert "2.50" in params.format_volume()
        assert "mL" in params.format_volume()

    def test_format_temperature(self):
        """Test temperature formatting."""
        params = StepParameters(temperature_c=37.0)
        assert "37" in params.format_temperature()
        assert "°C" in params.format_temperature()

    def test_format_duration_seconds(self):
        """Test duration formatting in seconds."""
        params = StepParameters(duration_s=45)
        assert "45s" in params.format_duration()

    def test_format_duration_minutes(self):
        """Test duration formatting in minutes."""
        params = StepParameters(duration_s=125)
        assert "m" in params.format_duration()

    def test_format_duration_hours(self):
        """Test duration formatting in hours."""
        params = StepParameters(duration_s=3700)
        assert "h" in params.format_duration()


class TestHumanExecutionStep:
    """Tests for human execution step."""

    def test_step_creation(self):
        """Test step creation."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer 100 µL"
        )
        assert step.step_id == "step_1"
        assert step.step_number == 1
        assert step.status == StepStatus.PENDING

    def test_step_start(self):
        """Test starting a step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        step.start()
        assert step.status == StepStatus.IN_PROGRESS
        assert step.started_at is not None

    def test_step_complete(self):
        """Test completing a step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        step.start()
        step.complete()
        assert step.status == StepStatus.COMPLETED
        assert step.completed_at is not None
        assert step.is_complete

    def test_step_verified(self):
        """Test verified step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        step.complete(verified=True)
        assert step.status == StepStatus.VERIFIED

    def test_step_skip(self):
        """Test skipping a step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        step.skip()
        assert step.status == StepStatus.SKIPPED
        assert step.is_complete

    def test_step_fail(self):
        """Test failing a step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        step.fail()
        assert step.status == StepStatus.FAILED

    def test_record_data(self):
        """Test recording data on a step."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.RECORD_DATA,
            instruction="Record volume"
        )
        step.record_value("volume", 100.5)
        assert step.recorded_data["volume"] == 100.5


class TestHumanExecutionPlan:
    """Tests for human execution plan."""

    def test_plan_creation(self):
        """Test plan creation."""
        plan = HumanExecutionPlan(
            plan_id="plan_1",
            protocol_name="Test Protocol"
        )
        assert plan.plan_id == "plan_1"
        assert plan.total_steps == 0

    def test_add_step(self):
        """Test adding steps."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer"
        )
        plan.add_step(step)
        assert plan.total_steps == 1
        assert "step_1" in plan.steps

    def test_current_step(self):
        """Test getting current step."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        plan.add_step(HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Step 1"
        ))
        plan.add_step(HumanExecutionStep(
            step_id="step_2", step_number=2,
            step_type=StepType.PIPETTE, instruction="Step 2"
        ))

        current = plan.get_current_step()
        assert current.step_id == "step_1"

    def test_advance(self):
        """Test advancing to next step."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        plan.add_step(HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Step 1"
        ))
        plan.add_step(HumanExecutionStep(
            step_id="step_2", step_number=2,
            step_type=StepType.PIPETTE, instruction="Step 2"
        ))

        plan.advance()
        current = plan.get_current_step()
        assert current.step_id == "step_2"

    def test_go_back(self):
        """Test going back to previous step."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        plan.add_step(HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Step 1"
        ))
        plan.add_step(HumanExecutionStep(
            step_id="step_2", step_number=2,
            step_type=StepType.PIPETTE, instruction="Step 2"
        ))

        plan.advance()
        plan.go_back()
        current = plan.get_current_step()
        assert current.step_id == "step_1"

    def test_progress(self):
        """Test progress calculation."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        for i in range(4):
            plan.add_step(HumanExecutionStep(
                step_id=f"step_{i}", step_number=i+1,
                step_type=StepType.PIPETTE, instruction=f"Step {i+1}"
            ))

        # Complete 2 of 4 steps
        plan.steps["step_0"].complete()
        plan.steps["step_1"].complete()

        assert plan.completed_steps == 2
        assert plan.progress_percent == 50.0

    def test_summary(self):
        """Test plan summary."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test")
        plan.add_step(HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Step 1"
        ))
        plan.steps["step_1"].complete()

        summary = plan.summary()
        assert summary["completed"] == 1
        assert summary["total_steps"] == 1


class TestStepRenderer:
    """Tests for step renderer."""

    def test_render_text(self):
        """Test rendering step as text."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer 100 µL from plate_1 A1 to plate_2 B1"
        )
        renderer = StepRenderer()
        text = renderer.render_step(step, RenderFormat.TEXT)
        assert "Transfer" in text
        assert "Step 1" in text

    def test_render_markdown(self):
        """Test rendering step as markdown."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer 100 µL"
        )
        renderer = StepRenderer()
        md = renderer.render_step(step, RenderFormat.MARKDOWN)
        assert "###" in md  # Header
        assert "Transfer" in md

    def test_render_html(self):
        """Test rendering step as HTML."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer 100 µL"
        )
        renderer = StepRenderer()
        html = renderer.render_step(step, RenderFormat.HTML)
        assert "<div" in html
        assert "step" in html

    def test_render_with_warnings(self):
        """Test rendering step with warnings."""
        step = HumanExecutionStep(
            step_id="step_1",
            step_number=1,
            step_type=StepType.PIPETTE,
            instruction="Transfer 100 µL",
            warnings=["Check volume carefully"]
        )
        renderer = StepRenderer()
        text = renderer.render_step(step, RenderFormat.TEXT)
        assert "WARNING" in text

    def test_render_plan(self):
        """Test rendering entire plan."""
        plan = HumanExecutionPlan(plan_id="plan_1", protocol_name="Test Protocol")
        plan.add_step(HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Step 1"
        ))
        plan.add_step(HumanExecutionStep(
            step_id="step_2", step_number=2,
            step_type=StepType.PIPETTE, instruction="Step 2"
        ))

        renderer = StepRenderer()
        text = renderer.render_plan(plan, RenderFormat.TEXT)
        assert "Test Protocol" in text
        assert "Step 1" in text
        assert "Step 2" in text


class TestTimerState:
    """Tests for timer state."""

    def test_timer_creation(self):
        """Test timer creation."""
        timer = TimerState(
            timer_id="timer_1",
            name="Incubation",
            timer_type=TimerType.COUNTDOWN,
            target_duration_s=300
        )
        assert timer.timer_id == "timer_1"
        assert timer.status == TimerStatus.IDLE

    def test_timer_start(self):
        """Test starting a timer."""
        timer = create_countdown_timer("timer_1", "Test", 60)
        timer.start()
        assert timer.status == TimerStatus.RUNNING
        assert timer.started_at is not None

    def test_timer_pause_resume(self):
        """Test pausing and resuming a timer."""
        timer = create_countdown_timer("timer_1", "Test", 60)
        timer.start()
        timer.pause()
        assert timer.status == TimerStatus.PAUSED

        timer.resume()
        assert timer.status == TimerStatus.RUNNING

    def test_timer_elapsed(self):
        """Test elapsed time calculation."""
        timer = create_stopwatch("timer_1", "Test")
        timer.start()
        time.sleep(0.1)
        elapsed = timer.elapsed_s
        assert elapsed >= 0.1

    def test_timer_remaining(self):
        """Test remaining time calculation."""
        timer = create_countdown_timer("timer_1", "Test", 60)
        timer.start()
        remaining = timer.remaining_s
        assert remaining > 0
        assert remaining <= 60

    def test_timer_progress(self):
        """Test progress percentage."""
        timer = create_countdown_timer("timer_1", "Test", 10)
        timer.start()
        timer.accumulated_s = 5  # Simulate 5 seconds passed
        assert timer.progress_percent >= 50

    def test_format_elapsed(self):
        """Test elapsed time formatting."""
        timer = create_countdown_timer("timer_1", "Test", 60)
        timer.accumulated_s = 125  # 2:05
        formatted = timer.format_elapsed()
        assert "2" in formatted
        assert ":" in formatted


class TestTimerManager:
    """Tests for timer manager."""

    def test_create_timer(self):
        """Test creating a timer."""
        manager = TimerManager()
        timer = manager.create_timer("timer_1", "Incubation", 300)
        assert timer is not None
        assert manager.get_timer("timer_1") is not None

    def test_start_timer(self):
        """Test starting a timer via manager."""
        manager = TimerManager()
        manager.create_timer("timer_1", "Test", 60)
        result = manager.start_timer("timer_1")
        assert result is True

        timer = manager.get_timer("timer_1")
        assert timer.status == TimerStatus.RUNNING

    def test_stop_timer(self):
        """Test stopping a timer."""
        manager = TimerManager()
        manager.create_timer("timer_1", "Test", 60)
        manager.start_timer("timer_1")
        manager.stop_timer("timer_1")

        timer = manager.get_timer("timer_1")
        assert timer.status == TimerStatus.COMPLETED

    def test_active_timers(self):
        """Test getting active timers."""
        manager = TimerManager()
        manager.create_timer("timer_1", "Test 1", 60)
        manager.create_timer("timer_2", "Test 2", 60)
        manager.start_timer("timer_1")

        active = manager.get_active_timers()
        assert len(active) == 1
        assert active[0].timer_id == "timer_1"

    def test_event_emission(self):
        """Test event emission."""
        manager = TimerManager()
        events = []
        manager.add_event_handler(lambda e: events.append(e))

        manager.create_timer("timer_1", "Test", 60)
        manager.start_timer("timer_1")

        assert len(events) == 1
        assert events[0].event_type == "started"


class TestDataField:
    """Tests for data field."""

    def test_volume_field(self):
        """Test volume field creation."""
        field = create_volume_field("vol_1", "Volume")
        assert field.field_type == FieldType.VOLUME
        assert field.unit == "µL"

    def test_temperature_field(self):
        """Test temperature field creation."""
        field = create_temperature_field("temp_1", "Temperature")
        assert field.field_type == FieldType.TEMPERATURE

    def test_text_field(self):
        """Test text field creation."""
        field = create_text_field("notes", "Notes", max_length=500)
        assert field.field_type == FieldType.TEXT

    def test_choice_field(self):
        """Test choice field creation."""
        field = create_choice_field("color", "Color", ["Red", "Green", "Blue"])
        assert field.field_type == FieldType.CHOICE
        assert len(field.choices) == 3

    def test_validate_required(self):
        """Test required field validation."""
        field = create_text_field("name", "Name", required=True)
        status, msg = field.validate(None)
        assert status == ValidationStatus.INVALID

    def test_validate_range(self):
        """Test numeric range validation."""
        field = create_volume_field("vol", "Volume", min_ul=10, max_ul=100)
        status, _ = field.validate(50)
        assert status == ValidationStatus.VALID

        status, _ = field.validate(5)
        assert status == ValidationStatus.INVALID


class TestDataCapture:
    """Tests for data capture."""

    def test_capture_creation(self):
        """Test capture creation."""
        capture = DataCapture(capture_id="cap_1", step_id="step_1")
        assert capture.capture_id == "cap_1"

    def test_add_field(self):
        """Test adding fields."""
        capture = DataCapture(capture_id="cap_1")
        field = create_volume_field("vol", "Volume")
        capture.add_field(field)
        assert "vol" in capture.fields

    def test_capture_value(self):
        """Test capturing a value."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(create_volume_field("vol", "Volume"))
        result = capture.capture("vol", 100.0, captured_by="user1")

        assert result.value == 100.0
        assert result.captured_by == "user1"

    def test_get_value(self):
        """Test getting captured value."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(create_volume_field("vol", "Volume"))
        capture.capture("vol", 100.0)

        assert capture.get_value("vol") == 100.0

    def test_validate_all(self):
        """Test validating all fields."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(create_volume_field("vol", "Volume"))
        capture.add_field(create_temperature_field("temp", "Temperature"))

        capture.capture("vol", 100.0)
        capture.capture("temp", 37.0)

        results = capture.validate_all()
        assert all(status == ValidationStatus.VALID for status, _ in results.values())

    def test_is_complete(self):
        """Test checking completion."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(create_volume_field("vol", "Volume", required=True))

        assert not capture.is_complete()

        capture.capture("vol", 100.0)
        assert capture.is_complete()

    def test_to_dict(self):
        """Test exporting to dictionary."""
        capture = DataCapture(capture_id="cap_1")
        capture.add_field(create_volume_field("vol", "Volume"))
        capture.add_field(create_temperature_field("temp", "Temp"))
        capture.capture("vol", 100.0)
        capture.capture("temp", 37.0)

        data = capture.to_dict()
        assert data["vol"] == 100.0
        assert data["temp"] == 37.0


class TestDataCaptureManager:
    """Tests for data capture manager."""

    def test_create_capture(self):
        """Test creating capture via manager."""
        manager = DataCaptureManager()
        capture = manager.create_capture("cap_1", step_id="step_1")
        assert capture is not None
        assert manager.get_capture("cap_1") is not None

    def test_capture_with_fields(self):
        """Test creating capture with fields."""
        manager = DataCaptureManager()
        fields = [
            create_volume_field("vol", "Volume"),
            create_temperature_field("temp", "Temp"),
        ]
        capture = manager.create_capture("cap_1", fields=fields)
        assert len(capture.fields) == 2

    def test_step_captures(self):
        """Test getting captures for a step."""
        manager = DataCaptureManager()
        manager.create_capture("cap_1", step_id="step_1")
        manager.create_capture("cap_2", step_id="step_1")
        manager.create_capture("cap_3", step_id="step_2")

        step1_captures = manager.get_step_captures("step_1")
        assert len(step1_captures) == 2


class TestSignature:
    """Tests for signatures."""

    def test_signature_creation(self):
        """Test signature creation."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.INITIALS,
            signer_id="user1",
            signer_name="John Doe",
            reason="Step verification"
        )
        assert sig.signature_id == "sig_1"
        assert not sig.revoked

    def test_compute_hash(self):
        """Test hash computation."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.INITIALS,
            signer_id="user1",
            signer_name="John Doe",
            reason="Test"
        )
        hash1 = sig.compute_hash("secret")
        hash2 = sig.compute_hash("secret")
        assert hash1 == hash2

    def test_verify_hash(self):
        """Test hash verification."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.INITIALS,
            signer_id="user1",
            signer_name="John Doe",
            reason="Test"
        )
        sig.signature_hash = sig.compute_hash("secret")
        assert sig.verify_hash("secret")
        assert not sig.verify_hash("wrong_secret")

    def test_compute_hash_requires_secret(self):
        """Signature hashes must not use an empty default secret."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.INITIALS,
            signer_id="user1",
            signer_name="John Doe",
            reason="Test"
        )
        with pytest.raises(ValueError, match="secret"):
            sig.compute_hash("")

    def test_add_witness(self):
        """Test adding witness."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.FULL_SIGNATURE,
            signer_id="user1",
            signer_name="John Doe",
            reason="Test"
        )
        sig.add_witness("user2", "Jane Doe")
        assert sig.witness_id == "user2"
        assert sig.witnessed_at is not None

    def test_revoke(self):
        """Test revoking signature."""
        sig = Signature(
            signature_id="sig_1",
            request_id="req_1",
            signature_type=SignatureType.INITIALS,
            signer_id="user1",
            signer_name="John Doe",
            reason="Test"
        )
        sig.revoke("Error in step")
        assert sig.revoked
        assert sig.revoked_reason == "Error in step"


class TestSignatureManager:
    """Tests for signature manager."""

    def test_create_request(self):
        """Test creating signature request."""
        manager = SignatureManager()
        request = manager.create_request(
            SignatureType.INITIALS,
            "Verify step completion",
            step_id="step_1"
        )
        assert request is not None
        assert request.status == SignatureStatus.PENDING

    def test_sign_request(self):
        """Test signing a request."""
        manager = SignatureManager()
        request = manager.create_request(
            SignatureType.INITIALS,
            "Verify step"
        )
        sig = manager.sign(
            request.request_id,
            signer_id="user1",
            signer_name="John Doe"
        )
        assert sig is not None
        assert request.status == SignatureStatus.SIGNED
        assert manager.verify(sig.signature_id)

    def test_reject_request(self):
        """Test rejecting a request."""
        manager = SignatureManager()
        request = manager.create_request(
            SignatureType.APPROVAL,
            "Approve step"
        )
        result = manager.reject(request.request_id, "Not approved")
        assert result
        assert request.status == SignatureStatus.REJECTED

    def test_verify_signature(self):
        """Test verifying signature."""
        manager = SignatureManager(secret="test_secret")
        request = manager.create_request(SignatureType.INITIALS, "Test")
        sig = manager.sign(
            request.request_id,
            signer_id="user1",
            signer_name="John Doe"
        )
        assert manager.verify(sig.signature_id)

    def test_get_step_signatures(self):
        """Test getting signatures for a step."""
        manager = SignatureManager()
        request = manager.create_request(
            SignatureType.INITIALS,
            "Test",
            step_id="step_1"
        )
        manager.sign(request.request_id, "user1", "John Doe")

        sigs = manager.get_step_signatures("step_1")
        assert len(sigs) == 1

    def test_gmp_policy(self):
        """Test GMP policy creation."""
        policy = create_gmp_policy()
        assert policy.required_signatures == 2
        assert policy.require_dual_control


class TestSignaturePolicy:
    """Tests for signature policies."""

    def test_standard_policy(self):
        """Test standard policy."""
        policy = create_standard_policy()
        assert policy.required_signatures == 1

    def test_check_policy_pass(self):
        """Test policy check passing."""
        manager = SignatureManager()
        manager.add_policy(create_standard_policy())

        request = manager.create_request(
            SignatureType.INITIALS,
            "Test",
            step_id="step_1"
        )
        manager.sign(request.request_id, "user1", "John Doe")

        passed, issues = manager.check_policy("standard", "step_1")
        assert passed
        assert len(issues) == 0

    def test_check_policy_fail(self):
        """Test policy check failing."""
        manager = SignatureManager()
        manager.add_policy(create_standard_policy())

        # No signatures yet
        passed, issues = manager.check_policy("standard", "step_1")
        assert not passed
        assert len(issues) > 0


class TestCheckpointUI:
    """Tests for checkpoint UI."""

    def test_pause_checkpoint(self):
        """Test creating pause checkpoint."""
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        ui = create_pause_checkpoint(step, "Please verify setup")
        assert ui.checkpoint_type == CheckpointType.PAUSE
        assert len(ui.options) >= 1

    def test_confirmation_checkpoint(self):
        """Test creating confirmation checkpoint."""
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        ui = create_confirmation_checkpoint(step)
        assert ui.checkpoint_type == CheckpointType.CONFIRMATION

    def test_checkpoint_options(self):
        """Test checkpoint options."""
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        generator = CheckpointUIGenerator()
        ui = generator.generate(CheckpointType.CONFIRMATION, step)

        assert len(ui.options) > 0
        has_continue = any(o.action == CheckpointAction.CONTINUE for o in ui.options)
        assert has_continue


class TestCheckpointManager:
    """Tests for checkpoint manager."""

    def test_create_checkpoint(self):
        """Test creating checkpoint."""
        manager = CheckpointManager()
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        state, ui = manager.create_checkpoint(CheckpointType.PAUSE, step)
        assert state is not None
        assert ui is not None

    def test_activate_checkpoint(self):
        """Test activating checkpoint."""
        manager = CheckpointManager()
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        state, _ = manager.create_checkpoint(CheckpointType.PAUSE, step)
        manager.activate(state.checkpoint_id)

        assert state.is_active
        assert manager.is_blocked()

    def test_resolve_checkpoint(self):
        """Test resolving checkpoint."""
        manager = CheckpointManager()
        step = HumanExecutionStep(
            step_id="step_1", step_number=1,
            step_type=StepType.PIPETTE, instruction="Transfer"
        )
        state, _ = manager.create_checkpoint(CheckpointType.PAUSE, step)
        manager.activate(state.checkpoint_id)

        result = manager.resolve(
            state.checkpoint_id,
            CheckpointAction.CONTINUE
        )
        assert result
        assert state.is_complete
        assert not manager.is_blocked()


class TestPlanToHumanConverter:
    """Tests for plan to human converter."""

    def _create_test_plan(self) -> ExecutionPlan:
        """Create a test execution plan."""
        plan = ExecutionPlan(plan_id="test_plan")

        # Add aspirate step
        plan.add_step(PlanStep(
            step_id="step_1",
            primitive=Aspirate(
                source=WellRef(plate_id="source_plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        # Add dispense step
        plan.add_step(PlanStep(
            step_id="step_2",
            primitive=Dispense(
                destination=WellRef(plate_id="dest_plate", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["step_1"]
        ))

        return plan

    def test_convert_plan(self):
        """Test converting execution plan."""
        plan = self._create_test_plan()
        converter = PlanToHumanConverter(ConversionOptions(add_checkpoints=False))
        human_plan = converter.convert(plan, "Test Protocol")

        assert human_plan.protocol_name == "Test Protocol"
        assert human_plan.total_steps >= 2

    def test_convert_aspirate(self):
        """Test converting aspirate step."""
        plan = self._create_test_plan()
        converter = PlanToHumanConverter(ConversionOptions(add_checkpoints=False))
        human_plan = converter.convert(plan)

        # Find aspirate step
        aspirate_steps = [s for s in human_plan.steps.values()
                        if s.step_type == StepType.ASPIRATE]
        assert len(aspirate_steps) == 1
        assert "100" in aspirate_steps[0].instruction or "Aspirate" in aspirate_steps[0].instruction

    def test_convert_dispense(self):
        """Test converting dispense step."""
        plan = self._create_test_plan()
        converter = PlanToHumanConverter(ConversionOptions(add_checkpoints=False))
        human_plan = converter.convert(plan)

        # Find dispense step
        dispense_steps = [s for s in human_plan.steps.values()
                         if s.step_type == StepType.DISPENSE]
        assert len(dispense_steps) == 1

    def test_convert_with_checkpoints(self):
        """Test conversion with automatic checkpoints."""
        plan = ExecutionPlan(plan_id="test_plan")
        # Add many steps
        for i in range(15):
            plan.add_step(PlanStep(
                step_id=f"step_{i}",
                primitive=Aspirate(
                    source=WellRef(plate_id="plate", well_id=f"A{i+1}"),
                    volume_ul=100.0
                ),
                status=PlanStepStatus.PENDING
            ))

        options = ConversionOptions(add_checkpoints=True, checkpoint_interval=10)
        converter = PlanToHumanConverter(options)
        human_plan = converter.convert(plan)

        # Should have checkpoints
        checkpoint_steps = [s for s in human_plan.steps.values()
                          if s.step_type == StepType.CHECKPOINT]
        assert len(checkpoint_steps) > 0

    def test_convert_tips_optional(self):
        """Test tip steps can be excluded."""
        plan = ExecutionPlan(plan_id="test_plan")
        plan.add_step(PlanStep(
            step_id="pick_tips",
            primitive=PickTips(
                tip_rack=TipRackRef(rack_id="tips", tip_type="tips_200"),
                tip_positions=["A1"]
            ),
            status=PlanStepStatus.PENDING
        ))
        plan.add_step(PlanStep(
            step_id="drop_tips",
            primitive=DropTips(to_waste=True),
            status=PlanStepStatus.PENDING
        ))

        # With tip steps
        options = ConversionOptions(include_tip_steps=True, add_checkpoints=False)
        converter = PlanToHumanConverter(options)
        human_plan = converter.convert(plan)
        assert any(s.step_type == StepType.GET_TIPS for s in human_plan.steps.values())

        # Without tip steps
        options = ConversionOptions(include_tip_steps=False, add_checkpoints=False)
        converter = PlanToHumanConverter(options)
        human_plan = converter.convert(plan)
        assert not any(s.step_type == StepType.GET_TIPS for s in human_plan.steps.values())


class TestFormatDuration:
    """Tests for duration formatting."""

    def test_seconds(self):
        """Test formatting seconds."""
        assert format_duration(45) == "0:45"

    def test_minutes(self):
        """Test formatting minutes."""
        result = format_duration(125)
        assert "2" in result
        assert ":" in result

    def test_hours(self):
        """Test formatting hours."""
        result = format_duration(3700)
        assert "1:" in result


class TestIntegration:
    """Integration tests for human runtime."""

    def test_full_workflow(self):
        """Test complete human execution workflow."""
        # Create execution plan
        plan = ExecutionPlan(plan_id="workflow_test")
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="source", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))
        plan.add_step(PlanStep(
            step_id="disp_1",
            primitive=Dispense(
                destination=WellRef(plate_id="dest", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["asp_1"]
        ))

        # Convert to human plan
        converter = PlanToHumanConverter(ConversionOptions(add_checkpoints=False))
        human_plan = converter.convert(plan, "Integration Test")

        # Start execution
        human_plan.start()
        assert human_plan.started_at is not None

        # Execute steps
        for step_id in human_plan.step_order:
            step = human_plan.steps[step_id]
            step.start()
            step.complete()
            human_plan.advance()

        # Complete
        human_plan.complete()
        assert human_plan.is_complete
        assert human_plan.progress_percent == 100.0

    def test_workflow_with_data_capture(self):
        """Test workflow with data capture."""
        # Create a step that requires data capture
        step = HumanExecutionStep(
            step_id="measure_step",
            step_number=1,
            step_type=StepType.RECORD_DATA,
            instruction="Record OD600 measurement",
            data_fields=["od600"]
        )

        # Set up data capture
        manager = DataCaptureManager()
        capture = manager.create_capture(
            "cap_1",
            step_id="measure_step",
            fields=[
                DataField(
                    field_id="od600",
                    name="OD600",
                    field_type=FieldType.DECIMAL,
                    constraint=FieldConstraint(min_value=0, max_value=10, required=True)
                )
            ]
        )

        # Capture value
        capture.capture("od600", 0.65, captured_by="user1")
        assert capture.is_complete()
        assert capture.get_value("od600") == 0.65

    def test_workflow_with_signatures(self):
        """Test workflow with signatures."""
        manager = SignatureManager(secret="test")
        manager.add_policy(create_standard_policy())

        # Create signature request
        request = manager.create_request(
            SignatureType.INITIALS,
            "Verify protocol completion",
            step_id="final_step"
        )

        # Sign
        sig = manager.sign(
            request.request_id,
            signer_id="operator1",
            signer_name="John Operator",
            signer_role="operator"
        )
        assert sig is not None

        # Verify
        assert manager.verify(sig.signature_id)

        # Check policy
        passed, _ = manager.check_policy("standard", "final_step")
        assert passed
