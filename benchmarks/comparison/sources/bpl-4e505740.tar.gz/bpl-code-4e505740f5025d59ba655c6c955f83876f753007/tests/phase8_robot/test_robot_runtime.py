"""Tests for robot runtime components."""

import pytest
import json

from bpl.runtime.robot.biomek import (
    # Biomek IR
    BiomekCommandType,
    AspirateMode,
    DispenseMode,
    TipType,
    BiomekPosition,
    LiquidClass,
    AspirateCommand,
    DispenseCommand,
    MixCommand,
    GetTipsCommand,
    DropTipsCommand,
    MoveToCommand,
    MoveLabwareCommand,
    SetTemperatureCommand,
    DelayCommand,
    PauseCommand,
    CommentCommand,
    LoopStartCommand,
    LoopEndCommand,
    BiomekProgram,
    # Translator
    DeckMapping,
    TranslationOptions,
    TranslationResult,
    PlanToBiomekTranslator,
    translate_plan_to_biomek,
    create_default_deck_mapping,
    # Code Generator
    OutputFormat,
    GenerationOptions,
    GenerationResult,
    BiomekCodeGenerator,
    generate_biomek_code,
    # Hybrid
    ExecutionTarget,
    HandoffType,
    HandoffPoint,
    StepClassification,
    HybridExecutionPlan,
    StepClassifier,
    HybridExecutor,
    HybridExecutionState,
    HybridExecutionManager,
    create_hybrid_plan,
)

from bpl.lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    StepStatus as PlanStepStatus,
    PrimitiveType,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    DropTips,
    Wait,
    MoveLabware,
    SetTemperature,
    WellRef,
    TipRackRef,
)


class TestBiomekPosition:
    """Tests for Biomek position."""

    def test_position_creation(self):
        """Test position creation."""
        pos = BiomekPosition(deck_position=5)
        assert pos.deck_position == 5
        assert pos.well_id is None

    def test_position_with_well(self):
        """Test position with well."""
        pos = BiomekPosition(deck_position=1, row="A", column=1)
        assert pos.well_id == "A1"

    def test_position_string(self):
        """Test position string representation."""
        pos = BiomekPosition(deck_position=1, row="B", column=3)
        assert "P1" in str(pos)
        assert "B3" in str(pos)


class TestLiquidClass:
    """Tests for liquid class."""

    def test_default_liquid_class(self):
        """Test default liquid class."""
        lc = LiquidClass.default()
        assert lc.name == "Default"

    def test_aqueous_liquid_class(self):
        """Test aqueous liquid class."""
        lc = LiquidClass.for_aqueous()
        assert lc.name == "Aqueous"
        assert lc.touch_off is True

    def test_viscous_liquid_class(self):
        """Test viscous liquid class."""
        lc = LiquidClass.for_viscous()
        assert lc.name == "Viscous"
        assert lc.aspirate_speed < lc.dispense_speed or lc.aspirate_speed == lc.dispense_speed

    def test_volatile_liquid_class(self):
        """Test volatile liquid class."""
        lc = LiquidClass.for_volatile()
        assert lc.name == "Volatile"
        assert lc.air_gap > 0


class TestBiomekCommands:
    """Tests for Biomek commands."""

    def test_aspirate_command(self):
        """Test aspirate command."""
        cmd = AspirateCommand(
            command_id="asp_1",
            source=BiomekPosition(1, "A", 1),
            volume_ul=100.0
        )
        assert cmd.command_type == BiomekCommandType.ASPIRATE
        assert cmd.volume_ul == 100.0
        biomek_str = cmd.to_biomek_string()
        assert "ASPIRATE" in biomek_str
        assert "100" in biomek_str

    def test_dispense_command(self):
        """Test dispense command."""
        cmd = DispenseCommand(
            command_id="disp_1",
            destination=BiomekPosition(2, "B", 1),
            volume_ul=100.0
        )
        assert cmd.command_type == BiomekCommandType.DISPENSE
        biomek_str = cmd.to_biomek_string()
        assert "DISPENSE" in biomek_str

    def test_mix_command(self):
        """Test mix command."""
        cmd = MixCommand(
            command_id="mix_1",
            position=BiomekPosition(1, "A", 1),
            volume_ul=50.0,
            cycles=5
        )
        assert cmd.cycles == 5
        biomek_str = cmd.to_biomek_string()
        assert "MIX" in biomek_str
        assert "5" in biomek_str

    def test_get_tips_command(self):
        """Test get tips command."""
        cmd = GetTipsCommand(
            command_id="tips_1",
            tip_rack_position=BiomekPosition(9),
            tip_type=TipType.TIPS_200
        )
        assert cmd.tip_type == TipType.TIPS_200
        biomek_str = cmd.to_biomek_string()
        assert "GET_TIPS" in biomek_str

    def test_drop_tips_command(self):
        """Test drop tips command."""
        cmd = DropTipsCommand(
            command_id="drop_1",
            waste_position=BiomekPosition(20)
        )
        biomek_str = cmd.to_biomek_string()
        assert "DROP_TIPS" in biomek_str

    def test_delay_command(self):
        """Test delay command."""
        cmd = DelayCommand(
            command_id="delay_1",
            duration_s=30.0
        )
        assert cmd.duration_s == 30.0
        biomek_str = cmd.to_biomek_string()
        assert "DELAY" in biomek_str
        assert "30" in biomek_str

    def test_pause_command(self):
        """Test pause command."""
        cmd = PauseCommand(
            command_id="pause_1",
            message="Check plate orientation"
        )
        biomek_str = cmd.to_biomek_string()
        assert "PAUSE" in biomek_str
        assert "Check plate" in biomek_str

    def test_set_temperature_command(self):
        """Test set temperature command."""
        cmd = SetTemperatureCommand(
            command_id="temp_1",
            module_position=BiomekPosition(3),
            temperature_c=37.0,
            wait=True
        )
        biomek_str = cmd.to_biomek_string()
        assert "SET_TEMP" in biomek_str
        assert "37" in biomek_str


class TestBiomekProgram:
    """Tests for Biomek program."""

    def test_program_creation(self):
        """Test program creation."""
        program = BiomekProgram(
            program_id="prog_1",
            name="Test Protocol"
        )
        assert program.program_id == "prog_1"
        assert program.command_count == 0

    def test_add_command(self):
        """Test adding commands."""
        program = BiomekProgram(program_id="prog_1", name="Test")
        cmd = AspirateCommand(
            source=BiomekPosition(1, "A", 1),
            volume_ul=100.0
        )
        program.add_command(cmd)
        assert program.command_count == 1

    def test_add_liquid_class(self):
        """Test adding liquid class."""
        program = BiomekProgram(program_id="prog_1", name="Test")
        program.add_liquid_class(LiquidClass.for_aqueous())
        assert "Aqueous" in program.liquid_classes

    def test_set_deck_position(self):
        """Test setting deck position."""
        program = BiomekProgram(program_id="prog_1", name="Test")
        program.set_deck_position(1, "96_well_plate")
        assert program.deck_layout[1] == "96_well_plate"

    def test_to_biomek_string(self):
        """Test program string output."""
        program = BiomekProgram(
            program_id="prog_1",
            name="Test Protocol",
            description="A test"
        )
        program.add_command(AspirateCommand(
            source=BiomekPosition(1, "A", 1),
            volume_ul=100.0
        ))
        output = program.to_biomek_string()
        assert "Test Protocol" in output
        assert "ASPIRATE" in output

    def test_program_summary(self):
        """Test program summary."""
        program = BiomekProgram(program_id="prog_1", name="Test")
        program.add_command(AspirateCommand(source=BiomekPosition(1), volume_ul=100))
        program.add_command(DispenseCommand(destination=BiomekPosition(2), volume_ul=100))

        summary = program.summary()
        assert summary["total_commands"] == 2
        assert "ASPIRATE" in summary["command_types"]


class TestDeckMapping:
    """Tests for deck mapping."""

    def test_mapping_creation(self):
        """Test mapping creation."""
        mapping = DeckMapping()
        mapping.add_mapping("source_plate", 1)
        assert mapping.get_position("source_plate") == 1
        assert mapping.get_labware(1) == "source_plate"

    def test_default_mapping(self):
        """Test default deck mapping."""
        mapping = create_default_deck_mapping()
        assert mapping.get_position("source_plate") == 1
        assert mapping.get_position("dest_plate") == 2


class TestPlanToBiomekTranslator:
    """Tests for plan to Biomek translator."""

    def _create_test_plan(self) -> ExecutionPlan:
        """Create a test execution plan."""
        plan = ExecutionPlan(plan_id="test_plan")

        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="source_plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        plan.add_step(PlanStep(
            step_id="disp_1",
            primitive=Dispense(
                destination=WellRef(plate_id="dest_plate", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["asp_1"]
        ))

        return plan

    def test_translate_basic_plan(self):
        """Test translating a basic plan."""
        plan = self._create_test_plan()
        mapping = create_default_deck_mapping()
        translator = PlanToBiomekTranslator(deck_mapping=mapping)

        result = translator.translate(plan, "Test Program")

        assert result.success
        assert result.program is not None
        assert result.program.command_count > 0

    def test_translate_aspirate(self):
        """Test translating aspirate primitive."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="source_plate", well_id="A1"),
                volume_ul=50.0
            ),
            status=PlanStepStatus.PENDING
        ))

        mapping = create_default_deck_mapping()
        result = translate_plan_to_biomek(plan, mapping)

        assert result.success
        aspirates = result.program.get_commands_by_type(BiomekCommandType.ASPIRATE)
        assert len(aspirates) >= 1

    def test_translate_dispense(self):
        """Test translating dispense primitive."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="disp_1",
            primitive=Dispense(
                destination=WellRef(plate_id="dest_plate", well_id="B1"),
                volume_ul=50.0
            ),
            status=PlanStepStatus.PENDING
        ))

        result = translate_plan_to_biomek(plan)

        assert result.success
        dispenses = result.program.get_commands_by_type(BiomekCommandType.DISPENSE)
        assert len(dispenses) >= 1

    def test_translate_mix(self):
        """Test translating mix primitive."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="mix_1",
            primitive=Mix(
                location=WellRef(plate_id="plate", well_id="A1"),
                cycles=5,
                volume_ul=50.0
            ),
            status=PlanStepStatus.PENDING
        ))

        result = translate_plan_to_biomek(plan)

        assert result.success
        mixes = result.program.get_commands_by_type(BiomekCommandType.MIX)
        assert len(mixes) >= 1

    def test_translate_tips(self):
        """Test translating tip operations."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="pick",
            primitive=PickTips(
                tip_rack=TipRackRef(rack_id="tips_200", tip_type="200uL"),
                tip_positions=["A1"]
            ),
            status=PlanStepStatus.PENDING
        ))
        plan.add_step(PlanStep(
            step_id="drop",
            primitive=DropTips(to_waste=True),
            status=PlanStepStatus.PENDING,
            dependencies=["pick"]
        ))

        result = translate_plan_to_biomek(plan)

        assert result.success
        tips = result.program.get_commands_by_type(BiomekCommandType.GET_TIPS)
        drops = result.program.get_commands_by_type(BiomekCommandType.DROP_TIPS)
        assert len(tips) >= 1
        assert len(drops) >= 1

    def test_translate_wait(self):
        """Test translating wait primitive."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="wait_1",
            primitive=Wait(duration_s=30.0),
            status=PlanStepStatus.PENDING
        ))

        result = translate_plan_to_biomek(plan)

        assert result.success
        delays = result.program.get_commands_by_type(BiomekCommandType.DELAY)
        assert len(delays) >= 1

    def test_step_mapping(self):
        """Test step to command mapping."""
        plan = self._create_test_plan()
        result = translate_plan_to_biomek(plan)

        assert "asp_1" in result.step_mapping
        assert len(result.step_mapping["asp_1"]) > 0


class TestBiomekCodeGenerator:
    """Tests for Biomek code generator."""

    def _create_test_program(self) -> BiomekProgram:
        """Create a test program."""
        program = BiomekProgram(
            program_id="test_prog",
            name="Test Protocol",
            description="Test description"
        )
        program.set_deck_position(1, "96_well_plate")
        program.add_liquid_class(LiquidClass.default())

        program.add_command(AspirateCommand(
            source=BiomekPosition(1, "A", 1),
            volume_ul=100.0
        ))
        program.add_command(DispenseCommand(
            destination=BiomekPosition(2, "B", 1),
            volume_ul=100.0
        ))

        return program

    def test_generate_biomek_script(self):
        """Test generating Biomek script format."""
        program = self._create_test_program()
        result = generate_biomek_code(program, OutputFormat.BIOMEK_SCRIPT)

        assert result.success
        assert "Aspirate" in result.code
        assert "Dispense" in result.code
        assert result.command_count == 2

    def test_generate_biomek_script_is_deterministic_by_default(self):
        """Default codegen output should be byte-stable across reruns."""
        program = self._create_test_program()
        result1 = generate_biomek_code(program, OutputFormat.BIOMEK_SCRIPT)
        result2 = generate_biomek_code(program, OutputFormat.BIOMEK_SCRIPT)

        assert result1.success
        assert result2.success
        assert result1.code == result2.code
        assert "Generated:" not in result1.code

    def test_generate_xml(self):
        """Test generating XML format."""
        program = self._create_test_program()
        result = generate_biomek_code(program, OutputFormat.XML)

        assert result.success
        assert "<BiomekProgram" in result.code
        assert "<Command" in result.code

    def test_generate_json(self):
        """Test generating JSON format."""
        program = self._create_test_program()
        result = generate_biomek_code(program, OutputFormat.JSON)

        assert result.success
        data = json.loads(result.code)
        assert data["name"] == "Test Protocol"
        assert len(data["commands"]) == 2

    def test_generate_python(self):
        """Test generating Python format."""
        program = self._create_test_program()
        result = generate_biomek_code(program, OutputFormat.PYTHON)

        assert result.success
        assert "def run_" in result.code
        assert "biomek.aspirate" in result.code
        assert "biomek.dispense" in result.code

    def test_generation_options(self):
        """Test generation options."""
        program = self._create_test_program()
        options = GenerationOptions(
            format=OutputFormat.BIOMEK_SCRIPT,
            include_header=True,
            include_deck_layout=True,
            include_liquid_classes=True
        )
        generator = BiomekCodeGenerator(options)
        result = generator.generate(program)

        assert result.success
        assert "Deck Layout" in result.code
        assert "Liquid Classes" in result.code


class TestStepClassifier:
    """Tests for step classifier."""

    def test_classify_aspirate(self):
        """Test classifying aspirate step."""
        classifier = StepClassifier()
        step = PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        )

        classification = classifier.classify(step)
        assert classification.target == ExecutionTarget.ROBOT

    def test_classify_human_only(self):
        """Test classifying human-only step."""
        classifier = StepClassifier()
        step = PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            annotations={"human_only": True}
        )

        classification = classifier.classify(step)
        assert classification.target == ExecutionTarget.HUMAN


class TestHybridExecutor:
    """Tests for hybrid executor."""

    def _create_mixed_plan(self) -> ExecutionPlan:
        """Create a plan with mixed execution targets."""
        plan = ExecutionPlan(plan_id="mixed_plan")

        # Robot step
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="source", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        # Human step (marked as human_only)
        plan.add_step(PlanStep(
            step_id="seal_1",
            primitive=Wait(duration_s=0),  # Placeholder for seal operation
            status=PlanStepStatus.PENDING,
            annotations={"human_only": True},
            dependencies=["asp_1"]
        ))

        # Robot step
        plan.add_step(PlanStep(
            step_id="disp_1",
            primitive=Dispense(
                destination=WellRef(plate_id="dest", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["seal_1"]
        ))

        return plan

    def test_create_hybrid_plan(self):
        """Test creating hybrid plan."""
        plan = self._create_mixed_plan()
        hybrid = create_hybrid_plan(plan, "Mixed Protocol")

        assert hybrid is not None
        assert len(hybrid.step_classifications) == 3
        assert len(hybrid.handoffs) > 0  # Should have handoffs

    def test_handoff_detection(self):
        """Test handoff detection."""
        plan = self._create_mixed_plan()
        executor = HybridExecutor()
        hybrid = executor.create_hybrid_plan(plan)

        # Should have handoffs where execution target changes
        assert len(hybrid.handoffs) >= 1

    def test_execution_sequence(self):
        """Test execution sequence."""
        plan = self._create_mixed_plan()
        hybrid = create_hybrid_plan(plan)

        assert len(hybrid.execution_sequence) == 3

    def test_get_next_block(self):
        """Test getting next execution block."""
        plan = self._create_mixed_plan()
        executor = HybridExecutor()
        hybrid = executor.create_hybrid_plan(plan)

        target, step_ids, next_index = executor.get_next_execution_block(hybrid, 0)
        assert target in (ExecutionTarget.ROBOT, ExecutionTarget.HUMAN)
        assert len(step_ids) >= 1


class TestHybridExecutionManager:
    """Tests for hybrid execution manager."""

    def test_create_session(self):
        """Test creating execution session."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        manager = HybridExecutionManager()
        state = manager.create_session(plan, "Test Protocol")

        assert state is not None
        assert state.started_at is not None
        assert not state.is_complete

    def test_advance_session(self):
        """Test advancing session."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        manager = HybridExecutionManager()
        state = manager.create_session(plan)

        target, step_ids, handoff = manager.advance_session(plan.plan_id)
        assert target is not None
        assert len(step_ids) >= 1

    def test_complete_step(self):
        """Test completing steps."""
        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="asp_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))

        manager = HybridExecutionManager()
        state = manager.create_session(plan)

        state.complete_step("asp_1", ExecutionTarget.ROBOT)
        assert "asp_1" in state.completed_robot_steps


class TestHandoffPoint:
    """Tests for handoff points."""

    def test_handoff_creation(self):
        """Test handoff creation."""
        handoff = HandoffPoint(
            handoff_id="h1",
            handoff_type=HandoffType.ROBOT_TO_HUMAN,
            before_step_id="step_1",
            after_step_id="step_2",
            description="Switch to manual operation"
        )
        assert handoff.handoff_type == HandoffType.ROBOT_TO_HUMAN
        assert not handoff.completed


class TestIntegration:
    """Integration tests."""

    def test_full_translation_and_generation(self):
        """Test complete translation and code generation workflow."""
        # Create plan
        plan = ExecutionPlan(plan_id="integration_test")
        plan.add_step(PlanStep(
            step_id="pick",
            primitive=PickTips(
                tip_rack=TipRackRef(rack_id="tips", tip_type="200uL"),
                tip_positions=["A1"]
            ),
            status=PlanStepStatus.PENDING
        ))
        plan.add_step(PlanStep(
            step_id="asp",
            primitive=Aspirate(
                source=WellRef(plate_id="source_plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["pick"]
        ))
        plan.add_step(PlanStep(
            step_id="disp",
            primitive=Dispense(
                destination=WellRef(plate_id="dest_plate", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["asp"]
        ))
        plan.add_step(PlanStep(
            step_id="drop",
            primitive=DropTips(to_waste=True),
            status=PlanStepStatus.PENDING,
            dependencies=["disp"]
        ))

        # Translate
        mapping = create_default_deck_mapping()
        result = translate_plan_to_biomek(plan, mapping, program_name="Full Test")

        assert result.success
        assert result.program.command_count >= 4

        # Generate code
        code_result = generate_biomek_code(result.program, OutputFormat.BIOMEK_SCRIPT)
        assert code_result.success
        assert "GetTips" in code_result.code
        assert "Aspirate" in code_result.code
        assert "Dispense" in code_result.code
        assert "DropTips" in code_result.code

    def test_hybrid_execution_workflow(self):
        """Test hybrid execution workflow."""
        # Create mixed plan
        plan = ExecutionPlan(plan_id="hybrid_test")
        plan.add_step(PlanStep(
            step_id="robot_asp",
            primitive=Aspirate(
                source=WellRef(plate_id="plate", well_id="A1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING
        ))
        plan.add_step(PlanStep(
            step_id="human_check",
            primitive=Wait(duration_s=0),
            status=PlanStepStatus.PENDING,
            annotations={"human_only": True},
            dependencies=["robot_asp"]
        ))
        plan.add_step(PlanStep(
            step_id="robot_disp",
            primitive=Dispense(
                destination=WellRef(plate_id="plate", well_id="B1"),
                volume_ul=100.0
            ),
            status=PlanStepStatus.PENDING,
            dependencies=["human_check"]
        ))

        # Create hybrid plan
        hybrid = create_hybrid_plan(plan, "Hybrid Test")

        assert hybrid.robot_program is not None
        assert hybrid.human_plan is not None

        # Should have robot and human steps classified correctly
        robot_classified = [
            s for s, c in hybrid.step_classifications.items()
            if c.target == ExecutionTarget.ROBOT
        ]
        human_classified = [
            s for s, c in hybrid.step_classifications.items()
            if c.target == ExecutionTarget.HUMAN
        ]

        assert len(robot_classified) == 2
        assert len(human_classified) == 1
