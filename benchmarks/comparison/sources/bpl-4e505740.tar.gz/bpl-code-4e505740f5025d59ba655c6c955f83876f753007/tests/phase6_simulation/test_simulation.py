"""Tests for Phase 6: Simulation Mode."""

import pytest
from datetime import datetime

from bpl.simulation import (
    # Virtual deck
    LabwareType,
    Component,
    VirtualContents,
    VirtualWell,
    VirtualLabware,
    TipState,
    VirtualPipette,
    VirtualDeckState,
    create_standard_deck,
    create_deck_with_labware,
    # Simulator
    SimulationStatus,
    StepTrace,
    SimulationResult,
    Simulator,
    simulate,
    # Validation
    ValidationSeverity,
    ValidationIssue,
    ValidationResult,
    NoOverflowCheck,
    NoEmptyAspirationCheck,
    NoNegativeVolumeCheck,
    Validator,
    create_validator,
    validate_plan,
    # Checkpoints
    CheckpointType,
    CheckpointData,
    Checkpoint,
    RecoveryPlan,
    CheckpointManager,
    create_checkpoint_manager,
    # Assertions
    AssertionMode,
    AssertionType,
    AssertionResult,
    Assertion,
    InvariantBlock,
    AssertionManager,
    assert_volume_positive,
    create_assertion_manager,
    # Breakpoints
    BreakpointType,
    BreakpointAction,
    Breakpoint,
    BreakpointHit,
    DebugMode,
    BreakpointManager,
    create_breakpoint_manager,
    # Logging
    LogLevel,
    LogOutput,
    LogEntry,
    SimulationLogger,
    create_logger,
    create_silent_logger,
)

from bpl.lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    DropTips,
    Wait,
    WellRef,
    TipRackRef,
)


class TestVirtualContents:
    """Tests for VirtualContents."""

    def test_create_empty_contents(self):
        """Test creating empty contents."""
        contents = VirtualContents()
        assert contents.volume_ul == 0.0
        assert contents.is_empty()

    def test_add_volume(self):
        """Test adding volume."""
        contents = VirtualContents(max_volume_ul=200.0)
        contents.add_volume(50.0)
        assert contents.volume_ul == 50.0

    def test_add_volume_with_component(self):
        """Test adding volume with component."""
        contents = VirtualContents()
        component = Component(name="PBS", volume_ul=50.0)
        contents.add_volume(50.0, component)
        assert len(contents.components) == 1
        assert contents.components[0].name == "PBS"

    def test_remove_volume(self):
        """Test removing volume."""
        contents = VirtualContents(volume_ul=100.0)
        removed = contents.remove_volume(30.0)
        assert removed == 30.0
        assert contents.volume_ul == 70.0

    def test_remove_more_than_available(self):
        """Test removing more than available."""
        contents = VirtualContents(volume_ul=50.0)
        removed = contents.remove_volume(100.0)
        assert removed == 50.0
        assert contents.volume_ul == 0.0

    def test_overflow_detection(self):
        """Test overflow detection."""
        contents = VirtualContents(volume_ul=150.0, max_volume_ul=200.0)
        assert contents.would_overflow(100.0) is True
        assert contents.would_overflow(50.0) is False

    def test_mix(self):
        """Test mixing."""
        contents = VirtualContents()
        contents.add_volume(50.0)
        assert contents.mixed is False
        contents.mix()
        assert contents.mixed is True

    def test_hash_changes(self):
        """Test that hash changes with content."""
        contents = VirtualContents(volume_ul=50.0)
        hash1 = contents.get_hash()
        contents.add_volume(10.0)
        hash2 = contents.get_hash()
        assert hash1 != hash2


class TestVirtualLabware:
    """Tests for VirtualLabware."""

    def test_create_96_plate(self):
        """Test creating a 96-well plate."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_96
        )
        assert len(labware.wells) == 96
        assert labware.rows == 8
        assert labware.cols == 12

    def test_create_384_plate(self):
        """Test creating a 384-well plate."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_384
        )
        assert len(labware.wells) == 384

    def test_get_well(self):
        """Test getting a well."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_96
        )
        well = labware.get_well("A1")
        assert well is not None
        assert well.well_id == "A1"

    def test_get_contents(self):
        """Test getting well contents."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_96
        )
        contents = labware.get_contents("B2")
        assert contents is not None
        assert contents.is_empty()

    def test_wells_in_row(self):
        """Test getting wells in a row."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_96
        )
        row_a = labware.get_wells_in_row("A")
        assert len(row_a) == 12

    def test_wells_in_column(self):
        """Test getting wells in a column."""
        labware = VirtualLabware(
            labware_id="plate_1",
            labware_type=LabwareType.PLATE_96
        )
        col_1 = labware.get_wells_in_column(1)
        assert len(col_1) == 8


class TestTipState:
    """Tests for TipState."""

    def test_create_tip_state(self):
        """Test creating tip state."""
        tips = {"A1", "A2", "A3"}
        state = TipState(rack_id="tips_1", available_tips=tips)
        assert state.available_count() == 3

    def test_pick_tip(self):
        """Test picking a tip."""
        state = TipState(rack_id="tips_1", available_tips={"A1", "A2"})
        result = state.pick_tip("A1")
        assert result is True
        assert state.has_tip("A1") is False
        assert state.available_count() == 1

    def test_pick_unavailable_tip(self):
        """Test picking an unavailable tip."""
        state = TipState(rack_id="tips_1", available_tips={"A2"})
        result = state.pick_tip("A1")
        assert result is False

    def test_reset_tips(self):
        """Test resetting tips."""
        state = TipState(rack_id="tips_1", available_tips={"A1", "A2"})
        state.pick_tip("A1")
        state.reset()
        assert state.available_count() == 2


class TestVirtualDeckState:
    """Tests for VirtualDeckState."""

    def test_create_deck(self):
        """Test creating a deck."""
        deck = create_standard_deck()
        assert len(deck.positions) == 12

    def test_add_labware(self):
        """Test adding labware to deck."""
        deck = create_standard_deck()
        labware = deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        assert labware is not None
        assert deck.positions["slot_1"] == "plate_1"

    def test_add_labware_occupied_raises(self):
        """Test adding labware to occupied position."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        with pytest.raises(ValueError):
            deck.add_labware("plate_2", LabwareType.PLATE_96, "slot_1")

    def test_remove_labware(self):
        """Test removing labware."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        deck.remove_labware("plate_1")
        assert deck.positions["slot_1"] is None

    def test_add_tip_rack_creates_tip_state(self):
        """Test that adding tip rack creates tip state."""
        deck = create_standard_deck()
        deck.add_labware("tips_1", LabwareType.TIP_RACK, "slot_2")
        assert "tips_1" in deck.tip_states
        assert deck.tip_states["tips_1"].available_count() == 96

    def test_add_pipette(self):
        """Test adding a pipette."""
        deck = create_standard_deck()
        pipette = deck.add_pipette("p200", channels=8, max_volume_ul=200.0)
        assert pipette.pipette_id == "p200"
        assert pipette.channels == 8

    def test_set_temperature(self):
        """Test setting temperature."""
        deck = create_standard_deck()
        deck.set_temperature("heater_1", 37.0)
        assert deck.get_temperature("heater_1") == 37.0

    def test_state_hash_changes(self):
        """Test that state hash changes."""
        deck = create_standard_deck()
        hash1 = deck.get_state_hash()

        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        hash2 = deck.get_state_hash()

        assert hash1 != hash2


class TestSimulator:
    """Tests for Simulator."""

    def test_create_simulator(self):
        """Test creating a simulator."""
        simulator = Simulator()
        assert simulator.deck_state is not None

    def test_simulate_empty_plan(self):
        """Test simulating an empty plan."""
        simulator = Simulator()
        plan = ExecutionPlan(plan_id="test")
        result = simulator.simulate(plan)
        assert result.success is True
        assert result.steps_executed == 0

    def test_simulate_simple_plan(self):
        """Test simulating a simple plan."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        # Add volume to source well
        contents = deck.get_well_contents("plate_1", "A1")
        contents.add_volume(100.0)

        simulator = Simulator(deck_state=deck, validate=False)
        simulator.deck_state.add_pipette("default_pipette")

        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="aspirate_1",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        ))

        result = simulator.simulate(plan)
        assert result.steps_executed == 1

    def test_simulation_result_properties(self):
        """Test SimulationResult properties."""
        result = SimulationResult(
            plan_id="test",
            status=SimulationStatus.COMPLETED,
            started_at=datetime.now()
        )
        result.completed_at = datetime.now()
        assert result.success is True
        assert result.duration_s is not None

    def test_simulate_rejects_non_positive_aspirate_volume(self):
        """Test non-positive aspirate volume fails simulation."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        deck.add_pipette("default_pipette")

        plan = ExecutionPlan(plan_id="invalid_volume")
        plan.add_step(PlanStep(
            step_id="aspirate_bad",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=0.0,
            )
        ))

        result = Simulator(deck_state=deck, validate=True).simulate(plan)
        assert result.status == SimulationStatus.FAILED
        assert any("must be positive" in err for err in result.validation_errors)

    def test_simulate_rejects_source_insufficiency(self):
        """Test aspirate source insufficiency fails simulation."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        deck.add_pipette("default_pipette")
        deck.get_well_contents("plate_1", "A1").add_volume(10.0)

        plan = ExecutionPlan(plan_id="insufficient_source")
        plan.add_step(PlanStep(
            step_id="aspirate_too_much",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=25.0,
            )
        ))

        result = Simulator(deck_state=deck, validate=True).simulate(plan)
        assert result.status == SimulationStatus.FAILED
        assert any("Source insufficiency" in err for err in result.validation_errors)


class TestValidation:
    """Tests for validation checks."""

    def test_no_overflow_check_passes(self):
        """Test NoOverflow check passing."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")

        step = PlanStep(
            step_id="dispense_1",
            primitive=Dispense(
                destination=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        )

        check = NoOverflowCheck()
        issue = check.validate(step, deck)
        assert issue is None  # Should pass

    def test_no_overflow_check_fails(self):
        """Test NoOverflow check failing."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")

        # Fill well almost full
        contents = deck.get_well_contents("plate_1", "A1")
        contents.add_volume(180.0)

        step = PlanStep(
            step_id="dispense_1",
            primitive=Dispense(
                destination=WellRef("plate_1", "A1"),
                volume_ul=50.0  # Would overflow
            )
        )

        check = NoOverflowCheck()
        issue = check.validate(step, deck)
        assert issue is not None
        assert issue.severity == ValidationSeverity.ERROR

    def test_no_empty_aspiration_passes(self):
        """Test NoEmptyAspiration passing."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        contents = deck.get_well_contents("plate_1", "A1")
        contents.add_volume(100.0)

        step = PlanStep(
            step_id="aspirate_1",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        )

        check = NoEmptyAspirationCheck()
        issue = check.validate(step, deck)
        assert issue is None

    def test_no_empty_aspiration_fails(self):
        """Test NoEmptyAspiration failing."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        # Well is empty

        step = PlanStep(
            step_id="aspirate_1",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        )

        check = NoEmptyAspirationCheck()
        issue = check.validate(step, deck)
        assert issue is not None

    def test_validator_multiple_checks(self):
        """Test validator with multiple checks."""
        validator = create_validator()
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")

        plan = ExecutionPlan(plan_id="test")
        plan.add_step(PlanStep(
            step_id="dispense_1",
            primitive=Dispense(
                destination=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        ))

        result = validator.validate_plan(plan, deck)
        assert result.passed is True


class TestCheckpoints:
    """Tests for checkpoint system."""

    def test_create_checkpoint(self):
        """Test creating a checkpoint."""
        manager = create_checkpoint_manager()
        checkpoint = manager.create_checkpoint(
            step_id="step_1",
            checkpoint_type=CheckpointType.MANUAL,
            deck_state_hash="abc123",
            execution_state_hash="def456"
        )
        assert checkpoint is not None
        assert checkpoint.step_id == "step_1"

    def test_checkpoint_integrity(self):
        """Test checkpoint integrity verification."""
        manager = create_checkpoint_manager()
        checkpoint = manager.create_checkpoint(
            step_id="step_1",
            checkpoint_type=CheckpointType.MANUAL,
            deck_state_hash="abc123",
            execution_state_hash="def456"
        )
        assert checkpoint.verify_integrity() is True

    def test_checkpoint_chain(self):
        """Test checkpoint chain."""
        manager = create_checkpoint_manager()
        cp1 = manager.create_checkpoint(
            step_id="step_1",
            checkpoint_type=CheckpointType.AUTO,
            deck_state_hash="hash1",
            execution_state_hash="exec1"
        )
        cp2 = manager.create_checkpoint(
            step_id="step_2",
            checkpoint_type=CheckpointType.AUTO,
            deck_state_hash="hash2",
            execution_state_hash="exec2"
        )

        assert cp2.parent_checkpoint_id == cp1.checkpoint_id
        assert len(manager.checkpoint_chain) == 2

    def test_verify_chain_integrity(self):
        """Test verifying chain integrity."""
        manager = create_checkpoint_manager()
        manager.create_checkpoint("s1", CheckpointType.AUTO, "h1", "e1")
        manager.create_checkpoint("s2", CheckpointType.AUTO, "h2", "e2")

        valid, issues = manager.verify_chain_integrity()
        assert valid is True
        assert len(issues) == 0

    def test_create_recovery_plan(self):
        """Test creating recovery plan."""
        manager = create_checkpoint_manager()
        cp = manager.create_checkpoint("s1", CheckpointType.MANUAL, "h1", "e1")

        recovery = manager.create_recovery_plan(
            from_checkpoint_id=cp.checkpoint_id,
            completed_steps=["s1", "s2", "s3"]
        )
        assert recovery.can_recover is True

    def test_serialize_deserialize_checkpoint(self):
        """Test checkpoint serialization."""
        manager = create_checkpoint_manager()
        cp = manager.create_checkpoint("s1", CheckpointType.MANUAL, "h1", "e1")

        json_str = manager.serialize_checkpoint(cp.checkpoint_id)
        assert json_str is not None

        restored = manager.deserialize_checkpoint(json_str)
        assert restored is not None
        assert restored.checkpoint_id == cp.checkpoint_id


class TestAssertions:
    """Tests for assertion system."""

    def test_create_assertion(self):
        """Test creating an assertion."""
        manager = create_assertion_manager()
        assertion = manager.create_assertion(
            expression="x > 0",
            message="x must be positive"
        )
        assert assertion is not None

    def test_assertion_passes(self):
        """Test assertion passing."""
        manager = create_assertion_manager()
        assertion = manager.create_assertion(
            expression="x > 0",
            condition=lambda ctx: ctx.get("x", 0) > 0
        )

        result = assertion.check({"x": 5})
        assert result.passed is True

    def test_assertion_fails(self):
        """Test assertion failing."""
        manager = create_assertion_manager()
        assertion = manager.create_assertion(
            expression="x > 0",
            condition=lambda ctx: ctx.get("x", 0) > 0
        )

        result = assertion.check({"x": -1})
        assert result.passed is False

    def test_assertion_modes(self):
        """Test assertion modes."""
        manager = create_assertion_manager(mode=AssertionMode.SKIP)
        assertion = manager.create_assertion(
            expression="test",
            condition=lambda _: False
        )

        result = manager.check_assertion(assertion.assertion_id, {})
        assert result.passed is True  # Skipped, so passes

    def test_invariant_block(self):
        """Test invariant block."""
        manager = create_assertion_manager()
        block = manager.create_invariant_block()
        block.add_assertion(Assertion(
            assertion_id="inv_1",
            expression="volume >= 0",
            condition=lambda ctx: ctx.get("volume", 0) >= 0
        ))

        results = block.check_all({"volume": 50})
        assert all(r.passed for r in results)

    def test_static_assertion(self):
        """Test static assertion."""
        manager = create_assertion_manager()
        manager.create_static_assertion(
            expression="True",
            message="Always passes"
        )

        results = manager.check_static_assertions({"value": True})
        assert all(r.passed for r in results)

    def test_expression_assertion_uses_restricted_evaluator(self):
        """Expression assertions do not expose Python object traversal."""
        assertion = Assertion(
            assertion_id="safe_1",
            expression="x > 0 and y < 10",
        )
        assert assertion.check({"x": 3, "y": 5}).passed is True

        malicious = Assertion(
            assertion_id="safe_2",
            expression="().__class__.__base__.__subclasses__()",
        )
        result = malicious.check({})
        assert result.passed is False
        assert "Unsupported assertion expression" in result.message


class TestBreakpoints:
    """Tests for breakpoint system."""

    def test_add_step_breakpoint(self):
        """Test adding step breakpoint."""
        manager = create_breakpoint_manager()
        bp = manager.add_step_breakpoint("step_5")
        assert bp.step_id == "step_5"

    def test_breakpoint_triggers(self):
        """Test breakpoint triggering."""
        manager = create_breakpoint_manager()
        manager.add_step_breakpoint("step_5")

        hit = manager.check_breakpoints("step_5", {})
        assert hit is not None
        assert hit.step_id == "step_5"

    def test_breakpoint_no_trigger(self):
        """Test breakpoint not triggering."""
        manager = create_breakpoint_manager()
        manager.add_step_breakpoint("step_5")

        hit = manager.check_breakpoints("step_3", {})
        assert hit is None

    def test_conditional_breakpoint(self):
        """Test conditional breakpoint."""
        manager = create_breakpoint_manager()
        manager.add_conditional_breakpoint(
            condition=lambda ctx: ctx.get("volume", 0) > 100,
            expression="volume > 100"
        )

        hit = manager.check_breakpoints("step_1", {"volume": 150})
        assert hit is not None

    def test_disable_breakpoint(self):
        """Test disabling breakpoint."""
        manager = create_breakpoint_manager()
        bp = manager.add_step_breakpoint("step_5")
        manager.disable_breakpoint(bp.breakpoint_id)

        hit = manager.check_breakpoints("step_5", {})
        assert hit is None

    def test_single_step_mode(self):
        """Test single-step debug mode."""
        manager = create_breakpoint_manager()
        manager.step()

        hit = manager.check_breakpoints("any_step", {})
        assert hit is not None  # Should break on every step

    def test_breakpoint_hit_count(self):
        """Test breakpoint hit counting."""
        manager = create_breakpoint_manager()
        bp = manager.add_step_breakpoint("step_1")

        manager.check_breakpoints("step_1", {})
        manager.check_breakpoints("step_1", {})

        assert bp.hit_count == 2


class TestLogging:
    """Tests for simulation logging."""

    def test_create_logger(self):
        """Test creating logger."""
        logger = create_logger()
        assert logger is not None

    def test_log_levels(self):
        """Test different log levels."""
        logger = create_silent_logger()
        logger.trace("trace message")
        logger.debug("debug message")
        logger.info("info message")
        logger.warn("warn message")
        logger.error("error message")

        assert len(logger.entries) == 5

    def test_log_filtering(self):
        """Test log filtering."""
        logger = create_logger(level=LogLevel.WARN)
        logger.debug("debug")  # Below threshold
        logger.warn("warn")    # At threshold
        logger.error("error")  # Above threshold

        # All 3 are logged internally
        assert len(logger.entries) == 3

    def test_get_errors(self):
        """Test getting error entries."""
        logger = create_silent_logger()
        logger.info("info")
        logger.error("error 1")
        logger.error("error 2")

        errors = logger.get_errors()
        assert len(errors) == 2

    def test_log_step_events(self):
        """Test logging step events."""
        logger = create_silent_logger()
        logger.log_step_start("step_1", "ASPIRATE")
        logger.log_step_complete("step_1", 50.0, True)

        assert len(logger.entries) == 2

    def test_step_level_override(self):
        """Test per-step log level override."""
        logger = create_logger(level=LogLevel.INFO)
        logger.set_step_level("debug_step", LogLevel.TRACE)

        # This step gets more verbose logging
        logger.trace("detailed", step_id="debug_step")
        # Check it was logged
        assert any(e.step_id == "debug_step" for e in logger.entries)

    def test_log_summary(self):
        """Test log summary."""
        logger = create_silent_logger()
        logger.info("info")
        logger.warn("warn")
        logger.error("error")

        summary = logger.get_summary()
        assert summary["total_entries"] == 3
        assert summary["errors"] == 1
        assert summary["warnings"] == 1


class TestIntegration:
    """Integration tests for simulation module."""

    def test_full_simulation_workflow(self):
        """Test complete simulation workflow."""
        # Setup deck
        deck = create_standard_deck()
        deck.add_labware("source_plate", LabwareType.PLATE_96, "slot_1")
        deck.add_labware("dest_plate", LabwareType.PLATE_96, "slot_2")
        deck.add_labware("tips", LabwareType.TIP_RACK, "slot_3")
        deck.add_pipette("default_pipette", channels=1, max_volume_ul=200.0)

        # Add reagent to source
        for row in "ABCDEFGH":
            for col in range(1, 13):
                contents = deck.get_well_contents("source_plate", f"{row}{col}")
                contents.add_volume(100.0)

        # Create plan
        plan = ExecutionPlan(plan_id="transfer_test")

        # Add steps for a simple transfer
        plan.add_step(PlanStep(
            step_id="pick_tips",
            primitive=PickTips(
                tip_rack=TipRackRef(rack_id="tips", tip_type="tips_200"),
                tip_positions=["A1"]
            )
        ))
        plan.add_step(PlanStep(
            step_id="aspirate_1",
            primitive=Aspirate(
                source=WellRef("source_plate", "A1"),
                volume_ul=50.0
            ),
            dependencies=["pick_tips"]
        ))
        plan.add_step(PlanStep(
            step_id="dispense_1",
            primitive=Dispense(
                destination=WellRef("dest_plate", "A1"),
                volume_ul=50.0
            ),
            dependencies=["aspirate_1"]
        ))
        plan.add_step(PlanStep(
            step_id="drop_tips",
            primitive=DropTips(to_waste=True),
            dependencies=["dispense_1"]
        ))

        # Run simulation
        simulator = Simulator(deck_state=deck, validate=True)
        result = simulator.simulate(plan)

        # Verify
        assert result.status == SimulationStatus.COMPLETED
        assert result.steps_executed == 4
        assert result.steps_failed == 0

        # Check state changes
        source_contents = deck.get_well_contents("source_plate", "A1")
        dest_contents = deck.get_well_contents("dest_plate", "A1")

        assert source_contents.volume_ul == 50.0  # 100 - 50
        assert dest_contents.volume_ul == 50.0    # 0 + 50

    def test_simulation_with_validation(self):
        """Test simulation with validation."""
        deck = create_standard_deck()
        deck.add_labware("plate_1", LabwareType.PLATE_96, "slot_1")
        # No volume in source - will cause empty aspiration

        plan = ExecutionPlan(plan_id="invalid_test")
        plan.add_step(PlanStep(
            step_id="bad_aspirate",
            primitive=Aspirate(
                source=WellRef("plate_1", "A1"),
                volume_ul=50.0
            )
        ))

        # Validate before running
        validator = create_validator()
        validation_result = validator.validate_plan(plan, deck)

        # Should detect empty aspiration
        assert validation_result.passed is False
        assert any("empty" in str(i.message).lower() for i in validation_result.issues)
