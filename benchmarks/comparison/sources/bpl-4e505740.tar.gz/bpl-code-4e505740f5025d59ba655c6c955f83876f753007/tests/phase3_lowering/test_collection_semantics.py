"""
Tests for BPL Collection Semantics.

Tests cover:
- Well range expansion
- ZIP semantics (1:1 mapping)
- BROADCAST semantics (1:N)
- PRODUCT semantics (M×N)
- Semantics inference and validation
"""

import pytest

from bpl.lowering import (
    Semantics,
    WellPair,
    CollectionSemanticsError,
    expand_well_range,
    expand_wells,
    apply_zip_semantics,
    apply_broadcast_semantics,
    apply_product_semantics,
    infer_semantics,
    expand_collection_operation,
    validate_collection_semantics,
    zip_transfer,
    distribute_to_all,
    pool_to_single,
)


class TestExpandWellRange:
    """Test well range expansion."""

    def test_single_row_range(self):
        """Expand A1:A12 (single row)."""
        wells = expand_well_range("A1", "A12")
        assert len(wells) == 12
        assert wells[0] == "A1"
        assert wells[-1] == "A12"

    def test_single_column_range(self):
        """Expand A1:H1 (single column)."""
        wells = expand_well_range("A1", "H1")
        assert len(wells) == 8
        assert wells[0] == "A1"
        assert wells[-1] == "H1"

    def test_full_plate_range(self):
        """Expand A1:H12 (full 96-well plate)."""
        wells = expand_well_range("A1", "H12")
        assert len(wells) == 96
        assert wells[0] == "A1"
        assert wells[-1] == "H12"

    def test_partial_range(self):
        """Expand B2:D4 (partial)."""
        wells = expand_well_range("B2", "D4")
        # 3 rows (B, C, D) × 3 cols (2, 3, 4) = 9 wells
        assert len(wells) == 9
        assert "B2" in wells
        assert "D4" in wells

    def test_row_major_order(self):
        """Wells are in row-major order."""
        wells = expand_well_range("A1", "B2")
        # A1, A2, B1, B2 (row-major)
        assert wells == ["A1", "A2", "B1", "B2"]

    def test_invalid_range_reversed(self):
        """Invalid range with start > end raises error."""
        with pytest.raises(CollectionSemanticsError, match="Invalid well range"):
            expand_well_range("H12", "A1")


class TestExpandWells:
    """Test well specification expansion."""

    def test_single_well(self):
        """Expand single well."""
        wells = expand_wells("A1")
        assert wells == ["A1"]

    def test_range(self):
        """Expand range."""
        wells = expand_wells("A1:A6")
        assert len(wells) == 6
        assert wells[0] == "A1"
        assert wells[-1] == "A6"

    def test_column_spec(self):
        """Expand column specification."""
        wells = expand_wells("Col1")
        assert len(wells) == 8
        assert "A1" in wells
        assert "H1" in wells

    def test_column_word_spec(self):
        """Expand full column spelling."""
        wells = expand_wells("Column1")
        assert len(wells) == 8
        assert wells == ["A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1"]

    def test_row_spec_letter(self):
        """Expand row specification with letter."""
        wells = expand_wells("RowA")
        assert len(wells) == 12
        assert "A1" in wells
        assert "A12" in wells

    def test_all_wells(self):
        """Expand 'All' specification."""
        wells = expand_wells("All")
        assert len(wells) == 96

    def test_case_insensitive(self):
        """Well specs are case insensitive."""
        wells1 = expand_wells("a1")
        wells2 = expand_wells("A1")
        assert wells1 == wells2


class TestZipSemantics:
    """Test ZIP semantics (1:1 mapping)."""

    def test_zip_equal_counts(self):
        """ZIP with equal counts succeeds."""
        source_wells = ["A1", "A2", "A3"]
        dest_wells = ["B1", "B2", "B3"]

        pairs = apply_zip_semantics(
            source_wells, dest_wells,
            "plate_1", "plate_2"
        )

        assert len(pairs) == 3
        assert pairs[0] == WellPair("plate_1", "A1", "plate_2", "B1")
        assert pairs[1] == WellPair("plate_1", "A2", "plate_2", "B2")
        assert pairs[2] == WellPair("plate_1", "A3", "plate_2", "B3")

    def test_zip_count_mismatch_error(self):
        """ZIP with different counts raises error."""
        source_wells = ["A1", "A2", "A3"]
        dest_wells = ["B1", "B2"]

        with pytest.raises(CollectionSemanticsError, match="equal counts"):
            apply_zip_semantics(source_wells, dest_wells, "p1", "p2")

    def test_zip_full_column(self):
        """ZIP full columns."""
        source_wells = expand_wells("Col1")
        dest_wells = expand_wells("Col2")

        pairs = apply_zip_semantics(
            source_wells, dest_wells,
            "plate_src", "plate_dst"
        )

        assert len(pairs) == 8
        # A1 → A2, B1 → B2, etc.
        assert pairs[0].source_well == "A1"
        assert pairs[0].dest_well == "A2"


class TestBroadcastSemantics:
    """Test BROADCAST semantics (1:N)."""

    def test_broadcast_single_to_multiple(self):
        """Broadcast single source to multiple dests."""
        source_wells = ["A1"]
        dest_wells = ["B1", "B2", "B3"]

        pairs = apply_broadcast_semantics(
            source_wells, dest_wells,
            "plate_1", "plate_2"
        )

        assert len(pairs) == 3
        assert all(p.source_well == "A1" for p in pairs)
        assert pairs[0].dest_well == "B1"
        assert pairs[1].dest_well == "B2"
        assert pairs[2].dest_well == "B3"

    def test_broadcast_multiple_sources(self):
        """Broadcast multiple sources to multiple dests (M×N)."""
        source_wells = ["A1", "A2"]
        dest_wells = ["B1", "B2", "B3"]

        pairs = apply_broadcast_semantics(
            source_wells, dest_wells,
            "plate_1", "plate_2"
        )

        # 2 sources × 3 dests = 6 pairs
        assert len(pairs) == 6


class TestProductSemantics:
    """Test PRODUCT semantics (M×N cartesian)."""

    def test_product_small(self):
        """Product with small sets."""
        source_wells = ["A1", "A2"]
        dest_wells = ["B1", "B2", "B3"]

        pairs = apply_product_semantics(
            source_wells, dest_wells,
            "p1", "p2"
        )

        assert len(pairs) == 6

    def test_product_too_large_error(self):
        """Product that's too large raises error."""
        source_wells = expand_wells("A1:H12")  # 96
        dest_wells = expand_wells("A1:H12")    # 96

        # 96 × 96 = 9216 > 1536 max
        with pytest.raises(CollectionSemanticsError, match="max 1536"):
            apply_product_semantics(source_wells, dest_wells, "p1", "p2")

    def test_product_moderate_ok(self):
        """Product within limits succeeds."""
        source_wells = expand_wells("A1:H1")   # 8
        dest_wells = expand_wells("A1:A12")    # 12

        # 8 × 12 = 96 (ok)
        pairs = apply_product_semantics(source_wells, dest_wells, "p1", "p2")
        assert len(pairs) == 96


class TestInferSemantics:
    """Test semantics inference."""

    def test_transfer_infers_zip(self):
        """Transfer infers ZIP semantics."""
        sem = infer_semantics("transfer", source_count=12, dest_count=12)
        assert sem == Semantics.ZIP

    def test_transfer_single_to_multiple_error(self):
        """Transfer 1→N suggests distribute."""
        with pytest.raises(CollectionSemanticsError, match="distribute"):
            infer_semantics("transfer", source_count=1, dest_count=12)

    def test_distribute_infers_broadcast(self):
        """Distribute infers BROADCAST."""
        sem = infer_semantics("distribute", source_count=1, dest_count=96)
        assert sem == Semantics.BROADCAST

    def test_consolidate_infers_broadcast(self):
        """Consolidate infers BROADCAST (all to one)."""
        sem = infer_semantics("consolidate", source_count=12, dest_count=1)
        assert sem == Semantics.BROADCAST


class TestValidateCollectionSemantics:
    """Test semantics validation."""

    def test_zip_valid(self):
        """ZIP with equal counts is valid."""
        is_valid, error = validate_collection_semantics(
            Semantics.ZIP, source_count=12, dest_count=12
        )
        assert is_valid is True
        assert error is None

    def test_zip_invalid_mismatch(self):
        """ZIP with unequal counts is invalid."""
        is_valid, error = validate_collection_semantics(
            Semantics.ZIP, source_count=12, dest_count=8
        )
        assert is_valid is False
        assert "equal counts" in error

    def test_broadcast_valid(self):
        """Broadcast is valid."""
        is_valid, error = validate_collection_semantics(
            Semantics.BROADCAST, source_count=1, dest_count=96
        )
        assert is_valid is True

    def test_product_warns_large(self):
        """Product warns for large sets."""
        is_valid, error = validate_collection_semantics(
            Semantics.PRODUCT, source_count=24, dest_count=24
        )
        # 576 operations - should warn
        assert is_valid is True
        assert "Warning" in error

    def test_product_invalid_too_large(self):
        """Product errors for too large sets."""
        is_valid, error = validate_collection_semantics(
            Semantics.PRODUCT, source_count=50, dest_count=50
        )
        # 2500 operations - error
        assert is_valid is False


class TestExpandCollectionOperation:
    """Test full collection operation expansion."""

    def test_transfer_column_to_column(self):
        """Transfer column 1 to column 2."""
        pairs = expand_collection_operation(
            intent_type="transfer",
            source_spec="Col1",
            source_plate="plate_src",
            dest_spec="Col2",
            dest_plate="plate_dst",
            semantics=None  # infer ZIP
        )

        assert len(pairs) == 8
        # First pair: A1 → A2
        assert pairs[0].source_well == "A1"
        assert pairs[0].dest_well == "A2"

    def test_distribute_to_row(self):
        """Distribute from reservoir to row."""
        pairs = expand_collection_operation(
            intent_type="distribute",
            source_spec="A1",
            source_plate="reservoir",
            dest_spec="RowA",
            dest_plate="plate_1",
            semantics=None  # infer BROADCAST
        )

        assert len(pairs) == 12
        assert all(p.source_well == "A1" for p in pairs)

    def test_explicit_semantics_override(self):
        """Explicit semantics overrides inference."""
        # Would normally error for transfer 1→N, but explicit broadcast allowed
        pairs = expand_collection_operation(
            intent_type="transfer",  # normally ZIP
            source_spec="A1",
            source_plate="p1",
            dest_spec="A1:A3",
            dest_plate="p2",
            semantics=Semantics.BROADCAST  # explicit override
        )

        assert len(pairs) == 3


class TestConvenienceFunctions:
    """Test convenience helper functions."""

    def test_zip_transfer(self):
        """Test zip_transfer helper."""
        pairs = zip_transfer(
            from_wells=["A1", "A2"],
            to_wells=["B1", "B2"],
            from_plate="p1",
            to_plate="p2"
        )

        assert len(pairs) == 2
        assert pairs[0].source_well == "A1"
        assert pairs[0].dest_well == "B1"

    def test_distribute_to_all(self):
        """Test distribute_to_all helper."""
        pairs = distribute_to_all(
            source_well="A1",
            dest_wells=["B1", "B2", "B3"],
            source_plate="reservoir",
            dest_plate="plate_1"
        )

        assert len(pairs) == 3
        assert all(p.source_well == "A1" for p in pairs)

    def test_pool_to_single(self):
        """Test pool_to_single helper."""
        pairs = pool_to_single(
            source_wells=["A1", "A2", "A3"],
            dest_well="B1",
            source_plate="plate_1",
            dest_plate="pool_tube"
        )

        assert len(pairs) == 3
        assert all(p.dest_well == "B1" for p in pairs)


class TestWellPair:
    """Test WellPair dataclass."""

    def test_well_pair_creation(self):
        """Create well pair."""
        pair = WellPair(
            source_plate="p1",
            source_well="A1",
            dest_plate="p2",
            dest_well="B1"
        )

        assert pair.source_plate == "p1"
        assert pair.source_well == "A1"
        assert pair.dest_plate == "p2"
        assert pair.dest_well == "B1"

    def test_well_pair_str(self):
        """String representation."""
        pair = WellPair("p1", "A1", "p2", "B1")
        assert str(pair) == "p1:A1 → p2:B1"

    def test_well_pair_equality(self):
        """Well pairs compare by value."""
        pair1 = WellPair("p1", "A1", "p2", "B1")
        pair2 = WellPair("p1", "A1", "p2", "B1")
        assert pair1 == pair2
