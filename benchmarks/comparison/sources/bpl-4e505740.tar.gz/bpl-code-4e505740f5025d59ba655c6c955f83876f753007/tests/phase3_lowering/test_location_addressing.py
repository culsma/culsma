"""Canonical location addressing and adapter tests."""

from bpl.export.worklist_exporter import WellRef as ExportWellRef
from bpl.location import (
    canonical_to_export_well_ref,
    canonical_to_plan_well_ref,
    export_well_ref_to_canonical,
    normalize_well_id,
    plan_well_ref_to_canonical,
    validate_well_in_plate_bounds,
    well_from_coordinates,
    well_to_coordinates,
)
from bpl.lowering import WellRef as PlanWellRef


def test_well_normalization_is_deterministic():
    assert normalize_well_id("a01") == "A1"
    assert normalize_well_id("AA0012") == "AA12"
    assert normalize_well_id("h12") == "H12"


def test_well_coordinate_mapping_is_zero_based():
    assert well_to_coordinates("A1") == (0, 0)
    assert well_to_coordinates("H12") == (7, 11)
    assert well_to_coordinates("AA1") == (26, 0)
    assert well_from_coordinates(0, 0) == "A1"
    assert well_from_coordinates(7, 11) == "H12"
    assert well_from_coordinates(26, 0) == "AA1"


def test_plate_bounds_validation_for_96_and_384():
    assert validate_well_in_plate_bounds("H12", plate_format="plate_96")
    assert not validate_well_in_plate_bounds("I1", plate_format="plate_96")
    assert validate_well_in_plate_bounds("P24", plate_format="plate_384")
    assert not validate_well_in_plate_bounds("Q1", plate_format="plate_384")


def test_bidirectional_adapters_for_legacy_well_refs():
    plan_ref = PlanWellRef(plate_id="plate_1", well_id="A01")
    canonical = plan_well_ref_to_canonical(plan_ref, plate_format="plate_96")
    assert canonical.labware_id == "plate_1"
    assert canonical.well == "A1"
    assert canonical.row == 0
    assert canonical.col == 0
    assert canonical.index == 0

    roundtrip_plan = canonical_to_plan_well_ref(canonical)
    assert roundtrip_plan == PlanWellRef(plate_id="plate_1", well_id="A1")

    export_ref = canonical_to_export_well_ref(canonical)
    assert export_ref == ExportWellRef(plate="plate_1", well="A1")

    roundtrip_canonical = export_well_ref_to_canonical(export_ref, plate_format="plate_96")
    assert roundtrip_canonical == canonical
