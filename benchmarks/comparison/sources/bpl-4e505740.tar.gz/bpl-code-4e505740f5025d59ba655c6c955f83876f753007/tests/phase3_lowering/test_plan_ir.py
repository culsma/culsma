"""
Tests for the BPL Plan IR.

Tests cover:
- Primitive types and creation
- PlanStep creation and dependencies
- ExecutionPlan DAG construction
- Topological ordering
"""

import pytest

from bpl.lowering import (
    # Primitives
    Aspirate, Dispense, Mix, PickTips, DropTips,
    HumanStep, Pause, Wait, Checkpoint,
    # References
    WellRef, ContainerRef, TipRackRef,
    # Plan structures
    PlanStep, ExecutionPlan,
    # Enums
    PrimitiveType, StepStatus, MixMethod,
)


class TestPrimitives:
    """Test primitive operation creation."""

    def test_aspirate(self):
        """Create aspirate primitive."""
        source = WellRef(plate_id="plate_1", well_id="A1")
        asp = Aspirate(source=source, volume_ul=100.0)

        assert asp.source == source
        assert asp.volume_ul == 100.0
        assert asp.primitive_type == PrimitiveType.ASPIRATE

    def test_dispense(self):
        """Create dispense primitive."""
        dest = WellRef(plate_id="plate_1", well_id="B1")
        disp = Dispense(destination=dest, volume_ul=100.0, blow_out=True)

        assert disp.destination == dest
        assert disp.volume_ul == 100.0
        assert disp.blow_out is True
        assert disp.primitive_type == PrimitiveType.DISPENSE

    def test_mix(self):
        """Create mix primitive."""
        loc = WellRef(plate_id="plate_1", well_id="A1")
        mix = Mix(location=loc, volume_ul=50.0, cycles=5)

        assert mix.location == loc
        assert mix.volume_ul == 50.0
        assert mix.cycles == 5
        assert mix.method == MixMethod.PIPETTE

    def test_pick_tips(self):
        """Create pick tips primitive."""
        rack = TipRackRef(rack_id="rack_1", tip_type="tips_200")
        pick = PickTips(tip_rack=rack, tip_positions=["A1", "A2"])

        assert pick.tip_rack == rack
        assert pick.tip_positions == ["A1", "A2"]
        assert pick.primitive_type == PrimitiveType.PICK_TIPS

    def test_drop_tips(self):
        """Create drop tips primitive."""
        drop = DropTips(to_waste=True)
        assert drop.to_waste is True
        assert drop.primitive_type == PrimitiveType.DROP_TIPS

    def test_human_step(self):
        """Create human step primitive."""
        step = HumanStep(
            instruction="Mix tube by vortex",
            expected_time_s=10.0,
            checklist=["Open tube", "Vortex 10s", "Close tube"]
        )

        assert step.instruction == "Mix tube by vortex"
        assert step.expected_time_s == 10.0
        assert len(step.checklist) == 3
        assert step.primitive_type == PrimitiveType.HUMAN_STEP

    def test_pause(self):
        """Create pause primitive."""
        pause = Pause(reason="Add reagent manually")
        assert pause.reason == "Add reagent manually"
        assert pause.requires_deck_confirmation is True

    def test_wait(self):
        """Create wait primitive."""
        wait = Wait(duration_s=300.0)
        assert wait.duration_s == 300.0

    def test_checkpoint(self):
        """Create checkpoint primitive."""
        cp = Checkpoint(checkpoint_id="cp_1")
        assert cp.checkpoint_id == "cp_1"

    def test_pick_colonies(self):
        """Create pick colonies primitive."""
        from bpl.lowering import PickColonies
        dest = WellRef(plate_id="dest_plate", well_id="A1")
        pick = PickColonies(
            source_plate="source_plate",
            well_id="A1",
            destination=dest,
            count=1,
            selection_criteria="largest"
        )
        assert pick.source_plate == "source_plate"
        assert pick.well_id == "A1"
        assert pick.destination == dest
        assert pick.count == 1
        assert pick.selection_criteria == "largest"
        assert pick.primitive_type == PrimitiveType.PICK_COLONIES

    def test_adjust_ph(self):
        """Create pH adjustment primitive."""
        from bpl.lowering import AdjustPH
        adjust = AdjustPH(
            container_id="beaker_1",
            target_ph=7.0,
            tolerance=0.1,
            acid_reagent="HCl_1M",
            base_reagent="NaOH_1M"
        )
        assert adjust.container_id == "beaker_1"
        assert adjust.target_ph == 7.0
        assert adjust.tolerance == 0.1
        assert adjust.acid_reagent == "HCl_1M"
        assert adjust.base_reagent == "NaOH_1M"
        assert adjust.primitive_type == PrimitiveType.ADJUST_PH

    def test_heat_shock(self):
        """Create heat shock primitive."""
        from bpl.lowering import HeatShock
        target = WellRef(plate_id="transform_plate", well_id="A1")
        hs = HeatShock(
            target=target,
            temperature_c=42.0,
            duration_s=60.0,
            device_id="water_bath"
        )
        assert hs.target == target
        assert hs.temperature_c == 42.0
        assert hs.duration_s == 60.0
        assert hs.device_id == "water_bath"
        assert hs.primitive_type == PrimitiveType.HEAT_SHOCK

    def test_on_ice(self):
        """Create on ice primitive."""
        from bpl.lowering import OnIce
        target = WellRef(plate_id="transform_plate", well_id="A1")
        ice = OnIce(target=target, duration_s=120.0)
        assert ice.target == target
        assert ice.duration_s == 120.0
        assert ice.primitive_type == PrimitiveType.ON_ICE

    def test_run_pcr(self):
        """Create run PCR primitive."""
        from bpl.lowering import RunPCR, PcrCycleStep
        pcr = RunPCR(
            plate_id="pcr_plate",
            device_id="thermocycler_1",
            initial_temp_c=98.0,
            initial_duration_s=30.0,
            cycle_count=35,
            cycle_steps=[
                PcrCycleStep(name="denature", temperature_c=98.0, duration_s=10.0),
                PcrCycleStep(name="anneal", temperature_c=60.0, duration_s=30.0),
                PcrCycleStep(name="extend", temperature_c=72.0, duration_s=20.0),
            ],
            final_temp_c=72.0,
            final_duration_s=120.0,
            hold_temp_c=4.0,
            lid_temp_c=105.0
        )
        assert pcr.plate_id == "pcr_plate"
        assert pcr.device_id == "thermocycler_1"
        assert pcr.initial_temp_c == 98.0
        assert pcr.cycle_count == 35
        assert len(pcr.cycle_steps) == 3
        assert pcr.cycle_steps[0].name == "denature"
        assert pcr.final_temp_c == 72.0
        assert pcr.hold_temp_c == 4.0
        assert pcr.lid_temp_c == 105.0
        assert pcr.primitive_type == PrimitiveType.RUN_PCR


class TestWellRef:
    """Test well reference."""

    def test_well_ref_creation(self):
        """Create well reference."""
        ref = WellRef(plate_id="plate_1", well_id="A1")
        assert ref.plate_id == "plate_1"
        assert ref.well_id == "A1"

    def test_well_ref_str(self):
        """String representation."""
        ref = WellRef(plate_id="plate_1", well_id="A1")
        assert str(ref) == "plate_1:A1"

    def test_well_ref_frozen(self):
        """Well ref is immutable."""
        ref = WellRef(plate_id="plate_1", well_id="A1")
        with pytest.raises(Exception):
            ref.well_id = "B1"


class TestContainerRef:
    """Test container reference."""

    def test_container_ref_creation(self):
        """Create container reference."""
        ref = ContainerRef(container_id="tube_1", container_type="eppendorf")
        assert ref.container_id == "tube_1"
        assert ref.container_type == "eppendorf"

    def test_container_ref_str(self):
        """String representation."""
        ref = ContainerRef(container_id="tube_1")
        assert str(ref) == "tube_1"


class TestPlanStep:
    """Test plan step creation and methods."""

    def test_create_step(self):
        """Create a plan step."""
        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(step_id="step_1", primitive=asp)

        assert step.step_id == "step_1"
        assert step.primitive == asp
        assert step.status == StepStatus.PENDING
        assert step.dependencies == []

    def test_step_with_dependencies(self):
        """Create step with dependencies."""
        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(
            step_id="step_2",
            primitive=asp,
            dependencies=["step_1"]
        )

        assert step.dependencies == ["step_1"]

    def test_step_is_ready_no_deps(self):
        """Step with no deps is ready."""
        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(step_id="step_1", primitive=asp)

        assert step.is_ready(set()) is True

    def test_step_is_ready_with_deps(self):
        """Step checks dependencies."""
        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(
            step_id="step_2",
            primitive=asp,
            dependencies=["step_1"]
        )

        # Not ready if dep not completed
        assert step.is_ready(set()) is False

        # Ready when dep completed
        assert step.is_ready({"step_1"}) is True

    def test_step_to_dict(self):
        """Convert step to dict."""
        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(step_id="step_1", primitive=asp, source_intent="transfer")

        d = step.to_dict()
        assert d["step_id"] == "step_1"
        assert d["primitive_type"] == "ASPIRATE"
        assert d["source_intent"] == "transfer"


class TestExecutionPlan:
    """Test execution plan DAG."""

    def test_create_plan(self):
        """Create empty plan."""
        plan = ExecutionPlan(plan_id="plan_1", protocol_name="test_protocol")

        assert plan.plan_id == "plan_1"
        assert plan.protocol_name == "test_protocol"
        assert plan.get_step_count() == 0

    def test_add_step(self):
        """Add step to plan."""
        plan = ExecutionPlan(plan_id="plan_1")

        asp = Aspirate(
            source=WellRef(plate_id="plate_1", well_id="A1"),
            volume_ul=100.0
        )
        step = PlanStep(step_id="step_1", primitive=asp)
        plan.add_step(step)

        assert plan.get_step_count() == 1
        assert "step_1" in plan.steps

    def test_add_step_rejects_duplicate_step_id(self):
        """Duplicate step identifiers are rejected deterministically."""
        plan = ExecutionPlan(plan_id="plan_1")
        step = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        plan.add_step(step)

        with pytest.raises(ValueError, match="Duplicate step_id 'step_1' in execution plan."):
            plan.add_step(PlanStep(step_id="step_1", primitive=Wait(duration_s=2.0)))

    def test_get_ready_steps(self):
        """Get steps ready to execute."""
        plan = ExecutionPlan(plan_id="plan_1")

        # Step 1: no deps
        step1 = PlanStep(
            step_id="step_1",
            primitive=PickTips(
                tip_rack=TipRackRef(rack_id="rack_1", tip_type="tips_200"),
                tip_positions=["A1"]
            )
        )

        # Step 2: depends on step 1
        step2 = PlanStep(
            step_id="step_2",
            primitive=Aspirate(
                source=WellRef(plate_id="plate_1", well_id="A1"),
                volume_ul=100.0
            ),
            dependencies=["step_1"]
        )

        plan.add_step(step1)
        plan.add_step(step2)

        # Initially only step 1 is ready
        ready = plan.get_ready_steps()
        assert len(ready) == 1
        assert ready[0].step_id == "step_1"

    def test_mark_completed(self):
        """Mark step as completed."""
        plan = ExecutionPlan(plan_id="plan_1")

        step = PlanStep(
            step_id="step_1",
            primitive=Wait(duration_s=10.0)
        )
        plan.add_step(step)

        plan.mark_completed("step_1", result={"actual_time": 10.5})

        assert plan.steps["step_1"].status == StepStatus.COMPLETED
        assert plan.steps["step_1"].result == {"actual_time": 10.5}
        assert "step_1" in plan.completed_steps

    def test_mark_failed(self):
        """Mark step as failed."""
        plan = ExecutionPlan(plan_id="plan_1")

        step = PlanStep(
            step_id="step_1",
            primitive=Aspirate(
                source=WellRef(plate_id="plate_1", well_id="A1"),
                volume_ul=100.0
            )
        )
        plan.add_step(step)

        plan.mark_failed("step_1", error="Tip clog detected")

        assert plan.steps["step_1"].status == StepStatus.FAILED
        assert plan.steps["step_1"].error == "Tip clog detected"

    def test_topological_order(self):
        """Get steps in topological order."""
        plan = ExecutionPlan(plan_id="plan_1")

        # Create linear dependency: 1 → 2 → 3
        step1 = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        step2 = PlanStep(step_id="step_2", primitive=Wait(duration_s=1.0), dependencies=["step_1"])
        step3 = PlanStep(step_id="step_3", primitive=Wait(duration_s=1.0), dependencies=["step_2"])

        plan.add_step(step3)  # Add out of order
        plan.add_step(step1)
        plan.add_step(step2)

        order = plan.topological_order()

        # step_1 must come before step_2, step_2 before step_3
        assert order.index("step_1") < order.index("step_2")
        assert order.index("step_2") < order.index("step_3")

    def test_is_complete(self):
        """Check if plan is complete."""
        plan = ExecutionPlan(plan_id="plan_1")

        step1 = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        step2 = PlanStep(step_id="step_2", primitive=Wait(duration_s=1.0))

        plan.add_step(step1)
        plan.add_step(step2)

        assert plan.is_complete is False

        plan.mark_completed("step_1")
        assert plan.is_complete is False

        plan.mark_completed("step_2")
        assert plan.is_complete is True

    def test_has_failures(self):
        """Check if plan has failures."""
        plan = ExecutionPlan(plan_id="plan_1")

        step = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        plan.add_step(step)

        assert plan.has_failures is False

        plan.mark_failed("step_1", error="timeout")
        assert plan.has_failures is True

    def test_compute_hash(self):
        """Compute plan hash."""
        plan = ExecutionPlan(plan_id="plan_1", protocol_name="test")

        step = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        plan.add_step(step)

        hash1 = plan.compute_hash()
        assert len(hash1) == 64  # SHA-256

        # Same plan = same hash
        hash2 = plan.compute_hash()
        assert hash1 == hash2

    def test_compute_hash_independent_of_insertion_order(self):
        """Equivalent DAGs hash the same regardless of step insertion order."""
        step_a = PlanStep(step_id="step_a", primitive=Wait(duration_s=1.0))
        step_b = PlanStep(step_id="step_b", primitive=Wait(duration_s=1.0))
        step_c = PlanStep(
            step_id="step_c",
            primitive=Wait(duration_s=1.0),
            dependencies=["step_a", "step_b"],
        )

        plan1 = ExecutionPlan(plan_id="plan_1", protocol_name="test")
        plan2 = ExecutionPlan(plan_id="plan_1", protocol_name="test")

        for step in [step_a, step_b, step_c]:
            plan1.add_step(step)
        for step in [step_c, step_b, step_a]:
            plan2.add_step(step)

        assert plan1.topological_order() == ["step_a", "step_b", "step_c"]
        assert plan2.topological_order() == ["step_a", "step_b", "step_c"]
        assert plan1.compute_hash() == plan2.compute_hash()

    def test_get_primitive_counts(self):
        """Get count of each primitive type."""
        plan = ExecutionPlan(plan_id="plan_1")

        plan.add_step(PlanStep(step_id="s1", primitive=Wait(duration_s=1.0)))
        plan.add_step(PlanStep(step_id="s2", primitive=Wait(duration_s=1.0)))
        plan.add_step(PlanStep(
            step_id="s3",
            primitive=Aspirate(source=WellRef("p1", "A1"), volume_ul=100.0)
        ))

        counts = plan.get_primitive_counts()
        assert counts["WAIT"] == 2
        assert counts["ASPIRATE"] == 1


class TestDAGConstruction:
    """Test complex DAG construction."""

    def test_diamond_dependency(self):
        """Test diamond-shaped dependency graph."""
        plan = ExecutionPlan(plan_id="plan_1")

        #     step_1
        #    /      \
        # step_2  step_3
        #    \      /
        #     step_4

        step1 = PlanStep(step_id="step_1", primitive=Wait(duration_s=1.0))
        step2 = PlanStep(step_id="step_2", primitive=Wait(duration_s=1.0), dependencies=["step_1"])
        step3 = PlanStep(step_id="step_3", primitive=Wait(duration_s=1.0), dependencies=["step_1"])
        step4 = PlanStep(step_id="step_4", primitive=Wait(duration_s=1.0), dependencies=["step_2", "step_3"])

        for step in [step1, step2, step3, step4]:
            plan.add_step(step)

        # Initially only step_1 is ready
        ready = plan.get_ready_steps()
        assert len(ready) == 1
        assert ready[0].step_id == "step_1"

        # After completing step_1, both step_2 and step_3 are ready
        plan.mark_completed("step_1")
        ready = plan.get_ready_steps()
        assert len(ready) == 2
        assert set(s.step_id for s in ready) == {"step_2", "step_3"}

        # After completing step_2, still waiting on step_3
        plan.mark_completed("step_2")
        ready = plan.get_ready_steps()
        assert len(ready) == 1
        assert ready[0].step_id == "step_3"

        # After completing step_3, step_4 is ready
        plan.mark_completed("step_3")
        ready = plan.get_ready_steps()
        assert len(ready) == 1
        assert ready[0].step_id == "step_4"

    def test_parallel_chains(self):
        """Test parallel chains that can execute concurrently."""
        plan = ExecutionPlan(plan_id="plan_1")

        # Chain A: a1 → a2
        # Chain B: b1 → b2
        # (independent)

        a1 = PlanStep(step_id="a1", primitive=Wait(duration_s=1.0))
        a2 = PlanStep(step_id="a2", primitive=Wait(duration_s=1.0), dependencies=["a1"])
        b1 = PlanStep(step_id="b1", primitive=Wait(duration_s=1.0))
        b2 = PlanStep(step_id="b2", primitive=Wait(duration_s=1.0), dependencies=["b1"])

        for step in [a1, a2, b1, b2]:
            plan.add_step(step)

        # Initially a1 and b1 are ready (parallel start)
        ready = plan.get_ready_steps()
        assert len(ready) == 2
        assert set(s.step_id for s in ready) == {"a1", "b1"}
