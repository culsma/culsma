"""Well-set addressing tests across plate formats."""

import pytest

from bpl.lowering import (
    PlateFormat,
    WellAddressingError,
    cherry_pick,
    row,
    well_range,
)


def test_well_range_normalizes_zero_padded_wells():
    selected = well_range("plate_1", "A01", "A03", plate_format=PlateFormat.PLATE_96)
    assert selected.wells == ["A1", "A2", "A3"]


def test_384_plate_bounds_are_validated_semantically():
    selected = cherry_pick("plate_384", ["A1", "P24"], plate_format=PlateFormat.PLATE_384)
    assert selected.wells == ["A1", "P24"]

    with pytest.raises(WellAddressingError, match="out of range"):
        cherry_pick("plate_384", ["Q1"], plate_format=PlateFormat.PLATE_384)


def test_multi_letter_row_addressing_supported_for_large_formats():
    selected = row("plate_1536", "AA", plate_format=PlateFormat.PLATE_1536)
    assert selected.first == "AA1"
    assert selected.last == "AA48"
