"""
Tests for BPL Intent Lowering.

Tests cover:
- add() lowering for solids and liquids
- transfer() lowering to primitives
- distribute() optimization
- consolidate() pooling
- mix() lowering
- manual() with hybrid execution
"""

import pytest

from bpl.lowering import (
    IntentLowerer,
    LoweringContext,
    ReagentInfo,
    PhysicalForm,
    WellRef,
    ContainerRef,
    TipRackRef,
    TipPolicy,
    MixMethod,
    PrimitiveType,
    Semantics,
    WellPair,
    collection_conflict_keys,
    ExecutionPlan,
)
from bpl.scheduler import create_scheduler
import bpl.lowering.intent_lowerer as intent_lowerer_module


@pytest.fixture
def basic_context():
    """Basic lowering context with tip rack."""
    return LoweringContext(
        target="robot",
        tip_policy=TipPolicy.SINGLE_USE,
        available_tip_racks=[
            TipRackRef(rack_id="tips_200", tip_type="tips_200")
        ]
    )


@pytest.fixture
def human_context():
    """Context for human execution."""
    return LoweringContext(target="human")


class TestAddLowering:
    """Test add() intent lowering."""

    def test_add_liquid_lowers_to_pipette(self, basic_context):
        """Add liquid lowers to aspirate/dispense."""
        lowerer = IntentLowerer(basic_context)

        dest = WellRef(plate_id="plate_1", well_id="A1")
        steps = lowerer.lower_add(
            source="water",
            destination=dest,
            volume_ul=100.0
        )

        # Should have: pick_tips, aspirate, dispense, drop_tips
        primitive_types = [s.primitive.primitive_type for s in steps]

        assert PrimitiveType.PICK_TIPS in primitive_types
        assert PrimitiveType.ASPIRATE in primitive_types
        assert PrimitiveType.DISPENSE in primitive_types
        assert PrimitiveType.DROP_TIPS in primitive_types

    def test_add_liquid_with_mix(self, basic_context):
        """Add with mix_after includes mix step."""
        lowerer = IntentLowerer(basic_context)

        dest = WellRef(plate_id="plate_1", well_id="A1")
        steps = lowerer.lower_add(
            source="water",
            destination=dest,
            volume_ul=100.0,
            mix_after=True
        )

        primitive_types = [s.primitive.primitive_type for s in steps]
        assert PrimitiveType.MIX in primitive_types

    def test_add_solid_lowers_to_weigh(self, basic_context):
        """Add solid lowers to weigh + human step."""
        # Register solid reagent
        basic_context.reagent_info["NaCl"] = ReagentInfo(
            reagent_id="NaCl",
            physical_form=PhysicalForm.SOLID,
            mw=58.44
        )

        lowerer = IntentLowerer(basic_context)

        dest = ContainerRef(container_id="beaker_1")
        steps = lowerer.lower_add(
            source="NaCl",
            destination=dest,
            mass_g=5.0
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # Should have pause (for human) + weigh + human step
        assert PrimitiveType.PAUSE in primitive_types
        assert PrimitiveType.WEIGH in primitive_types
        assert PrimitiveType.HUMAN_STEP in primitive_types

    def test_add_solid_requires_mass(self, basic_context):
        """Adding solid without mass raises error."""
        basic_context.reagent_info["NaCl"] = ReagentInfo(
            reagent_id="NaCl",
            physical_form=PhysicalForm.SOLID
        )

        lowerer = IntentLowerer(basic_context)
        dest = ContainerRef(container_id="beaker_1")

        with pytest.raises(ValueError, match="mass"):
            lowerer.lower_add(source="NaCl", destination=dest, volume_ul=100.0)

    def test_add_liquid_requires_volume(self, basic_context):
        """Adding liquid without volume raises error."""
        lowerer = IntentLowerer(basic_context)
        dest = WellRef(plate_id="plate_1", well_id="A1")

        with pytest.raises(ValueError, match="volume"):
            lowerer.lower_add(source="water", destination=dest, mass_g=5.0)


class TestTransferLowering:
    """Test transfer() intent lowering."""

    def test_transfer_lowers_to_primitives(self, basic_context):
        """Transfer lowers to pick/aspirate/dispense/drop."""
        lowerer = IntentLowerer(basic_context)

        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        assert PrimitiveType.PICK_TIPS in primitive_types
        assert PrimitiveType.ASPIRATE in primitive_types
        assert PrimitiveType.DISPENSE in primitive_types
        assert PrimitiveType.DROP_TIPS in primitive_types

    def test_transfer_with_mix_before(self, basic_context):
        """Transfer with mix_before includes mix step."""
        lowerer = IntentLowerer(basic_context)

        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0,
            mix_before=True
        )

        # Mix should appear before aspirate
        primitive_types = [s.primitive.primitive_type for s in steps]
        mix_idx = primitive_types.index(PrimitiveType.MIX)
        asp_idx = primitive_types.index(PrimitiveType.ASPIRATE)
        assert mix_idx < asp_idx

    def test_transfer_with_mix_after(self, basic_context):
        """Transfer with mix_after includes mix step after dispense."""
        lowerer = IntentLowerer(basic_context)

        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0,
            mix_after=True
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # Find positions
        disp_idx = primitive_types.index(PrimitiveType.DISPENSE)

        # Mix should appear after dispense (find the second MIX if mix_before)
        mix_positions = [i for i, pt in enumerate(primitive_types) if pt == PrimitiveType.MIX]
        assert any(idx > disp_idx for idx in mix_positions)

    def test_transfer_dependencies(self, basic_context):
        """Transfer steps have proper dependencies."""
        lowerer = IntentLowerer(basic_context)

        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0
        )

        # Find aspirate step
        aspirate_step = next(s for s in steps if s.primitive.primitive_type == PrimitiveType.ASPIRATE)

        # Find dispense step
        dispense_step = next(s for s in steps if s.primitive.primitive_type == PrimitiveType.DISPENSE)

        # Dispense should depend on aspirate
        assert aspirate_step.step_id in dispense_step.dependencies


class TestTransferCollectionLowering:
    """Test collection transfer lowering."""

    def test_collection_conflict_keys_include_source_destination_and_resources(self):
        """Conflict keys include source/destination identity and exclusive resources."""
        pair = WellPair(
            source_plate="plate_src",
            source_well="A01",
            dest_plate="plate_dst",
            dest_well="B02",
        )
        keys = collection_conflict_keys(
            pair,
            exclusive_resource_keys=["pipette_channel_1", "gripper"],
        )
        assert keys == (
            "source:plate_src:A1",
            "destination:plate_dst:B2",
            "resource:gripper",
            "resource:pipette_channel_1",
        )

    def test_transfer_column_zip(self, basic_context):
        """Transfer column with ZIP semantics."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_transfer_collection(
            from_plate="plate_src",
            from_wells="Col1",
            to_plate="plate_dst",
            to_wells="Col2",
            volume_ul=50.0
        )

        # 8 wells × (pick + aspirate + dispense + drop) steps
        # But with SINGLE_USE tips, we get independent transfers
        assert len(steps) > 0

        # Check we have multiple aspirate/dispense pairs
        aspirate_count = sum(1 for s in steps if s.primitive.primitive_type == PrimitiveType.ASPIRATE)
        dispense_count = sum(1 for s in steps if s.primitive.primitive_type == PrimitiveType.DISPENSE)

        assert aspirate_count == 8
        assert dispense_count == 8

    def test_transfer_collection_sorts_pairs_before_dependency_emission(
        self,
        basic_context,
        monkeypatch,
    ):
        """Collection transfer ordering is deterministic regardless of expansion order."""
        lowerer = IntentLowerer(basic_context)

        unsorted_pairs = [
            WellPair("plate_src", "B1", "plate_dst", "B1"),
            WellPair("plate_src", "A1", "plate_dst", "A1"),
        ]

        def _mock_expand_collection_operation(*args, **kwargs):  # noqa: ANN002, ANN003
            return unsorted_pairs

        monkeypatch.setattr(
            intent_lowerer_module,
            "expand_collection_operation",
            _mock_expand_collection_operation,
        )

        steps = lowerer.lower_transfer_collection(
            from_plate="plate_src",
            from_wells="ignored",
            to_plate="plate_dst",
            to_wells="ignored",
            volume_ul=10.0,
        )
        aspirates = [
            step
            for step in steps
            if step.primitive.primitive_type == PrimitiveType.ASPIRATE
        ]
        assert [step.primitive.source.well_id for step in aspirates] == ["A1", "B1"]

    def test_transfer_collection_emits_lower_bound_dependencies_for_conflicts(self, basic_context):
        """Second conflicting pair depends on first pair final step."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_transfer_collection(
            from_plate="plate_src",
            from_wells="A1",
            to_plate="plate_dst",
            to_wells="A1:A2",
            volume_ul=20.0,
            semantics=Semantics.BROADCAST,
        )

        assert len(steps) >= 8
        first_transfer_final_step = steps[3]
        second_transfer_first_step = steps[4]
        assert first_transfer_final_step.step_id in second_transfer_first_step.dependencies

    def test_scheduler_optimization_preserves_collection_safety_dependencies(self, basic_context):
        """Scheduler optimization keeps emitted safety dependencies intact."""
        lowerer = IntentLowerer(
            LoweringContext(
                target=basic_context.target,
                tip_policy=basic_context.tip_policy,
                available_tip_racks=basic_context.available_tip_racks,
                exclusive_resource_keys=["pipette_channel_1"],
            )
        )
        steps = lowerer.lower_transfer_collection(
            from_plate="plate_src",
            from_wells="A1",
            to_plate="plate_dst",
            to_wells="A1:A2",
            volume_ul=20.0,
            semantics=Semantics.BROADCAST,
        )

        plan = ExecutionPlan(plan_id="collection_safety")
        for step in steps:
            plan.add_step(step)

        assert steps[4].dependencies, "Expected safety dependencies before optimization."
        scheduler = create_scheduler("greedy")
        optimized_plan = scheduler.optimize_for_parallelism(plan)

        for step_id, original_step in plan.steps.items():
            optimized_dependencies = set(optimized_plan.steps[step_id].dependencies)
            assert set(original_step.dependencies).issubset(optimized_dependencies)


class TestDistributeLowering:
    """Test distribute() intent lowering."""

    def test_distribute_optimization(self, basic_context):
        """Distribute uses single aspirate, multiple dispenses."""
        lowerer = IntentLowerer(basic_context)

        source = ContainerRef(container_id="reservoir_1")
        destinations = [
            WellRef(plate_id="plate_1", well_id=f"A{i}")
            for i in range(1, 5)
        ]

        steps = lowerer.lower_distribute(
            source=source,
            destinations=destinations,
            volume_ul=100.0
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # Should have 1 pick, 1 aspirate, 4 dispenses, 1 drop
        assert primitive_types.count(PrimitiveType.ASPIRATE) == 1
        assert primitive_types.count(PrimitiveType.DISPENSE) == 4

    def test_distribute_total_volume(self, basic_context):
        """Distribute aspirates total volume needed."""
        lowerer = IntentLowerer(basic_context)

        source = ContainerRef(container_id="reservoir_1")
        destinations = [
            WellRef(plate_id="plate_1", well_id=f"A{i}")
            for i in range(1, 5)
        ]

        steps = lowerer.lower_distribute(
            source=source,
            destinations=destinations,
            volume_ul=100.0
        )

        # Find aspirate step
        aspirate_step = next(
            s for s in steps
            if s.primitive.primitive_type == PrimitiveType.ASPIRATE
        )

        # Total volume = 100 uL × 4 wells = 400 uL
        assert aspirate_step.primitive.volume_ul == 400.0


class TestConsolidateLowering:
    """Test consolidate() intent lowering."""

    def test_consolidate_pooling(self, basic_context):
        """Consolidate pools multiple sources to single dest."""
        lowerer = IntentLowerer(basic_context)

        sources = [
            WellRef(plate_id="plate_1", well_id=f"A{i}")
            for i in range(1, 5)
        ]
        destination = ContainerRef(container_id="pool_tube")

        steps = lowerer.lower_consolidate(
            sources=sources,
            destination=destination,
            volume_ul=50.0
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # 4 aspirates, 1 dispense
        assert primitive_types.count(PrimitiveType.ASPIRATE) == 4
        assert primitive_types.count(PrimitiveType.DISPENSE) == 1

    def test_consolidate_total_dispense(self, basic_context):
        """Consolidate dispenses total collected volume."""
        lowerer = IntentLowerer(basic_context)

        sources = [
            WellRef(plate_id="plate_1", well_id=f"A{i}")
            for i in range(1, 5)
        ]
        destination = ContainerRef(container_id="pool_tube")

        steps = lowerer.lower_consolidate(
            sources=sources,
            destination=destination,
            volume_ul=50.0
        )

        dispense_step = next(
            s for s in steps
            if s.primitive.primitive_type == PrimitiveType.DISPENSE
        )

        # Total = 50 uL × 4 sources = 200 uL
        assert dispense_step.primitive.volume_ul == 200.0


class TestMixLowering:
    """Test mix() intent lowering."""

    def test_mix_pipette_method(self, basic_context):
        """Mix with pipette method."""
        lowerer = IntentLowerer(basic_context)

        location = WellRef(plate_id="plate_1", well_id="A1")
        steps = lowerer.lower_mix(
            location=location,
            volume_ul=80.0,
            cycles=5,
            method=MixMethod.PIPETTE
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        assert PrimitiveType.MIX in primitive_types

        # Find mix step and check params
        mix_step = next(s for s in steps if s.primitive.primitive_type == PrimitiveType.MIX)
        assert mix_step.primitive.cycles == 5
        assert mix_step.primitive.volume_ul == 80.0

    def test_mix_method_selection(self, basic_context):
        """Non-pipette mix becomes human step."""
        lowerer = IntentLowerer(basic_context)

        location = ContainerRef(container_id="tube_1")
        steps = lowerer.lower_mix(
            location=location,
            volume_ul=100.0,
            method=MixMethod.VORTEX
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # Vortex is a human step
        assert PrimitiveType.HUMAN_STEP in primitive_types


class TestManualLowering:
    """Test manual() intent lowering."""

    def test_manual_human_target(self, human_context):
        """Manual step for human target."""
        lowerer = IntentLowerer(human_context)

        steps = lowerer.lower_manual(
            instruction="Vortex the tube for 10 seconds",
            expected_time_s=10.0,
            checklist=["Open tube", "Vortex", "Close tube"]
        )

        assert len(steps) == 1  # Just the human step
        assert steps[0].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert steps[0].primitive.instruction == "Vortex the tube for 10 seconds"
        assert len(steps[0].primitive.checklist) == 3

    def test_manual_robot_target(self, basic_context):
        """Manual step for robot target includes pause/resume."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_manual(
            instruction="Add reagent manually",
            safety_tags=["ChemHazard"]
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        # Should have: pause, human_step, resume
        assert PrimitiveType.PAUSE in primitive_types
        assert PrimitiveType.HUMAN_STEP in primitive_types
        assert PrimitiveType.RESUME in primitive_types


class TestIncubateLowering:
    """Test incubate() intent lowering."""

    def test_incubate_lowers_to_primitives(self, basic_context):
        """Incubate lowers to set_temp + incubate."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_incubate(
            device_id="incubator_1",
            temperature_c=37.0,
            duration_s=3600.0,
            shake_rpm=200.0
        )

        primitive_types = [s.primitive.primitive_type for s in steps]

        assert PrimitiveType.SET_TEMPERATURE in primitive_types
        assert PrimitiveType.INCUBATE in primitive_types

        # Check incubate params
        incubate_step = next(
            s for s in steps
            if s.primitive.primitive_type == PrimitiveType.INCUBATE
        )
        assert incubate_step.primitive.temperature_c == 37.0
        assert incubate_step.primitive.duration_s == 3600.0
        assert incubate_step.primitive.shake_rpm == 200.0


class TestCheckpointLowering:
    """Test checkpoint lowering."""

    def test_checkpoint(self, basic_context):
        """Checkpoint creates checkpoint primitive."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_checkpoint(checkpoint_id="cp_1")

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.CHECKPOINT
        assert steps[0].primitive.checkpoint_id == "cp_1"


class TestExecutionPlanBuilding:
    """Test building complete execution plans."""

    def test_add_steps_to_plan(self, basic_context):
        """Steps are added to plan correctly."""
        lowerer = IntentLowerer(basic_context)

        # Lower a simple transfer
        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0
        )

        lowerer.add_steps_to_plan(steps)

        plan = lowerer.get_plan()
        assert plan.get_step_count() == len(steps)

    def test_plan_target(self, basic_context):
        """Plan inherits target from context."""
        lowerer = IntentLowerer(basic_context)
        plan = lowerer.get_plan()

        assert plan.target == "robot"

    def test_source_intent_tracking(self, basic_context):
        """Steps track their source intent."""
        lowerer = IntentLowerer(basic_context)

        source = WellRef(plate_id="plate_1", well_id="A1")
        dest = WellRef(plate_id="plate_2", well_id="A1")

        steps = lowerer.lower_transfer(
            from_location=source,
            to_location=dest,
            volume_ul=50.0
        )

        for step in steps:
            assert step.source_intent == "transfer"


class TestRunPCRLowering:
    """Test run_pcr() intent lowering."""

    def test_run_pcr_human_target(self, human_context):
        """Run PCR for human target produces HumanStep."""
        lowerer = IntentLowerer(human_context)

        steps = lowerer.lower_run_pcr(
            plate_id="pcr_plate",
            initial_temp_c=98.0,
            initial_duration_s=30.0,
            cycle_count=35,
            cycle_steps=[
                {"name": "denature", "temp": 98.0, "duration": 10.0},
                {"name": "anneal", "temp": 60.0, "duration": 30.0},
                {"name": "extend", "temp": 72.0, "duration": 20.0},
            ],
            final_temp_c=72.0,
            final_duration_s=120.0,
            hold_temp_c=4.0
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert "PCR" in steps[0].primitive.instruction
        assert steps[0].source_intent == "run_pcr"

    def test_run_pcr_robot_target(self, basic_context):
        """Run PCR for robot target produces RunPCR primitive."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_run_pcr(
            plate_id="pcr_plate",
            device_id="thermocycler_1",
            initial_temp_c=98.0,
            initial_duration_s=30.0,
            cycle_count=30,
            cycle_steps=[
                {"name": "denature", "temp": 98.0, "duration": 10.0},
                {"name": "anneal", "temp": 55.0, "duration": 30.0},
                {"name": "extend", "temp": 72.0, "duration": 30.0},
            ],
            final_temp_c=72.0,
            final_duration_s=120.0
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.RUN_PCR
        assert steps[0].primitive.plate_id == "pcr_plate"
        assert steps[0].primitive.cycle_count == 30
        assert len(steps[0].primitive.cycle_steps) == 3

    def test_run_pcr_cycle_steps(self, basic_context):
        """PCR cycle steps are correctly converted."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_run_pcr(
            plate_id="pcr_plate",
            cycle_count=25,
            cycle_steps=[
                {"name": "denature", "temp": 95.0, "duration": 15.0},
                {"name": "anneal_extend", "temp": 68.0, "duration": 60.0},
            ]
        )

        pcr = steps[0].primitive
        assert pcr.cycle_steps[0].name == "denature"
        assert pcr.cycle_steps[0].temperature_c == 95.0
        assert pcr.cycle_steps[0].duration_s == 15.0
        assert pcr.cycle_steps[1].name == "anneal_extend"


class TestPickColoniesLowering:
    """Test pick_colonies() intent lowering."""

    def test_pick_colonies_human_target(self, human_context):
        """Pick colonies for human target produces HumanStep."""
        lowerer = IntentLowerer(human_context)

        dest = WellRef(plate_id="dest_plate", well_id="A1")
        steps = lowerer.lower_pick_colonies(
            source_plate="agar_plate",
            well_id="A1",
            destination=dest,
            count=1,
            selection_criteria="largest"
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert "Pick" in steps[0].primitive.instruction
        assert "largest" in steps[0].primitive.instruction

    def test_pick_colonies_robot_target(self, basic_context):
        """Pick colonies for robot target produces PickColonies primitive."""
        lowerer = IntentLowerer(basic_context)

        dest = WellRef(plate_id="dest_plate", well_id="A1")
        steps = lowerer.lower_pick_colonies(
            source_plate="agar_plate",
            well_id="A1",
            destination=dest,
            count=3,
            selection_criteria="random"
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.PICK_COLONIES
        assert steps[0].primitive.source_plate == "agar_plate"
        assert steps[0].primitive.count == 3
        assert steps[0].primitive.selection_criteria == "random"

    def test_pick_colonies_hybrid_target(self):
        """Pick colonies for hybrid target includes pause."""
        context = LoweringContext(target="hybrid")
        lowerer = IntentLowerer(context)

        dest = WellRef(plate_id="dest_plate", well_id="A1")
        steps = lowerer.lower_pick_colonies(
            source_plate="agar_plate",
            well_id="A1",
            destination=dest
        )

        assert len(steps) == 2
        assert steps[0].primitive.primitive_type == PrimitiveType.PAUSE
        assert steps[1].primitive.primitive_type == PrimitiveType.PICK_COLONIES


class TestAdjustPHLowering:
    """Test adjust_ph() intent lowering."""

    def test_adjust_ph_human_target(self, human_context):
        """Adjust pH for human target produces steps."""
        lowerer = IntentLowerer(human_context)

        steps = lowerer.lower_adjust_ph(
            container_id="beaker_1",
            target_ph=7.0,
            tolerance=0.1,
            acid_reagent="HCl_1M",
            base_reagent="NaOH_1M"
        )

        # Should have AdjustPH + HumanStep
        assert len(steps) == 2
        assert steps[0].primitive.primitive_type == PrimitiveType.ADJUST_PH
        assert steps[0].primitive.target_ph == 7.0
        assert steps[1].primitive.primitive_type == PrimitiveType.HUMAN_STEP

    def test_adjust_ph_robot_target(self, basic_context):
        """Adjust pH for robot target includes pause/resume."""
        lowerer = IntentLowerer(basic_context)

        steps = lowerer.lower_adjust_ph(
            container_id="beaker_1",
            target_ph=7.5,
            tolerance=0.05
        )

        # Should have Pause + AdjustPH + HumanStep + Resume
        assert len(steps) == 4
        assert steps[0].primitive.primitive_type == PrimitiveType.PAUSE
        assert steps[1].primitive.primitive_type == PrimitiveType.ADJUST_PH
        assert steps[2].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert steps[3].primitive.primitive_type == PrimitiveType.RESUME

    def test_adjust_ph_checklist_includes_reagents(self, human_context):
        """Checklist includes acid and base reagents."""
        lowerer = IntentLowerer(human_context)

        steps = lowerer.lower_adjust_ph(
            container_id="flask_1",
            target_ph=6.5,
            acid_reagent="HCl_6N",
            base_reagent="NaOH_5M"
        )

        human_step = steps[1]  # HumanStep
        checklist = human_step.primitive.checklist
        assert any("HCl_6N" in item for item in checklist)
        assert any("NaOH_5M" in item for item in checklist)


class TestHeatShockLowering:
    """Test heat_shock() intent lowering."""

    def test_heat_shock_human_target(self, human_context):
        """Heat shock for human target produces HumanStep."""
        lowerer = IntentLowerer(human_context)

        target = WellRef(plate_id="transform_plate", well_id="A1")
        steps = lowerer.lower_heat_shock(
            target=target,
            temperature_c=42.0,
            duration_s=60.0
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert "42" in steps[0].primitive.instruction
        assert "60" in steps[0].primitive.instruction

    def test_heat_shock_robot_target(self, basic_context):
        """Heat shock for robot target produces HeatShock primitive."""
        lowerer = IntentLowerer(basic_context)

        target = WellRef(plate_id="transform_plate", well_id="A1")
        steps = lowerer.lower_heat_shock(
            target=target,
            temperature_c=42.0,
            duration_s=45.0,
            device_id="heat_block"
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.HEAT_SHOCK
        assert steps[0].primitive.temperature_c == 42.0
        assert steps[0].primitive.duration_s == 45.0
        assert steps[0].primitive.device_id == "heat_block"


class TestOnIceLowering:
    """Test on_ice() intent lowering."""

    def test_on_ice_human_target(self, human_context):
        """On ice for human target produces HumanStep."""
        lowerer = IntentLowerer(human_context)

        target = WellRef(plate_id="transform_plate", well_id="A1")
        steps = lowerer.lower_on_ice(
            target=target,
            duration_s=120.0
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.HUMAN_STEP
        assert "ice" in steps[0].primitive.instruction.lower()

    def test_on_ice_robot_target(self, basic_context):
        """On ice for robot target produces OnIce primitive."""
        lowerer = IntentLowerer(basic_context)

        target = WellRef(plate_id="transform_plate", well_id="A1")
        steps = lowerer.lower_on_ice(
            target=target,
            duration_s=300.0
        )

        assert len(steps) == 1
        assert steps[0].primitive.primitive_type == PrimitiveType.ON_ICE
        assert steps[0].primitive.duration_s == 300.0


class TestTransformationWorkflow:
    """Test complete transformation workflow using new intents."""

    def test_heat_shock_transformation_human(self, human_context):
        """Complete heat shock transformation workflow for human."""
        lowerer = IntentLowerer(human_context)

        target = WellRef(plate_id="tubes", well_id="A1")

        # Pre-incubation on ice
        ice_steps = lowerer.lower_on_ice(target=target, duration_s=1800)  # 30 min

        # Heat shock
        heat_steps = lowerer.lower_heat_shock(
            target=target,
            temperature_c=42.0,
            duration_s=60.0
        )

        # Recovery on ice
        recovery_steps = lowerer.lower_on_ice(target=target, duration_s=120)

        total_steps = ice_steps + heat_steps + recovery_steps
        assert len(total_steps) == 3
        assert all(s.primitive.primitive_type == PrimitiveType.HUMAN_STEP for s in total_steps)

    def test_heat_shock_transformation_robot(self, basic_context):
        """Complete heat shock transformation workflow for robot."""
        lowerer = IntentLowerer(basic_context)

        target = WellRef(plate_id="tubes", well_id="A1")

        ice_steps = lowerer.lower_on_ice(target=target, duration_s=1800)
        heat_steps = lowerer.lower_heat_shock(target=target, temperature_c=42.0, duration_s=60.0)
        recovery_steps = lowerer.lower_on_ice(target=target, duration_s=120)

        total_steps = ice_steps + heat_steps + recovery_steps
        assert len(total_steps) == 3
        assert total_steps[0].primitive.primitive_type == PrimitiveType.ON_ICE
        assert total_steps[1].primitive.primitive_type == PrimitiveType.HEAT_SHOCK
        assert total_steps[2].primitive.primitive_type == PrimitiveType.ON_ICE
