"""Workflow graph builder tests."""

import hashlib
import json
import re

import pytest

from bpl.graph import GraphIntegrityError, build_workflow_graph, render_workflow_graph
from bpl.lowering import ExecutionPlan, HumanStep, PlanStep


def _hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _extract_reactflow_payload(html_output: str) -> dict[str, object]:
    match = re.search(r"window.__BPL_GRAPH_PAYLOAD__ = (\{[\s\S]*?\});", html_output)
    assert match is not None
    return json.loads(match.group(1))


def test_builder_preserves_step_identity_and_dependencies():
    plan = ExecutionPlan(plan_id="plan_a", protocol_name="ProtocolA", target="human")
    plan.add_step(
        PlanStep(
            step_id="s1",
            primitive=HumanStep(instruction="transfer"),
            source_intent="transfer",
        )
    )
    plan.add_step(
        PlanStep(
            step_id="s2",
            primitive=HumanStep(instruction="mix"),
            dependencies=["s1"],
            source_intent="mix",
        )
    )

    graph = build_workflow_graph(plan)

    assert [node.node_id for node in graph.nodes] == ["s1", "s2"]
    assert [edge.to_dict() for edge in graph.edges] == [{"from": "s1", "to": "s2"}]
    assert graph.nodes[0].metadata["diagnostic_step_id"] == "s1"
    assert graph.nodes[1].primitive_type == "HUMAN_STEP"


def test_builder_rejects_cycles():
    plan = ExecutionPlan(plan_id="plan_cycle")
    plan.add_step(
        PlanStep(
            step_id="a",
            primitive=HumanStep(instruction="a"),
            dependencies=["b"],
        )
    )
    plan.add_step(
        PlanStep(
            step_id="b",
            primitive=HumanStep(instruction="b"),
            dependencies=["a"],
        )
    )

    with pytest.raises(GraphIntegrityError) as exc:
        build_workflow_graph(plan)
    assert exc.value.code == "GRAPH_CYCLE"


def test_builder_rejects_missing_dependency_reference():
    plan = ExecutionPlan(plan_id="plan_missing_dep")
    plan.add_step(
        PlanStep(
            step_id="s1",
            primitive=HumanStep(instruction="step"),
            dependencies=["missing"],
        )
    )

    with pytest.raises(GraphIntegrityError) as exc:
        build_workflow_graph(plan)
    assert exc.value.code == "GRAPH_MISSING_DEPENDENCY"


def test_renderer_output_hash_is_stable():
    plan = ExecutionPlan(plan_id="plan_hash", protocol_name="HashProtocol")
    plan.add_step(PlanStep(step_id="step_1", primitive=HumanStep(instruction="one")))
    plan.add_step(
        PlanStep(
            step_id="step_2",
            primitive=HumanStep(instruction="two"),
            dependencies=["step_1"],
        )
    )

    graph = build_workflow_graph(plan)
    json_output_1 = render_workflow_graph(graph, "json")
    json_output_2 = render_workflow_graph(graph, "json")
    mermaid_output_1 = render_workflow_graph(graph, "mermaid")
    mermaid_output_2 = render_workflow_graph(graph, "mermaid")

    assert _hash_text(json_output_1) == _hash_text(json_output_2)
    assert _hash_text(mermaid_output_1) == _hash_text(mermaid_output_2)


def test_reactflow_renderer_surfaces_step_annotations():
    plan = ExecutionPlan(plan_id="plan_annotations")
    plan.add_step(
        PlanStep(
            step_id="step_1",
            primitive=HumanStep(instruction="annotated"),
            source_intent="transfer",
            annotations={
                "source_comment": "Load template DNA into PCR plate\nMix gently before transfer",
                "source_call": "transfer(from: source_A1, to: pcr_A1, volume: 10 uL)",
            },
        )
    )

    graph = build_workflow_graph(plan)
    html_output = render_workflow_graph(graph, "reactflow-html")
    payload = _extract_reactflow_payload(html_output)
    rendered_nodes = payload.get("nodes")
    assert isinstance(rendered_nodes, list)
    first_node_data = rendered_nodes[0].get("data", {}) if rendered_nodes else {}
    assert isinstance(first_node_data, dict)
    label = first_node_data.get("label", "")
    assert isinstance(label, str)

    assert "<!doctype html>" in html_output.lower()
    assert "call: transfer(from: source_A1, to: pcr_A1, volume: 10 uL)" in label
    assert "// Load template DNA into PCR plate" in html_output
    assert "src: transfer(from: source_A1, to: pcr_A1, volume: 10 uL)" in html_output


def test_mermaid_renderer_surfaces_step_annotations():
    plan = ExecutionPlan(plan_id="plan_annotations_mermaid")
    plan.add_step(
        PlanStep(
            step_id="step_1",
            primitive=HumanStep(instruction="annotated"),
            source_intent="transfer",
            annotations={
                "source_comment": "Prime tips and inspect reservoirs",
                "source_call": "transfer(from: source_A1, to: pcr_A1, volume: 10 uL)",
            },
        )
    )

    graph = build_workflow_graph(plan)
    mermaid_output = render_workflow_graph(graph, "mermaid")

    assert "intent: transfer" in mermaid_output
    assert "// Prime tips and inspect reservoirs" in mermaid_output
    assert "src: transfer(from: source_A1, to: pcr_A1, volume: 10 uL)" in mermaid_output


def test_reactflow_renderer_uses_timeline_layout_for_large_chain():
    plan = ExecutionPlan(plan_id="plan_chain_layout")
    previous_step: str | None = None

    for index in range(1, 31):
        step_id = f"step_{index:04d}"
        dependencies = [previous_step] if previous_step else []
        plan.add_step(
            PlanStep(
                step_id=step_id,
                primitive=HumanStep(instruction=f"step {index}"),
                dependencies=dependencies,
                source_intent="wait",
                annotations={"source_comment": f"chain step {index}"},
            )
        )
        previous_step = step_id

    graph = build_workflow_graph(plan)
    html_output = render_workflow_graph(graph, "reactflow-html")
    payload = _extract_reactflow_payload(html_output)
    rendered_nodes = payload.get("nodes")
    assert isinstance(rendered_nodes, list)

    x_values = {
        node.get("position", {}).get("x")
        for node in rendered_nodes
        if isinstance(node, dict)
    }
    assert x_values == {0}

    y_values = [
        node.get("position", {}).get("y")
        for node in rendered_nodes
        if isinstance(node, dict)
    ]
    assert y_values == sorted(y_values)
