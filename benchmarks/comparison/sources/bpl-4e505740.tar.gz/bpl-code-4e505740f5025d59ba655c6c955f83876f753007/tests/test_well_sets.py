"""
Tests for BPL Well Sets - Library functions for well addressing.
"""

import pytest
from bpl.lowering.well_sets import (
    PlateFormat,
    WellSet,
    WellAddressingError,
    well_range,
    cherry_pick,
    column,
    row,
    quadrant,
    wells,
    all_wells,
    every_nth_well,
    stamp_pattern,
    serial_dilution_wells,
)


class TestPlateFormat:
    """Test PlateFormat enum."""

    def test_plate_96_dimensions(self):
        assert PlateFormat.PLATE_96.rows == 8
        assert PlateFormat.PLATE_96.cols == 12
        assert PlateFormat.PLATE_96.well_count == 96

    def test_plate_384_dimensions(self):
        assert PlateFormat.PLATE_384.rows == 16
        assert PlateFormat.PLATE_384.cols == 24
        assert PlateFormat.PLATE_384.well_count == 384

    def test_plate_24_dimensions(self):
        assert PlateFormat.PLATE_24.rows == 4
        assert PlateFormat.PLATE_24.cols == 6
        assert PlateFormat.PLATE_24.well_count == 24


class TestWellSet:
    """Test WellSet dataclass."""

    def test_create_wellset(self):
        ws = WellSet("Plate1", ["A1", "A2", "A3"])
        assert ws.plate_id == "Plate1"
        assert len(ws) == 3
        assert list(ws) == ["A1", "A2", "A3"]

    def test_wellset_contains(self):
        ws = WellSet("Plate1", ["A1", "B2", "C3"])
        assert "A1" in ws
        assert "a1" in ws  # Case insensitive
        assert "D4" not in ws

    def test_wellset_union(self):
        ws1 = WellSet("Plate1", ["A1", "A2"])
        ws2 = WellSet("Plate1", ["A2", "A3"])
        combined = ws1 + ws2
        assert list(combined) == ["A1", "A2", "A3"]  # A2 not duplicated

    def test_wellset_difference(self):
        ws1 = WellSet("Plate1", ["A1", "A2", "A3"])
        ws2 = WellSet("Plate1", ["A2"])
        diff = ws1 - ws2
        assert list(diff) == ["A1", "A3"]

    def test_wellset_intersection(self):
        ws1 = WellSet("Plate1", ["A1", "A2", "A3"])
        ws2 = WellSet("Plate1", ["A2", "A3", "A4"])
        inter = ws1 & ws2
        assert list(inter) == ["A2", "A3"]

    def test_wellset_different_plates_error(self):
        ws1 = WellSet("Plate1", ["A1"])
        ws2 = WellSet("Plate2", ["A1"])
        with pytest.raises(ValueError, match="different plates"):
            _ = ws1 + ws2

    def test_wellset_first_last(self):
        ws = WellSet("Plate1", ["A1", "B2", "H12"])
        assert ws.first == "A1"
        assert ws.last == "H12"

    def test_wellset_as_tuples(self):
        ws = WellSet("Plate1", ["A1", "B2"])
        tuples = ws.as_tuples()
        assert tuples == [("Plate1", "A1"), ("Plate1", "B2")]


class TestWellRange:
    """Test well_range function."""

    def test_single_row(self):
        ws = well_range("Plate1", "A1", "A12")
        assert len(ws) == 12
        assert ws.first == "A1"
        assert ws.last == "A12"

    def test_single_column(self):
        ws = well_range("Plate1", "A1", "H1")
        assert len(ws) == 8
        assert list(ws) == ["A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1"]

    def test_rectangular_block(self):
        ws = well_range("Plate1", "A1", "D6")
        assert len(ws) == 4 * 6  # 4 rows x 6 cols = 24
        assert ws.first == "A1"
        assert ws.last == "D6"

    def test_full_plate(self):
        ws = well_range("Plate1", "A1", "H12")
        assert len(ws) == 96

    def test_invalid_range_row(self):
        with pytest.raises(WellAddressingError):
            well_range("Plate1", "H1", "A1")  # End row before start

    def test_invalid_range_col(self):
        with pytest.raises(WellAddressingError):
            well_range("Plate1", "A12", "A1")  # End col before start

    def test_384_well_range(self):
        ws = well_range("Plate384", "A1", "P24", PlateFormat.PLATE_384)
        assert len(ws) == 384


class TestCherryPick:
    """Test cherry_pick function."""

    def test_simple_cherry_pick(self):
        ws = cherry_pick("Plate1", ["A1", "B3", "D5", "H12"])
        assert len(ws) == 4
        assert "A1" in ws
        assert "B3" in ws
        assert "D5" in ws
        assert "H12" in ws

    def test_cherry_pick_preserves_order(self):
        ws = cherry_pick("Plate1", ["H12", "A1", "D6"])
        assert list(ws) == ["H12", "A1", "D6"]

    def test_cherry_pick_case_insensitive(self):
        ws = cherry_pick("Plate1", ["a1", "b2", "C3"])
        assert list(ws) == ["A1", "B2", "C3"]

    def test_cherry_pick_invalid_well(self):
        with pytest.raises(WellAddressingError):
            cherry_pick("Plate1", ["A1", "Z99"])

    def test_cherry_pick_out_of_range(self):
        with pytest.raises(WellAddressingError):
            cherry_pick("Plate1", ["A1", "A13"])  # Column 13 doesn't exist in 96-well


class TestColumn:
    """Test column function."""

    def test_column_1(self):
        ws = column("Plate1", 1)
        assert len(ws) == 8
        assert list(ws) == ["A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1"]

    def test_column_12(self):
        ws = column("Plate1", 12)
        assert len(ws) == 8
        assert ws.first == "A12"
        assert ws.last == "H12"

    def test_column_out_of_range(self):
        with pytest.raises(WellAddressingError):
            column("Plate1", 13)

    def test_column_zero(self):
        with pytest.raises(WellAddressingError):
            column("Plate1", 0)

    def test_column_384_plate(self):
        ws = column("Plate384", 1, PlateFormat.PLATE_384)
        assert len(ws) == 16  # 16 rows in 384-well plate


class TestRow:
    """Test row function."""

    def test_row_a_letter(self):
        ws = row("Plate1", "A")
        assert len(ws) == 12
        assert ws.first == "A1"
        assert ws.last == "A12"

    def test_row_h_letter(self):
        ws = row("Plate1", "H")
        assert len(ws) == 12
        assert list(ws)[0] == "H1"

    def test_row_1_number(self):
        ws = row("Plate1", 1)
        assert len(ws) == 12
        assert ws.first == "A1"  # Row 1 = Row A

    def test_row_case_insensitive(self):
        ws = row("Plate1", "a")
        assert ws.first == "A1"

    def test_row_out_of_range(self):
        with pytest.raises(WellAddressingError):
            row("Plate1", "I")  # Row I doesn't exist in 96-well

    def test_row_384_plate(self):
        ws = row("Plate384", "P", PlateFormat.PLATE_384)
        assert len(ws) == 24  # 24 columns in 384-well plate


class TestQuadrant:
    """Test quadrant function for 384->96 stamping."""

    def test_quadrant_1(self):
        ws = quadrant("Plate384", 1)
        assert len(ws) == 96
        # Quadrant 1 starts at A1, includes A1, A3, A5, ...
        assert "A1" in ws
        assert "A3" in ws
        assert "A2" not in ws  # A2 is in quadrant 2

    def test_quadrant_2(self):
        ws = quadrant("Plate384", 2)
        assert len(ws) == 96
        assert "A2" in ws
        assert "A4" in ws
        assert "A1" not in ws

    def test_quadrant_3(self):
        ws = quadrant("Plate384", 3)
        assert len(ws) == 96
        assert "B1" in ws
        assert "B3" in ws
        assert "A1" not in ws

    def test_quadrant_4(self):
        ws = quadrant("Plate384", 4)
        assert len(ws) == 96
        assert "B2" in ws
        assert "B4" in ws
        assert "A1" not in ws

    def test_quadrant_invalid(self):
        with pytest.raises(WellAddressingError):
            quadrant("Plate384", 0)
        with pytest.raises(WellAddressingError):
            quadrant("Plate384", 5)


class TestWells:
    """Test general-purpose wells function."""

    def test_single_well(self):
        ws = wells("Plate1", "A1")
        assert len(ws) == 1
        assert "A1" in ws

    def test_range_spec(self):
        ws = wells("Plate1", "A1:A12")
        assert len(ws) == 12

    def test_column_spec(self):
        ws = wells("Plate1", "Column1")
        assert len(ws) == 8

    def test_col_shorthand(self):
        ws = wells("Plate1", "Col6")
        assert len(ws) == 8
        assert ws.first == "A6"

    def test_row_spec_letter(self):
        ws = wells("Plate1", "RowA")
        assert len(ws) == 12
        assert ws.first == "A1"

    def test_row_spec_number(self):
        ws = wells("Plate1", "Row3")
        assert len(ws) == 12
        assert ws.first == "C1"  # Row 3 = Row C

    def test_all_wells(self):
        ws = wells("Plate1", "All")
        assert len(ws) == 96

    def test_comma_separated(self):
        ws = wells("Plate1", "A1, B2, C3")
        assert len(ws) == 3
        assert list(ws) == ["A1", "B2", "C3"]

    def test_invalid_spec(self):
        with pytest.raises(WellAddressingError):
            wells("Plate1", "invalid")


class TestAllWells:
    """Test all_wells function."""

    def test_all_wells_96(self):
        ws = all_wells("Plate1")
        assert len(ws) == 96
        assert ws.first == "A1"
        assert ws.last == "H12"

    def test_all_wells_384(self):
        ws = all_wells("Plate384", PlateFormat.PLATE_384)
        assert len(ws) == 384


class TestEveryNthWell:
    """Test every_nth_well function."""

    def test_every_2nd_well(self):
        ws = every_nth_well("Plate1", 2)
        assert len(ws) == 48  # Half of 96
        assert "A1" in ws
        assert "A3" in ws
        assert "A2" not in ws

    def test_every_8th_well(self):
        ws = every_nth_well("Plate1", 8)
        assert len(ws) == 12

    def test_every_12th_well(self):
        ws = every_nth_well("Plate1", 12)
        assert len(ws) == 8
        # Every 12th well from A1 gives A1, B1, C1, ... (first well of each row)
        assert "A1" in ws
        assert "B1" in ws


class TestStampPattern:
    """Test stamp_pattern function."""

    def test_full_plate_stamp(self):
        pairs = stamp_pattern("Source", "Dest")
        assert len(pairs) == 1
        source_ws, dest_ws = pairs[0]
        assert len(source_ws) == 96
        assert len(dest_ws) == 96
        assert source_ws.plate_id == "Source"
        assert dest_ws.plate_id == "Dest"

    def test_partial_stamp(self):
        pairs = stamp_pattern("Source", "Dest", "A1", "A1", rows=4, cols=6)
        source_ws, dest_ws = pairs[0]
        assert len(source_ws) == 24  # 4x6
        assert len(dest_ws) == 24


class TestSerialDilutionWells:
    """Test serial_dilution_wells function."""

    def test_single_row_dilution(self):
        pairs = serial_dilution_wells("Plate1", start_col=1, end_col=12, rows="A")
        assert len(pairs) == 11  # 11 transfer steps for 12 columns

        # First pair: A1 -> A2
        src, dst = pairs[0]
        assert "A1" in src
        assert "A2" in dst

        # Last pair: A11 -> A12
        src, dst = pairs[-1]
        assert "A11" in src
        assert "A12" in dst

    def test_multi_row_dilution(self):
        pairs = serial_dilution_wells("Plate1", start_col=1, end_col=6, rows=["A", "B", "C"])
        assert len(pairs) == 5  # 5 transfer steps

        src, dst = pairs[0]
        assert len(src) == 3  # 3 rows
        assert "A1" in src
        assert "B1" in src
        assert "C1" in src


class TestIntegration:
    """Integration tests combining multiple functions."""

    def test_combine_columns(self):
        """Test combining multiple columns."""
        col1 = column("Plate1", 1)
        col2 = column("Plate1", 2)
        combined = col1 + col2
        assert len(combined) == 16

    def test_exclude_wells_from_range(self):
        """Test excluding specific wells from a range."""
        full_row = row("Plate1", "A")
        controls = cherry_pick("Plate1", ["A1", "A12"])
        samples = full_row - controls
        assert len(samples) == 10
        assert "A1" not in samples
        assert "A12" not in samples
        assert "A2" in samples

    def test_find_common_wells(self):
        """Test finding wells common to two sets."""
        block1 = well_range("Plate1", "A1", "D6")
        block2 = well_range("Plate1", "C4", "H12")
        overlap = block1 & block2
        # Overlap is C4:D6 (2 rows x 3 cols = 6 wells)
        assert len(overlap) == 6
        assert "C4" in overlap
        assert "D6" in overlap
        assert "A1" not in overlap
        assert "H12" not in overlap
