"""Tests for error policy system."""


from bpl.errors import (
    # Error types
    ErrorSeverity,
    ErrorCategory,
    BPLError,
    PipetteErrorType,
    PipetteError,
    MotionErrorType,
    MotionError,
    SensorErrorType,
    SensorError,
    HumanErrorType,
    HumanError,
    ErrorRegistry,
    # Factory functions
    tip_clog_error,
    liquid_not_found_error,
    over_aspiration_error,
    tip_pickup_fail_error,
    collision_detected_error,
    position_unreachable_error,
    labware_not_found_error,
    reader_timeout_error,
    temperature_out_of_range_error,
    confirmation_timeout_error,
    invalid_data_entry_error,
    safety_violation_error,
    # Policy
    ErrorAction,
    ErrorPolicy,
    PolicyMatcher,
    ErrorPolicyManager,
    on_error_stop,
    on_error_retry,
    on_error_skip,
    on_error_continue,
)


class TestErrorTypes:
    """Tests for error type definitions."""

    def test_base_error_creation(self):
        """Test BPLError creation."""
        error = BPLError(
            error_id="TEST_001",
            category=ErrorCategory.PIPETTE,
            severity=ErrorSeverity.ERROR,
            message="Test error"
        )
        assert error.error_id == "TEST_001"
        assert error.category == ErrorCategory.PIPETTE
        assert error.severity == ErrorSeverity.ERROR
        assert error.recoverable is True

    def test_pipette_error_creation(self):
        """Test PipetteError creation."""
        error = PipetteError(
            error_id="PIP_001",
            category=ErrorCategory.PIPETTE,
            severity=ErrorSeverity.ERROR,
            message="Tip clog",
            pipette_error_type=PipetteErrorType.TIP_CLOG,
            channel_id="1",
            well_location="A1"
        )
        assert error.pipette_error_type == PipetteErrorType.TIP_CLOG
        assert error.channel_id == "1"

    def test_motion_error_creation(self):
        """Test MotionError creation."""
        error = MotionError(
            error_id="MOT_001",
            category=ErrorCategory.MOTION,
            severity=ErrorSeverity.CRITICAL,
            message="Collision",
            motion_error_type=MotionErrorType.COLLISION_DETECTED,
            position="slot_1"
        )
        assert error.motion_error_type == MotionErrorType.COLLISION_DETECTED
        assert error.position == "slot_1"

    def test_sensor_error_creation(self):
        """Test SensorError creation."""
        error = SensorError(
            error_id="SEN_001",
            category=ErrorCategory.SENSOR,
            severity=ErrorSeverity.WARNING,
            message="Temp out of range",
            sensor_error_type=SensorErrorType.TEMPERATURE_OUT_OF_RANGE,
            device_id="incubator_1",
            expected_value=37.0,
            actual_value=38.5
        )
        assert error.sensor_error_type == SensorErrorType.TEMPERATURE_OUT_OF_RANGE
        assert error.expected_value == 37.0
        assert error.actual_value == 38.5

    def test_human_error_creation(self):
        """Test HumanError creation."""
        error = HumanError(
            error_id="HUM_001",
            category=ErrorCategory.HUMAN,
            severity=ErrorSeverity.ERROR,
            message="Invalid data",
            human_error_type=HumanErrorType.INVALID_DATA_ENTRY,
            expected_input="number",
            actual_input="abc"
        )
        assert error.human_error_type == HumanErrorType.INVALID_DATA_ENTRY


class TestErrorFactories:
    """Tests for error factory functions."""

    def test_tip_clog_error(self):
        """Test tip_clog_error factory."""
        error = tip_clog_error("step_1", "channel_1", "A1")
        assert isinstance(error, PipetteError)
        assert error.pipette_error_type == PipetteErrorType.TIP_CLOG
        assert "channel_1" in error.message
        assert error.suggested_action is not None

    def test_liquid_not_found_error(self):
        """Test liquid_not_found_error factory."""
        error = liquid_not_found_error("step_2", "B2", 100.0)
        assert error.pipette_error_type == PipetteErrorType.LIQUID_NOT_FOUND
        assert error.expected_volume_ul == 100.0

    def test_over_aspiration_error(self):
        """Test over_aspiration_error factory."""
        error = over_aspiration_error("step_3", "C3", 200.0, 150.0)
        assert error.pipette_error_type == PipetteErrorType.OVER_ASPIRATION
        assert error.severity == ErrorSeverity.WARNING

    def test_tip_pickup_fail_error(self):
        """Test tip_pickup_fail_error factory."""
        error = tip_pickup_fail_error("step_4", "channel_1", "A1")
        assert error.pipette_error_type == PipetteErrorType.TIP_PICKUP_FAIL

    def test_collision_detected_error(self):
        """Test collision_detected_error factory."""
        error = collision_detected_error("step_5", "slot_3", "plate_1")
        assert isinstance(error, MotionError)
        assert error.motion_error_type == MotionErrorType.COLLISION_DETECTED
        assert error.severity == ErrorSeverity.CRITICAL
        assert error.recoverable is False

    def test_position_unreachable_error(self):
        """Test position_unreachable_error factory."""
        error = position_unreachable_error("step_6", "slot_99")
        assert error.motion_error_type == MotionErrorType.POSITION_UNREACHABLE

    def test_labware_not_found_error(self):
        """Test labware_not_found_error factory."""
        error = labware_not_found_error("step_7", "plate_1", "slot_1")
        assert error.motion_error_type == MotionErrorType.LABWARE_NOT_FOUND
        assert error.labware_id == "plate_1"

    def test_reader_timeout_error(self):
        """Test reader_timeout_error factory."""
        error = reader_timeout_error("step_8", "reader_1", 30.0)
        assert isinstance(error, SensorError)
        assert error.sensor_error_type == SensorErrorType.READER_TIMEOUT

    def test_temperature_out_of_range_error(self):
        """Test temperature_out_of_range_error factory."""
        error = temperature_out_of_range_error("step_9", "incubator_1", 37.0, 39.0, 1.0)
        assert error.sensor_error_type == SensorErrorType.TEMPERATURE_OUT_OF_RANGE
        assert error.tolerance == 1.0

    def test_confirmation_timeout_error(self):
        """Test confirmation_timeout_error factory."""
        error = confirmation_timeout_error("step_10", 60.0)
        assert isinstance(error, HumanError)
        assert error.human_error_type == HumanErrorType.CONFIRMATION_TIMEOUT

    def test_invalid_data_entry_error(self):
        """Test invalid_data_entry_error factory."""
        error = invalid_data_entry_error("step_11", "volume", "float", "abc")
        assert error.human_error_type == HumanErrorType.INVALID_DATA_ENTRY
        assert error.actual_input == "abc"

    def test_safety_violation_error(self):
        """Test safety_violation_error factory."""
        error = safety_violation_error("step_12", "PPE not worn")
        assert error.human_error_type == HumanErrorType.SAFETY_VIOLATION
        assert error.severity == ErrorSeverity.CRITICAL
        assert error.recoverable is False


class TestErrorRegistry:
    """Tests for error registry."""

    def test_record_error(self):
        """Test recording errors."""
        registry = ErrorRegistry()
        error = tip_clog_error("step_1", "ch1", "A1")
        registry.record(error)
        assert registry.error_count() == 1

    def test_get_by_category(self):
        """Test filtering by category."""
        registry = ErrorRegistry()
        registry.record(tip_clog_error("s1", "ch1", "A1"))
        registry.record(collision_detected_error("s2", "slot_1"))

        pipette_errors = registry.get_errors_by_category(ErrorCategory.PIPETTE)
        assert len(pipette_errors) == 1

    def test_get_by_severity(self):
        """Test filtering by severity."""
        registry = ErrorRegistry()
        registry.record(over_aspiration_error("s1", "A1", 100, 50))  # WARNING
        registry.record(collision_detected_error("s2", "slot_1"))   # CRITICAL

        warnings = registry.get_errors_by_severity(ErrorSeverity.WARNING)
        assert len(warnings) == 1

    def test_get_by_step(self):
        """Test filtering by step."""
        registry = ErrorRegistry()
        registry.record(tip_clog_error("step_1", "ch1", "A1"))
        registry.record(tip_clog_error("step_2", "ch1", "B1"))

        step1_errors = registry.get_errors_for_step("step_1")
        assert len(step1_errors) == 1

    def test_has_critical_errors(self):
        """Test critical error detection."""
        registry = ErrorRegistry()
        registry.record(tip_clog_error("s1", "ch1", "A1"))
        assert registry.has_critical_errors() is False

        registry.record(collision_detected_error("s2", "slot_1"))
        assert registry.has_critical_errors() is True

    def test_summary(self):
        """Test summary generation."""
        registry = ErrorRegistry()
        registry.record(tip_clog_error("s1", "ch1", "A1"))
        registry.record(tip_clog_error("s2", "ch1", "A2"))

        summary = registry.summary()
        assert "PIPETTE: 2" in summary


class TestErrorPolicies:
    """Tests for error policies."""

    def test_stop_policy(self):
        """Test stop policy creation."""
        policy = ErrorPolicy.stop("Fatal error")
        assert policy.action == ErrorAction.STOP
        assert policy.message_template == "Fatal error"

    def test_retry_policy(self):
        """Test retry policy creation."""
        policy = ErrorPolicy.retry(max_attempts=5, delay_s=2.0)
        assert policy.action == ErrorAction.RETRY
        assert policy.retry_config.max_attempts == 5
        assert policy.retry_config.delay_s == 2.0

    def test_skip_policy(self):
        """Test skip policy creation."""
        policy = ErrorPolicy.skip("Skipping step")
        assert policy.action == ErrorAction.SKIP
        assert policy.log_level == "WARNING"

    def test_alert_and_continue_policy(self):
        """Test alert-and-continue policy."""
        policy = ErrorPolicy.alert_and_continue("Alert message")
        assert policy.action == ErrorAction.ALERT_AND_CONTINUE

    def test_fallback_policy(self):
        """Test fallback policy creation."""
        policy = ErrorPolicy.fallback("use_default_volume", amount=100)
        assert policy.action == ErrorAction.FALLBACK
        assert policy.fallback_config.fallback_action == "use_default_volume"
        assert policy.fallback_config.parameters["amount"] == 100

    def test_escalate_policy(self):
        """Test escalation policy creation."""
        policy = ErrorPolicy.escalate(to="supervisor", timeout_s=600.0)
        assert policy.action == ErrorAction.ESCALATE
        assert policy.escalation_config.escalate_to == "supervisor"
        assert policy.escalation_config.timeout_s == 600.0


class TestPolicyMatcher:
    """Tests for policy matching."""

    def test_match_by_error_type(self):
        """Test matching by specific error type."""
        matcher = PolicyMatcher()
        matcher.set_policy_for_type(
            PipetteErrorType.TIP_CLOG,
            ErrorPolicy.retry(max_attempts=2)
        )

        error = tip_clog_error("step_1", "ch1", "A1")
        policy = matcher.match(error)
        assert policy.action == ErrorAction.RETRY

    def test_match_by_category(self):
        """Test matching by category."""
        matcher = PolicyMatcher()
        matcher.set_policy_for_category(
            ErrorCategory.MOTION,
            ErrorPolicy.stop()
        )

        error = collision_detected_error("step_1", "slot_1")
        policy = matcher.match(error)
        assert policy.action == ErrorAction.STOP

    def test_match_by_severity(self):
        """Test matching by severity."""
        matcher = PolicyMatcher()
        matcher.set_policy_for_severity(
            ErrorSeverity.WARNING,
            ErrorPolicy.alert_and_continue()
        )

        error = over_aspiration_error("step_1", "A1", 100, 50)
        policy = matcher.match(error)
        assert policy.action == ErrorAction.ALERT_AND_CONTINUE

    def test_default_policy(self):
        """Test default policy fallback."""
        matcher = PolicyMatcher()
        matcher.set_default_policy(ErrorPolicy.stop("Default stop"))

        error = tip_clog_error("step_1", "ch1", "A1")
        policy = matcher.match(error)
        assert policy.action == ErrorAction.STOP

    def test_priority_specific_over_category(self):
        """Test that specific type takes priority over category."""
        matcher = PolicyMatcher()
        matcher.set_policy_for_category(
            ErrorCategory.PIPETTE,
            ErrorPolicy.stop()
        )
        matcher.set_policy_for_type(
            PipetteErrorType.TIP_CLOG,
            ErrorPolicy.retry(max_attempts=3)
        )

        error = tip_clog_error("step_1", "ch1", "A1")
        policy = matcher.match(error)
        # Specific type should win
        assert policy.action == ErrorAction.RETRY

    def test_custom_matcher(self):
        """Test custom predicate matching."""
        matcher = PolicyMatcher()

        # Custom matcher for specific well
        def is_a1_error(e: BPLError) -> bool:
            return hasattr(e, 'well_location') and e.well_location == "A1"

        matcher.add_custom_matcher(is_a1_error, ErrorPolicy.skip())

        error = tip_clog_error("step_1", "ch1", "A1")
        policy = matcher.match(error)
        assert policy.action == ErrorAction.SKIP


class TestErrorPolicyManager:
    """Tests for error policy manager."""

    def test_register_default_policies(self):
        """Test default policy registration."""
        manager = ErrorPolicyManager()
        manager.register_default_policies()

        # Check some defaults
        error = tip_clog_error("step_1", "ch1", "A1")
        policy = manager.get_policy(error)
        assert policy.action == ErrorAction.RETRY

    def test_step_override(self):
        """Test step-specific policy override."""
        manager = ErrorPolicyManager()
        manager.register_default_policies()

        # Override for specific step
        manager.set_step_override(
            "critical_step",
            PipetteErrorType.TIP_CLOG,
            ErrorPolicy.stop()
        )

        error = tip_clog_error("critical_step", "ch1", "A1")
        policy = manager.get_policy(error, step_id="critical_step")
        assert policy.action == ErrorAction.STOP

    def test_apply_from_annotation(self):
        """Test applying policy from annotation."""
        manager = ErrorPolicyManager()

        annotation_args = {
            "action": "retry",
            "max_attempts": 5,
            "delay_s": 3.0
        }

        manager.apply_from_annotation("step_1", annotation_args)

        error = tip_clog_error("step_1", "ch1", "A1")
        policy = manager.get_policy(error, step_id="step_1")
        # After annotation applied, should use retry
        assert policy.action == ErrorAction.RETRY


class TestConvenienceFunctions:
    """Tests for convenience policy functions."""

    def test_on_error_stop(self):
        """Test on_error_stop function."""
        policy = on_error_stop()
        assert policy.action == ErrorAction.STOP

    def test_on_error_retry(self):
        """Test on_error_retry function."""
        policy = on_error_retry(attempts=5)
        assert policy.action == ErrorAction.RETRY
        assert policy.retry_config.max_attempts == 5

    def test_on_error_skip(self):
        """Test on_error_skip function."""
        policy = on_error_skip()
        assert policy.action == ErrorAction.SKIP

    def test_on_error_continue(self):
        """Test on_error_continue function."""
        policy = on_error_continue()
        assert policy.action == ErrorAction.ALERT_AND_CONTINUE
