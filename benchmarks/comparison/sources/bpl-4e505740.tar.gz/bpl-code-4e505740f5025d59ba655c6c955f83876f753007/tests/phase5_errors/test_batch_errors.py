"""Tests for batch error handling."""


from bpl.errors import (
    tip_clog_error,
    liquid_not_found_error,
    BatchContinuationPolicy,
    WellResult,
    BatchResult,
    BatchErrorPolicy,
    BatchErrorHandler,
    create_batch_handler,
    check_batch_threshold,
)


class TestWellResult:
    """Tests for well result tracking."""

    def test_successful_well_result(self):
        """Test successful well result."""
        result = WellResult(
            well_id="A1",
            success=True,
            volume_ul=100.0
        )
        assert result.well_id == "A1"
        assert result.success is True
        assert result.volume_ul == 100.0

    def test_failed_well_result(self):
        """Test failed well result."""
        error = tip_clog_error("step_1", "ch1", "A1")
        result = WellResult(
            well_id="A1",
            success=False,
            error=error,
            retry_count=2
        )
        assert result.success is False
        assert result.error is not None
        assert result.retry_count == 2

    def test_well_result_metadata(self):
        """Test metadata on well result."""
        result = WellResult(
            well_id="A1",
            success=True,
            metadata={"reagent": "PBS", "temperature": 25.0}
        )
        assert result.metadata["reagent"] == "PBS"


class TestBatchResult:
    """Tests for batch result tracking."""

    def test_batch_creation(self):
        """Test batch result creation."""
        batch = BatchResult(
            batch_id="batch_001",
            operation="transfer"
        )
        assert batch.batch_id == "batch_001"
        assert batch.operation == "transfer"
        assert batch.total_wells == 0

    def test_record_success(self):
        """Test recording successful well."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_success("A1", volume_ul=50.0)

        assert batch.success_count == 1
        assert "A1" in batch.successful_wells
        assert batch.results["A1"].volume_ul == 50.0

    def test_record_failure(self):
        """Test recording failed well."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        error = tip_clog_error("step_1", "ch1", "A1")
        batch.record_failure("A1", error, retry_count=1)

        assert batch.failure_count == 1
        assert "A1" in batch.failed_wells
        assert len(batch.errors) == 1

    def test_record_skip(self):
        """Test recording skipped well."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_skip("A1", reason="Empty well")

        assert batch.skip_count == 1
        assert "A1" in batch.skipped_wells

    def test_completion_rate(self):
        """Test completion rate calculation."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_success("A1")
        batch.record_success("A2")
        batch.record_success("A3")
        batch.record_failure("A4", tip_clog_error("s1", "ch1", "A4"))

        assert batch.completion_rate == 75.0  # 3/4

    def test_failure_rate(self):
        """Test failure rate calculation."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_success("A1")
        batch.record_failure("A2", tip_clog_error("s1", "ch1", "A2"))

        assert batch.failure_rate == 50.0  # 1/2

    def test_is_above_threshold(self):
        """Test threshold checking."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        # 9 successes, 1 failure = 90%
        for i in range(9):
            batch.record_success(f"A{i+1}")
        batch.record_failure("A10", tip_clog_error("s1", "ch1", "A10"))

        assert batch.is_above_threshold(90.0) is True
        assert batch.is_above_threshold(95.0) is False

    def test_complete_batch(self):
        """Test completing a batch."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_success("A1")
        batch.complete()

        assert batch.completed_at is not None
        assert batch.duration_s is not None

    def test_summary(self):
        """Test batch summary."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        batch.record_success("A1")
        batch.record_success("A2")
        batch.record_failure("A3", tip_clog_error("s1", "ch1", "A3"))

        summary = batch.summary()
        assert "b1" in summary
        assert "2/3" in summary


class TestBatchErrorPolicy:
    """Tests for batch error policies."""

    def test_strict_policy(self):
        """Test strict policy creation."""
        policy = BatchErrorPolicy.strict()
        assert policy.continuation_policy == BatchContinuationPolicy.STOP_ON_FIRST
        assert policy.failure_threshold == 0.0
        assert policy.min_success_rate == 100.0

    def test_lenient_policy(self):
        """Test lenient policy creation."""
        policy = BatchErrorPolicy.lenient()
        assert policy.continuation_policy == BatchContinuationPolicy.CONTINUE_ALL
        assert policy.min_success_rate == 50.0

    def test_standard_policy(self):
        """Test standard policy creation."""
        policy = BatchErrorPolicy.standard()
        assert policy.continuation_policy == BatchContinuationPolicy.STOP_ON_THRESHOLD
        assert policy.failure_threshold == 10.0
        assert policy.min_success_rate == 90.0

    def test_custom_policy(self):
        """Test custom policy creation."""
        policy = BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.COMPLETE_ROW,
            failure_threshold=20.0,
            min_success_rate=80.0,
            max_consecutive_failures=5
        )
        assert policy.max_consecutive_failures == 5


class TestBatchErrorHandler:
    """Tests for batch error handler."""

    def test_start_batch(self):
        """Test starting a new batch."""
        handler = BatchErrorHandler()
        batch = handler.start_batch("batch_1", "transfer")

        assert batch.batch_id == "batch_1"
        assert handler.get_current_batch() is not None

    def test_record_success(self):
        """Test recording well success."""
        handler = BatchErrorHandler()
        handler.start_batch("batch_1", "transfer")
        handler.record_well_success("A1", volume_ul=50.0)

        batch = handler.get_current_batch()
        assert batch.success_count == 1

    def test_record_failure_continues(self):
        """Test recording failure with standard policy."""
        handler = BatchErrorHandler(BatchErrorPolicy.standard())
        handler.start_batch("batch_1", "transfer")

        # Record some successes first to stay under 10% threshold
        for i in range(20):
            handler.record_well_success(f"S{i}")

        # Record one failure (now under 10% threshold: 1/21 = ~5%)
        error = tip_clog_error("s1", "ch1", "A1")
        should_continue, msg = handler.record_well_failure("A1", error)

        assert should_continue is True

    def test_record_failure_stops_strict(self):
        """Test that strict policy stops on first failure."""
        handler = BatchErrorHandler(BatchErrorPolicy.strict())
        handler.start_batch("batch_1", "transfer")

        error = tip_clog_error("s1", "ch1", "A1")
        should_continue, msg = handler.record_well_failure("A1", error)

        assert should_continue is False
        assert "strict" in msg.lower()

    def test_consecutive_failures_stop(self):
        """Test stopping after consecutive failures."""
        policy = BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.STOP_ON_THRESHOLD,
            failure_threshold=50.0,  # High threshold so we hit consecutive first
            max_consecutive_failures=3
        )
        handler = BatchErrorHandler(policy)
        handler.start_batch("batch_1", "transfer")

        # Record some successes first to not trigger threshold
        for i in range(10):
            handler.record_well_success(f"S{i}")

        # First two failures should continue
        for i in range(2):
            error = tip_clog_error(f"s{i}", "ch1", f"F{i+1}")
            should_continue, _ = handler.record_well_failure(f"F{i+1}", error)
            assert should_continue is True

        # Third consecutive should stop
        error = tip_clog_error("s3", "ch1", "F3")
        should_continue, msg = handler.record_well_failure("F3", error)
        assert should_continue is False
        assert "consecutive" in msg.lower()

    def test_threshold_exceeded_stops(self):
        """Test stopping when failure threshold exceeded."""
        policy = BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.STOP_ON_THRESHOLD,
            failure_threshold=20.0,  # 20%
            max_consecutive_failures=99  # Don't trigger this
        )
        handler = BatchErrorHandler(policy)
        handler.start_batch("batch_1", "transfer")

        # Record some successes first
        for i in range(4):
            handler.record_well_success(f"S{i}")

        # Record failure (20% of 5)
        error = tip_clog_error("s1", "ch1", "F1")
        should_continue, msg = handler.record_well_failure("F1", error)
        assert should_continue is True  # 20% exactly

        # Record another failure (now 33%)
        error = tip_clog_error("s2", "ch1", "F2")
        should_continue, msg = handler.record_well_failure("F2", error)
        assert should_continue is False
        assert "threshold" in msg.lower()

    def test_skip_well(self):
        """Test skipping a well."""
        handler = BatchErrorHandler()
        handler.start_batch("batch_1", "transfer")
        handler.skip_well("A1", reason="Empty source")

        batch = handler.get_current_batch()
        assert batch.skip_count == 1

    def test_complete_batch(self):
        """Test completing a batch."""
        handler = BatchErrorHandler()
        handler.start_batch("batch_1", "transfer")
        handler.record_well_success("A1")

        batch = handler.complete_batch()
        assert batch.completed_at is not None
        assert handler.get_current_batch() is None

    def test_complete_batch_below_threshold_warns(self):
        """Test warning when completion rate below minimum."""
        policy = BatchErrorPolicy(min_success_rate=90.0)
        handler = BatchErrorHandler(policy)
        handler.start_batch("batch_1", "transfer")

        # 8 success, 2 failures = 80%
        for i in range(8):
            handler.record_well_success(f"S{i}")
        for i in range(2):
            error = tip_clog_error(f"s{i}", "ch1", f"F{i}")
            handler.record_well_failure(f"F{i}", error)

        batch = handler.complete_batch()
        # Should have added a warning error
        assert any("below minimum" in str(e.message).lower() for e in batch.errors)

    def test_batch_history(self):
        """Test batch history tracking."""
        handler = BatchErrorHandler()

        handler.start_batch("batch_1", "transfer")
        handler.record_well_success("A1")
        handler.complete_batch()

        handler.start_batch("batch_2", "distribute")
        handler.record_well_success("B1")
        handler.complete_batch()

        history = handler.get_batch_history()
        assert len(history) == 2

    def test_aggregate_stats(self):
        """Test aggregate statistics."""
        handler = BatchErrorHandler()

        handler.start_batch("batch_1", "transfer")
        handler.record_well_success("A1")
        handler.record_well_success("A2")
        handler.complete_batch()

        handler.start_batch("batch_2", "distribute")
        handler.record_well_success("B1")
        handler.record_well_failure("B2", tip_clog_error("s1", "ch1", "B2"))
        handler.complete_batch()

        stats = handler.get_aggregate_stats()
        assert stats["total_batches"] == 2
        assert stats["total_wells"] == 4
        assert stats["total_success"] == 3
        assert stats["total_failure"] == 1
        assert stats["overall_success_rate"] == 75.0


class TestBatchConvenienceFunctions:
    """Tests for convenience functions."""

    def test_create_batch_handler_standard(self):
        """Test creating standard handler."""
        handler = create_batch_handler("standard")
        assert handler.policy.min_success_rate == 90.0

    def test_create_batch_handler_strict(self):
        """Test creating strict handler."""
        handler = create_batch_handler("strict")
        assert handler.policy.continuation_policy == BatchContinuationPolicy.STOP_ON_FIRST

    def test_create_batch_handler_lenient(self):
        """Test creating lenient handler."""
        handler = create_batch_handler("lenient")
        assert handler.policy.continuation_policy == BatchContinuationPolicy.CONTINUE_ALL

    def test_create_batch_handler_default(self):
        """Test creating with unknown type defaults to standard."""
        handler = create_batch_handler("unknown")
        assert handler.policy.min_success_rate == 90.0

    def test_check_batch_threshold_pass(self):
        """Test threshold check passing."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        for i in range(10):
            batch.record_success(f"A{i}")

        passed, msg = check_batch_threshold(batch, 90.0)
        assert passed is True
        assert "passed" in msg.lower()

    def test_check_batch_threshold_fail(self):
        """Test threshold check failing."""
        batch = BatchResult(batch_id="b1", operation="transfer")
        for i in range(8):
            batch.record_success(f"S{i}")
        for i in range(2):
            batch.record_failure(f"F{i}", tip_clog_error(f"s{i}", "ch1", f"F{i}"))

        passed, msg = check_batch_threshold(batch, 90.0)
        assert passed is False
        assert "failed" in msg.lower()


class TestBatchIntegration:
    """Integration tests for batch error handling."""

    def test_full_batch_workflow(self):
        """Test complete batch handling workflow."""
        handler = create_batch_handler("standard")

        # Start batch
        handler.start_batch("batch_001", "96_well_transfer")

        # Simulate transfers across a plate
        for row in "ABCDEFGH":
            for col in range(1, 13):
                well_id = f"{row}{col}"
                # Simulate occasional failures
                if (row == "D" and col == 6) or (row == "G" and col == 10):
                    error = liquid_not_found_error(f"step_{well_id}", well_id, 100.0)
                    should_continue, _ = handler.record_well_failure(well_id, error)
                    if not should_continue:
                        break
                else:
                    handler.record_well_success(well_id, volume_ul=100.0)

        # Complete batch
        result = handler.complete_batch()

        # Verify results
        assert result.total_wells == 96
        assert result.failure_count == 2
        assert result.completion_rate > 95.0
        assert result.is_above_threshold(90.0)

    def test_early_termination_workflow(self):
        """Test workflow with early termination."""
        handler = create_batch_handler("strict")

        handler.start_batch("batch_002", "critical_transfer")

        # First well succeeds
        handler.record_well_success("A1", volume_ul=50.0)

        # Second well fails - should stop
        error = tip_clog_error("step_A2", "ch1", "A2")
        should_continue, msg = handler.record_well_failure("A2", error)

        assert should_continue is False

        # Complete partial batch
        result = handler.complete_batch()
        assert result.total_wells == 2
        assert result.success_count == 1
