"""Tests for recovery procedures."""


from bpl.errors import (
    # Error types
    tip_clog_error,
    tip_pickup_fail_error,
    temperature_out_of_range_error,
    collision_detected_error,
    # Recovery
    RecoveryStatus,
    RecoveryStep,
    RecoveryResult,
    TipClogRecovery,
    TipPickupRecovery,
    TemperatureRecovery,
    HumanInterventionRecovery,
    RecoveryManager,
    create_recovery_manager,
)


class TestRecoveryStep:
    """Tests for recovery step definition."""

    def test_step_creation(self):
        """Test RecoveryStep creation."""
        step = RecoveryStep(
            step_id="eject_tip",
            description="Eject the clogged tip",
            action="drop_tips"
        )
        assert step.step_id == "eject_tip"
        assert step.action == "drop_tips"
        assert step.requires_human is False

    def test_step_with_human_requirement(self):
        """Test step requiring human intervention."""
        step = RecoveryStep(
            step_id="confirm_action",
            description="Wait for operator confirmation",
            action="await_confirmation",
            requires_human=True,
            timeout_s=60.0
        )
        assert step.requires_human is True
        assert step.timeout_s == 60.0

    def test_step_with_parameters(self):
        """Test step with action parameters."""
        step = RecoveryStep(
            step_id="wait",
            description="Wait for stabilization",
            action="wait",
            parameters={"duration_s": 30.0}
        )
        assert step.parameters["duration_s"] == 30.0


class TestRecoveryResult:
    """Tests for recovery result."""

    def test_successful_result(self):
        """Test successful recovery result."""
        result = RecoveryResult(
            status=RecoveryStatus.SUCCEEDED,
            steps_completed=["step_1", "step_2"],
            error_resolved=True,
            message="Recovery successful"
        )
        assert result.success is True
        assert result.error_resolved is True
        assert len(result.steps_completed) == 2

    def test_failed_result(self):
        """Test failed recovery result."""
        result = RecoveryResult(
            status=RecoveryStatus.FAILED,
            steps_completed=["step_1"],
            steps_failed=["step_2"],
            error_resolved=False,
            message="Recovery failed"
        )
        assert result.success is False
        assert len(result.steps_failed) == 1

    def test_partial_result(self):
        """Test partial recovery result."""
        result = RecoveryResult(
            status=RecoveryStatus.PARTIAL,
            steps_completed=["step_1"],
            steps_failed=["step_2"],
            error_resolved=False
        )
        assert result.status == RecoveryStatus.PARTIAL
        assert result.success is False


class TestTipClogRecovery:
    """Tests for tip clog recovery procedure."""

    def test_can_recover_tip_clog(self):
        """Test that procedure can recover tip clog."""
        recovery = TipClogRecovery()
        error = tip_clog_error("step_1", "ch1", "A1")
        assert recovery.can_recover(error) is True

    def test_cannot_recover_other_errors(self):
        """Test that procedure rejects other error types."""
        recovery = TipClogRecovery()
        error = tip_pickup_fail_error("step_1", "ch1", "A1")
        assert recovery.can_recover(error) is False

    def test_execute_recovery(self):
        """Test executing recovery procedure."""
        recovery = TipClogRecovery()
        error = tip_clog_error("step_1", "ch1", "A1")

        result = recovery.execute(error, {})
        assert result.status == RecoveryStatus.SUCCEEDED
        assert result.error_resolved is True
        assert len(result.steps_completed) == 3

    def test_recovery_steps_defined(self):
        """Test that recovery steps are properly defined."""
        recovery = TipClogRecovery()
        assert len(recovery.steps) == 3
        assert recovery.steps[0].action == "drop_tips"
        assert recovery.steps[1].action == "pick_tips"


class TestTipPickupRecovery:
    """Tests for tip pickup recovery procedure."""

    def test_can_recover_tip_pickup(self):
        """Test that procedure can recover tip pickup failures."""
        recovery = TipPickupRecovery()
        error = tip_pickup_fail_error("step_1", "ch1", "A1")
        assert recovery.can_recover(error) is True

    def test_cannot_recover_clog(self):
        """Test rejection of different error type."""
        recovery = TipPickupRecovery()
        error = tip_clog_error("step_1", "ch1", "A1")
        assert recovery.can_recover(error) is False

    def test_execute_recovery(self):
        """Test executing tip pickup recovery."""
        recovery = TipPickupRecovery()
        error = tip_pickup_fail_error("step_1", "ch1", "A1")

        result = recovery.execute(error, {})
        assert result.status == RecoveryStatus.SUCCEEDED

    def test_recovery_has_human_step(self):
        """Test that recovery includes human intervention option."""
        recovery = TipPickupRecovery()
        human_steps = [s for s in recovery.steps if s.requires_human]
        assert len(human_steps) > 0


class TestTemperatureRecovery:
    """Tests for temperature recovery procedure."""

    def test_can_recover_temperature(self):
        """Test temperature error recovery."""
        recovery = TemperatureRecovery()
        error = temperature_out_of_range_error(
            "step_1", "incubator_1", 37.0, 39.0, 1.0
        )
        assert recovery.can_recover(error) is True

    def test_execute_recovery(self):
        """Test executing temperature recovery."""
        recovery = TemperatureRecovery()
        error = temperature_out_of_range_error(
            "step_1", "incubator_1", 37.0, 39.0, 1.0
        )

        result = recovery.execute(error, {})
        assert result.status == RecoveryStatus.SUCCEEDED

    def test_includes_wait_step(self):
        """Test that recovery includes waiting for stabilization."""
        recovery = TemperatureRecovery()
        wait_steps = [s for s in recovery.steps if s.action == "wait"]
        assert len(wait_steps) > 0


class TestHumanInterventionRecovery:
    """Tests for human intervention recovery."""

    def test_can_recover_any_recoverable(self):
        """Test that human recovery can handle any recoverable error."""
        recovery = HumanInterventionRecovery()
        error = tip_clog_error("step_1", "ch1", "A1")
        assert recovery.can_recover(error) is True

    def test_cannot_recover_non_recoverable(self):
        """Test rejection of non-recoverable errors."""
        recovery = HumanInterventionRecovery()
        error = collision_detected_error("step_1", "slot_1")
        # Collision is marked as non-recoverable
        assert recovery.can_recover(error) is False

    def test_execute_recovery(self):
        """Test executing human intervention recovery."""
        recovery = HumanInterventionRecovery()
        error = tip_clog_error("step_1", "ch1", "A1")

        result = recovery.execute(error, {})
        assert result.status == RecoveryStatus.SUCCEEDED

    def test_all_steps_include_human(self):
        """Test that procedure includes human steps."""
        recovery = HumanInterventionRecovery()
        human_steps = [s for s in recovery.steps if s.requires_human]
        assert len(human_steps) >= 1


class TestRecoveryManager:
    """Tests for recovery manager."""

    def test_register_procedure(self):
        """Test registering a recovery procedure."""
        manager = RecoveryManager()
        recovery = TipClogRecovery()
        manager.register_procedure(recovery)

        error = tip_clog_error("step_1", "ch1", "A1")
        found = manager.find_procedure(error)
        assert found is not None
        assert found.procedure_id == "tip_clog_recovery"

    def test_register_default_procedures(self):
        """Test registering default procedures."""
        manager = RecoveryManager()
        manager.register_default_procedures()

        # Should have multiple procedures registered
        error = tip_clog_error("step_1", "ch1", "A1")
        assert manager.find_procedure(error) is not None

        error = tip_pickup_fail_error("step_1", "ch1", "A1")
        assert manager.find_procedure(error) is not None

    def test_find_procedure_returns_none_if_not_found(self):
        """Test that find returns None for unknown errors."""
        manager = RecoveryManager()
        # Don't register any procedures

        error = tip_clog_error("step_1", "ch1", "A1")
        assert manager.find_procedure(error) is None

    def test_attempt_recovery_success(self):
        """Test successful recovery attempt."""
        manager = RecoveryManager()
        manager.register_default_procedures()

        error = tip_clog_error("step_1", "ch1", "A1")
        result = manager.attempt_recovery(error)

        assert result.status == RecoveryStatus.SUCCEEDED
        assert result.error_resolved is True

    def test_attempt_recovery_no_procedure(self):
        """Test recovery when no procedure is found."""
        manager = RecoveryManager()
        # Don't register procedures

        error = tip_clog_error("step_1", "ch1", "A1")
        result = manager.attempt_recovery(error)

        assert result.status == RecoveryStatus.FAILED
        assert "No recovery procedure found" in result.message

    def test_attempt_recovery_non_recoverable(self):
        """Test recovery for non-recoverable error."""
        manager = RecoveryManager()
        manager.register_default_procedures()

        error = collision_detected_error("step_1", "slot_1")
        result = manager.attempt_recovery(error)

        assert result.status == RecoveryStatus.SKIPPED
        assert "non-recoverable" in result.message

    def test_recovery_history(self):
        """Test recovery history tracking."""
        manager = RecoveryManager()
        manager.register_default_procedures()

        error1 = tip_clog_error("step_1", "ch1", "A1")
        error2 = tip_pickup_fail_error("step_2", "ch1", "A2")

        manager.attempt_recovery(error1)
        manager.attempt_recovery(error2)

        history = manager.get_recovery_history()
        assert len(history) == 2

    def test_clear_history(self):
        """Test clearing recovery history."""
        manager = RecoveryManager()
        manager.register_default_procedures()

        error = tip_clog_error("step_1", "ch1", "A1")
        manager.attempt_recovery(error)

        manager.clear_history()
        assert len(manager.get_recovery_history()) == 0


class TestRecoveryManagerFactory:
    """Tests for recovery manager factory."""

    def test_create_recovery_manager(self):
        """Test factory function."""
        manager = create_recovery_manager()

        # Should have defaults registered
        error = tip_clog_error("step_1", "ch1", "A1")
        assert manager.find_procedure(error) is not None

    def test_created_manager_works(self):
        """Test that created manager can execute recovery."""
        manager = create_recovery_manager()

        error = tip_clog_error("step_1", "ch1", "A1")
        result = manager.attempt_recovery(error)
        assert result.success is True
