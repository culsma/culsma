"""
Phase 9: Audit Trail Tests

Comprehensive tests for the audit trail system including:
- AuditTrail and AuditEntry
- ChainHash integrity verification
- Amendment tracking
- Compliance checking
- Export functionality
"""

import pytest
from datetime import datetime, timedelta
from typing import Dict, Any
import json
import tempfile
import os


# =============================================================================
# Audit Trail Tests
# =============================================================================

class TestAuditEventType:
    """Tests for AuditEventType enum."""

    def test_protocol_lifecycle_events(self):
        """Test protocol lifecycle event types."""
        from bpl.audit import AuditEventType

        assert AuditEventType.PROTOCOL_STARTED is not None
        assert AuditEventType.PROTOCOL_COMPLETED is not None
        assert AuditEventType.PROTOCOL_ABORTED is not None
        assert AuditEventType.PROTOCOL_PAUSED is not None
        assert AuditEventType.PROTOCOL_RESUMED is not None

    def test_step_events(self):
        """Test step-related event types."""
        from bpl.audit import AuditEventType

        assert AuditEventType.STEP_STARTED is not None
        assert AuditEventType.STEP_COMPLETED is not None
        assert AuditEventType.STEP_FAILED is not None
        assert AuditEventType.STEP_SKIPPED is not None
        assert AuditEventType.STEP_RETRIED is not None

    def test_data_events(self):
        """Test data-related event types."""
        from bpl.audit import AuditEventType

        assert AuditEventType.DATA_RECORDED is not None
        assert AuditEventType.DATA_MODIFIED is not None

    def test_signature_events(self):
        """Test signature-related event types."""
        from bpl.audit import AuditEventType

        assert AuditEventType.SIGNATURE_APPLIED is not None
        assert AuditEventType.SIGNATURE_REJECTED is not None

    def test_error_events(self):
        """Test error-related event types."""
        from bpl.audit import AuditEventType

        assert AuditEventType.ERROR_OCCURRED is not None
        assert AuditEventType.ERROR_RECOVERED is not None


class TestAuditEntry:
    """Tests for AuditEntry dataclass."""

    def test_entry_creation(self):
        """Test creating an audit entry."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        entry = AuditEntry(
            entry_id="entry_001",
            event_type=AuditEventType.STEP_STARTED,
            timestamp=datetime.now(),
            description="Started step 1",
            user_id="user123",
            user_name="Test User",
        )

        assert entry.entry_id == "entry_001"
        assert entry.event_type == AuditEventType.STEP_STARTED
        assert entry.description == "Started step 1"
        assert entry.user_id == "user123"
        assert entry.user_name == "Test User"
        assert entry.timestamp is not None

    def test_entry_with_step(self):
        """Test entry with step information."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        entry = AuditEntry(
            entry_id="entry_002",
            event_type=AuditEventType.STEP_COMPLETED,
            timestamp=datetime.now(),
            description="Completed pipetting",
            step_id="step_pipette_1",
        )

        assert entry.step_id == "step_pipette_1"

    def test_entry_with_data(self):
        """Test entry with data dict."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        entry = AuditEntry(
            entry_id="entry_003",
            event_type=AuditEventType.DATA_RECORDED,
            timestamp=datetime.now(),
            description="Recorded measurement",
            data={"value": 7.4, "unit": "pH"},
        )

        assert entry.data["value"] == 7.4
        assert entry.data["unit"] == "pH"

    def test_entry_to_dict(self):
        """Test converting entry to dictionary."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        entry = AuditEntry(
            entry_id="entry_004",
            event_type=AuditEventType.PROTOCOL_STARTED,
            timestamp=datetime.now(),
            description="Protocol began",
        )

        data = entry.to_dict()
        assert data["entry_id"] == "entry_004"
        assert data["event_type"] == "PROTOCOL_STARTED"
        assert "timestamp" in data

    def test_entry_compute_hash(self):
        """Test computing entry hash."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        entry = AuditEntry(
            entry_id="entry_005",
            event_type=AuditEventType.PROTOCOL_STARTED,
            timestamp=datetime.now(),
            description="Test",
        )

        h = entry.compute_hash()
        assert len(h) == 64  # SHA256 hex

    def test_entry_hash_uses_canonical_fields(self):
        """Delimiter characters in fields must not create hash ambiguity."""
        from bpl.audit.audit_trail import AuditEntry, AuditEventType

        ts = datetime.now()
        entry1 = AuditEntry(
            entry_id="entry:005",
            event_type=AuditEventType.PROTOCOL_STARTED,
            timestamp=ts,
            description="a",
            protocol_id="b",
        )
        entry2 = AuditEntry(
            entry_id="entry",
            event_type=AuditEventType.PROTOCOL_STARTED,
            timestamp=ts,
            description="005:a",
            protocol_id="b",
        )

        assert entry1.compute_hash() != entry2.compute_hash()


class TestAuditTrail:
    """Tests for AuditTrail class."""

    def test_create_audit_trail(self):
        """Test creating an audit trail."""
        from bpl.audit import create_audit_trail

        trail = create_audit_trail("proto_001", "Test Protocol")

        assert trail.protocol_id == "proto_001"
        assert trail.protocol_name == "Test Protocol"
        # create_audit_trail adds a PROTOCOL_CREATED entry
        assert len(trail.entries) == 1
        assert trail.created_at is not None

    def test_add_entry(self):
        """Test adding entries to trail."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_002",
            protocol_id="proto_002",
            protocol_name="Test"
        )

        entry = trail.add_entry(
            event_type=AuditEventType.PROTOCOL_STARTED,
            description="Protocol started",
            user_id="user1",
        )

        assert len(trail.entries) == 1
        assert entry.entry_id is not None
        assert entry.event_type == AuditEventType.PROTOCOL_STARTED

    def test_entry_hook_exceptions_propagate(self):
        """Audit hooks are part of compliance flow and must not be swallowed."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_hook",
            protocol_id="proto_hook",
            protocol_name="Test",
        )

        def failing_hook(_entry):
            raise RuntimeError("downstream audit sink failed")

        trail.add_entry_hook(failing_hook)
        with pytest.raises(RuntimeError, match="downstream audit sink failed"):
            trail.add_entry(AuditEventType.PROTOCOL_STARTED, "start")

    def test_chain_hash_linking(self):
        """Test that entries are linked via hash chain."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_003",
            protocol_id="proto_003",
            protocol_name="Test"
        )

        entry1 = trail.add_entry(
            event_type=AuditEventType.PROTOCOL_STARTED,
            description="Started",
        )
        entry2 = trail.add_entry(
            event_type=AuditEventType.STEP_STARTED,
            description="Step 1 started",
        )

        # Second entry should reference first entry's hash
        assert entry2.previous_hash == entry1.entry_hash
        assert entry1.entry_hash != ""
        assert entry2.entry_hash != ""

    def test_verify_chain_valid(self):
        """Test chain verification with valid chain."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_004",
            protocol_id="proto_004",
            protocol_name="Test"
        )

        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Step 1 done")

        assert trail.verify_chain() is True

    def test_log_protocol_start(self):
        """Test logging protocol start."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_005",
            protocol_id="proto_005",
            protocol_name="Test"
        )

        entry = trail.log_protocol_start(user_id="user1")

        assert entry.event_type == AuditEventType.PROTOCOL_STARTED
        assert entry.user_id == "user1"

    def test_log_step_started(self):
        """Test logging step start."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_006",
            protocol_id="proto_006",
            protocol_name="Test"
        )

        entry = trail.log_step_started(
            step_id="step_1",
            step_name="Pipette A",
            user_id="user1",
        )

        assert entry.event_type == AuditEventType.STEP_STARTED
        assert entry.step_id == "step_1"

    def test_log_step_completed(self):
        """Test logging step completion."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_007",
            protocol_id="proto_007",
            protocol_name="Test"
        )

        entry = trail.log_step_completed(
            step_id="step_1",
            step_name="Pipette A",
            user_id="user1",
        )

        assert entry.event_type == AuditEventType.STEP_COMPLETED

    def test_log_data_recorded(self):
        """Test logging data recording."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_008",
            protocol_id="proto_008",
            protocol_name="Test"
        )

        entry = trail.log_data_recorded(
            field_name="pH",
            value=7.4,
            user_id="user1",
        )

        assert entry.event_type == AuditEventType.DATA_RECORDED
        assert "pH" in entry.description

    def test_log_error(self):
        """Test logging errors."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_009",
            protocol_id="proto_009",
            protocol_name="Test"
        )

        entry = trail.log_error(
            error_type="VolumeError",
            error_message="Volume exceeded",
            step_id="step_1",
        )

        assert entry.event_type == AuditEventType.ERROR_OCCURRED
        assert entry.severity == "ERROR"

    def test_log_signature(self):
        """Test logging signatures."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_010",
            protocol_id="proto_010",
            protocol_name="Test"
        )

        entry = trail.log_signature_applied(
            signature_type="step_approval",
            signer_id="user1",
            signer_name="Test User",
            step_id="step_1",
        )

        assert entry.event_type == AuditEventType.SIGNATURE_APPLIED

    def test_summary(self):
        """Test getting trail summary."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_011",
            protocol_id="proto_011",
            protocol_name="Test"
        )

        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Step 1 done")
        trail.add_entry(AuditEventType.ERROR_OCCURRED, "Error!", severity="ERROR")

        summary = trail.summary()

        assert summary["total_entries"] == 4
        assert summary["error_count"] == 1
        assert summary["chain_valid"] is True

    def test_to_dict(self):
        """Test converting trail to dictionary."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_012",
            protocol_id="proto_012",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        data = trail.to_dict()

        assert data["protocol_id"] == "proto_012"
        assert data["protocol_name"] == "Test"
        assert len(data["entries"]) == 1

    def test_get_entries_by_type(self):
        """Test filtering entries by type."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_013",
            protocol_id="proto_013",
            protocol_name="Test"
        )

        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Step 1 done")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 2")

        step_starts = trail.get_entries_by_type(AuditEventType.STEP_STARTED)

        assert len(step_starts) == 2

    def test_get_entries_by_step(self):
        """Test filtering entries by step."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_014",
            protocol_id="proto_014",
            protocol_name="Test"
        )

        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1", step_id="step_1")
        trail.add_entry(AuditEventType.DATA_RECORDED, "Data", step_id="step_1")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 2", step_id="step_2")

        step1_entries = trail.get_entries_by_step("step_1")

        assert len(step1_entries) == 2


# =============================================================================
# Chain Hash Tests
# =============================================================================

class TestHashAlgorithm:
    """Tests for HashAlgorithm enum."""

    def test_supported_algorithms(self):
        """Test supported hash algorithms."""
        from bpl.audit import HashAlgorithm

        assert HashAlgorithm.SHA256 is not None
        assert HashAlgorithm.SHA512 is not None


class TestComputeHash:
    """Tests for compute_hash function."""

    def test_compute_hash_string(self):
        """Test hashing a string."""
        from bpl.audit import compute_hash

        h = compute_hash("test data")
        assert len(h) == 64  # SHA256 hex length

    def test_compute_hash_dict(self):
        """Test hashing a dictionary."""
        from bpl.audit import compute_hash

        h = compute_hash({"key": "value", "num": 42})
        assert len(h) == 64

    def test_hash_deterministic(self):
        """Test that hashing is deterministic."""
        from bpl.audit import compute_hash

        h1 = compute_hash("same data")
        h2 = compute_hash("same data")
        assert h1 == h2

    def test_hash_different_data(self):
        """Test that different data produces different hashes."""
        from bpl.audit import compute_hash

        h1 = compute_hash("data 1")
        h2 = compute_hash("data 2")
        assert h1 != h2


class TestChainHash:
    """Tests for ChainHash class."""

    def test_create_chain_hash(self):
        """Test creating a chain hash."""
        from bpl.audit import ChainHash

        chain = ChainHash()
        assert len(chain.blocks) == 0

    def test_add_block(self):
        """Test adding blocks to chain."""
        from bpl.audit import ChainHash

        chain = ChainHash()

        block1 = chain.add_block({"event": "start"}, "block_1")
        block2 = chain.add_block({"event": "step"}, "block_2")

        assert len(chain.blocks) == 2
        assert block2.previous_hash == block1.block_hash

    def test_verify_valid_chain(self):
        """Test verifying a valid chain."""
        from bpl.audit import ChainHash

        chain = ChainHash()
        chain.add_block({"event": "start"}, "block_1")
        chain.add_block({"event": "step"}, "block_2")
        chain.add_block({"event": "end"}, "block_3")

        result = chain.verify()
        assert result.valid is True
        assert len(result.errors) == 0

    def test_block_hash_uses_canonical_fields(self):
        """Block hashes distinguish values containing delimiters."""
        from bpl.audit import ChainHash

        chain = ChainHash()
        block1 = chain.add_block({"value": "a:b"}, "block:1")
        block2 = chain.add_block({"value": "a", "suffix": "b"}, "block")

        assert block1.block_hash != block2.block_hash
        assert chain.verify().valid is True

    def test_get_block(self):
        """Test getting a block by ID."""
        from bpl.audit import ChainHash

        chain = ChainHash()
        chain.add_block({"event": "start"}, "block_1")

        block = chain.get_block("block_1")
        assert block is not None
        assert block.block_id == "block_1"

    def test_get_latest_hash(self):
        """Test getting latest hash."""
        from bpl.audit import ChainHash

        chain = ChainHash()
        block = chain.add_block({"event": "start"}, "block_1")

        assert chain.get_latest_hash() == block.block_hash


class TestMerkleRoot:
    """Tests for compute_merkle_root function."""

    def test_merkle_root_single(self):
        """Test Merkle root with single hash."""
        from bpl.audit import compute_merkle_root

        hashes = ["abc123"]
        root = compute_merkle_root(hashes)
        assert root is not None

    def test_merkle_root_multiple(self):
        """Test Merkle root with multiple hashes."""
        from bpl.audit import compute_merkle_root

        hashes = ["hash1", "hash2", "hash3", "hash4"]
        root = compute_merkle_root(hashes)
        assert root is not None
        assert len(root) == 64

    def test_merkle_root_deterministic(self):
        """Test Merkle root is deterministic."""
        from bpl.audit import compute_merkle_root

        hashes = ["a", "b", "c"]
        root1 = compute_merkle_root(hashes)
        root2 = compute_merkle_root(hashes)
        assert root1 == root2

    def test_merkle_root_order_matters(self):
        """Test that hash order affects Merkle root."""
        from bpl.audit import compute_merkle_root

        root1 = compute_merkle_root(["a", "b"])
        root2 = compute_merkle_root(["b", "a"])
        assert root1 != root2


class TestVerifyChainIntegrity:
    """Tests for verify_chain_integrity function."""

    def test_verify_integrity_function(self):
        """Test the verify_chain_integrity helper."""
        from bpl.audit import ChainHash, verify_chain_integrity

        chain = ChainHash()
        chain.add_block({"event": "start"}, "block_1")
        chain.add_block({"event": "end"}, "block_2")

        result = verify_chain_integrity(chain)
        assert result.valid is True


# =============================================================================
# Amendment Tests
# =============================================================================

class TestAmendmentType:
    """Tests for AmendmentType enum."""

    def test_amendment_types(self):
        """Test amendment type values."""
        from bpl.audit import AmendmentType

        assert AmendmentType.DATA_CORRECTION is not None
        assert AmendmentType.DATA_ADDITION is not None
        assert AmendmentType.PROTOCOL_DEVIATION is not None
        assert AmendmentType.PROTOCOL_PARAMETER is not None


class TestAmendmentStatus:
    """Tests for AmendmentStatus enum."""

    def test_amendment_statuses(self):
        """Test amendment status values."""
        from bpl.audit import AmendmentStatus

        assert AmendmentStatus.DRAFT is not None
        assert AmendmentStatus.PENDING_REVIEW is not None
        assert AmendmentStatus.APPROVED is not None
        assert AmendmentStatus.REJECTED is not None


class TestAmendment:
    """Tests for Amendment dataclass."""

    def test_create_amendment(self):
        """Test creating an amendment."""
        from bpl.audit.amendments import Amendment, AmendmentType, AmendmentStatus

        amendment = Amendment(
            amendment_id="amend_001",
            amendment_type=AmendmentType.DATA_CORRECTION,
            description="Corrected volume measurement",
            protocol_id="proto_001",
            reason="Typographical error",
        )

        assert amendment.amendment_id == "amend_001"
        assert amendment.amendment_type == AmendmentType.DATA_CORRECTION
        assert amendment.status == AmendmentStatus.DRAFT

    def test_amendment_approval(self):
        """Test approving an amendment."""
        from bpl.audit.amendments import Amendment, AmendmentType, AmendmentStatus

        amendment = Amendment(
            amendment_id="amend_002",
            amendment_type=AmendmentType.PROTOCOL_DEVIATION,
            description="Changed incubation time",
            protocol_id="proto_002",
            reason="Equipment delay",
            required_approvers=1,
        )

        # Request approval
        amendment.request_approval()
        assert amendment.status == AmendmentStatus.PENDING_REVIEW

        # Approve
        success = amendment.approve(
            signer_id="approver1",
            signer_name="Test Approver",
            signer_role="Supervisor",
        )

        assert success is True
        assert amendment.status == AmendmentStatus.APPROVED

    def test_amendment_rejection(self):
        """Test rejecting an amendment."""
        from bpl.audit.amendments import Amendment, AmendmentType, AmendmentStatus

        amendment = Amendment(
            amendment_id="amend_003",
            amendment_type=AmendmentType.PROTOCOL_PARAMETER,
            description="Change protocol step",
            protocol_id="proto_003",
            reason="Optimization",
        )

        amendment.request_approval()
        amendment.reject(
            reason="Insufficient justification",
            rejector_id="reviewer1",
        )

        assert amendment.status == AmendmentStatus.REJECTED
        assert amendment.metadata["rejection_reason"] == "Insufficient justification"

    def test_amendment_with_original_value(self):
        """Test amendment with original/new values."""
        from bpl.audit.amendments import Amendment, AmendmentType

        amendment = Amendment(
            amendment_id="amend_004",
            amendment_type=AmendmentType.DATA_CORRECTION,
            description="Volume correction",
            protocol_id="proto_004",
            reason="Measurement error",
            original_value="100 uL",
            new_value="150 uL",
        )

        assert amendment.original_value == "100 uL"
        assert amendment.new_value == "150 uL"

    def test_amendment_to_dict(self):
        """Test converting amendment to dictionary."""
        from bpl.audit.amendments import Amendment, AmendmentType

        amendment = Amendment(
            amendment_id="amend_005",
            amendment_type=AmendmentType.DATA_ADDITION,
            description="Additional notes",
            protocol_id="proto_005",
            reason="Missing information",
        )

        data = amendment.to_dict()

        assert data["amendment_id"] == "amend_005"
        assert data["amendment_type"] == "DATA_ADDITION"


class TestAmendmentManager:
    """Tests for AmendmentManager class."""

    def test_create_amendment_manager(self):
        """Test creating an amendment manager."""
        from bpl.audit import AmendmentManager

        manager = AmendmentManager(protocol_id="proto_001")
        assert manager.protocol_id == "proto_001"
        assert len(manager.amendments) == 0

    def test_create_amendment_via_manager(self):
        """Test creating amendments through manager."""
        from bpl.audit import AmendmentManager, AmendmentType

        manager = AmendmentManager(protocol_id="proto_002")

        amendment = manager.create_amendment(
            amendment_type=AmendmentType.DATA_CORRECTION,
            description="Fix value",
            reason="Error",
        )

        assert amendment is not None
        assert len(manager.amendments) == 1

    def test_get_amendment(self):
        """Test retrieving an amendment."""
        from bpl.audit import AmendmentManager, AmendmentType

        manager = AmendmentManager(protocol_id="proto_003")

        created = manager.create_amendment(
            amendment_type=AmendmentType.PROTOCOL_DEVIATION,
            description="Deviation",
            reason="Equipment issue",
        )

        retrieved = manager.get_amendment(created.amendment_id)
        assert retrieved is not None
        assert retrieved.description == "Deviation"

    def test_get_pending_amendments(self):
        """Test filtering amendments by pending status."""
        from bpl.audit import AmendmentManager, AmendmentType

        manager = AmendmentManager(protocol_id="proto_004")

        amend1 = manager.create_amendment(AmendmentType.DATA_CORRECTION, "Fix 1", "Error")
        amend2 = manager.create_amendment(AmendmentType.DATA_CORRECTION, "Fix 2", "Error")

        amend1.request_approval()

        pending = manager.get_pending_amendments()
        assert len(pending) == 2  # Both are pending (DRAFT and PENDING_REVIEW)

    def test_approve_amendment_via_manager(self):
        """Test approving amendments via manager."""
        from bpl.audit import AmendmentManager, AmendmentType, AmendmentStatus

        manager = AmendmentManager(protocol_id="proto_005")

        amendment = manager.create_amendment(
            AmendmentType.DATA_CORRECTION,
            "Fix",
            "Error",
            required_approvers=1
        )
        amendment.request_approval()

        success = manager.approve_amendment(
            amendment.amendment_id,
            "user1",
            "User 1",
            "Supervisor"
        )

        assert success is True
        assert amendment.status == AmendmentStatus.APPROVED


class TestCreateAmendmentFunction:
    """Tests for create_amendment convenience function."""

    def test_create_amendment_function(self):
        """Test the create_amendment helper."""
        from bpl.audit import create_amendment, AmendmentType

        amendment = create_amendment(
            protocol_id="proto_001",
            amendment_type=AmendmentType.DATA_ADDITION,
            description="Additional info",
            reason="Missing data",
        )

        assert amendment is not None
        assert amendment.amendment_type == AmendmentType.DATA_ADDITION


# =============================================================================
# Compliance Tests
# =============================================================================

class TestComplianceLevel:
    """Tests for ComplianceLevel enum."""

    def test_compliance_levels(self):
        """Test compliance level values."""
        from bpl.audit import ComplianceLevel

        assert ComplianceLevel.BASIC is not None
        assert ComplianceLevel.GLP is not None
        assert ComplianceLevel.GMP is not None
        assert ComplianceLevel.FDA_21_CFR_11 is not None


class TestRequirementStatus:
    """Tests for RequirementStatus enum."""

    def test_requirement_statuses(self):
        """Test requirement status values."""
        from bpl.audit import RequirementStatus

        assert RequirementStatus.PASSED is not None
        assert RequirementStatus.FAILED is not None
        assert RequirementStatus.WARNING is not None
        assert RequirementStatus.NOT_APPLICABLE is not None


class TestRequirementResult:
    """Tests for RequirementResult dataclass."""

    def test_create_result(self):
        """Test creating a requirement result."""
        from bpl.audit import RequirementResult, RequirementStatus, RequirementCategory

        result = RequirementResult(
            requirement_id="req_001",
            requirement_name="Chain integrity",
            status=RequirementStatus.PASSED,
            message="All entries verified",
            category=RequirementCategory.AUDIT_TRAIL,
        )

        assert result.requirement_id == "req_001"
        assert result.status == RequirementStatus.PASSED


class TestComplianceReport:
    """Tests for ComplianceReport dataclass."""

    def test_create_report(self):
        """Test creating a compliance report."""
        from bpl.audit import ComplianceReport, ComplianceLevel

        report = ComplianceReport(
            report_id="report_001",
            protocol_id="proto_001",
            compliance_level=ComplianceLevel.BASIC,
        )

        assert report.protocol_id == "proto_001"
        assert report.compliance_level == ComplianceLevel.BASIC

    def test_report_with_results(self):
        """Test report with requirement results."""
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_002",
            protocol_id="proto_001",
            compliance_level=ComplianceLevel.BASIC,
        )

        result1 = RequirementResult(
            requirement_id="req_1",
            requirement_name="Test 1",
            status=RequirementStatus.PASSED,
            message="OK",
            category=RequirementCategory.AUDIT_TRAIL,
        )
        result2 = RequirementResult(
            requirement_id="req_2",
            requirement_name="Test 2",
            status=RequirementStatus.PASSED,
            message="OK",
            category=RequirementCategory.DOCUMENTATION,
        )

        report.add_result(result1)
        report.add_result(result2)

        assert report.total_requirements == 2
        assert report.passed == 2

    def test_report_overall_compliant(self):
        """Test overall compliance calculation."""
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        # All passed - no critical failures
        report_pass = ComplianceReport(
            report_id="report_pass",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report_pass.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report_pass.add_result(RequirementResult(
            "req_2", "Test 2", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report_pass.finalize()
        assert report_pass.overall_compliant is True

        # One critical failure
        report_fail = ComplianceReport(
            report_id="report_fail",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report_fail.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report_fail.add_result(RequirementResult(
            "req_2", "Test 2", RequirementStatus.FAILED, "Failed", RequirementCategory.AUDIT_TRAIL, is_critical=True
        ))
        report_fail.finalize()
        assert report_fail.overall_compliant is False

    def test_report_passed_count(self):
        """Test passed count calculation."""
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_count",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report.add_result(RequirementResult(
            "req_2", "Test 2", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report.add_result(RequirementResult(
            "req_3", "Test 3", RequirementStatus.FAILED, "Failed", RequirementCategory.AUDIT_TRAIL
        ))

        assert report.passed == 2
        assert report.failed == 1

    def test_report_compliance_percentage(self):
        """Test compliance percentage calculation."""
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_pct",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report.add_result(RequirementResult(
            "req_2", "Test 2", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))
        report.add_result(RequirementResult(
            "req_3", "Test 3", RequirementStatus.FAILED, "Failed", RequirementCategory.AUDIT_TRAIL
        ))
        report.add_result(RequirementResult(
            "req_4", "Test 4", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))

        assert report.compliance_percentage == 75.0

    def test_report_to_dict(self):
        """Test converting report to dictionary."""
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_dict",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))

        data = report.to_dict()
        assert data["protocol_id"] == "proto"
        assert data["compliance_level"] == "BASIC"


class TestComplianceChecker:
    """Tests for ComplianceChecker class."""

    def test_create_checker(self):
        """Test creating a compliance checker."""
        from bpl.audit import ComplianceChecker, ComplianceLevel

        checker = ComplianceChecker(level=ComplianceLevel.BASIC)
        assert checker.level == ComplianceLevel.BASIC

    def test_check_basic_compliance(self):
        """Test basic compliance checking."""
        from bpl.audit import ComplianceChecker, ComplianceLevel
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        checker = ComplianceChecker(level=ComplianceLevel.BASIC)

        trail = AuditTrail(
            trail_id="trail_001",
            protocol_id="proto_001",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started", user_id="user1")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1", user_id="user1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Done", user_id="user1")
        trail.add_entry(AuditEventType.PROTOCOL_COMPLETED, "Completed", user_id="user1")

        report = checker.check(trail)

        assert report is not None
        assert report.compliance_level == ComplianceLevel.BASIC

    def test_check_glp_compliance(self):
        """Test GLP compliance checking."""
        from bpl.audit import ComplianceChecker, ComplianceLevel
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        checker = ComplianceChecker(level=ComplianceLevel.GLP)

        trail = AuditTrail(
            trail_id="trail_002",
            protocol_id="proto_002",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started", user_id="user1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Done", user_id="user1")
        trail.add_entry(AuditEventType.PROTOCOL_COMPLETED, "Completed", user_id="user1")

        report = checker.check(trail)

        assert report is not None
        assert report.compliance_level == ComplianceLevel.GLP

    def test_chain_integrity_check(self):
        """Test that chain integrity is checked."""
        from bpl.audit import ComplianceChecker, ComplianceLevel
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        checker = ComplianceChecker(level=ComplianceLevel.BASIC)

        trail = AuditTrail(
            trail_id="trail_003",
            protocol_id="proto_003",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        report = checker.check(trail)

        # Find chain integrity result
        chain_results = [r for r in report.results if "chain" in r.requirement_name.lower()]
        # BASIC level may not have chain check, so this is ok
        assert report is not None


class TestCheckComplianceFunction:
    """Tests for check_compliance convenience function."""

    def test_check_compliance_function(self):
        """Test the check_compliance helper."""
        from bpl.audit import check_compliance, ComplianceLevel
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_001",
            protocol_id="proto_001",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        report = check_compliance(trail, level=ComplianceLevel.BASIC)

        assert report is not None


class TestGetRequirementsForLevel:
    """Tests for get_requirements_for_level function."""

    def test_get_basic_requirements(self):
        """Test getting BASIC requirements."""
        from bpl.audit import get_requirements_for_level, ComplianceLevel

        reqs = get_requirements_for_level(ComplianceLevel.BASIC)
        assert len(reqs) > 0

    def test_get_glp_requirements(self):
        """Test getting GLP requirements."""
        from bpl.audit import get_requirements_for_level, ComplianceLevel

        reqs = get_requirements_for_level(ComplianceLevel.GLP)
        assert len(reqs) > 0

    def test_higher_levels_have_more_requirements(self):
        """Test that higher compliance levels have more requirements."""
        from bpl.audit import get_requirements_for_level, ComplianceLevel

        basic = get_requirements_for_level(ComplianceLevel.BASIC)
        glp = get_requirements_for_level(ComplianceLevel.GLP)
        gmp = get_requirements_for_level(ComplianceLevel.GMP)

        assert len(glp) >= len(basic)
        assert len(gmp) >= len(glp)


# =============================================================================
# Export Tests
# =============================================================================

class TestExportFormat:
    """Tests for ExportFormat enum."""

    def test_export_formats(self):
        """Test export format values."""
        from bpl.audit import ExportFormat

        assert ExportFormat.JSON is not None
        assert ExportFormat.CSV is not None
        assert ExportFormat.HTML is not None
        assert ExportFormat.MARKDOWN is not None
        assert ExportFormat.TEXT is not None


class TestExportOptions:
    """Tests for ExportOptions dataclass."""

    def test_default_options(self):
        """Test default export options."""
        from bpl.audit import ExportOptions, ExportFormat

        options = ExportOptions()

        assert options.format == ExportFormat.JSON
        assert options.include_metadata is True
        assert options.include_summary is True
        assert options.pretty_print is True

    def test_custom_options(self):
        """Test custom export options."""
        from bpl.audit import ExportOptions, ExportFormat

        options = ExportOptions(
            format=ExportFormat.CSV,
            include_chain_hashes=False,
            pretty_print=False,
        )

        assert options.format == ExportFormat.CSV
        assert options.include_chain_hashes is False


class TestExportResult:
    """Tests for ExportResult dataclass."""

    def test_successful_result(self):
        """Test successful export result."""
        from bpl.audit import ExportResult, ExportFormat

        result = ExportResult(
            success=True,
            content="exported data",
            format=ExportFormat.JSON,
            exported_entries=10,
        )

        assert result.success is True
        assert result.exported_entries == 10
        assert len(result.errors) == 0

    def test_failed_result(self):
        """Test failed export result."""
        from bpl.audit import ExportResult, ExportFormat

        result = ExportResult(
            success=False,
            errors=["Export failed: file not found"],
        )

        assert result.success is False
        assert len(result.errors) == 1


class TestAuditExporter:
    """Tests for AuditExporter class."""

    def test_create_exporter(self):
        """Test creating an exporter."""
        from bpl.audit import AuditExporter, ExportOptions

        exporter = AuditExporter()
        assert exporter.options is not None

    def test_export_json(self):
        """Test exporting to JSON."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_001",
            protocol_id="proto_001",
            protocol_name="Test Protocol"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Step done")

        options = ExportOptions(format=ExportFormat.JSON)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        assert result.success is True
        assert result.format == ExportFormat.JSON
        assert result.exported_entries == 2

        # Verify valid JSON
        data = json.loads(result.content)
        assert data["protocol_id"] == "proto_001"

    def test_export_csv(self):
        """Test exporting to CSV."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_002",
            protocol_id="proto_002",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        options = ExportOptions(format=ExportFormat.CSV)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        assert result.success is True
        assert result.format == ExportFormat.CSV
        assert "entry_id" in result.content  # Header
        assert "PROTOCOL_STARTED" in result.content

    def test_export_html(self):
        """Test exporting to HTML."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_003",
            protocol_id="proto_003",
            protocol_name="Test Protocol"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        options = ExportOptions(format=ExportFormat.HTML)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        assert result.success is True
        assert result.format == ExportFormat.HTML
        assert "<html>" in result.content
        assert "Test Protocol" in result.content

    def test_export_markdown(self):
        """Test exporting to Markdown."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_004",
            protocol_id="proto_004",
            protocol_name="Test Protocol"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        options = ExportOptions(format=ExportFormat.MARKDOWN)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        assert result.success is True
        assert result.format == ExportFormat.MARKDOWN
        assert "# Audit Trail:" in result.content

    def test_export_text(self):
        """Test exporting to plain text."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_005",
            protocol_id="proto_005",
            protocol_name="Test Protocol"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        options = ExportOptions(format=ExportFormat.TEXT)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        assert result.success is True
        assert result.format == ExportFormat.TEXT
        assert "AUDIT TRAIL:" in result.content

    def test_export_without_hashes(self):
        """Test exporting without chain hashes."""
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_006",
            protocol_id="proto_006",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        options = ExportOptions(format=ExportFormat.JSON, include_chain_hashes=False)
        exporter = AuditExporter(options)

        result = exporter.export(trail)

        data = json.loads(result.content)
        # Check entries don't have hash fields
        for entry in data.get("entries", []):
            assert "entry_hash" not in entry
            assert "previous_hash" not in entry


class TestExportAuditTrailFunction:
    """Tests for export_audit_trail convenience function."""

    def test_export_audit_trail_function(self):
        """Test the export_audit_trail helper."""
        from bpl.audit import export_audit_trail, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_001",
            protocol_id="proto_001",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        result = export_audit_trail(trail, format=ExportFormat.JSON)

        assert result.success is True


class TestExportToFile:
    """Tests for export_to_file function."""

    def test_export_to_file(self):
        """Test exporting to a file."""
        from bpl.audit import export_to_file, ExportFormat
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_001",
            protocol_id="proto_001",
            protocol_name="Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_path = f.name

        try:
            result = export_to_file(trail, temp_path, format=ExportFormat.JSON)

            assert result.success is True
            assert os.path.exists(temp_path)

            with open(temp_path, 'r') as f:
                content = f.read()
                data = json.loads(content)
                assert data["protocol_id"] == "proto_001"
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)


class TestExportComplianceReport:
    """Tests for export_compliance_report function."""

    def test_export_compliance_json(self):
        """Test exporting compliance report as JSON."""
        from bpl.audit import export_compliance_report, ExportFormat
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_json",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))

        output = export_compliance_report(report, format=ExportFormat.JSON)

        data = json.loads(output)
        assert data["protocol_id"] == "proto"

    def test_export_compliance_markdown(self):
        """Test exporting compliance report as Markdown."""
        from bpl.audit import export_compliance_report, ExportFormat
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_md",
            protocol_id="proto",
            compliance_level=ComplianceLevel.GLP,
        )
        report.add_result(RequirementResult(
            "req_1", "Chain Integrity", RequirementStatus.PASSED, "Valid", RequirementCategory.DATA_INTEGRITY
        ))

        output = export_compliance_report(report, format=ExportFormat.MARKDOWN)

        assert "# Compliance Report:" in output
        assert "GLP" in output
        assert "Chain Integrity" in output

    def test_export_compliance_text(self):
        """Test exporting compliance report as text."""
        from bpl.audit import export_compliance_report, ExportFormat
        from bpl.audit import ComplianceReport, ComplianceLevel, RequirementResult, RequirementStatus, RequirementCategory

        report = ComplianceReport(
            report_id="report_txt",
            protocol_id="proto",
            compliance_level=ComplianceLevel.BASIC,
        )
        report.add_result(RequirementResult(
            "req_1", "Test 1", RequirementStatus.PASSED, "OK", RequirementCategory.AUDIT_TRAIL
        ))

        output = export_compliance_report(report, format=ExportFormat.TEXT)

        assert "COMPLIANCE REPORT:" in output


# =============================================================================
# Integration Tests
# =============================================================================

class TestAuditIntegration:
    """Integration tests for audit trail system."""

    def test_full_protocol_audit(self):
        """Test auditing a complete protocol execution."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_int",
            protocol_id="proto_integration",
            protocol_name="Integration Test"
        )

        # Start protocol
        trail.log_protocol_start(user_id="user1")

        # Execute steps
        for i in range(3):
            step_id = f"step_{i}"
            trail.log_step_started(step_id, f"Step {i}", user_id="user1")
            trail.log_data_recorded(f"measurement_{i}", i * 10.5, user_id="user1")
            trail.log_step_completed(step_id, f"Step {i}", user_id="user1")

        # Complete protocol
        trail.log_protocol_completed(user_id="user1")

        # Verify
        assert len(trail.entries) == 11  # 1 start + 3*(start+data+complete) + 1 end = 1+9+1
        assert trail.verify_chain() is True

    def test_audit_with_amendments(self):
        """Test audit trail with amendments."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType
        from bpl.audit import AmendmentManager, AmendmentType

        trail = AuditTrail(
            trail_id="trail_amend",
            protocol_id="proto_amend",
            protocol_name="Amendment Test"
        )
        manager = AmendmentManager(protocol_id="proto_amend")

        # Log some entries
        trail.log_protocol_start(user_id="user1")
        entry = trail.log_data_recorded("volume", 100.0, user_id="user1")

        # Create amendment for correction
        amendment = manager.create_amendment(
            amendment_type=AmendmentType.DATA_CORRECTION,
            description="Volume correction",
            reason="Measurement error",
            original_value="100.0 uL",
            new_value="150.0 uL",
        )

        # Log amendment in trail
        trail.add_entry(
            AuditEventType.AMENDMENT_REQUESTED,
            f"Amendment created: {amendment.description}",
            data={"amendment_id": amendment.amendment_id},
        )

        assert len(manager.amendments) == 1

    def test_compliance_check_with_export(self):
        """Test compliance checking and export."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType
        from bpl.audit import (
            check_compliance, ComplianceLevel,
            export_audit_trail, export_compliance_report, ExportFormat
        )

        # Create trail with proper entries
        trail = AuditTrail(
            trail_id="trail_comply",
            protocol_id="proto_comply",
            protocol_name="Compliance Test"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started", user_id="user1")
        trail.add_entry(AuditEventType.STEP_STARTED, "Step 1", user_id="user1")
        trail.add_entry(AuditEventType.DATA_RECORDED, "Data", user_id="user1")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Done", user_id="user1")
        trail.add_entry(AuditEventType.PROTOCOL_COMPLETED, "Complete", user_id="user1")

        # Check compliance
        report = check_compliance(trail, level=ComplianceLevel.BASIC)

        # Export both
        trail_export = export_audit_trail(trail, format=ExportFormat.JSON)
        report_export = export_compliance_report(report, format=ExportFormat.MARKDOWN)

        assert trail_export.success is True
        assert "# Compliance Report:" in report_export

    def test_chain_integrity_detection(self):
        """Test that chain verification works."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType

        trail = AuditTrail(
            trail_id="trail_tamper",
            protocol_id="proto_tamper",
            protocol_name="Tamper Test"
        )

        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.STEP_COMPLETED, "Done")

        # Verify before any issues
        assert trail.verify_chain() is True

    def test_multi_format_export(self):
        """Test exporting to multiple formats."""
        from bpl.audit.audit_trail import AuditTrail, AuditEventType
        from bpl.audit import AuditExporter, ExportOptions, ExportFormat

        trail = AuditTrail(
            trail_id="trail_multi",
            protocol_id="proto_multi",
            protocol_name="Multi Export"
        )
        trail.add_entry(AuditEventType.PROTOCOL_STARTED, "Started")
        trail.add_entry(AuditEventType.PROTOCOL_COMPLETED, "Completed")

        formats = [
            ExportFormat.JSON,
            ExportFormat.CSV,
            ExportFormat.HTML,
            ExportFormat.MARKDOWN,
            ExportFormat.TEXT,
        ]

        for fmt in formats:
            options = ExportOptions(format=fmt)
            exporter = AuditExporter(options)
            result = exporter.export(trail)

            assert result.success is True, f"Export to {fmt.name} failed"
            assert result.exported_entries == 2
            assert len(result.content) > 0
