#!/usr/bin/env python3
"""Generate markdown documentation for the column catalog."""

from __future__ import annotations

from typing import cast

from bpl.agentic.column_catalog import (
    DETECTION_COMPATIBILITY,
    PHASE_SELECTIVITY,
    PORE_SIZE_GUIDANCE,
    convert_method,
    get_all_columns,
    get_all_profiles,
    get_column,
    get_profile,
)


def main() -> None:
    lines: list[str] = []
    L = lines.append

    L("# BPL Chromatography Column Catalog & Method Conversion Tool")
    L("")
    L("> Auto-generated documentation for the analytical chromatography tools")
    L("> available to the LLM during BPL SOP-to-protocol generation.")
    L(">")
    L("> Conversion engine implements **2025 Chinese Pharmacopoeia 0512** formulas")
    L("> and **Darcy's law** backpressure estimation.")
    L(">")
    L("> Regenerate this file with: `uv run python scripts/gen_column_docs.py > docs/column_catalog.md`")
    L("")

    # ---- TOC ----
    L("## Table of Contents")
    L("")
    L("1. [Overview](#overview)")
    L("2. [Conversion Formulas](#conversion-formulas)")
    L("3. [Available Tools](#available-tools)")
    L("4. [Column Catalog](#column-catalog)")
    L("5. [Stationary Phase Reference](#stationary-phase-reference)")
    L("6. [Pore Size Guidance](#pore-size-guidance)")
    L("7. [Detection Mode Compatibility](#detection-mode-compatibility)")
    L("8. [Pharmacopoeia Compliance Checks](#pharmacopoeia-compliance-checks)")
    L("9. [Conversion Examples](#conversion-examples)")
    L("10. [API Reference](#api-reference)")
    L("")

    # ---- Overview ----
    L("---")
    L("")
    L("## Overview")
    L("")
    L("The chromatography column catalog provides the BPL generation agent with")
    L("tools to select HPLC/UHPLC analytical columns and compute method parameters")
    L("when converting between columns of different dimensions, particle sizes,")
    L("and stationary phases.")
    L("")
    L("**Key capabilities:**")
    L("")
    L("- **11 pre-registered columns** spanning 8 stationary phases "
       "(C18, C8, C4, Phenyl, Biphenyl, PFP, Amide/HILIC, SCX)")
    L("- **17 supported stationary phase types** with selectivity guidance")
    L("- **8 detection modes** with compatibility checking "
       "(UV, DAD, FLD, RID, ELSD, CAD, MS, MS/MS)")
    L("- **Dynamic column creation** — the LLM can register arbitrary columns at runtime")
    L("- **Full method conversion** with geometric scaling + pharmacopoeia compliance")
    L("- **Backpressure estimation** using Darcy's law")
    L("")

    # ---- Formulas ----
    L("---")
    L("")
    L("## Conversion Formulas")
    L("")
    L("All formulas follow the **2025 Chinese Pharmacopoeia 0512** "
       "(高效液相色谱法通则) guidelines.")
    L("")
    L("### Flow Rate")
    L("")
    L("```")
    L("F2 = F1 * (dc2^2 * dp1) / (dc1^2 * dp2)")
    L("```")
    L("")
    L("Where:")
    L("- F1, F2 = original and converted flow rates (mL/min)")
    L("- dc1, dc2 = original and target column inner diameters (mm)")
    L("- dp1, dp2 = original and target particle sizes (um)")
    L("")
    L("### Injection Volume")
    L("")
    L("```")
    L("Vinj2 = Vinj1 * (L2 * dc2^2) / (L1 * dc1^2)")
    L("```")
    L("")
    L("Where:")
    L("- L1, L2 = original and target column lengths (mm)")
    L("")
    L("### Gradient Time")
    L("")
    L("```")
    L("tG2 = tG1 * (F1 / F2) * (L2 * dc2^2) / (L1 * dc1^2)")
    L("```")
    L("")
    L("### Backpressure (Darcy's Law)")
    L("")
    L("```")
    L("P2/P1 = (F2/F1) * (L2/L1) * (dp1/dp2)^2 * (dc1/dc2)^2")
    L("```")
    L("")
    L("### Column Volume")
    L("")
    L("```")
    L("Vcol = (pi/4) * dc^2 * L")
    L("```")
    L("")
    L("Void volume estimated at 65% porosity (fully porous) or 55% (core-shell).")
    L("")

    # ---- Tools ----
    L("---")
    L("")
    L("## Available Tools")
    L("")
    L("These tools are registered on the Pydantic AI generation agent "
       "and callable by the LLM during BPL generation.")
    L("")
    L("| Tool | Description |")
    L("|------|-------------|")
    L("| `list_columns` | List all columns grouped by stationary phase |")
    L("| `get_column_method` | Detailed specs and method for a specific column |")
    L("| `get_phase_info` | Selectivity guidance for a phase (C18, HILIC, PFP, etc.) |")
    L("| `convert_column_method` | Convert method between columns with ChP 0512 compliance |")
    L("| `create_custom_column` | Register a column with arbitrary specs at runtime |")
    L("| `estimate_backpressure` | Darcy's law pressure ratio between two columns |")
    L("")

    # ---- Column Catalog ----
    L("---")
    L("")
    L("## Column Catalog")
    L("")
    L("### Pre-Registered Columns")
    L("")
    columns = get_all_columns()
    L("| Column ID | Name | Phase | Dimensions | Particle | Packing | Pore | L/dp | Max P |")
    L("|-----------|------|-------|------------|----------|---------|------|------|-------|")
    for col in columns.values():
        profile = get_profile(col.column_id)
        run_info = f" ({profile.method.run_time_min:.1f} min)" if profile else ""
        packing_label = col.packing_type.value.replace("_", " ")
        L(
            f"| `{col.column_id}` | {col.name} | {col.stationary_phase.value} | "
            f"{col.inner_diameter_mm}x{col.length_mm} mm | {col.particle_size_um} um "
            f"({packing_label}) | "
            f"{col.pore_size_angstrom:.0f} A ({col.pore_category.value}) | "
            f"{col.l_over_dp:.0f} | {col.max_pressure_bar:.0f} bar{run_info} |"
        )
    L("")

    # Method profiles
    L("### Columns with Method Profiles")
    L("")
    profiles = get_all_profiles()
    for pid, profile in profiles.items():
        col = profile.column
        m = profile.method
        L(f"#### {col.name} (`{col.column_id}`)")
        L("")
        L(f"- **Description:** {profile.description}")
        L(f"- **Application:** {profile.application}")
        L(f"- **Target analytes:** {', '.join(profile.target_analytes)}")
        L("")
        L("**Column specs:**")
        L("")
        L("| Parameter | Value |")
        L("|-----------|-------|")
        L(f"| Stationary phase | {col.stationary_phase.value} |")
        L(f"| Dimensions | {col.inner_diameter_mm} x {col.length_mm} mm |")
        L(f"| Particle size | {col.particle_size_um} um |")
        L(f"| Packing type | {col.packing_type.value} |")
        L(f"| Pore size | {col.pore_size_angstrom} A ({col.pore_category.value}) |")
        L(f"| L/dp | {col.l_over_dp:.0f} |")
        L(f"| Column volume | {col.column_volume_ul:.1f} uL |")
        L(f"| Void volume | {col.void_volume_ul:.1f} uL |")
        L(f"| Part number | {col.part_number} ({col.vendor}) |")
        L(f"| Max pressure | {col.max_pressure_bar:.0f} bar |")
        L(f"| Max temperature | {col.max_temp_c} C |")
        L(f"| pH range | {col.ph_range[0]}-{col.ph_range[1]} |")
        L("")
        L("**Method parameters:**")
        L("")
        L("| Parameter | Value |")
        L("|-----------|-------|")
        L(f"| Flow rate | {m.flow_rate_ml_min} mL/min |")
        L(f"| Injection volume | {m.injection_volume_ul} uL |")
        L(f"| Column temperature | {m.column_temp_c} C |")
        wl = ", ".join(f"{w:.0f}" for w in m.detection_wavelengths_nm)
        L(f"| Detection | {m.detection_mode.value} at {wl} nm |")
        L(f"| Mobile phase A | {m.mobile_phase_a} |")
        L(f"| Mobile phase B | {m.mobile_phase_b} |")
        L(f'| Elution mode | {"Gradient" if m.is_gradient else "Isocratic"} |')
        L(f"| Run time | {m.run_time_min:.1f} min |")
        L("")
        if m.gradient_table:
            L("**Gradient table:**")
            L("")
            L("| Time (min) | %B |")
            L("|------------|-----|")
            for step in m.gradient_table:
                L(f"| {step.time_min:.2f} | {step.percent_b:.1f} |")
            L("")
        L("")

    # ---- Stationary Phase Reference ----
    L("---")
    L("")
    L("## Stationary Phase Reference")
    L("")
    L("| Phase | Hydrophobicity | Mechanism | Best For | Mobile Phase | pH Range |")
    L("|-------|---------------|-----------|----------|--------------|----------|")
    for phase, info in PHASE_SELECTIVITY.items():
        L(
            f'| **{phase.value}** | {info.get("hydrophobicity", "—")} | '
            f'{info.get("mechanism", "—")} | {info.get("best_for", "—")} | '
            f'{info.get("mobile_phase", "—")} | {info.get("pH_range", "—")} |'
        )
    L("")

    # ---- Pore Size ----
    L("---")
    L("")
    L("## Pore Size Guidance")
    L("")
    L("| Category | Pore Range (A) | Typical (A) | Description |")
    L("|----------|---------------|-------------|-------------|")
    for cat, info in PORE_SIZE_GUIDANCE.items():
        lo, hi = cast(tuple[int, int], info["range_angstrom"])
        L(
            f'| **{cat.value}** | {lo}-{hi} | {info["typical_angstrom"]} '
            f'| {info["description"]} |'
        )
    L("")

    # ---- Detection ----
    L("---")
    L("")
    L("## Detection Mode Compatibility")
    L("")
    L("| Mode | Gradient OK | Destructive | Notes |")
    L("|------|------------|-------------|-------|")
    for mode, info in DETECTION_COMPATIBILITY.items():
        grad = "Yes" if info["gradient_ok"] else "**No**"
        dest = "Yes" if info["destructive"] else "No"
        L(f'| **{mode.value}** | {grad} | {dest} | {info["notes"]} |')
    L("")

    # ---- Pharmacopoeia Checks ----
    L("---")
    L("")
    L("## Pharmacopoeia Compliance Checks")
    L("")
    L("The conversion engine performs the following checks per **ChP 2025 0512**:")
    L("")
    L("| Check | Rule | Severity |")
    L("|-------|------|----------|")
    L("| L/dp ratio | Must stay within -25% to +50% of original | Warning |")
    L("| Stationary phase change | Selectivity and elution order must be preserved | Warning |")
    L("| Packing type change | Verify system suitability after conversion | Warning |")
    L("| Pore category change | May affect retention and mass transfer | Warning |")
    L("| Column temperature | +/-10 C (isocratic), +/-5 C (gradient) | Info |")
    L("| Detection wavelength | Cannot be changed | Info |")
    L("| pH range | Must be within target column's rated pH range | Error |")
    L("| Max temperature | Method temp must not exceed column max | Error |")
    L("| Backpressure | Estimate via Darcy's law; flag if >2x increase | Warning |")
    L("| RID + gradient | Refractive index detector incompatible with gradient | Error |")
    L("| MS flow limit | Flow >0.5 mL/min may exceed MS source capacity | Warning |")
    L("| Buffer concentration | +/-10% of original value | Info |")
    L("")

    # ---- Conversion Examples ----
    L("---")
    L("")
    L("## Conversion Examples")
    L("")

    # Example 1: short -> long
    L("### Example 1: UHPLC Short Column -> Conventional Long Column")
    L("")
    L("**Source:** Phenomenex Kinetex C18, 2.1x50 mm, 1.7 um (core-shell)")
    L("")
    L("**Target:** Agilent ValueLab LC C18, 4.6x250 mm, 5.0 um (fully porous)")
    L("")

    src_profile = get_profile("kinetex-c18-2.1x50-1.7um")
    tgt_col = get_column("valuelab-c18-4.6x250-5um")
    assert src_profile is not None and tgt_col is not None
    result = convert_method(src_profile, tgt_col)
    src_m = src_profile.method
    conv_m = result.converted_method

    L("| Parameter | Source | Converted |")
    L("|-----------|--------|-----------|")
    L(f"| Flow rate | {src_m.flow_rate_ml_min} mL/min | {conv_m.flow_rate_ml_min} mL/min |")
    L(f"| Injection volume | {src_m.injection_volume_ul} uL | {conv_m.injection_volume_ul} uL |")
    L(f"| Column temperature | {src_m.column_temp_c} C | {conv_m.column_temp_c} C |")
    wl = ", ".join(f"{w:.0f}" for w in conv_m.detection_wavelengths_nm)
    L(f"| Detection | DAD at {wl} nm | unchanged |")
    L(f"| Run time | {src_m.run_time_min:.1f} min | {conv_m.run_time_min:.1f} min |")
    L(f"| Speed factor | — | {result.speed_factor:.2f}x |")
    L(f"| Solvent saving | — | {result.solvent_saving_percent:.0f}% |")
    L(f"| Pressure ratio | — | {result.estimated_pressure_ratio:.2f}x |")
    L("")

    L("**Gradient conversion:**")
    L("")
    L("| Source Time (min) | Converted Time (min) | %B |")
    L("|-------------------|----------------------|-----|")
    for s, c in zip(src_m.gradient_table, conv_m.gradient_table):
        L(f"| {s.time_min:.2f} | {c.time_min:.2f} | {c.percent_b:.1f} |")
    L("")

    L("**Compliance warnings:**")
    L("")
    for w in result.warnings:
        L(f"- **[{w.severity.upper()}]** `{w.parameter}` — {w.message}")
    L("")

    # Example 2: long -> short
    L("### Example 2: Conventional Long Column -> UHPLC Short Column")
    L("")
    L("**Source:** Agilent ValueLab LC C18, 4.6x250 mm, 5.0 um")
    L("")
    L("**Target:** Phenomenex Kinetex C18, 2.1x50 mm, 1.7 um")
    L("")

    src_profile2 = get_profile("valuelab-c18-4.6x250-5um")
    tgt_col2 = get_column("kinetex-c18-2.1x50-1.7um")
    assert src_profile2 is not None and tgt_col2 is not None
    result2 = convert_method(src_profile2, tgt_col2)
    src_m2 = src_profile2.method
    conv_m2 = result2.converted_method

    L("| Parameter | Source | Converted |")
    L("|-----------|--------|-----------|")
    L(f"| Flow rate | {src_m2.flow_rate_ml_min} mL/min | {conv_m2.flow_rate_ml_min} mL/min |")
    L(f"| Injection volume | {src_m2.injection_volume_ul} uL | {conv_m2.injection_volume_ul} uL |")
    L(f"| Column temperature | {src_m2.column_temp_c} C | {conv_m2.column_temp_c} C |")
    L(f"| Run time | {src_m2.run_time_min:.1f} min | {conv_m2.run_time_min:.1f} min |")
    L(f"| Speed factor | — | {result2.speed_factor:.2f}x |")
    L(f"| Solvent saving | — | {result2.solvent_saving_percent:.0f}% |")
    L(f"| Pressure ratio | — | {result2.estimated_pressure_ratio:.2f}x |")
    L("")

    L("**Gradient conversion:**")
    L("")
    L("| Source Time (min) | Converted Time (min) | %B |")
    L("|-------------------|----------------------|-----|")
    for s, c in zip(src_m2.gradient_table, conv_m2.gradient_table):
        L(f"| {s.time_min:.2f} | {c.time_min:.2f} | {c.percent_b:.1f} |")
    L("")

    L("**Compliance warnings:**")
    L("")
    for w in result2.warnings:
        L(f"- **[{w.severity.upper()}]** `{w.parameter}` — {w.message}")
    L("")

    # ---- API Reference ----
    L("---")
    L("")
    L("## API Reference")
    L("")
    L("### Python API")
    L("")
    L("```python")
    L("from bpl.agentic import (")
    L("    # Data models")
    L("    ColumnSpec, MethodParams, ColumnMethodProfile, GradientStep,")
    L("    MethodConversionResult, ConversionWarning,")
    L("    # Enums")
    L("    StationaryPhase, PackingType, DetectionMode,")
    L("    # Registry")
    L("    get_all_columns, get_column, get_all_profiles, get_profile,")
    L("    register_column, register_column_profile,")
    L("    # Conversion")
    L("    convert_method,")
    L(")")
    L("")
    L('# Look up a column')
    L('col = get_column("kinetex-c18-2.1x50-1.7um")')
    L("")
    L("# Get a method profile")
    L('profile = get_profile("kinetex-c18-2.1x50-1.7um")')
    L("")
    L("# Convert method to a different column")
    L('target = get_column("valuelab-c18-4.6x250-5um")')
    L("result = convert_method(profile, target)")
    L("print(result.converted_method.flow_rate_ml_min)")
    L("print(result.warnings)")
    L("")
    L("# Register a custom column")
    L("my_col = ColumnSpec(")
    L('    column_id="my-c18",')
    L('    name="My Custom C18",')
    L("    stationary_phase=StationaryPhase.C18,")
    L("    inner_diameter_mm=3.0,")
    L("    length_mm=150,")
    L("    particle_size_um=3.5,")
    L("    pore_size_angstrom=120,")
    L("    packing_type=PackingType.FULLY_POROUS,")
    L(")")
    L("register_column(my_col)")
    L("```")
    L("")
    L("### LLM Tool Signatures")
    L("")
    L("```")
    L("list_columns() -> str")
    L("get_column_method(column_id: str) -> str")
    L("get_phase_info(stationary_phase: str) -> str")
    L("convert_column_method(source_column_id: str, target_column_id: str) -> str")
    L("create_custom_column(column_id, name, stationary_phase, inner_diameter_mm,")
    L("    length_mm, particle_size_um, pore_size_angstrom, packing_type,")
    L('    vendor="", part_number="", max_pressure_bar=0.0) -> str')
    L("estimate_backpressure(source_column_id, target_column_id,")
    L("    source_flow_ml_min=0.0) -> str")
    L("```")
    L("")
    L("---")
    L("")
    L("*Source files:* `bpl/agentic/column_catalog.py`, `bpl/agentic/workflow.py`")
    L("")
    L("*Tests:* `tests/test_column_catalog.py` (61 tests)")
    L("")
    L("*Formulas reference:* 2025 Chinese Pharmacopoeia 0512 (HPLC); "
       "Agilent 5994-8817ZHCN")

    print("\n".join(lines))


if __name__ == "__main__":
    main()
