"""Run the BPL paper-level reproducibility workflow.

This script is intentionally offline: it does not call model APIs, fetch raw
papers, or require private SOPs. It verifies the public compiler package,
generates example compiler artifacts, recomputes the shipped benchmark summary,
and optionally runs the test/type/build checks used for the paper code package.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from typing import Any

from bpl import __version__ as bpl_version

REPO_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_ROOT = REPO_ROOT / "paper_artifacts"
EXAMPLE_INPUT = REPO_ROOT / "examples" / "minimal_protocol.bpl"

EVAL_DIR = REPO_ROOT / "tools" / "bpl_eval"
EVAL_REDRAW_SCRIPT = EVAL_DIR / "redraw_publication_figures.py"
EVAL_FIG_DIR = EVAL_DIR / "figures" / "publication_redraw"

# tools/bpl_eval/ is not a Python package on the install path; bootstrap it
# so we can call into compute_determinism.py without a subprocess.
sys.path.insert(0, str(EVAL_DIR))
from compute_determinism import compute_determinism  # noqa: E402
from method_translation import write_translation as write_method_translation  # noqa: E402
from sensitivity_analysis import run_sensitivity  # noqa: E402
EVAL_EXPECTED_FIGS = (
    "fig1_pipeline_architecture",
    "fig2_benchmark_validation",
    "fig2a_llm_validation_scores",
    "fig3_structural_determinism",
    "fig4_compiler_diagnostics",
    "fig5_wetlab_validation",
    "fig6_language_design",
    "fig7_corpus_quality_assurance",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the offline BPL paper reproducibility workflow."
    )
    parser.add_argument(
        "--artifact-dir",
        type=Path,
        default=ARTIFACT_ROOT,
        help="Directory for generated reproducibility artifacts.",
    )
    parser.add_argument("--skip-tests", action="store_true", help="Skip pytest.")
    parser.add_argument("--skip-pyright", action="store_true", help="Skip pyright.")
    parser.add_argument("--skip-build", action="store_true", help="Skip package build.")
    parser.add_argument(
        "--skip-eval-figs",
        action="store_true",
        help="Skip regeneration of paper figures from the frozen evaluation artifacts.",
    )
    return parser.parse_args()


def rel(path: Path) -> str:
    return str(path.relative_to(REPO_ROOT))


def run_command(
    name: str,
    args: list[str],
    *,
    log_dir: Path,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    start = time.perf_counter()
    completed = subprocess.run(
        args,
        cwd=REPO_ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    duration = time.perf_counter() - start

    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / f"{name}.stdout.log"
    stderr_path = log_dir / f"{name}.stderr.log"
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)

    record: dict[str, Any] = {
        "name": name,
        "command": args,
        "exit_code": completed.returncode,
        "duration_seconds": round(duration, 3),
        "stdout_log": rel(stdout_path),
        "stderr_log": rel(stderr_path),
    }
    if completed.returncode != 0:
        record["status"] = "failed"
    else:
        record["status"] = "passed"
    return record


def parse_last_json_line(text: str) -> dict[str, Any] | None:
    for line in reversed(text.splitlines()):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            value = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def run_bplc(
    name: str,
    args: list[str],
    *,
    log_dir: Path,
) -> dict[str, Any]:
    command = [sys.executable, "-m", "bpl.cli.main", *args]
    record = run_command(name, command, log_dir=log_dir)
    stdout = (log_dir / f"{name}.stdout.log").read_text()
    manifest = parse_last_json_line(stdout)
    if manifest is not None:
        record["cli_manifest"] = manifest
    return record


def build_env() -> dict[str, str]:
    env = os.environ.copy()
    repo_path = str(REPO_ROOT)
    current = env.get("PYTHONPATH")
    env["PYTHONPATH"] = repo_path if not current else f"{repo_path}{os.pathsep}{current}"
    return env


def run_workflow(args: argparse.Namespace) -> dict[str, Any]:
    artifact_dir = args.artifact_dir.resolve()
    example_dir = artifact_dir / "example"
    benchmark_dir = artifact_dir / "benchmark"
    log_dir = artifact_dir / "logs"
    dist_dir = artifact_dir / "dist"

    artifact_dir.mkdir(parents=True, exist_ok=True)
    example_dir.mkdir(parents=True, exist_ok=True)
    benchmark_dir.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "repository": str(REPO_ROOT),
        "python": {
            "executable": sys.executable,
            "version": sys.version,
            "implementation": platform.python_implementation(),
            "platform": platform.platform(),
        },
        "bpl_version": bpl_version,
        "offline": True,
        "commands": [],
        "artifacts": {
            "artifact_dir": rel(artifact_dir),
            "example_dir": rel(example_dir),
            "benchmark_dir": rel(benchmark_dir),
            "logs_dir": rel(log_dir),
        },
    }

    bplc_commands: list[tuple[str, list[str]]] = [
        (
            "bplc-check",
            ["check", str(EXAMPLE_INPUT), "--quiet"],
        ),
        (
            "bplc-parse",
            [
                "parse",
                str(EXAMPLE_INPUT),
                "--format",
                "json",
                "--out",
                str(example_dir / "minimal.ast.json"),
                "--quiet",
            ],
        ),
        (
            "bplc-lower",
            [
                "lower",
                str(EXAMPLE_INPUT),
                "--target",
                "human",
                "--out",
                str(example_dir / "minimal.plan.json"),
                "--quiet",
            ],
        ),
        (
            "bplc-validate",
            ["validate", str(EXAMPLE_INPUT), "--target", "human", "--quiet"],
        ),
        (
            "bplc-simulate",
            [
                "simulate",
                "--input-bpl",
                str(EXAMPLE_INPUT),
                "--trace",
                str(example_dir / "minimal.trace.json"),
                "--quiet",
            ],
        ),
        (
            "bplc-export",
            [
                "export",
                "--input-bpl",
                str(EXAMPLE_INPUT),
                "--format",
                "csv",
                "--out",
                str(example_dir / "minimal.worklist.csv"),
                "--quiet",
            ],
        ),
        (
            "bplc-graph",
            [
                "graph",
                "--input-bpl",
                str(EXAMPLE_INPUT),
                "--format",
                "json",
                "--out",
                str(example_dir / "minimal.graph.json"),
                "--quiet",
            ],
        ),
    ]
    for name, command_args in bplc_commands:
        manifest["commands"].append(run_bplc(name, command_args, log_dir=log_dir))

    benchmark_out = benchmark_dir / "determinism_results.json"
    start = time.perf_counter()
    determinism = compute_determinism(out_path=benchmark_out)
    summary = determinism["summary"]
    coverage = summary.get("coverage", {})
    benchmark_record: dict[str, Any] = {
        "determinism_results": rel(benchmark_out),
        "n_papers": summary["n_papers"],
        "identical_all_runs_pct": summary["identical_all_runs_pct"],
        "mean_step_count_range": summary["mean_step_count_range"],
        "mean_match_vs_digest_pct": summary["mean_match_vs_digest_pct"],
        "coverage_n_papers": coverage.get("n_papers"),
        "coverage_total_scored_variants": coverage.get("total_scored_variants"),
        "coverage_papers_with_nonstandard_variant_count": len(
            coverage.get("papers_with_nonstandard_variant_count", []) or []
        ),
        "duration_seconds": round(time.perf_counter() - start, 3),
    }
    # Headline-value sanity check — the figure-3 panel and the manuscript
    # prose claim ≥98% identical-runs, ≥99% mean match-vs-digest, and a
    # mean step-count range below 1. Threshold values must stay aligned
    # with the figure label and the README; tightening them here surfaces
    # any silent drift in the shipped data immediately.
    headline_violations: list[str] = []
    if summary["n_papers"] < 300:
        headline_violations.append(
            f"n_papers={summary['n_papers']} (expected ≥ 300)"
        )
    if summary["identical_all_runs_pct"] < 98.0:
        headline_violations.append(
            f"identical_all_runs_pct={summary['identical_all_runs_pct']:.2f}"
            " (expected ≥ 98)"
        )
    if summary["mean_match_vs_digest_pct"] < 99.0:
        headline_violations.append(
            f"mean_match_vs_digest_pct={summary['mean_match_vs_digest_pct']:.2f}"
            " (expected ≥ 99)"
        )
    if summary["mean_step_count_range"] >= 1.0:
        headline_violations.append(
            f"mean_step_count_range={summary['mean_step_count_range']:.3f}"
            " (expected < 1.0)"
        )
    # LLM-judge coverage from per_paper records — independent of the regex
    # consistency report, so drift in either side is caught. Missing values
    # are treated as a violation: silently passing on absent coverage was a
    # round-4 regression.
    coverage_n = coverage.get("n_papers")
    coverage_variants = coverage.get("total_scored_variants")
    if coverage_n is None:
        headline_violations.append(
            "coverage.n_papers missing from determinism summary"
        )
    elif coverage_n < 300:
        headline_violations.append(
            f"coverage_n_papers={coverage_n} (expected ≥ 300)"
        )
    if coverage_variants is None:
        headline_violations.append(
            "coverage.total_scored_variants missing from determinism summary"
        )
    elif coverage_variants < 2900:
        headline_violations.append(
            f"coverage_total_scored_variants={coverage_variants} (expected ≥ 2900)"
        )
    benchmark_record["headline_violations"] = headline_violations
    manifest["benchmark"] = benchmark_record
    if headline_violations:
        manifest["commands"].append(
            {
                "name": "benchmark-headline-check",
                "command": ["verify-headline-values"],
                "exit_code": 1,
                "duration_seconds": 0.0,
                "status": "failed",
                "error": "; ".join(headline_violations),
            }
        )

    # Methods §103 sensitivity analysis (44-triplet grid under the weak-
    # ordering interpretation; paper reports 47 — see
    # tools/bpl_eval/sensitivity_analysis.py docstring for the convention).
    sens_start = time.perf_counter()
    sens_out = benchmark_dir / "sensitivity_results.json"
    sens_result = run_sensitivity(out_path=sens_out)
    sens_metrics = sens_result["summary"]["metrics"]
    paper_sens = sens_result["summary"]["paper_claimed_bounds"]
    sens_record: dict[str, Any] = {
        "sensitivity_results": rel(sens_out),
        "n_triplets": sens_result["summary"]["n_triplets"],
        "mean_overall_range": [
            round(sens_metrics["mean_overall"]["min"], 3),
            round(sens_metrics["mean_overall"]["max"], 3),
        ],
        "median_overall_range": [
            round(sens_metrics["median_overall"]["min"], 3),
            round(sens_metrics["median_overall"]["max"], 3),
        ],
        "frac_ge_80_pct_range": [
            round(sens_metrics["frac_ge_80_pct"]["min"], 3),
            round(sens_metrics["frac_ge_80_pct"]["max"], 3),
        ],
        "mean_paper_std_range": [
            round(sens_metrics["mean_paper_std"]["min"], 3),
            round(sens_metrics["mean_paper_std"]["max"], 3),
        ],
        "duration_seconds": round(time.perf_counter() - sens_start, 3),
    }
    sens_violations: list[str] = []
    if sens_metrics["mean_overall"]["min"] < paper_sens["mean_overall_min"] - 1.0:
        sens_violations.append(
            f"mean_overall_min={sens_metrics['mean_overall']['min']:.2f} below paper "
            f"{paper_sens['mean_overall_min']} − 1"
        )
    if sens_metrics["mean_overall"]["max"] > paper_sens["mean_overall_max"] + 1.0:
        sens_violations.append(
            f"mean_overall_max={sens_metrics['mean_overall']['max']:.2f} above paper "
            f"{paper_sens['mean_overall_max']} + 1"
        )
    if sens_metrics["frac_ge_80_pct"]["min"] < 97.0:
        sens_violations.append(
            f"frac_ge_80_pct_min={sens_metrics['frac_ge_80_pct']['min']:.2f} below 97"
        )
    sens_record["violations"] = sens_violations
    manifest["sensitivity"] = sens_record
    if sens_violations:
        manifest["commands"].append(
            {
                "name": "sensitivity-check",
                "command": ["verify-sensitivity-bounds"],
                "exit_code": 1,
                "duration_seconds": 0.0,
                "status": "failed",
                "error": "; ".join(sens_violations),
            }
        )

    # Fig 5 HPLC→UHPLC method-translation reproducer.
    method_start = time.perf_counter()
    method_out = benchmark_dir / "method_translation.json"
    method_summary = write_method_translation(out_path=method_out)
    method_record: dict[str, Any] = {
        "method_translation": rel(method_out),
        "translated_flow_ml_min": method_summary["translation"]["flow_rate_ml_min"],
        "translated_run_time_min": method_summary["translation"]["run_time_min"],
        "warning_count": method_summary["warning_count"],
        "duration_seconds": round(time.perf_counter() - method_start, 3),
    }
    method_violations: list[str] = []
    paper_flow = method_summary["paper_claims"]["flow_rate_ml_min"]
    if abs(method_summary["translation"]["flow_rate_ml_min"] - paper_flow) > 1e-2:
        method_violations.append(
            f"flow_rate {method_summary['translation']['flow_rate_ml_min']} "
            f"≠ paper {paper_flow}"
        )
    paper_warn = method_summary["paper_claims"]["warning_count"]
    if method_summary["warning_count"] != paper_warn:
        method_violations.append(
            f"warning_count={method_summary['warning_count']} "
            f"≠ paper {paper_warn}"
        )
    method_record["violations"] = method_violations
    manifest["method_translation"] = method_record
    if method_violations:
        manifest["commands"].append(
            {
                "name": "method-translation-check",
                "command": ["verify-method-translation"],
                "exit_code": 1,
                "duration_seconds": 0.0,
                "status": "failed",
                "error": "; ".join(method_violations),
            }
        )

    env = build_env()

    if not args.skip_eval_figs:
        manifest["commands"].append(
            run_command(
                "eval-figures",
                [sys.executable, str(EVAL_REDRAW_SCRIPT)],
                log_dir=log_dir,
                env=env,
            )
        )
        rendered: dict[str, dict[str, Any]] = {}
        for stem in EVAL_EXPECTED_FIGS:
            entry: dict[str, Any] = {}
            for ext in ("pdf", "png"):
                fig_path = EVAL_FIG_DIR / f"{stem}.{ext}"
                if fig_path.exists() and fig_path.stat().st_size > 0:
                    entry[ext] = {
                        "path": rel(fig_path),
                        "bytes": fig_path.stat().st_size,
                    }
            rendered[stem] = entry
        missing = [
            f"{stem}.{ext}"
            for stem, entry in rendered.items()
            for ext in ("pdf", "png")
            if ext not in entry
        ]
        manifest["eval_figures"] = {
            "output_dir": rel(EVAL_FIG_DIR),
            "expected": list(EVAL_EXPECTED_FIGS),
            "rendered": rendered,
            "missing": missing,
        }
        if missing:
            manifest["commands"].append(
                {
                    "name": "eval-figures-verify",
                    "command": ["verify-fig-artifacts"],
                    "exit_code": 1,
                    "duration_seconds": 0,
                    "status": "failed",
                    "error": f"missing figure artifacts: {', '.join(missing)}",
                }
            )
    if not args.skip_tests:
        manifest["commands"].append(
            run_command(
                "pytest",
                [sys.executable, "-m", "pytest"],
                log_dir=log_dir,
                env=env,
            )
        )

    pyright_path = shutil.which("pyright")
    if not args.skip_pyright:
        if pyright_path is None:
            manifest["commands"].append(
                {
                    "name": "pyright",
                    "command": ["pyright"],
                    "exit_code": 127,
                    "duration_seconds": 0,
                    "status": "failed",
                    "error": "pyright executable not found in PATH",
                }
            )
        else:
            manifest["commands"].append(
                run_command("pyright", [pyright_path], log_dir=log_dir, env=env)
            )

    if not args.skip_build:
        uv_path = shutil.which("uv")
        dist_dir.mkdir(parents=True, exist_ok=True)
        if uv_path is None:
            manifest["commands"].append(
                {
                    "name": "uv-build",
                    "command": ["uv", "build", "--out-dir", str(dist_dir)],
                    "exit_code": 127,
                    "duration_seconds": 0,
                    "status": "failed",
                    "error": "uv executable not found in PATH",
                }
            )
        else:
            manifest["commands"].append(
                run_command(
                    "uv-build",
                    [uv_path, "build", "--out-dir", str(dist_dir)],
                    log_dir=log_dir,
                    env=env,
                )
            )
            manifest["artifacts"]["dist_dir"] = rel(dist_dir)

    failures = [cmd for cmd in manifest["commands"] if cmd["exit_code"] != 0]
    manifest["status"] = "failed" if failures else "passed"
    manifest["failed_commands"] = [cmd["name"] for cmd in failures]

    manifest_path = artifact_dir / "reproducibility_manifest.json"
    manifest["artifacts"]["manifest"] = rel(manifest_path)
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return manifest


def main() -> int:
    args = parse_args()
    manifest = run_workflow(args)
    manifest_path = manifest["artifacts"]["manifest"]
    if manifest["status"] == "passed":
        print(f"PASS paper reproducibility workflow: {manifest_path}")
        bench = manifest["benchmark"]
        print(
            "Benchmark: "
            f"{bench['n_papers']} papers, "
            f"identical_all_runs={bench['identical_all_runs_pct']:.2f}%, "
            f"match_vs_digest={bench['mean_match_vs_digest_pct']:.2f}%, "
            f"mean_range={bench['mean_step_count_range']:.3f}"
        )
        return 0

    print(f"FAIL paper reproducibility workflow: {manifest_path}", file=sys.stderr)
    print(
        "Failed commands: " + ", ".join(manifest["failed_commands"]),
        file=sys.stderr,
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
