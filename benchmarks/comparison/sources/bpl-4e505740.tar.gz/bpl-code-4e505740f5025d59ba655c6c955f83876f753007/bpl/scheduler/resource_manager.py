"""
BPL Resource Manager - Tracks and books shared resources.

Manages:
- Resource definitions and capacities
- Resource booking and release
- Cooldown periods
- Conflict detection
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple
from enum import Enum, auto
from datetime import datetime, timedelta


class ResourceType(Enum):
    """Types of resources."""
    PIPETTE_CHANNEL = auto()  # Single or multi-channel
    TIP_RACK = auto()
    PLATE_POSITION = auto()
    INCUBATOR = auto()
    SHAKER = auto()
    CENTRIFUGE = auto()
    PLATE_READER = auto()
    BALANCE = auto()
    THERMAL_CYCLER = auto()
    GRIPPER = auto()


class ResourceState(Enum):
    """State of a resource."""
    AVAILABLE = auto()
    IN_USE = auto()
    RESERVED = auto()
    COOLDOWN = auto()
    OFFLINE = auto()


@dataclass
class Resource:
    """Definition of a shared resource."""
    resource_id: str
    resource_type: ResourceType
    capacity: int = 1  # Number of concurrent uses
    cooldown_seconds: float = 0.0  # Cooldown after use
    position: Optional[str] = None  # Deck position if applicable

    # State tracking
    current_users: Set[str] = field(default_factory=set)
    state: ResourceState = ResourceState.AVAILABLE
    last_used: Optional[datetime] = None
    reserved_by: Optional[str] = None
    reserved_until: Optional[datetime] = None

    @property
    def is_available(self) -> bool:
        """Check if resource is available for use."""
        if self.state in [ResourceState.OFFLINE, ResourceState.COOLDOWN]:
            return False
        if self.state == ResourceState.RESERVED:
            return False
        return len(self.current_users) < self.capacity


@dataclass
class ResourceBooking:
    """A booking for a resource."""
    booking_id: str
    resource_id: str
    step_id: str
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration_estimate_s: Optional[float] = None


class ResourceConflictError(Exception):
    """Raised when a resource conflict occurs."""
    pass


class ResourceNotFoundError(Exception):
    """Raised when a resource is not found."""
    pass


class ResourceManager:
    """
    Manages shared resources for protocol execution.

    Handles resource booking, release, and conflict detection.
    """

    def __init__(self):
        self.resources: Dict[str, Resource] = {}
        self.bookings: Dict[str, ResourceBooking] = {}
        self._booking_counter = 0

    def register_resource(self, resource: Resource) -> None:
        """Register a resource with the manager."""
        self.resources[resource.resource_id] = resource

    def register_resources(self, resources: List[Resource]) -> None:
        """Register multiple resources."""
        for resource in resources:
            self.register_resource(resource)

    def get_resource(self, resource_id: str) -> Resource:
        """Get a resource by ID."""
        if resource_id not in self.resources:
            raise ResourceNotFoundError(f"Resource not found: {resource_id}")
        return self.resources[resource_id]

    def is_available(self, resource_id: str) -> bool:
        """Check if a resource is available."""
        resource = self.get_resource(resource_id)
        return resource.is_available

    def acquire(self, resource_id: str, step_id: str) -> ResourceBooking:
        """
        Acquire a resource for a step.

        Raises ResourceConflictError if not available.
        """
        resource = self.get_resource(resource_id)

        if not resource.is_available:
            raise ResourceConflictError(
                f"Resource {resource_id} is not available. "
                f"State: {resource.state.name}, "
                f"Users: {resource.current_users}"
            )

        # Add user
        resource.current_users.add(step_id)
        if len(resource.current_users) >= resource.capacity:
            resource.state = ResourceState.IN_USE

        # Create booking
        self._booking_counter += 1
        booking = ResourceBooking(
            booking_id=f"booking_{self._booking_counter}",
            resource_id=resource_id,
            step_id=step_id,
            start_time=datetime.now()
        )
        self.bookings[booking.booking_id] = booking

        return booking

    def release(self, resource_id: str, step_id: str) -> None:
        """Release a resource."""
        resource = self.get_resource(resource_id)

        if step_id in resource.current_users:
            resource.current_users.remove(step_id)
            resource.last_used = datetime.now()

            # Enter cooldown if specified
            if resource.cooldown_seconds > 0:
                resource.state = ResourceState.COOLDOWN
            elif len(resource.current_users) == 0:
                resource.state = ResourceState.AVAILABLE
            else:
                resource.state = ResourceState.IN_USE

    def reserve(
        self,
        resource_id: str,
        step_id: str,
        duration_s: Optional[float] = None
    ) -> None:
        """Reserve a resource for future use."""
        resource = self.get_resource(resource_id)

        if not resource.is_available:
            raise ResourceConflictError(
                f"Cannot reserve {resource_id}: not available"
            )

        resource.state = ResourceState.RESERVED
        resource.reserved_by = step_id
        if duration_s:
            resource.reserved_until = datetime.now() + timedelta(seconds=duration_s)

    def unreserve(self, resource_id: str) -> None:
        """Cancel a reservation."""
        resource = self.get_resource(resource_id)
        resource.state = ResourceState.AVAILABLE
        resource.reserved_by = None
        resource.reserved_until = None

    def update_cooldowns(self) -> None:
        """Update resources in cooldown state."""
        now = datetime.now()
        for resource in self.resources.values():
            if resource.state == ResourceState.COOLDOWN and resource.last_used:
                elapsed = (now - resource.last_used).total_seconds()
                if elapsed >= resource.cooldown_seconds:
                    resource.state = ResourceState.AVAILABLE

    def get_available_resources(
        self,
        resource_type: Optional[ResourceType] = None
    ) -> List[Resource]:
        """Get all available resources, optionally filtered by type."""
        available = []
        for resource in self.resources.values():
            if resource.is_available:
                if resource_type is None or resource.resource_type == resource_type:
                    available.append(resource)
        return available

    def get_resources_by_type(self, resource_type: ResourceType) -> List[Resource]:
        """Get all resources of a given type."""
        return [
            r for r in self.resources.values()
            if r.resource_type == resource_type
        ]

    def check_conflict(
        self,
        required_resources: List[str]
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if all required resources are available.

        Returns:
            (all_available, first_conflict_resource_id or None)
        """
        for resource_id in required_resources:
            if not self.is_available(resource_id):
                return (False, resource_id)
        return (True, None)

    def acquire_all(
        self,
        resource_ids: List[str],
        step_id: str
    ) -> List[ResourceBooking]:
        """
        Acquire multiple resources atomically.

        Either all are acquired or none are.
        """
        # First check all available
        available, conflict = self.check_conflict(resource_ids)
        if not available:
            raise ResourceConflictError(
                f"Cannot acquire all resources: {conflict} is not available"
            )

        # Acquire all
        bookings = []
        for resource_id in resource_ids:
            booking = self.acquire(resource_id, step_id)
            bookings.append(booking)

        return bookings

    def release_all(self, resource_ids: List[str], step_id: str) -> None:
        """Release multiple resources."""
        for resource_id in resource_ids:
            self.release(resource_id, step_id)

    def get_current_usage(self) -> Dict[str, List[str]]:
        """Get current resource usage map."""
        usage = {}
        for resource_id, resource in self.resources.items():
            if resource.current_users:
                usage[resource_id] = list(resource.current_users)
        return usage

    def reset(self) -> None:
        """Reset all resources to available state."""
        for resource in self.resources.values():
            resource.current_users.clear()
            resource.state = ResourceState.AVAILABLE
            resource.reserved_by = None
            resource.reserved_until = None
        self.bookings.clear()
