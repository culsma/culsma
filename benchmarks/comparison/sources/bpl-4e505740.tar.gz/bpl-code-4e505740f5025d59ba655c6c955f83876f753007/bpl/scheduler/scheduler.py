"""
BPL Scheduler - Schedules execution plan steps.

Provides multiple scheduling strategies:
- Greedy: First-come first-served
- Time-window: Respects time constraints
- Critical path: Optimizes for shortest total time
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple
from enum import Enum, auto
from datetime import datetime, timedelta

from ..lowering import ExecutionPlan, PlanStep, PrimitiveType
from .resource_manager import ResourceManager
from .deck_state import DeckStateManager


class SchedulingStrategy(Enum):
    """Available scheduling strategies."""
    GREEDY = auto()           # Simple first-available
    TIME_WINDOW = auto()      # Respects time windows
    CRITICAL_PATH = auto()    # Optimizes total time


@dataclass
class ScheduledStep:
    """A scheduled step with timing information."""
    step: PlanStep
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    estimated_duration_s: float = 0.0
    required_resources: List[str] = field(default_factory=list)
    priority: int = 0


@dataclass
class ScheduleResult:
    """Result of scheduling an execution plan."""
    success: bool
    scheduled_steps: List[ScheduledStep]
    total_estimated_time_s: float
    parallel_opportunities: int
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class SchedulerError(Exception):
    """Error during scheduling."""
    pass


class Scheduler:
    """
    Schedules execution plan steps for optimal execution.

    Considers:
    - Step dependencies
    - Resource availability
    - Time constraints
    - Parallelization opportunities
    """

    def __init__(
        self,
        resource_manager: Optional[ResourceManager] = None,
        deck_manager: Optional[DeckStateManager] = None,
        strategy: SchedulingStrategy = SchedulingStrategy.GREEDY
    ):
        self.resource_manager = resource_manager or ResourceManager()
        self.deck_manager = deck_manager
        self.strategy = strategy

        # Duration estimates for primitives (in seconds)
        self._duration_estimates: Dict[PrimitiveType, float] = {
            PrimitiveType.ASPIRATE: 2.0,
            PrimitiveType.DISPENSE: 2.0,
            PrimitiveType.MIX: 10.0,
            PrimitiveType.PICK_TIPS: 3.0,
            PrimitiveType.DROP_TIPS: 2.0,
            PrimitiveType.MOVE_LABWARE: 5.0,
            PrimitiveType.SEAL_PLATE: 10.0,
            PrimitiveType.UNSEAL_PLATE: 10.0,
            PrimitiveType.READ_ABSORBANCE: 30.0,
            PrimitiveType.READ_FLUORESCENCE: 60.0,
            PrimitiveType.WEIGH: 15.0,
            PrimitiveType.SET_TEMPERATURE: 5.0,
            PrimitiveType.INCUBATE: 3600.0,  # Placeholder, actual from step
            PrimitiveType.CENTRIFUGE: 600.0,
            PrimitiveType.HUMAN_STEP: 60.0,
            PrimitiveType.PAUSE: 30.0,
            PrimitiveType.RESUME: 5.0,
            PrimitiveType.WAIT: 0.0,  # Actual from step
            PrimitiveType.CHECKPOINT: 1.0,
        }

    def estimate_duration(self, step: PlanStep) -> float:
        """Estimate duration of a step in seconds."""
        ptype = step.primitive.primitive_type
        base = self._duration_estimates.get(ptype, 5.0)

        # Adjust for specific primitives that have duration_s attribute
        if ptype == PrimitiveType.WAIT:
            return getattr(step.primitive, 'duration_s', base)
        if ptype == PrimitiveType.INCUBATE:
            return getattr(step.primitive, 'duration_s', base)
        if ptype == PrimitiveType.HUMAN_STEP:
            expected_time = getattr(step.primitive, 'expected_time_s', None)
            if expected_time is not None:
                return expected_time

        return base

    def get_required_resources(self, step: PlanStep) -> List[str]:
        """Determine resources required by a step."""
        resources = []
        ptype = step.primitive.primitive_type

        # Pipetting requires pipette channel
        if ptype in [PrimitiveType.ASPIRATE, PrimitiveType.DISPENSE, PrimitiveType.MIX]:
            resources.append("pipette_channel_1")

        # Plate reader
        if ptype in [PrimitiveType.READ_ABSORBANCE, PrimitiveType.READ_FLUORESCENCE]:
            resources.append("plate_reader")

        # Incubation
        if ptype == PrimitiveType.INCUBATE:
            device_id = getattr(step.primitive, 'device_id', 'incubator')
            resources.append(device_id)

        # Centrifuge
        if ptype == PrimitiveType.CENTRIFUGE:
            device_id = getattr(step.primitive, 'device_id', 'centrifuge')
            resources.append(device_id)

        # Gripper for labware movement
        if ptype == PrimitiveType.MOVE_LABWARE:
            resources.append("gripper")

        return resources

    def schedule_greedy(self, plan: ExecutionPlan) -> ScheduleResult:
        """
        Schedule using greedy strategy.

        Executes steps as soon as their dependencies are met.
        """
        scheduled: List[ScheduledStep] = []
        completed: Set[str] = set()
        errors: List[str] = []
        warnings: List[str] = []

        # Get topological order
        order = plan.topological_order()

        current_time = datetime.now()
        total_time = 0.0

        for step_id in order:
            step = plan.steps[step_id]

            # Create scheduled step
            duration = self.estimate_duration(step)
            resources = self.get_required_resources(step)

            scheduled_step = ScheduledStep(
                step=step,
                scheduled_start=current_time,
                scheduled_end=current_time + timedelta(seconds=duration),
                estimated_duration_s=duration,
                required_resources=resources
            )

            # Check resource availability
            if resources:
                available, conflict = self.resource_manager.check_conflict(resources)
                if not available:
                    warnings.append(
                        f"Step {step_id} may conflict on resource {conflict}"
                    )

            scheduled.append(scheduled_step)
            completed.add(step_id)
            total_time += duration
            current_time += timedelta(seconds=duration)

        # Count parallel opportunities
        parallel_ops = self._count_parallel_opportunities(plan)

        return ScheduleResult(
            success=True,
            scheduled_steps=scheduled,
            total_estimated_time_s=total_time,
            parallel_opportunities=parallel_ops,
            errors=errors,
            warnings=warnings
        )

    def schedule_time_window(self, plan: ExecutionPlan) -> ScheduleResult:
        """
        Schedule with time-window awareness.

        Respects time constraints and allows parallel execution.
        """
        scheduled: List[ScheduledStep] = []
        step_end_times: Dict[str, datetime] = {}
        errors: List[str] = []
        warnings: List[str] = []

        current_time = datetime.now()

        # Build dependency graph
        order = plan.topological_order()

        for step_id in order:
            step = plan.steps[step_id]

            # Determine earliest start time (after all dependencies)
            earliest_start = current_time
            for dep_id in step.dependencies:
                if dep_id in step_end_times:
                    dep_end = step_end_times[dep_id]
                    if dep_end > earliest_start:
                        earliest_start = dep_end

            duration = self.estimate_duration(step)
            resources = self.get_required_resources(step)

            scheduled_step = ScheduledStep(
                step=step,
                scheduled_start=earliest_start,
                scheduled_end=earliest_start + timedelta(seconds=duration),
                estimated_duration_s=duration,
                required_resources=resources
            )

            scheduled.append(scheduled_step)
            if scheduled_step.scheduled_end is not None:
                step_end_times[step_id] = scheduled_step.scheduled_end

        # Calculate total time (max end time - start)
        if step_end_times:
            max_end = max(step_end_times.values())
            total_time = (max_end - current_time).total_seconds()
        else:
            total_time = 0.0

        parallel_ops = self._count_parallel_opportunities(plan)

        return ScheduleResult(
            success=True,
            scheduled_steps=scheduled,
            total_estimated_time_s=total_time,
            parallel_opportunities=parallel_ops,
            errors=errors,
            warnings=warnings
        )

    def schedule(self, plan: ExecutionPlan) -> ScheduleResult:
        """Schedule plan using configured strategy."""
        if self.strategy == SchedulingStrategy.GREEDY:
            return self.schedule_greedy(plan)
        elif self.strategy == SchedulingStrategy.TIME_WINDOW:
            return self.schedule_time_window(plan)
        else:
            return self.schedule_greedy(plan)

    def _count_parallel_opportunities(self, plan: ExecutionPlan) -> int:
        """Count how many steps could run in parallel."""
        # Steps with no shared dependencies can run in parallel
        parallel_count = 0

        for step_id, step in plan.steps.items():
            # Count steps with no dependencies that could run together
            if not step.dependencies:
                parallel_count += 1

        return max(0, parallel_count - 1)  # Subtract 1 since at least one runs

    def validate_schedule(
        self,
        result: ScheduleResult
    ) -> Tuple[bool, List[str]]:
        """
        Validate schedule correctness, conflicts, and deadlock risks.

        Returns:
            (is_valid, list of issues)
        """
        issues: List[str] = []
        issues.extend(self._validate_dependency_order(result.scheduled_steps))
        issues.extend(self._validate_resource_overlap_conflicts(result.scheduled_steps))
        issues.extend(self._detect_deadlock_risk_diagnostics(result.scheduled_steps))
        deterministic_issues = sorted(set(issues))
        return (len(deterministic_issues) == 0, deterministic_issues)

    def _validate_dependency_order(self, scheduled_steps: List[ScheduledStep]) -> List[str]:
        """Validate that each step starts after all dependency steps complete."""
        issues: List[str] = []
        if not scheduled_steps:
            return issues

        step_map = {scheduled.step.step_id: scheduled for scheduled in scheduled_steps}
        schedule_index = {
            scheduled.step.step_id: index
            for index, scheduled in enumerate(scheduled_steps)
        }

        for scheduled in scheduled_steps:
            step_id = scheduled.step.step_id
            for dependency in sorted(set(scheduled.step.dependencies)):
                dep_scheduled = step_map.get(dependency)
                if dep_scheduled is None:
                    issues.append(
                        "SCHEDULE_DEPENDENCY_MISSING: "
                        f"step '{step_id}' depends on missing scheduled step '{dependency}'."
                    )
                    continue

                if (
                    dep_scheduled.scheduled_end is not None
                    and scheduled.scheduled_start is not None
                    and dep_scheduled.scheduled_end > scheduled.scheduled_start
                ):
                    issues.append(
                        "SCHEDULE_DEPENDENCY_ORDER_VIOLATION: "
                        f"step '{step_id}' starts before dependency '{dependency}' completes."
                    )
                    continue

                if schedule_index[dependency] > schedule_index[step_id]:
                    issues.append(
                        "SCHEDULE_DEPENDENCY_ORDER_VIOLATION: "
                        f"step '{step_id}' is scheduled before dependency '{dependency}'."
                    )

        return issues

    def _validate_resource_overlap_conflicts(
        self,
        scheduled_steps: List[ScheduledStep],
    ) -> List[str]:
        """Validate overlaps on exclusive resources."""
        issues: List[str] = []
        for left, right in _iter_overlapping_pairs(scheduled_steps):
            shared_resources = sorted(
                set(left.required_resources) & set(right.required_resources)
            )
            for resource in shared_resources:
                issues.append(
                    "SCHEDULE_RESOURCE_OVERLAP_CONFLICT: "
                    f"steps '{left.step.step_id}' and '{right.step.step_id}' overlap "
                    f"on exclusive resource '{resource}'."
                )
        return issues

    def _detect_deadlock_risk_diagnostics(
        self,
        scheduled_steps: List[ScheduledStep],
    ) -> List[str]:
        """
        Detect deadlock-risk diagnostics via wait-for/resource-order analysis.

        If overlapping steps acquire the same resource set in conflicting order,
        they can produce a wait-for cycle in runtime.
        """
        issues: List[str] = []
        for left, right in _iter_overlapping_pairs(scheduled_steps):
            shared_resources = sorted(
                set(left.required_resources) & set(right.required_resources)
            )
            if len(shared_resources) < 2:
                continue

            left_order = sorted(
                shared_resources,
                key=lambda resource: left.required_resources.index(resource),
            )
            right_order = sorted(
                shared_resources,
                key=lambda resource: right.required_resources.index(resource),
            )
            if left_order == right_order:
                continue

            issues.append(
                "SCHEDULE_DEADLOCK_RISK: "
                f"steps '{left.step.step_id}' and '{right.step.step_id}' acquire shared "
                f"resources in conflicting order {left_order} vs {right_order}."
            )
        return issues

    def optimize_for_parallelism(
        self,
        plan: ExecutionPlan
    ) -> ExecutionPlan:
        """
        Restructure plan to maximize parallel execution.

        Returns a new plan with optimized dependencies.
        """
        # This is a placeholder for more sophisticated optimization
        # For now, just return the original plan
        return plan


def create_scheduler(
    strategy: str = "greedy",
    resource_manager: Optional[ResourceManager] = None
) -> Scheduler:
    """Factory function to create a scheduler."""
    strategy_map = {
        "greedy": SchedulingStrategy.GREEDY,
        "time_window": SchedulingStrategy.TIME_WINDOW,
        "critical_path": SchedulingStrategy.CRITICAL_PATH,
    }

    strat = strategy_map.get(strategy.lower(), SchedulingStrategy.GREEDY)
    return Scheduler(resource_manager=resource_manager, strategy=strat)


def _iter_overlapping_pairs(
    scheduled_steps: List[ScheduledStep],
) -> List[Tuple[ScheduledStep, ScheduledStep]]:
    """Return deterministic pairs of steps with overlapping execution windows."""
    overlapping_pairs: List[Tuple[ScheduledStep, ScheduledStep]] = []
    ordered = sorted(
        scheduled_steps,
        key=lambda scheduled: (
            scheduled.scheduled_start.isoformat() if scheduled.scheduled_start else "",
            scheduled.step.step_id,
        ),
    )
    for index, left in enumerate(ordered):
        if left.scheduled_start is None or left.scheduled_end is None:
            continue
        for right in ordered[index + 1:]:
            if right.scheduled_start is None or right.scheduled_end is None:
                continue
            if _windows_overlap(
                left.scheduled_start,
                left.scheduled_end,
                right.scheduled_start,
                right.scheduled_end,
            ):
                overlapping_pairs.append((left, right))
    return overlapping_pairs


def _windows_overlap(
    left_start: datetime,
    left_end: datetime,
    right_start: datetime,
    right_end: datetime,
) -> bool:
    """True when two [start, end) windows overlap."""
    return left_start < right_end and right_start < left_end
