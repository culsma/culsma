"""
BPL Tip Optimizer - Optimizes tip usage and tracks consumption.

Features:
- Tip usage tracking
- Tip reuse strategies
- Waste capacity management
- Tip consumption estimation
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from enum import Enum, auto


class TipSize(Enum):
    """Tip volume sizes."""
    P10 = 10       # 0.5-10 uL
    P20 = 20       # 2-20 uL
    P50 = 50       # 5-50 uL
    P200 = 200     # 20-200 uL
    P300 = 300     # 20-300 uL
    P1000 = 1000   # 100-1000 uL


class TipReuseStrategy(Enum):
    """Strategies for tip reuse."""
    NEVER = auto()           # Always new tip (safest)
    SAME_SOURCE = auto()     # Reuse for same source
    SAME_REAGENT = auto()    # Reuse for same reagent type
    SERIAL_DILUTION = auto() # Reuse through dilution series
    AGGRESSIVE = auto()       # Maximum reuse (caution)


@dataclass
class TipRack:
    """A tip rack on the deck."""
    rack_id: str
    tip_size: TipSize
    rows: int = 8
    cols: int = 12
    tips_used: int = 0
    tips_remaining: Optional[int] = None

    def __post_init__(self):
        if self.tips_remaining is None:
            self.tips_remaining = self.rows * self.cols

    @property
    def capacity(self) -> int:
        return self.rows * self.cols

    @property
    def is_empty(self) -> bool:
        return (self.tips_remaining or 0) <= 0

    def use_tips(self, count: int = 1) -> bool:
        """Use tips from rack. Returns True if successful."""
        remaining = self.tips_remaining or 0
        if remaining >= count:
            self.tips_remaining = remaining - count
            self.tips_used += count
            return True
        return False

    def get_next_tip_position(self) -> Optional[str]:
        """Get the next available tip position."""
        if self.is_empty:
            return None

        # Calculate which tip is next (column-major order)
        tip_index = self.tips_used
        row = tip_index % self.rows
        col = tip_index // self.rows

        row_letter = chr(ord('A') + row)
        return f"{row_letter}{col + 1}"


@dataclass
class TipWaste:
    """Tip waste container."""
    waste_id: str
    capacity: int = 768  # Standard tip waste capacity
    current_count: int = 0

    @property
    def remaining_capacity(self) -> int:
        return self.capacity - self.current_count

    @property
    def is_full(self) -> bool:
        return self.current_count >= self.capacity

    def add_tips(self, count: int) -> bool:
        """Add tips to waste. Returns True if successful."""
        if self.current_count + count <= self.capacity:
            self.current_count += count
            return True
        return False


@dataclass
class TipUsageRecord:
    """Record of tip usage for a step."""
    step_id: str
    tips_used: int
    tip_size: TipSize
    rack_id: str
    reused: bool = False


class TipError(Exception):
    """Error related to tip handling."""
    pass


class TipOptimizer:
    """
    Optimizes tip usage during protocol execution.

    Tracks:
    - Available tip racks
    - Tips used per step
    - Tip waste capacity
    - Reuse opportunities
    """

    def __init__(
        self,
        strategy: TipReuseStrategy = TipReuseStrategy.NEVER
    ):
        self.strategy = strategy
        self.tip_racks: Dict[str, TipRack] = {}
        self.tip_waste: Optional[TipWaste] = None
        self.usage_history: List[TipUsageRecord] = []

        # Tracking for reuse decisions
        self._current_tip_source: Optional[str] = None
        self._current_tip_reagent: Optional[str] = None
        self._tips_on_pipette: int = 0

    def add_tip_rack(self, rack: TipRack) -> None:
        """Add a tip rack."""
        self.tip_racks[rack.rack_id] = rack

    def set_waste(self, waste: TipWaste) -> None:
        """Set the tip waste container."""
        self.tip_waste = waste

    def get_rack(self, rack_id: str) -> TipRack:
        """Get a tip rack by ID."""
        if rack_id not in self.tip_racks:
            raise TipError(f"Tip rack not found: {rack_id}")
        return self.tip_racks[rack_id]

    def find_rack_for_volume(self, volume_ul: float) -> Optional[TipRack]:
        """Find a non-empty rack suitable for the given volume."""
        suitable = []
        for rack in self.tip_racks.values():
            if not rack.is_empty and rack.tip_size.value >= volume_ul:
                suitable.append(rack)

        if not suitable:
            return None

        # Prefer smallest suitable tip
        suitable.sort(key=lambda r: r.tip_size.value)
        return suitable[0]

    def should_reuse_tip(
        self,
        source_id: str,
        reagent_id: Optional[str] = None
    ) -> bool:
        """
        Determine if current tip should be reused.

        Based on strategy and current tip state.
        """
        if self._tips_on_pipette == 0:
            return False

        if self.strategy == TipReuseStrategy.NEVER:
            return False

        if self.strategy == TipReuseStrategy.SAME_SOURCE:
            return source_id == self._current_tip_source

        if self.strategy == TipReuseStrategy.SAME_REAGENT:
            return reagent_id == self._current_tip_reagent

        if self.strategy == TipReuseStrategy.SERIAL_DILUTION:
            # Allow reuse for dilution series
            return True

        if self.strategy == TipReuseStrategy.AGGRESSIVE:
            return True

        return False

    def pick_tips(
        self,
        step_id: str,
        count: int = 1,
        rack_id: Optional[str] = None,
        volume_ul: Optional[float] = None
    ) -> Tuple[str, List[str]]:
        """
        Pick tips for a step.

        Returns:
            (rack_id, list of tip positions)
        """
        # Find appropriate rack
        if rack_id:
            rack = self.get_rack(rack_id)
        elif volume_ul:
            rack = self.find_rack_for_volume(volume_ul)
            if not rack:
                raise TipError(f"No suitable tips for {volume_ul} uL")
        else:
            # Use first non-empty rack
            rack = next(
                (r for r in self.tip_racks.values() if not r.is_empty),
                None
            )
            if not rack:
                raise TipError("No tips available")

        # Check availability
        remaining = rack.tips_remaining or 0
        if remaining < count:
            raise TipError(
                f"Not enough tips in {rack.rack_id}: "
                f"need {count}, have {remaining}"
            )

        # Get positions and use tips
        positions = []
        for _ in range(count):
            pos = rack.get_next_tip_position()
            if pos:
                positions.append(pos)
            rack.use_tips(1)

        self._tips_on_pipette = count

        # Record usage
        record = TipUsageRecord(
            step_id=step_id,
            tips_used=count,
            tip_size=rack.tip_size,
            rack_id=rack.rack_id
        )
        self.usage_history.append(record)

        return (rack.rack_id, positions)

    def drop_tips(self, count: Optional[int] = None) -> None:
        """Drop current tips to waste."""
        if count is None:
            count = self._tips_on_pipette

        if self.tip_waste:
            if not self.tip_waste.add_tips(count):
                raise TipError("Tip waste is full")

        self._tips_on_pipette = 0
        self._current_tip_source = None
        self._current_tip_reagent = None

    def set_current_source(
        self,
        source_id: str,
        reagent_id: Optional[str] = None
    ) -> None:
        """Set the current source for reuse tracking."""
        self._current_tip_source = source_id
        self._current_tip_reagent = reagent_id

    def get_total_tips_used(self) -> int:
        """Get total tips used so far."""
        return sum(r.tips_used for r in self.usage_history)

    def get_tips_remaining(self) -> Dict[str, int]:
        """Get tips remaining per rack."""
        return {
            rack_id: rack.tips_remaining or 0
            for rack_id, rack in self.tip_racks.items()
        }

    def get_waste_capacity_remaining(self) -> int:
        """Get remaining waste capacity."""
        if self.tip_waste:
            return self.tip_waste.remaining_capacity
        # Return a large value when no waste tracking (effectively unlimited)
        return 2**31 - 1

    def estimate_tips_needed(
        self,
        num_transfers: int,
        reuse_factor: float = 1.0
    ) -> int:
        """
        Estimate tips needed for a set of transfers.

        Args:
            num_transfers: Number of transfers
            reuse_factor: Expected reuse (1.0 = no reuse, 0.5 = 50% reuse)
        """
        return int(num_transfers * reuse_factor)

    def check_sufficient_tips(
        self,
        tips_needed: int,
        tip_size: Optional[TipSize] = None
    ) -> Tuple[bool, str]:
        """
        Check if there are sufficient tips for a protocol.

        Returns:
            (is_sufficient, message)
        """
        total_available = 0
        for rack in self.tip_racks.values():
            if tip_size is None or rack.tip_size == tip_size:
                total_available += rack.tips_remaining or 0

        if total_available >= tips_needed:
            return (True, f"{total_available} tips available, {tips_needed} needed")
        else:
            return (False, f"Insufficient tips: {total_available} available, {tips_needed} needed")

    def check_waste_capacity(self, tips_to_dispose: int) -> Tuple[bool, str]:
        """Check if waste can handle the tips."""
        if not self.tip_waste:
            return (True, "No waste tracking")

        if self.tip_waste.remaining_capacity >= tips_to_dispose:
            return (True, f"Waste can hold {tips_to_dispose} more tips")
        else:
            return (
                False,
                f"Waste capacity insufficient: {self.tip_waste.remaining_capacity} "
                f"available, {tips_to_dispose} needed"
            )

    def reset(self) -> None:
        """Reset optimizer state."""
        self._tips_on_pipette = 0
        self._current_tip_source = None
        self._current_tip_reagent = None
        self.usage_history.clear()
