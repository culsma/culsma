"""
BPL Deck State Manager - Tracks labware positions on deck.

Manages:
- Deck position definitions
- Labware placement and tracking
- Position conflict detection
- Labware movement
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Set
from enum import Enum, auto


class Footprint(Enum):
    """Standard labware footprints."""
    SBS_STANDARD = auto()   # Standard 96/384 well plate footprint
    SBS_HALF = auto()       # Half-size footprint
    RESERVOIR = auto()      # Single/multi-well reservoir
    TUBE_RACK = auto()      # Tube rack
    TIP_RACK = auto()       # Tip rack
    CUSTOM = auto()         # Non-standard


@dataclass
class DeckPosition:
    """A position on the robot deck."""
    position_id: str
    x: float  # X coordinate
    y: float  # Y coordinate
    z: float  # Z coordinate
    accepts: List[Footprint] = field(default_factory=lambda: [Footprint.SBS_STANDARD])
    occupied_by: Optional[str] = None  # Labware ID
    accessible_by: Set[str] = field(default_factory=set)  # Channel IDs

    @property
    def is_occupied(self) -> bool:
        return self.occupied_by is not None


@dataclass
class LabwareInstance:
    """An instance of labware on the deck."""
    labware_id: str
    labware_type: str
    footprint: Footprint
    position_id: Optional[str] = None
    rows: int = 8
    cols: int = 12

    @property
    def is_placed(self) -> bool:
        return self.position_id is not None


class DeckPositionError(Exception):
    """Error related to deck positions."""
    pass


class DeckStateManager:
    """
    Manages the state of the robot deck.

    Tracks:
    - Available deck positions
    - Placed labware
    - Labware movements
    """

    def __init__(self):
        self.positions: Dict[str, DeckPosition] = {}
        self.labware: Dict[str, LabwareInstance] = {}
        self._movement_history: List[Tuple[str, str, str]] = []  # (labware, from, to)

    def add_position(self, position: DeckPosition) -> None:
        """Add a deck position."""
        self.positions[position.position_id] = position

    def add_positions(self, positions: List[DeckPosition]) -> None:
        """Add multiple deck positions."""
        for pos in positions:
            self.add_position(pos)

    def register_labware(self, labware: LabwareInstance) -> None:
        """Register a labware instance."""
        self.labware[labware.labware_id] = labware

    def get_position(self, position_id: str) -> DeckPosition:
        """Get a position by ID."""
        if position_id not in self.positions:
            raise DeckPositionError(f"Position not found: {position_id}")
        return self.positions[position_id]

    def get_labware(self, labware_id: str) -> LabwareInstance:
        """Get labware by ID."""
        if labware_id not in self.labware:
            raise DeckPositionError(f"Labware not found: {labware_id}")
        return self.labware[labware_id]

    def place_labware(
        self,
        labware_id: str,
        position_id: str
    ) -> None:
        """
        Place labware at a deck position.

        Raises DeckPositionError if position is occupied or incompatible.
        """
        position = self.get_position(position_id)
        labware = self.get_labware(labware_id)

        # Check if position is occupied
        if position.is_occupied:
            raise DeckPositionError(
                f"Position {position_id} is occupied by {position.occupied_by}"
            )

        # Check footprint compatibility
        if labware.footprint not in position.accepts:
            raise DeckPositionError(
                f"Position {position_id} does not accept {labware.footprint.name}"
            )

        # If labware was somewhere else, clear that position
        if labware.position_id:
            old_position = self.positions.get(labware.position_id)
            if old_position:
                old_position.occupied_by = None

        # Place labware
        position.occupied_by = labware_id
        labware.position_id = position_id

    def remove_labware(self, labware_id: str) -> None:
        """Remove labware from deck."""
        labware = self.get_labware(labware_id)

        if labware.position_id:
            position = self.positions.get(labware.position_id)
            if position:
                position.occupied_by = None
            labware.position_id = None

    def move_labware(
        self,
        labware_id: str,
        to_position: str
    ) -> None:
        """
        Move labware from current position to new position.

        Records movement in history.
        """
        labware = self.get_labware(labware_id)
        from_position = labware.position_id or "off_deck"

        # Remove from current position
        if labware.position_id:
            self.remove_labware(labware_id)

        # Place at new position
        self.place_labware(labware_id, to_position)

        # Record movement
        self._movement_history.append((labware_id, from_position, to_position))

    def get_available_positions(
        self,
        footprint: Optional[Footprint] = None
    ) -> List[DeckPosition]:
        """Get all available (unoccupied) positions."""
        available = []
        for pos in self.positions.values():
            if not pos.is_occupied:
                if footprint is None or footprint in pos.accepts:
                    available.append(pos)
        return available

    def get_labware_at(self, position_id: str) -> Optional[LabwareInstance]:
        """Get the labware at a position, if any."""
        position = self.get_position(position_id)
        if position.occupied_by:
            return self.labware.get(position.occupied_by)
        return None

    def find_labware_position(self, labware_id: str) -> Optional[str]:
        """Find the current position of a labware."""
        labware = self.labware.get(labware_id)
        if labware:
            return labware.position_id
        return None

    def check_position_conflict(
        self,
        labware_id: str,
        position_id: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if placing labware at position would conflict.

        Returns:
            (has_conflict, conflicting_labware_id or None)
        """
        position = self.get_position(position_id)
        labware = self.get_labware(labware_id)

        # Check if occupied by different labware
        if position.is_occupied and position.occupied_by != labware_id:
            return (True, position.occupied_by)

        # Check footprint
        if labware.footprint not in position.accepts:
            return (True, None)

        return (False, None)

    def get_deck_layout(self) -> Dict[str, Optional[str]]:
        """Get current deck layout as position -> labware mapping."""
        layout = {}
        for pos_id, pos in self.positions.items():
            layout[pos_id] = pos.occupied_by
        return layout

    def get_movement_history(self) -> List[Tuple[str, str, str]]:
        """Get movement history."""
        return list(self._movement_history)

    def clear_history(self) -> None:
        """Clear movement history."""
        self._movement_history.clear()

    def reset(self) -> None:
        """Reset deck state (all labware off-deck)."""
        for pos in self.positions.values():
            pos.occupied_by = None
        for lw in self.labware.values():
            lw.position_id = None
        self._movement_history.clear()

    def validate_deck_state(self) -> Tuple[bool, List[str]]:
        """
        Validate the current deck state.

        Returns:
            (is_valid, list of error messages)
        """
        errors = []

        # Check for position/labware consistency
        for pos_id, pos in self.positions.items():
            if pos.occupied_by:
                labware = self.labware.get(pos.occupied_by)
                if not labware:
                    errors.append(f"Position {pos_id} claims {pos.occupied_by} but labware not found")
                elif labware.position_id != pos_id:
                    errors.append(f"Position {pos_id} and labware {pos.occupied_by} disagree on placement")

        # Check labware positions
        for lw_id, lw in self.labware.items():
            if lw.position_id:
                pos = self.positions.get(lw.position_id)
                if not pos:
                    errors.append(f"Labware {lw_id} at unknown position {lw.position_id}")
                elif pos.occupied_by != lw_id:
                    errors.append(f"Labware {lw_id} claims {lw.position_id} but position says {pos.occupied_by}")

        return (len(errors) == 0, errors)


def create_standard_deck(num_positions: int = 12) -> DeckStateManager:
    """Create a standard deck layout with numbered positions."""
    manager = DeckStateManager()

    for i in range(1, num_positions + 1):
        position = DeckPosition(
            position_id=f"slot_{i}",
            x=float((i - 1) % 4) * 100,
            y=float((i - 1) // 4) * 100,
            z=0.0,
            accepts=[Footprint.SBS_STANDARD, Footprint.TIP_RACK, Footprint.RESERVOIR]
        )
        manager.add_position(position)

    return manager
