"""
BPL Deadlock Detection - Detects and prevents resource deadlocks.

Features:
- Resource acquisition graph
- Cycle detection
- Ordered acquisition enforcement
- Timeout-based recovery
"""

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Tuple
from enum import Enum, auto
from datetime import datetime


class DeadlockState(Enum):
    """State of deadlock detection."""
    SAFE = auto()       # No deadlock risk
    AT_RISK = auto()    # Potential deadlock detected
    DEADLOCKED = auto() # Confirmed deadlock


@dataclass
class WaitingStep:
    """A step waiting for resources."""
    step_id: str
    waiting_for: Set[str]  # Resource IDs
    holding: Set[str]      # Resources currently held
    wait_start: datetime = field(default_factory=datetime.now)
    timeout_s: float = 60.0


@dataclass
class DeadlockInfo:
    """Information about a detected deadlock."""
    steps_involved: List[str]
    resources_involved: List[str]
    cycle: List[str]  # Step IDs forming the cycle
    detection_time: datetime = field(default_factory=datetime.now)


class DeadlockError(Exception):
    """Raised when a deadlock is detected."""
    def __init__(self, message: str, info: Optional[DeadlockInfo] = None):
        super().__init__(message)
        self.info = info


class DeadlockDetector:
    """
    Detects and prevents resource deadlocks.

    Uses:
    - Wait-for graph analysis
    - Cycle detection
    - Ordered acquisition
    """

    def __init__(
        self,
        enable_ordered_acquisition: bool = True,
        default_timeout_s: float = 60.0
    ):
        self.enable_ordered_acquisition = enable_ordered_acquisition
        self.default_timeout_s = default_timeout_s

        # Current state
        self.waiting_steps: Dict[str, WaitingStep] = {}
        self.resource_holders: Dict[str, str] = {}  # resource_id -> step_id
        self.resource_order: List[str] = []  # Canonical ordering

        # History
        self.detected_deadlocks: List[DeadlockInfo] = []

    def set_resource_order(self, resources: List[str]) -> None:
        """
        Set the canonical order for resource acquisition.

        Resources should always be acquired in this order to prevent deadlocks.
        """
        self.resource_order = resources

    def register_acquisition(
        self,
        step_id: str,
        resource_id: str
    ) -> None:
        """Register that a step has acquired a resource."""
        self.resource_holders[resource_id] = step_id

        # Remove from waiting if applicable
        if step_id in self.waiting_steps:
            waiting = self.waiting_steps[step_id]
            waiting.waiting_for.discard(resource_id)
            waiting.holding.add(resource_id)
            if not waiting.waiting_for:
                del self.waiting_steps[step_id]

    def register_release(
        self,
        step_id: str,
        resource_id: str
    ) -> None:
        """Register that a step has released a resource."""
        if self.resource_holders.get(resource_id) == step_id:
            del self.resource_holders[resource_id]

    def register_wait(
        self,
        step_id: str,
        waiting_for: Set[str],
        holding: Set[str],
        timeout_s: Optional[float] = None
    ) -> None:
        """Register that a step is waiting for resources."""
        self.waiting_steps[step_id] = WaitingStep(
            step_id=step_id,
            waiting_for=waiting_for,
            holding=holding,
            timeout_s=timeout_s or self.default_timeout_s
        )

    def clear_wait(self, step_id: str) -> None:
        """Clear wait status for a step."""
        self.waiting_steps.pop(step_id, None)

    def check_deadlock(self) -> Tuple[DeadlockState, Optional[DeadlockInfo]]:
        """
        Check for deadlock in current state.

        Returns:
            (state, deadlock_info if deadlocked)
        """
        # Build wait-for graph
        # edge: step A -> step B means A is waiting for a resource held by B
        wait_for: Dict[str, Set[str]] = {}

        for step_id, waiting in self.waiting_steps.items():
            wait_for[step_id] = set()
            for resource_id in waiting.waiting_for:
                holder = self.resource_holders.get(resource_id)
                if holder and holder != step_id:
                    wait_for[step_id].add(holder)

        # Detect cycle using DFS
        cycle = self._detect_cycle(wait_for)

        if cycle:
            # Get involved resources
            resources_involved = set()
            for step_id in cycle:
                if step_id in self.waiting_steps:
                    resources_involved.update(self.waiting_steps[step_id].waiting_for)
                    resources_involved.update(self.waiting_steps[step_id].holding)

            info = DeadlockInfo(
                steps_involved=list(cycle),
                resources_involved=list(resources_involved),
                cycle=list(cycle)
            )
            self.detected_deadlocks.append(info)

            return (DeadlockState.DEADLOCKED, info)

        # Check for at-risk (long waits)
        now = datetime.now()
        for step_id, waiting in self.waiting_steps.items():
            elapsed = (now - waiting.wait_start).total_seconds()
            if elapsed > waiting.timeout_s * 0.5:
                return (DeadlockState.AT_RISK, None)

        return (DeadlockState.SAFE, None)

    def _detect_cycle(self, graph: Dict[str, Set[str]]) -> Optional[List[str]]:
        """Detect cycle in directed graph using DFS."""
        visited = set()
        rec_stack = set()
        path = []

        def dfs(node: str) -> Optional[List[str]]:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in graph.get(node, set()):
                if neighbor not in visited:
                    cycle = dfs(neighbor)
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    return path[cycle_start:]

            path.pop()
            rec_stack.remove(node)
            return None

        for node in graph:
            if node not in visited:
                cycle = dfs(node)
                if cycle:
                    return cycle

        return None

    def validate_acquisition_order(
        self,
        step_id: str,
        resources: List[str]
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate that resources are acquired in canonical order.

        Returns:
            (is_valid, error_message if invalid)
        """
        if not self.enable_ordered_acquisition:
            return (True, None)

        if not self.resource_order:
            return (True, None)

        # Get indices in canonical order
        indices = []
        for resource_id in resources:
            if resource_id in self.resource_order:
                indices.append(self.resource_order.index(resource_id))
            else:
                # Unknown resource, allow it
                pass

        # Check if sorted
        if indices != sorted(indices):
            return (
                False,
                f"Step {step_id} acquires resources out of order: {resources}. "
                f"Canonical order would be: {sorted(resources, key=lambda r: self.resource_order.index(r) if r in self.resource_order else 999)}"
            )

        return (True, None)

    def check_timeout(self) -> List[str]:
        """
        Check for timed-out waits.

        Returns list of step IDs that have timed out.
        """
        timed_out = []
        now = datetime.now()

        for step_id, waiting in self.waiting_steps.items():
            elapsed = (now - waiting.wait_start).total_seconds()
            if elapsed > waiting.timeout_s:
                timed_out.append(step_id)

        return timed_out

    def suggest_resolution(self, info: DeadlockInfo) -> List[str]:
        """
        Suggest resolution strategies for a deadlock.

        Returns list of suggestions.
        """
        suggestions = []

        # Identify victim (step with fewest resources held)
        min_held = float('inf')
        victim = None

        for step_id in info.steps_involved:
            if step_id in self.waiting_steps:
                held_count = len(self.waiting_steps[step_id].holding)
                if held_count < min_held:
                    min_held = held_count
                    victim = step_id

        if victim:
            suggestions.append(
                f"Abort step {victim} (holding fewest resources: {min_held})"
            )

        suggestions.append("Retry affected steps with randomized backoff")
        suggestions.append("Review resource ordering to prevent future deadlocks")

        return suggestions

    def reset(self) -> None:
        """Reset detector state."""
        self.waiting_steps.clear()
        self.resource_holders.clear()

    def get_wait_graph(self) -> Dict[str, List[str]]:
        """Get current wait-for graph for debugging."""
        graph = {}
        for step_id, waiting in self.waiting_steps.items():
            waiting_for_steps = []
            for resource_id in waiting.waiting_for:
                holder = self.resource_holders.get(resource_id)
                if holder:
                    waiting_for_steps.append(holder)
            graph[step_id] = waiting_for_steps
        return graph


def prevent_deadlock(
    step_id: str,
    required_resources: List[str],
    detector: DeadlockDetector
) -> Tuple[bool, Optional[str]]:
    """
    Check if acquiring resources would cause deadlock risk.

    Returns:
        (is_safe, warning_message if risky)
    """
    # Check order
    is_valid, error = detector.validate_acquisition_order(step_id, required_resources)
    if not is_valid:
        return (False, error)

    # Check current state
    state, info = detector.check_deadlock()
    if state == DeadlockState.DEADLOCKED and info is not None:
        return (False, f"System is deadlocked: {info.cycle}")

    return (True, None)
