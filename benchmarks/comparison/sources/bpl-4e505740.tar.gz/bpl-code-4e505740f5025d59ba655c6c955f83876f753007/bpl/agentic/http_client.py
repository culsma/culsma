"""Retry-enabled HTTP client for agentic model calls."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import logging

import httpx
from pydantic_ai.retries import AsyncTenacityTransport, RetryConfig, wait_retry_after
from tenacity import retry_if_exception_type, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)

RETRYABLE_NETWORK_ERRORS = (
    httpx.TimeoutException,
    httpx.ConnectError,
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.HTTPStatusError,
)
RETRYABLE_STATUS_CODES = (429, 502, 503, 504)


@dataclass(frozen=True)
class RetryHTTPConfig:
    """Runtime retry and timeout settings for model HTTP calls."""

    max_retries: int = 3
    min_wait: float = 1.0
    max_wait: float = 30.0
    timeout: float = 600.0
    connect_timeout: float = 10.0


def _validate_response_for_retry(response: httpx.Response) -> None:
    if response.status_code in RETRYABLE_STATUS_CODES:
        response.raise_for_status()


def _log_retry(retry_state) -> None:
    attempt = retry_state.attempt_number
    exception = retry_state.outcome.exception() if retry_state.outcome else None
    wait_time = retry_state.next_action.sleep if retry_state.next_action else 0
    logger.warning(
        "Retrying SOP model request (attempt %s): %s. Sleeping %.1fs.",
        attempt,
        f"{type(exception).__name__}: {exception}",
        wait_time,
    )


def create_retry_http_client(config: RetryHTTPConfig) -> httpx.AsyncClient:
    """Create a retry-enabled httpx AsyncClient."""
    transport = AsyncTenacityTransport(
        config=RetryConfig(
            retry=retry_if_exception_type(RETRYABLE_NETWORK_ERRORS),
            wait=wait_retry_after(
                fallback_strategy=wait_exponential(multiplier=config.min_wait, max=config.max_wait),
                max_wait=config.max_wait * 2,
            ),
            stop=stop_after_attempt(config.max_retries + 1),
            reraise=True,
            before_sleep=_log_retry,
        ),
        validate_response=_validate_response_for_retry,
    )
    return httpx.AsyncClient(
        transport=transport,
        timeout=httpx.Timeout(timeout=config.timeout, connect=config.connect_timeout),
    )


@lru_cache(maxsize=8)
def get_retry_http_client(
    *,
    max_retries: int,
    min_wait: float,
    max_wait: float,
    timeout: float,
    connect_timeout: float,
) -> httpx.AsyncClient:
    """Get a cached retry-enabled client keyed by config values."""
    return create_retry_http_client(
        RetryHTTPConfig(
            max_retries=max_retries,
            min_wait=min_wait,
            max_wait=max_wait,
            timeout=timeout,
            connect_timeout=connect_timeout,
        )
    )
