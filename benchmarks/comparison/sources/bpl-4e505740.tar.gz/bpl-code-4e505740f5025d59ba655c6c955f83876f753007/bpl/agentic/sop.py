"""SOP markdown ingestion and normalization helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re


_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+(?P<title>.+?)\s*$")


@dataclass(frozen=True)
class SOPDocument:
    """Normalized SOP markdown payload used by the generation workflow."""

    source_path: Path
    title: str
    normalized_markdown: str
    section_headings: tuple[str, ...]


def load_sop_document(path: Path) -> SOPDocument:
    """Load and normalize an SOP markdown file."""
    if not path.exists():
        raise FileNotFoundError(f"SOP file not found: {path}")

    raw_text = path.read_text(encoding="utf-8")
    normalized = normalize_sop_markdown(raw_text)
    headings = tuple(_extract_headings(normalized))
    title = headings[0] if headings else _fallback_title(path)
    return SOPDocument(
        source_path=path,
        title=title,
        normalized_markdown=normalized,
        section_headings=headings,
    )


def normalize_sop_markdown(markdown: str) -> str:
    """Apply deterministic markdown normalization for SOP ingestion."""
    normalized = markdown.replace("\ufeff", "")
    normalized = normalized.replace("\r\n", "\n").replace("\r", "\n")
    lines = [line.rstrip() for line in normalized.split("\n")]
    normalized = "\n".join(lines).strip()
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    if normalized and not normalized.endswith("\n"):
        normalized += "\n"
    return normalized


def _extract_headings(markdown: str) -> list[str]:
    headings: list[str] = []
    for line in markdown.splitlines():
        match = _HEADING_RE.match(line)
        if not match:
            continue
        heading = match.group("title").strip()
        if heading:
            headings.append(heading)
    return headings


def _fallback_title(path: Path) -> str:
    raw = path.stem.strip()
    sanitized = "".join(char for char in raw if char.isalnum() or char in {"_", "-", " "})
    normalized = sanitized.replace("_", " ").strip()
    return normalized or "SOP"
