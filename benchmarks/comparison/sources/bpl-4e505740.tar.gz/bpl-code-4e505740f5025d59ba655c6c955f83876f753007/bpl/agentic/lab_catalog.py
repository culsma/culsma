"""Lab catalog ingestion helpers for SOP-to-BPL generation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Iterable

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet


_DEFAULT_DATA_START_ROW = 4
_MAX_REAGENTS_IN_PROMPT = 80
_MAX_CONSUMABLES_IN_PROMPT = 80
_MAX_EQUIPMENT_IN_PROMPT = 40


@dataclass(frozen=True)
class LabCatalogItem:
    """One reagent/consumable/equipment item extracted from the xlsx catalog."""

    item_id: str
    name: str
    category: str | None = None
    use_tags: str | None = None
    vendor: str | None = None
    model_or_spec: str | None = None
    location: str | None = None

    def searchable_text(self) -> str:
        parts = [
            self.item_id,
            self.name,
            self.category or "",
            self.use_tags or "",
            self.vendor or "",
            self.model_or_spec or "",
            self.location or "",
        ]
        return " ".join(part for part in parts if part).lower()

    def to_prompt_line(self) -> str:
        parts = [self.item_id, self.name]
        if self.category:
            parts.append(f"type={self.category}")
        if self.use_tags:
            parts.append(f"use={self.use_tags}")
        if self.model_or_spec:
            parts.append(f"spec={self.model_or_spec}")
        if self.vendor:
            parts.append(f"vendor={self.vendor}")
        if self.location:
            parts.append(f"location={self.location}")
        return " | ".join(parts)


@dataclass(frozen=True)
class LabCatalog:
    """Structured reagent/consumable/equipment catalog."""

    source_path: Path
    reagents: tuple[LabCatalogItem, ...]
    consumables: tuple[LabCatalogItem, ...]
    equipment: tuple[LabCatalogItem, ...]

    def totals(self) -> dict[str, int]:
        return {
            "reagents_total": len(self.reagents),
            "consumables_total": len(self.consumables),
            "equipment_total": len(self.equipment),
        }


def default_lab_catalog_path_for_sop(sop_path: Path) -> Path | None:
    """Resolve default xlsx catalog near SOP docs when available."""
    candidate = sop_path.parent / "lab_inventory.xlsx"
    if candidate.exists():
        return candidate
    return None


def load_lab_catalog(path: Path) -> LabCatalog:
    """Load a lab inventory xlsx into a typed catalog."""
    if not path.exists():
        raise FileNotFoundError(f"Lab catalog xlsx not found: {path}")

    workbook = load_workbook(path, data_only=True)

    reagents_ws = _require_sheet(workbook, "01_Reagents")
    consumables_ws = _require_sheet(workbook, "02_Consumables")
    equipment_ws = _require_sheet(workbook, "04_Equipment")

    reagents = tuple(
        _unique_items(
            _read_items(
                reagents_ws,
                field_aliases={
                    "item_id": ("reagent_id", "试剂id"),
                    "name": ("name", "试剂名称"),
                    "category": ("reagent_type", "计量单位"),
                    "use_tags": ("use_tags", "用途", "关键词"),
                    "vendor": ("vendor", "供应商"),
                    "model_or_spec": ("spec", "规格", "浓度"),
                    "location": ("storage_location", "存放位置"),
                },
            )
        )
    )
    consumables = tuple(
        _unique_items(
            _read_items(
                consumables_ws,
                field_aliases={
                    "item_id": ("consumable_id", "耗材id"),
                    "name": ("name", "耗材名称"),
                    "category": ("category", "类别"),
                    "use_tags": ("notes", "备注", "compatible_equipment", "兼容设备"),
                    "vendor": ("vendor", "供应商"),
                    "model_or_spec": ("spec", "规格", "型号"),
                    "location": ("storage_location", "存储位置"),
                },
            )
        )
    )
    equipment = tuple(
        _unique_items(
            _read_items(
                equipment_ws,
                field_aliases={
                    "item_id": ("equipment_id", "设备序号", "设备序号id"),
                    "name": ("设备名称", "name"),
                    "category": ("类别",),
                    "use_tags": ("use_tags", "用途", "关键词"),
                    "vendor": ("设备厂家", "vendor"),
                    "model_or_spec": ("设备型号", "model"),
                    "location": ("位置", "location"),
                },
            )
        )
    )

    return LabCatalog(
        source_path=path,
        reagents=reagents,
        consumables=consumables,
        equipment=equipment,
    )


def build_lab_catalog_prompt_context(
    *,
    catalog: LabCatalog,
    sop_markdown: str,
) -> tuple[str, dict[str, int]]:
    """Build compact prompt text from the catalog with SOP-aware relevance ranking."""
    sop_text = sop_markdown.lower()

    reagent_items = _select_relevant_items(
        catalog.reagents,
        sop_text=sop_text,
        max_items=_MAX_REAGENTS_IN_PROMPT,
    )
    consumable_items = _select_relevant_items(
        catalog.consumables,
        sop_text=sop_text,
        max_items=_MAX_CONSUMABLES_IN_PROMPT,
    )
    equipment_items = _select_relevant_items(
        _dedupe_equipment_by_name_model(catalog.equipment),
        sop_text=sop_text,
        max_items=_MAX_EQUIPMENT_IN_PROMPT,
    )

    lines: list[str] = [
        f"source: {catalog.source_path}",
        "",
        _format_section("Reagents", catalog.reagents, reagent_items),
        "",
        _format_section("Consumables", catalog.consumables, consumable_items),
        "",
        _format_section("Equipment", catalog.equipment, equipment_items),
    ]
    context = "\n".join(lines).strip()
    stats = {
        **catalog.totals(),
        "reagents_in_prompt": len(reagent_items),
        "consumables_in_prompt": len(consumable_items),
        "equipment_in_prompt": len(equipment_items),
    }
    return context, stats


def _require_sheet(workbook, sheet_name: str) -> Worksheet:
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Missing sheet '{sheet_name}' in lab catalog workbook.")
    return workbook[sheet_name]


def _read_items(
    worksheet: Worksheet,
    *,
    field_aliases: dict[str, tuple[str, ...]],
) -> list[LabCatalogItem]:
    column_map = _resolve_column_map(worksheet, field_aliases)
    items: list[LabCatalogItem] = []

    for row_index in range(_DEFAULT_DATA_START_ROW, worksheet.max_row + 1):
        item_id = _value_for_field(worksheet, row_index, column_map.get("item_id"))
        name = _value_for_field(worksheet, row_index, column_map.get("name"))
        category = _value_for_field(worksheet, row_index, column_map.get("category"))
        use_tags = _value_for_field(worksheet, row_index, column_map.get("use_tags"))
        vendor = _value_for_field(worksheet, row_index, column_map.get("vendor"))
        model_or_spec = _value_for_field(worksheet, row_index, column_map.get("model_or_spec"))
        location = _value_for_field(worksheet, row_index, column_map.get("location"))

        if not item_id and not name:
            continue
        normalized_id = item_id or f"ROW-{row_index:04d}"
        normalized_name = name or normalized_id

        items.append(
            LabCatalogItem(
                item_id=normalized_id,
                name=normalized_name,
                category=category,
                use_tags=use_tags,
                vendor=vendor,
                model_or_spec=model_or_spec,
                location=location,
            )
        )

    return items


def _resolve_column_map(
    worksheet: Worksheet,
    field_aliases: dict[str, tuple[str, ...]],
) -> dict[str, int]:
    max_column = worksheet.max_column
    header_rows = (1, 2)
    headers_by_column: dict[int, tuple[str, ...]] = {}

    for column_index in range(1, max_column + 1):
        headers: list[str] = []
        for row_index in header_rows:
            value = worksheet.cell(row=row_index, column=column_index).value
            normalized = _normalize_header(_as_text(value))
            if normalized:
                headers.append(normalized)
        headers_by_column[column_index] = tuple(headers)

    resolved: dict[str, int] = {}
    for field_name, aliases in field_aliases.items():
        alias_tokens = tuple(_normalize_header(alias) for alias in aliases)
        best_column: int | None = None
        for column_index, column_headers in headers_by_column.items():
            if _header_matches_aliases(column_headers, alias_tokens):
                best_column = column_index
                break
        if best_column is not None:
            resolved[field_name] = best_column

    return resolved


def _header_matches_aliases(headers: tuple[str, ...], aliases: tuple[str, ...]) -> bool:
    for header in headers:
        for alias in aliases:
            if not alias:
                continue
            if alias in header or header in alias:
                return True
    return False


def _value_for_field(worksheet: Worksheet, row_index: int, column_index: int | None) -> str | None:
    if column_index is None:
        return None
    value = worksheet.cell(row=row_index, column=column_index).value
    text = _as_text(value).strip()
    if not text:
        return None
    return text


def _normalize_header(text: str) -> str:
    normalized = text.strip().lower()
    normalized = normalized.replace("*", "")
    normalized = re.sub(r"[\s\-\_:/()（）\n]+", "", normalized)
    return normalized


def _as_text(value: object) -> str:
    if value is None:
        return ""
    return str(value)


def _unique_items(items: Iterable[LabCatalogItem]) -> list[LabCatalogItem]:
    deduped: list[LabCatalogItem] = []
    seen: set[str] = set()
    for item in items:
        key = item.item_id.strip().lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _dedupe_equipment_by_name_model(items: tuple[LabCatalogItem, ...]) -> tuple[LabCatalogItem, ...]:
    deduped: list[LabCatalogItem] = []
    seen: set[str] = set()
    for item in items:
        key = f"{item.name.strip().lower()}|{(item.model_or_spec or '').strip().lower()}"
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return tuple(deduped)


def _select_relevant_items(
    items: Iterable[LabCatalogItem],
    *,
    sop_text: str,
    max_items: int,
) -> list[LabCatalogItem]:
    candidates = list(items)
    if len(candidates) <= max_items:
        return candidates

    scored: list[tuple[int, int, LabCatalogItem]] = []
    for index, item in enumerate(candidates):
        scored.append((_relevance_score(item, sop_text), index, item))

    scored.sort(key=lambda row: (-row[0], row[1]))
    top = scored[:max_items]
    selected = [item for _, _, item in top]
    return selected


def _relevance_score(item: LabCatalogItem, sop_text: str) -> int:
    score = 0
    searchable = item.searchable_text()

    if item.item_id.lower() in sop_text:
        score += 8
    if item.name.lower() in sop_text:
        score += 10

    if item.use_tags:
        for token in re.split(r"[;,，、/|]+", item.use_tags.lower()):
            token = token.strip()
            if len(token) < 2:
                continue
            if token in sop_text:
                score += 2

    # Favor richer records when relevance ties.
    score += len(searchable.split()) // 6
    return score


def _format_section(
    title: str,
    all_items: tuple[LabCatalogItem, ...],
    selected_items: list[LabCatalogItem],
) -> str:
    lines = [f"{title} ({len(selected_items)}/{len(all_items)} shown):"]
    for item in selected_items:
        lines.append(f"- {item.to_prompt_line()}")
    return "\n".join(lines)
