"""Generic chromatography column catalog and method conversion tools.

Supports arbitrary HPLC/UHPLC columns with any stationary phase, dimensions,
packing type, and detection mode. Implements method conversion using both:
- Geometric scaling formulas (column volume, cross-section, linear velocity)
- 2025 Chinese Pharmacopoeia 0512 compliance checks (L/dp, temperature, wavelength)

The LLM can list pre-registered columns, create new ones with custom specs,
and convert methods between any two columns.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Sequence


# ---------------------------------------------------------------------------
# Enums — stationary phases, detection modes, packing types
# ---------------------------------------------------------------------------


class StationaryPhase(str, Enum):
    """Common HPLC stationary phase chemistries."""

    C18 = "C18"
    C8 = "C8"
    C4 = "C4"
    PHENYL = "Phenyl"
    BIPHENYL = "Biphenyl"
    PFP = "PFP"  # pentafluorophenyl
    CN = "CN"  # cyano
    NH2 = "NH2"  # amino
    HILIC = "HILIC"
    SILICA = "Silica"
    AMIDE = "Amide"
    SCX = "SCX"  # strong cation exchange
    SAX = "SAX"  # strong anion exchange
    WAX = "WAX"  # weak anion exchange
    WCX = "WCX"  # weak cation exchange
    MIXED_MODE = "Mixed-Mode"
    OTHER = "Other"


class PackingType(str, Enum):
    """Column packing particle architecture."""

    FULLY_POROUS = "fully_porous"
    SUPERFICIALLY_POROUS = "superficially_porous"  # core-shell


class DetectionMode(str, Enum):
    """HPLC detection modes."""

    UV = "UV"
    DAD = "DAD"  # diode array (multi-wavelength UV-Vis)
    FLD = "FLD"  # fluorescence
    RID = "RID"  # refractive index
    ELSD = "ELSD"  # evaporative light scattering
    CAD = "CAD"  # charged aerosol
    MS = "MS"  # mass spectrometry
    MS_MS = "MS/MS"  # tandem MS


class PoreCategory(str, Enum):
    """Pore size classification by analyte type."""

    SMALL_MOLECULE = "small_molecule"  # 60-130 Å
    PEPTIDE = "peptide"  # 120-200 Å
    PROTEIN = "protein"  # 200-300+ Å


# ---------------------------------------------------------------------------
# Reference data — phase selectivity, pore guidance, pressure limits
# ---------------------------------------------------------------------------


PHASE_SELECTIVITY: dict[StationaryPhase, dict[str, str]] = {
    StationaryPhase.C18: {
        "hydrophobicity": "high",
        "mechanism": "reversed-phase (hydrophobic)",
        "best_for": "general-purpose, non-polar to moderately polar analytes",
        "mobile_phase": "water/acetonitrile or water/methanol",
        "pH_range": "2-8 (silica); 1-12 (hybrid/polymer)",
    },
    StationaryPhase.C8: {
        "hydrophobicity": "moderate",
        "mechanism": "reversed-phase (hydrophobic)",
        "best_for": "analytes with excessive C18 retention, faster elution",
        "mobile_phase": "water/acetonitrile or water/methanol",
        "pH_range": "2-8",
    },
    StationaryPhase.C4: {
        "hydrophobicity": "low-moderate",
        "mechanism": "reversed-phase",
        "best_for": "proteins, peptides, very hydrophobic analytes",
        "mobile_phase": "water/acetonitrile with TFA or formic acid",
        "pH_range": "2-8",
    },
    StationaryPhase.PHENYL: {
        "hydrophobicity": "moderate",
        "mechanism": "reversed-phase + pi-pi interactions",
        "best_for": "aromatic compounds, selectivity alternative to C18",
        "mobile_phase": "water/methanol (enhances pi-pi) or water/acetonitrile",
        "pH_range": "2-8",
    },
    StationaryPhase.BIPHENYL: {
        "hydrophobicity": "moderate-high",
        "mechanism": "reversed-phase + strong pi-pi + shape selectivity",
        "best_for": "aromatic isomers, PAHs, steroids",
        "mobile_phase": "water/methanol or water/acetonitrile",
        "pH_range": "1.5-9",
    },
    StationaryPhase.PFP: {
        "hydrophobicity": "moderate",
        "mechanism": "reversed-phase + pi-pi + dipole-dipole + H-bonding",
        "best_for": "halogenated compounds, polar aromatics, isomer separation",
        "mobile_phase": "water/methanol preferred (enhances selectivity)",
        "pH_range": "2-8",
    },
    StationaryPhase.CN: {
        "hydrophobicity": "low",
        "mechanism": "normal-phase or reversed-phase (dipole interactions)",
        "best_for": "moderately polar analytes, needs less organic than C18",
        "mobile_phase": "RP: water/acetonitrile; NP: hexane/ethyl acetate",
        "pH_range": "2-7.5",
    },
    StationaryPhase.NH2: {
        "hydrophobicity": "very low",
        "mechanism": "normal-phase / weak anion exchange / HILIC",
        "best_for": "sugars, carbohydrates, polar acids",
        "mobile_phase": "acetonitrile/water or hexane/isopropanol",
        "pH_range": "3-7 (sensitive to low pH hydrolysis)",
    },
    StationaryPhase.HILIC: {
        "hydrophobicity": "very low",
        "mechanism": "hydrophilic interaction + partitioning",
        "best_for": "very polar analytes poorly retained on C18",
        "mobile_phase": "high % acetonitrile with 5-40% aqueous buffer",
        "pH_range": "2-8 (depends on substrate)",
    },
    StationaryPhase.SILICA: {
        "hydrophobicity": "none",
        "mechanism": "normal-phase adsorption",
        "best_for": "non-polar matrices, lipid class separation",
        "mobile_phase": "hexane/ethyl acetate or hexane/isopropanol",
        "pH_range": "2-8",
    },
    StationaryPhase.AMIDE: {
        "hydrophobicity": "very low",
        "mechanism": "HILIC (amide-bonded)",
        "best_for": "glycans, polar metabolites, nucleotides",
        "mobile_phase": "acetonitrile/ammonium formate buffer",
        "pH_range": "2-8",
    },
    StationaryPhase.SCX: {
        "hydrophobicity": "none",
        "mechanism": "strong cation exchange",
        "best_for": "basic analytes, cations, proteins (by charge)",
        "mobile_phase": "aqueous buffer with salt gradient",
        "pH_range": "2-7",
    },
    StationaryPhase.SAX: {
        "hydrophobicity": "none",
        "mechanism": "strong anion exchange",
        "best_for": "acidic analytes, anions, nucleotides",
        "mobile_phase": "aqueous buffer with salt gradient",
        "pH_range": "2-9",
    },
}

PORE_SIZE_GUIDANCE: dict[PoreCategory, dict[str, object]] = {
    PoreCategory.SMALL_MOLECULE: {
        "range_angstrom": (60, 130),
        "typical_angstrom": 100,
        "description": "60-130 Å optimal for small molecules < 3 kDa; higher surface area",
    },
    PoreCategory.PEPTIDE: {
        "range_angstrom": (120, 200),
        "typical_angstrom": 150,
        "description": "120-200 Å for peptides 1-10 kDa; balances access and area",
    },
    PoreCategory.PROTEIN: {
        "range_angstrom": (200, 1000),
        "typical_angstrom": 300,
        "description": "200-300+ Å for proteins > 10 kDa; wide pores for mass transfer",
    },
}

DETECTION_COMPATIBILITY: dict[DetectionMode, dict[str, object]] = {
    DetectionMode.UV: {
        "gradient_ok": True,
        "destructive": False,
        "notes": "Check solvent UV cutoff; acetonitrile cut ~190 nm, methanol ~205 nm",
    },
    DetectionMode.DAD: {
        "gradient_ok": True,
        "destructive": False,
        "notes": "Multi-wavelength; same solvent cutoff limits as UV",
    },
    DetectionMode.FLD: {
        "gradient_ok": True,
        "destructive": False,
        "notes": "Very sensitive; analyte must be naturally fluorescent or derivatized",
    },
    DetectionMode.RID: {
        "gradient_ok": False,
        "destructive": False,
        "notes": "Incompatible with gradient elution; isocratic only",
    },
    DetectionMode.ELSD: {
        "gradient_ok": True,
        "destructive": True,
        "notes": "Avoid volatile analytes; incompatible with non-volatile buffers/mineral acids",
    },
    DetectionMode.CAD: {
        "gradient_ok": True,
        "destructive": True,
        "notes": "Requires volatile mobile phase components; better linearity than ELSD",
    },
    DetectionMode.MS: {
        "gradient_ok": True,
        "destructive": True,
        "notes": "Requires volatile buffers (formic acid, ammonium acetate); "
                 "2.1mm ID columns preferred; may need flow splitting for >0.5 mL/min",
    },
    DetectionMode.MS_MS: {
        "gradient_ok": True,
        "destructive": True,
        "notes": "Same as MS; narrow-bore columns strongly recommended",
    },
}


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GradientStep:
    """One row in a gradient elution timetable."""

    time_min: float
    percent_b: float

    def to_dict(self) -> dict[str, float]:
        return {"time_min": self.time_min, "percent_b": self.percent_b}


@dataclass(frozen=True)
class ColumnSpec:
    """Physical specification of a chromatography column."""

    column_id: str
    name: str
    stationary_phase: StationaryPhase
    inner_diameter_mm: float
    length_mm: float
    particle_size_um: float
    pore_size_angstrom: float
    packing_type: PackingType
    part_number: str = ""
    vendor: str = ""
    max_pressure_bar: float = 0.0  # 0 = unspecified
    max_temp_c: float = 80.0
    ph_range: tuple[float, float] = (2.0, 8.0)

    @property
    def l_over_dp(self) -> float:
        """Column length / particle diameter ratio (L in µm / dp in µm)."""
        return (self.length_mm * 1000) / self.particle_size_um

    @property
    def cross_section_mm2(self) -> float:
        """Column cross-sectional area in mm²."""
        return math.pi * (self.inner_diameter_mm / 2) ** 2

    @property
    def column_volume_ul(self) -> float:
        """Geometric column volume in µL (π/4 × dc² × L), approximate void ≈ 65%."""
        # Total geometric volume; actual void volume is ~60-70% for packed columns
        return self.cross_section_mm2 * self.length_mm  # mm² × mm = mm³ = µL

    @property
    def void_volume_ul(self) -> float:
        """Estimated void volume assuming 65% porosity for fully porous, 55% for core-shell."""
        porosity = 0.55 if self.packing_type == PackingType.SUPERFICIALLY_POROUS else 0.65
        return self.column_volume_ul * porosity

    @property
    def pore_category(self) -> PoreCategory:
        if self.pore_size_angstrom <= 130:
            return PoreCategory.SMALL_MOLECULE
        elif self.pore_size_angstrom <= 200:
            return PoreCategory.PEPTIDE
        return PoreCategory.PROTEIN

    def to_dict(self) -> dict[str, object]:
        return {
            "column_id": self.column_id,
            "name": self.name,
            "stationary_phase": self.stationary_phase.value,
            "inner_diameter_mm": self.inner_diameter_mm,
            "length_mm": self.length_mm,
            "particle_size_um": self.particle_size_um,
            "pore_size_angstrom": self.pore_size_angstrom,
            "packing_type": self.packing_type.value,
            "part_number": self.part_number,
            "vendor": self.vendor,
            "L_over_dp": round(self.l_over_dp, 1),
            "column_volume_ul": round(self.column_volume_ul, 1),
            "void_volume_ul": round(self.void_volume_ul, 1),
            "max_pressure_bar": self.max_pressure_bar,
        }


@dataclass(frozen=True)
class MethodParams:
    """HPLC/UHPLC method operating parameters."""

    flow_rate_ml_min: float
    injection_volume_ul: float
    column_temp_c: float
    detection_wavelengths_nm: tuple[float, ...]
    detection_mode: DetectionMode
    mobile_phase_a: str
    mobile_phase_b: str
    gradient_table: tuple[GradientStep, ...]
    is_gradient: bool = True
    buffer_concentration_mm: float = 0.0  # 0 = unspecified
    mobile_phase_ph: float = 0.0  # 0 = unspecified

    @property
    def run_time_min(self) -> float:
        if not self.gradient_table:
            return 0.0
        return self.gradient_table[-1].time_min

    def to_dict(self) -> dict[str, object]:
        return {
            "flow_rate_ml_min": self.flow_rate_ml_min,
            "injection_volume_ul": self.injection_volume_ul,
            "column_temp_c": self.column_temp_c,
            "detection_wavelengths_nm": list(self.detection_wavelengths_nm),
            "detection_mode": self.detection_mode.value,
            "mobile_phase_a": self.mobile_phase_a,
            "mobile_phase_b": self.mobile_phase_b,
            "gradient_table": [step.to_dict() for step in self.gradient_table],
            "is_gradient": self.is_gradient,
            "run_time_min": self.run_time_min,
            "buffer_concentration_mm": self.buffer_concentration_mm,
            "mobile_phase_ph": self.mobile_phase_ph,
        }


@dataclass(frozen=True)
class ColumnMethodProfile:
    """A complete analytical method profile: column + method + target analytes."""

    column: ColumnSpec
    method: MethodParams
    target_analytes: tuple[str, ...]
    application: str = ""
    description: str = ""

    def to_dict(self) -> dict[str, object]:
        return {
            "column": self.column.to_dict(),
            "method": self.method.to_dict(),
            "target_analytes": list(self.target_analytes),
            "application": self.application,
            "description": self.description,
        }


# ---------------------------------------------------------------------------
# Method conversion result
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ConversionWarning:
    """A compliance warning from method conversion."""

    parameter: str
    message: str
    severity: str = "warning"  # "warning" | "info" | "error"


@dataclass(frozen=True)
class MethodConversionResult:
    """Result of converting a method from one column to another."""

    source_profile: ColumnMethodProfile
    target_column: ColumnSpec
    converted_method: MethodParams
    warnings: tuple[ConversionWarning, ...]
    speed_factor: float
    solvent_saving_percent: float
    estimated_pressure_ratio: float

    def to_dict(self) -> dict[str, object]:
        return {
            "source_column": self.source_profile.column.to_dict(),
            "target_column": self.target_column.to_dict(),
            "converted_method": self.converted_method.to_dict(),
            "warnings": [
                {"parameter": w.parameter, "message": w.message, "severity": w.severity}
                for w in self.warnings
            ],
            "speed_factor": round(self.speed_factor, 2),
            "solvent_saving_percent": round(self.solvent_saving_percent, 1),
            "estimated_pressure_ratio": round(self.estimated_pressure_ratio, 2),
        }


# ---------------------------------------------------------------------------
# Built-in column profiles
# ---------------------------------------------------------------------------

# -- Short UHPLC column: Phenomenex Kinetex C18 (RT 2.1min method) --
_KINETEX_SHORT = ColumnSpec(
    column_id="kinetex-c18-2.1x50-1.7um",
    name="Phenomenex Kinetex C18 100A",
    stationary_phase=StationaryPhase.C18,
    inner_diameter_mm=2.1,
    length_mm=50,
    particle_size_um=1.7,
    pore_size_angstrom=100,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="00B-4475-AN",
    vendor="Phenomenex",
    max_pressure_bar=1000,
    max_temp_c=60,
)

_KINETEX_SHORT_METHOD = MethodParams(
    flow_rate_ml_min=0.6,
    injection_volume_ul=1.0,
    column_temp_c=50.0,
    detection_wavelengths_nm=(328.0, 382.0, 452.0, 475.0, 210.0),
    detection_mode=DetectionMode.DAD,
    mobile_phase_a="Ultrapure water",
    mobile_phase_b="Acetonitrile/Isopropanol 75:25",
    gradient_table=(
        GradientStep(0.0, 75.0),
        GradientStep(0.4, 75.0),
        GradientStep(0.5, 100.0),
        GradientStep(2.0, 100.0),
        GradientStep(2.1, 75.0),
    ),
    is_gradient=True,
)

KINETEX_SHORT_PROFILE = ColumnMethodProfile(
    column=_KINETEX_SHORT,
    method=_KINETEX_SHORT_METHOD,
    target_analytes=(
        "Retinol", "Retinal", "Retinyl acetate",
        "Lycopene", "beta-Carotene", "Squalene",
    ),
    application="food/nutraceutical",
    description="Fast 2.1-min UHPLC method for retinoid/carotenoid analysis (core-shell C18)",
)

# -- Long conventional column: Agilent ValueLab LC C18 --
_VALUELAB_LONG = ColumnSpec(
    column_id="valuelab-c18-4.6x250-5um",
    name="Agilent ValueLab LC C18 170A",
    stationary_phase=StationaryPhase.C18,
    inner_diameter_mm=4.6,
    length_mm=250,
    particle_size_um=5.0,
    pore_size_angstrom=170,
    packing_type=PackingType.FULLY_POROUS,
    part_number="588965-902",
    vendor="Agilent",
    max_pressure_bar=400,
    max_temp_c=60,
)

_VALUELAB_LONG_METHOD = MethodParams(
    flow_rate_ml_min=1.0,
    injection_volume_ul=20.0,
    column_temp_c=35.0,
    detection_wavelengths_nm=(328.0, 382.0, 452.0, 475.0, 210.0),
    detection_mode=DetectionMode.DAD,
    mobile_phase_a="Ultrapure water",
    mobile_phase_b="Acetonitrile/Isopropanol 75:25",
    gradient_table=(
        GradientStep(0.0, 75.0),
        GradientStep(5.0, 75.0),
        GradientStep(20.0, 35.0),
        GradientStep(50.0, 35.0),
        GradientStep(55.0, 75.0),
        GradientStep(60.0, 75.0),
    ),
    is_gradient=True,
)

VALUELAB_LONG_PROFILE = ColumnMethodProfile(
    column=_VALUELAB_LONG,
    method=_VALUELAB_LONG_METHOD,
    target_analytes=(
        "Retinol", "Retinal", "Retinyl acetate",
        "Lycopene", "beta-Carotene", "Squalene",
    ),
    application="food/nutraceutical",
    description="Conventional 60-min HPLC method (fully porous C18) for retinoid/carotenoid",
)

# -- Generic UHPLC C18: Waters BEH C18 (very common reference column) --
_BEH_C18 = ColumnSpec(
    column_id="beh-c18-2.1x100-1.7um",
    name="Waters BEH C18 130A",
    stationary_phase=StationaryPhase.C18,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=1.7,
    pore_size_angstrom=130,
    packing_type=PackingType.FULLY_POROUS,
    part_number="186002352",
    vendor="Waters",
    max_pressure_bar=1034,
    max_temp_c=80,
    ph_range=(1.0, 12.0),
)

# -- Agilent Poroshell 120: popular core-shell mid-range --
_POROSHELL_C18 = ColumnSpec(
    column_id="poroshell-c18-3.0x100-2.7um",
    name="Agilent Poroshell 120 EC-C18",
    stationary_phase=StationaryPhase.C18,
    inner_diameter_mm=3.0,
    length_mm=100,
    particle_size_um=2.7,
    pore_size_angstrom=120,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="695975-302",
    vendor="Agilent",
    max_pressure_bar=600,
    max_temp_c=60,
)

# -- Phenyl-Hexyl example --
_PHENYL_HEXYL = ColumnSpec(
    column_id="kinetex-phenyl-2.1x100-2.6um",
    name="Phenomenex Kinetex Phenyl-Hexyl",
    stationary_phase=StationaryPhase.PHENYL,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=2.6,
    pore_size_angstrom=100,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="00D-4495-AN",
    vendor="Phenomenex",
    max_pressure_bar=600,
    max_temp_c=60,
)

# -- HILIC column example --
_HILIC_AMIDE = ColumnSpec(
    column_id="beh-amide-2.1x100-1.7um",
    name="Waters BEH Amide 130A (HILIC)",
    stationary_phase=StationaryPhase.AMIDE,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=1.7,
    pore_size_angstrom=130,
    packing_type=PackingType.FULLY_POROUS,
    part_number="186004801",
    vendor="Waters",
    max_pressure_bar=1034,
    max_temp_c=80,
    ph_range=(2.0, 8.0),
)

# -- PFP (pentafluorophenyl) example --
_PFP_COLUMN = ColumnSpec(
    column_id="kinetex-pfp-2.1x100-2.6um",
    name="Phenomenex Kinetex PFP",
    stationary_phase=StationaryPhase.PFP,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=2.6,
    pore_size_angstrom=100,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="00D-4477-AN",
    vendor="Phenomenex",
    max_pressure_bar=600,
    max_temp_c=60,
)

# -- C8 conventional column --
_C8_CONVENTIONAL = ColumnSpec(
    column_id="eclipse-c8-4.6x150-5um",
    name="Agilent Eclipse XDB-C8",
    stationary_phase=StationaryPhase.C8,
    inner_diameter_mm=4.6,
    length_mm=150,
    particle_size_um=5.0,
    pore_size_angstrom=80,
    packing_type=PackingType.FULLY_POROUS,
    part_number="993967-906",
    vendor="Agilent",
    max_pressure_bar=400,
    max_temp_c=60,
)

# -- Biphenyl UHPLC --
_BIPHENYL = ColumnSpec(
    column_id="kinetex-biphenyl-2.1x100-1.7um",
    name="Phenomenex Kinetex Biphenyl",
    stationary_phase=StationaryPhase.BIPHENYL,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=1.7,
    pore_size_angstrom=100,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="00D-4622-AN",
    vendor="Phenomenex",
    max_pressure_bar=1000,
    max_temp_c=60,
)

# -- C4 wide-pore for proteins --
_C4_WIDEPORE = ColumnSpec(
    column_id="biozen-c4-2.1x100-1.7um",
    name="Phenomenex bioZen Widepore C4",
    stationary_phase=StationaryPhase.C4,
    inner_diameter_mm=2.1,
    length_mm=100,
    particle_size_um=1.7,
    pore_size_angstrom=300,
    packing_type=PackingType.SUPERFICIALLY_POROUS,
    part_number="00D-4782-AN",
    vendor="Phenomenex",
    max_pressure_bar=1000,
    max_temp_c=90,
    ph_range=(1.5, 8.0),
)

# -- Ion exchange SCX --
_SCX_COLUMN = ColumnSpec(
    column_id="biozen-scx-4.6x250-5um",
    name="Agilent Bio SCX NP-5",
    stationary_phase=StationaryPhase.SCX,
    inner_diameter_mm=4.6,
    length_mm=250,
    particle_size_um=5.0,
    pore_size_angstrom=300,
    packing_type=PackingType.FULLY_POROUS,
    part_number="5190-2471",
    vendor="Agilent",
    max_pressure_bar=300,
    max_temp_c=60,
    ph_range=(2.0, 7.0),
)


# ---------------------------------------------------------------------------
# Column registry
# ---------------------------------------------------------------------------

_BUILTIN_COLUMNS: dict[str, ColumnSpec] = {
    c.column_id: c
    for c in [
        _KINETEX_SHORT, _VALUELAB_LONG, _BEH_C18, _POROSHELL_C18,
        _PHENYL_HEXYL, _HILIC_AMIDE, _PFP_COLUMN, _C8_CONVENTIONAL,
        _BIPHENYL, _C4_WIDEPORE, _SCX_COLUMN,
    ]
}

_BUILTIN_PROFILES: dict[str, ColumnMethodProfile] = {
    KINETEX_SHORT_PROFILE.column.column_id: KINETEX_SHORT_PROFILE,
    VALUELAB_LONG_PROFILE.column.column_id: VALUELAB_LONG_PROFILE,
}

_custom_columns: dict[str, ColumnSpec] = {}
_custom_profiles: dict[str, ColumnMethodProfile] = {}


def register_column(column: ColumnSpec) -> None:
    """Register a custom column spec."""
    _custom_columns[column.column_id] = column


def register_column_profile(profile: ColumnMethodProfile) -> None:
    """Register a custom column method profile (also registers the column)."""
    _custom_columns[profile.column.column_id] = profile.column
    _custom_profiles[profile.column.column_id] = profile


def get_all_columns() -> dict[str, ColumnSpec]:
    """Return all registered columns (built-in + custom)."""
    return {**_BUILTIN_COLUMNS, **_custom_columns}


def get_column(column_id: str) -> ColumnSpec | None:
    """Look up a column by ID."""
    return _custom_columns.get(column_id) or _BUILTIN_COLUMNS.get(column_id)


def get_all_profiles() -> dict[str, ColumnMethodProfile]:
    """Return all registered profiles (built-in + custom)."""
    return {**_BUILTIN_PROFILES, **_custom_profiles}


def get_profile(column_id: str) -> ColumnMethodProfile | None:
    """Look up a column method profile by ID."""
    return _custom_profiles.get(column_id) or _BUILTIN_PROFILES.get(column_id)


# ---------------------------------------------------------------------------
# Geometric scaling formulas
# ---------------------------------------------------------------------------


def calc_linear_velocity_mm_s(flow_ml_min: float, column: ColumnSpec) -> float:
    """Linear velocity u = F / (cross_section × porosity), in mm/s."""
    porosity = 0.55 if column.packing_type == PackingType.SUPERFICIALLY_POROUS else 0.65
    area = column.cross_section_mm2
    return (flow_ml_min / 60.0) / (area * porosity)  # mL/s ÷ mm² = mm/s (1 mL = 1 mm³... wait)


def estimate_relative_backpressure(
    source: ColumnSpec, target: ColumnSpec,
    source_flow: float, target_flow: float,
) -> float:
    """Estimate pressure ratio P2/P1 using Darcy's law scaling.

    P ∝ (F × L × η) / (dc² × dp²)
    At constant viscosity: P2/P1 = (F2/F1) × (L2/L1) × (dp1/dp2)² × (dc1/dc2)²
    """
    flow_ratio = target_flow / source_flow if source_flow > 0 else 1.0
    length_ratio = target.length_mm / source.length_mm
    dp_ratio_sq = (source.particle_size_um / target.particle_size_um) ** 2
    dc_ratio_sq_inv = (source.inner_diameter_mm / target.inner_diameter_mm) ** 2
    return flow_ratio * length_ratio * dp_ratio_sq * dc_ratio_sq_inv


# ---------------------------------------------------------------------------
# Method conversion engine (Pharmacopoeia 0512 + geometric scaling)
# ---------------------------------------------------------------------------


def convert_method(
    source: ColumnMethodProfile,
    target_column: ColumnSpec,
) -> MethodConversionResult:
    """Convert HPLC method from source to target column.

    Applies geometric scaling formulas:
    - Flow rate:       F2 = F1 × (dc2² × dp1) / (dc1² × dp2)
    - Injection vol:   Vinj2 = Vinj1 × (L2 × dc2²) / (L1 × dc1²)
    - Gradient time:   tG2 = tG1 × (F1/F2) × (L2 × dc2²) / (L1 × dc1²)
    - Backpressure:    P2/P1 ≈ (F2/F1) × (L2/L1) × (dp1/dp2)² × (dc1/dc2)²

    Also checks 2025 Chinese Pharmacopoeia 0512 compliance:
    - L/dp ratio within -25% to +50%
    - Temperature tolerance ±5°C (gradient) / ±10°C (isocratic)
    - Detection wavelength immutability
    - pH within ±0.2
    - Buffer concentration within ±10%
    """
    src_col = source.column
    src_method = source.method
    warnings: list[ConversionWarning] = []

    # -- L/dp ratio check --
    src_ldp = src_col.l_over_dp
    tgt_ldp = target_column.l_over_dp
    ldp_ratio = tgt_ldp / src_ldp if src_ldp > 0 else 0
    if ldp_ratio < 0.75:
        warnings.append(ConversionWarning(
            parameter="L/dp",
            message=(
                f"Target L/dp ({tgt_ldp:.0f}) is {(1 - ldp_ratio) * 100:.0f}% below "
                f"source ({src_ldp:.0f}). ChP 0512 allows max -25%."
            ),
            severity="warning",
        ))
    elif ldp_ratio > 1.50:
        warnings.append(ConversionWarning(
            parameter="L/dp",
            message=(
                f"Target L/dp ({tgt_ldp:.0f}) is {(ldp_ratio - 1) * 100:.0f}% above "
                f"source ({src_ldp:.0f}). ChP 0512 allows max +50%."
            ),
            severity="warning",
        ))
    else:
        warnings.append(ConversionWarning(
            parameter="L/dp",
            message=f"L/dp OK: {src_ldp:.0f} -> {tgt_ldp:.0f} (ratio {ldp_ratio:.2f})",
            severity="info",
        ))

    # -- Stationary phase compatibility --
    if src_col.stationary_phase != target_column.stationary_phase:
        warnings.append(ConversionWarning(
            parameter="stationary_phase",
            message=(
                f"Phase change: {src_col.stationary_phase.value} -> "
                f"{target_column.stationary_phase.value}. Selectivity will change; "
                "verify elution order and system suitability. "
                "Geometric scaling preserves timing but not selectivity."
            ),
            severity="warning",
        ))

    # -- Packing type change --
    if src_col.packing_type != target_column.packing_type:
        warnings.append(ConversionWarning(
            parameter="packing_type",
            message=(
                f"Packing change: {src_col.packing_type.value} -> "
                f"{target_column.packing_type.value}. Per ChP 0512, "
                "selectivity and elution order must remain unchanged."
            ),
            severity="warning",
        ))

    # -- Pore size compatibility --
    if src_col.pore_category != target_column.pore_category:
        warnings.append(ConversionWarning(
            parameter="pore_size",
            message=(
                f"Pore category change: {src_col.pore_category.value} -> "
                f"{target_column.pore_category.value}. "
                "May affect retention and mass transfer for large analytes."
            ),
            severity="warning",
        ))

    # -- Flow rate conversion: F2 = F1 × (dc2²×dp1)/(dc1²×dp2) --
    dc_ratio_sq = (target_column.inner_diameter_mm / src_col.inner_diameter_mm) ** 2
    dp_ratio_inv = src_col.particle_size_um / target_column.particle_size_um
    flow_scale = dc_ratio_sq * dp_ratio_inv
    new_flow = src_method.flow_rate_ml_min * flow_scale

    # -- Injection volume: Vinj2 = Vinj1 × (L2×dc2²)/(L1×dc1²) --
    volume_scale = (
        (target_column.length_mm * target_column.inner_diameter_mm ** 2)
        / (src_col.length_mm * src_col.inner_diameter_mm ** 2)
    )
    new_injection = src_method.injection_volume_ul * volume_scale

    # -- Gradient time: tG2 = tG1 × (F1/F2) × (L2×dc2²)/(L1×dc1²) --
    time_scale = volume_scale / flow_scale if flow_scale > 0 else 1.0
    new_gradient = tuple(
        GradientStep(
            time_min=round(step.time_min * time_scale, 2),
            percent_b=step.percent_b,
        )
        for step in src_method.gradient_table
    )

    # -- Backpressure estimation --
    pressure_ratio = estimate_relative_backpressure(
        src_col, target_column, src_method.flow_rate_ml_min, new_flow,
    )
    if target_column.max_pressure_bar > 0 and pressure_ratio > 1.0:
        warnings.append(ConversionWarning(
            parameter="backpressure",
            message=(
                f"Estimated pressure increase: {pressure_ratio:.1f}x. "
                f"Target column rated to {target_column.max_pressure_bar} bar. "
                "Verify instrument pressure capability."
            ),
            severity="warning" if pressure_ratio > 2.0 else "info",
        ))

    # -- Detection mode compatibility --
    det = src_method.detection_mode
    if det in DETECTION_COMPATIBILITY:
        compat = DETECTION_COMPATIBILITY[det]
        if src_method.is_gradient and not compat["gradient_ok"]:
            warnings.append(ConversionWarning(
                parameter="detection",
                message=f"{det.value} is incompatible with gradient elution.",
                severity="error",
            ))
        # MS flow limit check
        if det in (DetectionMode.MS, DetectionMode.MS_MS) and new_flow > 0.5:
            warnings.append(ConversionWarning(
                parameter="detection",
                message=(
                    f"Flow {new_flow:.2f} mL/min may be too high for MS source. "
                    "Consider 2.1mm ID column or flow splitting."
                ),
                severity="warning",
            ))

    # -- Column temperature (pharmacopoeia) --
    new_temp = src_method.column_temp_c
    temp_tol = 5.0 if src_method.is_gradient else 10.0
    if new_temp > target_column.max_temp_c:
        warnings.append(ConversionWarning(
            parameter="column_temp",
            message=(
                f"Method temp {new_temp}C exceeds target column max {target_column.max_temp_c}C."
            ),
            severity="error",
        ))
    warnings.append(ConversionWarning(
        parameter="column_temp",
        message=(
            f"Temperature: {new_temp}C (adjustable +/-{temp_tol}C per ChP "
            f"{'gradient' if src_method.is_gradient else 'isocratic'} rules)"
        ),
        severity="info",
    ))

    # -- pH compatibility check --
    if src_method.mobile_phase_ph > 0:
        ph_lo, ph_hi = target_column.ph_range
        if src_method.mobile_phase_ph < ph_lo or src_method.mobile_phase_ph > ph_hi:
            warnings.append(ConversionWarning(
                parameter="pH",
                message=(
                    f"Mobile phase pH {src_method.mobile_phase_ph} outside target column "
                    f"range {ph_lo}-{ph_hi}. May damage stationary phase."
                ),
                severity="error",
            ))

    # -- Detection wavelength immutability --
    warnings.append(ConversionWarning(
        parameter="detection_wavelength",
        message="Detection wavelengths must not change per ChP 0512.",
        severity="info",
    ))

    # -- Build converted method --
    converted = MethodParams(
        flow_rate_ml_min=round(new_flow, 3),
        injection_volume_ul=round(new_injection, 2),
        column_temp_c=new_temp,
        detection_wavelengths_nm=src_method.detection_wavelengths_nm,
        detection_mode=src_method.detection_mode,
        mobile_phase_a=src_method.mobile_phase_a,
        mobile_phase_b=src_method.mobile_phase_b,
        gradient_table=new_gradient,
        is_gradient=src_method.is_gradient,
        buffer_concentration_mm=src_method.buffer_concentration_mm,
        mobile_phase_ph=src_method.mobile_phase_ph,
    )

    # -- Speed and solvent savings --
    src_time = src_method.run_time_min
    tgt_time = converted.run_time_min
    speed_factor = src_time / tgt_time if tgt_time > 0 else 1.0

    src_solvent = src_method.flow_rate_ml_min * src_time
    tgt_solvent = converted.flow_rate_ml_min * tgt_time
    solvent_saving = (
        ((src_solvent - tgt_solvent) / src_solvent * 100) if src_solvent > 0 else 0.0
    )

    return MethodConversionResult(
        source_profile=source,
        target_column=target_column,
        converted_method=converted,
        warnings=tuple(warnings),
        speed_factor=speed_factor,
        solvent_saving_percent=solvent_saving,
        estimated_pressure_ratio=pressure_ratio,
    )


# ---------------------------------------------------------------------------
# Prompt context builder
# ---------------------------------------------------------------------------


def build_column_catalog_prompt_context() -> str:
    """Build compact prompt text describing all available columns."""
    columns = get_all_columns()
    if not columns:
        return "No analytical columns registered."

    lines: list[str] = ["Available chromatography columns:"]
    for col in columns.values():
        profile = get_profile(col.column_id)
        lines.append(
            f"  {col.column_id}: {col.name} | "
            f"{col.stationary_phase.value} | "
            f"{col.inner_diameter_mm}x{col.length_mm}mm, {col.particle_size_um}um | "
            f"{col.packing_type.value} | "
            f"L/dp={col.l_over_dp:.0f}"
            + (f" | run={profile.method.run_time_min:.1f}min" if profile else "")
        )
    lines.append("")
    lines.append(
        "Tools: list_columns, get_column_method, convert_column_method, "
        "create_custom_column, get_phase_info, estimate_backpressure"
    )
    return "\n".join(lines)


def _format_gradient_inline(gradient: Sequence[GradientStep]) -> str:
    return " | ".join(f"{s.time_min:.1f}min->{s.percent_b:.0f}%B" for s in gradient)


# ---------------------------------------------------------------------------
# Pydantic AI tool functions (called by the LLM during BPL generation)
# ---------------------------------------------------------------------------


def tool_list_columns() -> str:
    """List all available chromatography columns with specs.

    Returns columns grouped by stationary phase, showing dimensions,
    particle size, packing type, and L/dp ratio.
    """
    columns = get_all_columns()
    if not columns:
        return "No columns registered."

    by_phase: dict[str, list[str]] = {}
    for col in columns.values():
        phase = col.stationary_phase.value
        profile = get_profile(col.column_id)
        line = (
            f"  {col.column_id}: {col.name} | "
            f"{col.inner_diameter_mm}x{col.length_mm}mm {col.particle_size_um}um "
            f"({col.packing_type.value}) | "
            f"L/dp={col.l_over_dp:.0f} | "
            f"pore={col.pore_size_angstrom}A"
        )
        if profile:
            line += f" | run={profile.method.run_time_min:.1f}min"
        if col.max_pressure_bar > 0:
            line += f" | max={col.max_pressure_bar:.0f}bar"
        by_phase.setdefault(phase, []).append(line)

    lines: list[str] = []
    for phase, entries in by_phase.items():
        lines.append(f"[{phase}]")
        lines.extend(entries)
        lines.append("")
    return "\n".join(lines).strip()


def tool_get_column_method(column_id: str) -> str:
    """Get detailed specs and method for a specific column.

    Args:
        column_id: Column identifier (use list_columns to see all IDs).

    Returns column specs. If a method profile exists, includes full method
    parameters with gradient table. Otherwise returns physical specs only.
    """
    col = get_column(column_id)
    if col is None:
        available = ", ".join(get_all_columns().keys())
        return f"Column '{column_id}' not found. Available: {available}"

    phase_info = PHASE_SELECTIVITY.get(col.stationary_phase, {})
    lines = [
        f"Column: {col.name}",
        f"  ID: {col.column_id}",
        f"  Phase: {col.stationary_phase.value}",
        f"  Dimensions: {col.inner_diameter_mm} x {col.length_mm} mm",
        f"  Particle: {col.particle_size_um} um ({col.packing_type.value})",
        f"  Pore: {col.pore_size_angstrom} A ({col.pore_category.value})",
        f"  L/dp: {col.l_over_dp:.0f}",
        f"  Column volume: {col.column_volume_ul:.1f} uL (void ~{col.void_volume_ul:.1f} uL)",
    ]
    if col.part_number:
        lines.append(f"  Part#: {col.part_number} ({col.vendor})")
    if col.max_pressure_bar > 0:
        lines.append(f"  Max pressure: {col.max_pressure_bar:.0f} bar")
    lines.append(f"  Max temp: {col.max_temp_c}C, pH range: {col.ph_range[0]}-{col.ph_range[1]}")

    if phase_info:
        lines.append("")
        lines.append(f"Phase selectivity ({col.stationary_phase.value}):")
        for k, v in phase_info.items():
            lines.append(f"  {k}: {v}")

    profile = get_profile(column_id)
    if profile:
        m = profile.method
        lines.append("")
        lines.append("Method parameters:")
        lines.append(f"  Flow: {m.flow_rate_ml_min} mL/min")
        lines.append(f"  Injection: {m.injection_volume_ul} uL")
        lines.append(f"  Temp: {m.column_temp_c}C")
        lines.append(f"  Detection: {m.detection_mode.value} at "
                      f"{', '.join(f'{w:.0f}nm' for w in m.detection_wavelengths_nm)}")
        lines.append(f"  Mobile phase A: {m.mobile_phase_a}")
        lines.append(f"  Mobile phase B: {m.mobile_phase_b}")
        lines.append(f"  Mode: {'Gradient' if m.is_gradient else 'Isocratic'}")
        if m.gradient_table:
            lines.append("  Gradient:")
            lines.append("    Time(min)  %B")
            for step in m.gradient_table:
                lines.append(f"    {step.time_min:>8.2f}  {step.percent_b:>5.1f}")
        lines.append(f"  Run time: {m.run_time_min:.1f} min")
        lines.append(f"  Analytes: {', '.join(profile.target_analytes)}")

    return "\n".join(lines)


def tool_convert_column_method(source_column_id: str, target_column_id: str) -> str:
    """Convert HPLC method parameters between two columns.

    Uses geometric scaling (Chinese Pharmacopoeia 0512 formulas):
    - Flow rate: F2 = F1 x (dc2^2 x dp1) / (dc1^2 x dp2)
    - Injection: Vinj2 = Vinj1 x (L2 x dc2^2) / (L1 x dc1^2)
    - Gradient time: tG2 = tG1 x (F1/F2) x (L2 x dc2^2) / (L1 x dc1^2)

    Includes compliance warnings for L/dp ratio, phase change, temperature,
    pH, packing type, pore size, backpressure, and detector compatibility.

    Args:
        source_column_id: Source column ID (must have a method profile).
        target_column_id: Target column ID.
    """
    source = get_profile(source_column_id)
    if source is None:
        profiles = ", ".join(get_all_profiles().keys())
        return (
            f"Source '{source_column_id}' has no method profile. "
            f"Columns with methods: {profiles}. "
            "Use create_custom_column to register a column with a method first."
        )

    target_col = get_column(target_column_id)
    if target_col is None:
        available = ", ".join(get_all_columns().keys())
        return f"Target column '{target_column_id}' not found. Available: {available}"

    result = convert_method(source, target_col)
    conv = result.converted_method

    lines = [
        "=== Method Conversion ===",
        f"Source: {source.column.name} ({source.column.column_id})",
        f"Target: {target_col.name} ({target_col.column_id})",
        "",
        "Converted parameters:",
        f"  Flow:      {source.method.flow_rate_ml_min:>8.3f} -> {conv.flow_rate_ml_min:>8.3f} mL/min",
        f"  Injection: {source.method.injection_volume_ul:>8.2f} -> {conv.injection_volume_ul:>8.2f} uL",
        f"  Temp:      {conv.column_temp_c}C (unchanged)",
        f"  Detection: {conv.detection_mode.value} at "
        f"{', '.join(f'{w:.0f}nm' for w in conv.detection_wavelengths_nm)}",
    ]
    if conv.gradient_table:
        lines.append("")
        lines.append("  Gradient table:")
        lines.append("    Time(min)  %B")
        for step in conv.gradient_table:
            lines.append(f"    {step.time_min:>8.2f}  {step.percent_b:>5.1f}")

    lines.extend([
        "",
        "Performance:",
        f"  Run time:      {source.method.run_time_min:.1f} -> {conv.run_time_min:.1f} min",
        f"  Speed factor:  {result.speed_factor:.1f}x",
        f"  Solvent saved: {result.solvent_saving_percent:.0f}%",
        f"  Pressure:      ~{result.estimated_pressure_ratio:.1f}x relative",
    ])

    errors = [w for w in result.warnings if w.severity == "error"]
    warns = [w for w in result.warnings if w.severity == "warning"]
    infos = [w for w in result.warnings if w.severity == "info"]

    if errors:
        lines.append("")
        lines.append("ERRORS (must resolve):")
        for w in errors:
            lines.append(f"  X [{w.parameter}] {w.message}")
    if warns:
        lines.append("")
        lines.append("Warnings:")
        for w in warns:
            lines.append(f"  ! [{w.parameter}] {w.message}")
    if infos:
        lines.append("")
        lines.append("Info:")
        for w in infos:
            lines.append(f"  i [{w.parameter}] {w.message}")

    return "\n".join(lines)


def tool_create_custom_column(
    column_id: str,
    name: str,
    stationary_phase: str,
    inner_diameter_mm: float,
    length_mm: float,
    particle_size_um: float,
    pore_size_angstrom: float,
    packing_type: str,
    vendor: str = "",
    part_number: str = "",
    max_pressure_bar: float = 0.0,
) -> str:
    """Register a new chromatography column with custom specifications.

    This makes the column available for method conversion and lookup.

    Args:
        column_id: Unique identifier for the column (e.g. 'my-c18-2.1x50').
        name: Human-readable name.
        stationary_phase: Phase chemistry. One of: C18, C8, C4, Phenyl,
            Biphenyl, PFP, CN, NH2, HILIC, Silica, Amide, SCX, SAX,
            WAX, WCX, Mixed-Mode, Other.
        inner_diameter_mm: Column inner diameter in mm (e.g. 2.1, 3.0, 4.6).
        length_mm: Column length in mm (e.g. 50, 100, 150, 250).
        particle_size_um: Particle size in micrometers (e.g. 1.7, 2.7, 5.0).
        pore_size_angstrom: Pore size in Angstroms (e.g. 100, 130, 300).
        packing_type: 'fully_porous' or 'superficially_porous'.
        vendor: Column vendor/manufacturer.
        part_number: Catalog part number.
        max_pressure_bar: Maximum operating pressure in bar.
    """
    try:
        phase = StationaryPhase(stationary_phase)
    except ValueError:
        phases = ", ".join(p.value for p in StationaryPhase)
        return f"Invalid phase '{stationary_phase}'. Valid: {phases}"

    try:
        packing = PackingType(packing_type)
    except ValueError:
        packings = ", ".join(p.value for p in PackingType)
        return f"Invalid packing '{packing_type}'. Valid: {packings}"

    col = ColumnSpec(
        column_id=column_id,
        name=name,
        stationary_phase=phase,
        inner_diameter_mm=inner_diameter_mm,
        length_mm=length_mm,
        particle_size_um=particle_size_um,
        pore_size_angstrom=pore_size_angstrom,
        packing_type=packing,
        part_number=part_number,
        vendor=vendor,
        max_pressure_bar=max_pressure_bar,
    )
    register_column(col)

    return (
        f"Registered: {col.name} ({col.column_id})\n"
        f"  {col.stationary_phase.value} | "
        f"{col.inner_diameter_mm}x{col.length_mm}mm {col.particle_size_um}um | "
        f"L/dp={col.l_over_dp:.0f} | "
        f"Vol={col.column_volume_ul:.1f}uL"
    )


def tool_get_phase_info(stationary_phase: str) -> str:
    """Get selectivity and usage guidance for a stationary phase chemistry.

    Args:
        stationary_phase: Phase name (e.g. 'C18', 'HILIC', 'PFP', 'Phenyl').
    """
    try:
        phase = StationaryPhase(stationary_phase)
    except ValueError:
        phases = ", ".join(p.value for p in StationaryPhase)
        return f"Unknown phase '{stationary_phase}'. Available: {phases}"

    info = PHASE_SELECTIVITY.get(phase)
    if info is None:
        return f"No selectivity data for {phase.value}."

    lines = [f"Stationary phase: {phase.value}"]
    for k, v in info.items():
        lines.append(f"  {k}: {v}")

    # Find columns using this phase
    cols = [c for c in get_all_columns().values() if c.stationary_phase == phase]
    if cols:
        lines.append("")
        lines.append(f"Available columns with {phase.value}:")
        for c in cols:
            lines.append(
                f"  {c.column_id}: {c.inner_diameter_mm}x{c.length_mm}mm "
                f"{c.particle_size_um}um ({c.packing_type.value})"
            )

    return "\n".join(lines)


def tool_estimate_backpressure(
    source_column_id: str,
    target_column_id: str,
    source_flow_ml_min: float = 0.0,
) -> str:
    """Estimate relative backpressure change between two columns.

    Uses Darcy's law scaling: P proportional to (F x L) / (dc^2 x dp^2).

    Args:
        source_column_id: Source column ID.
        target_column_id: Target column ID.
        source_flow_ml_min: Source flow rate; if 0, uses profile flow or 1.0 mL/min.
    """
    src = get_column(source_column_id)
    if src is None:
        return f"Source '{source_column_id}' not found."
    tgt = get_column(target_column_id)
    if tgt is None:
        return f"Target '{target_column_id}' not found."

    # Resolve source flow
    src_flow = source_flow_ml_min
    if src_flow <= 0:
        profile = get_profile(source_column_id)
        src_flow = profile.method.flow_rate_ml_min if profile else 1.0

    # Calculate scaled flow for target
    dc_ratio_sq = (tgt.inner_diameter_mm / src.inner_diameter_mm) ** 2
    dp_ratio_inv = src.particle_size_um / tgt.particle_size_um
    tgt_flow = src_flow * dc_ratio_sq * dp_ratio_inv

    ratio = estimate_relative_backpressure(src, tgt, src_flow, tgt_flow)

    lines = [
        f"Backpressure estimate: {src.name} -> {tgt.name}",
        f"  Source flow: {src_flow:.3f} mL/min",
        f"  Target flow (scaled): {tgt_flow:.3f} mL/min",
        f"  Pressure ratio: {ratio:.2f}x",
    ]
    if ratio > 1:
        lines.append(f"  Pressure will INCREASE by ~{(ratio - 1) * 100:.0f}%")
    else:
        lines.append(f"  Pressure will DECREASE by ~{(1 - ratio) * 100:.0f}%")
    if tgt.max_pressure_bar > 0:
        lines.append(f"  Target column max: {tgt.max_pressure_bar:.0f} bar")

    return "\n".join(lines)
