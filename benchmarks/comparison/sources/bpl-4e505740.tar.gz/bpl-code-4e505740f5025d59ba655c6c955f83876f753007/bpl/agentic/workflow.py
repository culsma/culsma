"""Agentic SOP-to-BPL generation workflow."""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
import json
import os
from pathlib import Path
import re
from tempfile import TemporaryDirectory
from typing import Protocol, Sequence

from pydantic_ai import Agent
from pydantic_ai.models.openrouter import OpenRouterModel
from pydantic_ai.providers.openrouter import OpenRouterProvider

from bpl.graph import build_workflow_graph, render_workflow_graph
from bpl.parser.bpl_parser import GRAMMAR_PATH
from bpl.orchestrator import (
    Diagnostic,
    OrchestrationError,
    ValidationPipelineResult,
    run_parse_gate,
    run_pipeline_for_plan,
    run_semantic_gate,
    run_setup_gate,
)

from .column_catalog import (
    build_column_catalog_prompt_context,
    tool_convert_column_method,
    tool_create_custom_column,
    tool_estimate_backpressure,
    tool_get_column_method,
    tool_get_phase_info,
    tool_list_columns,
)
from .http_client import get_retry_http_client
from .lab_catalog import (
    build_lab_catalog_prompt_context,
    default_lab_catalog_path_for_sop,
    load_lab_catalog,
)
from .sop import SOPDocument, load_sop_document

_DEFAULT_MODEL = "openrouter:google/gemini-3.1-pro-preview-customtools"
_DEFAULT_MAX_ATTEMPTS = 3
_DEFAULT_TARGET = "human"

_BPL_CODE_BLOCK_RE = re.compile(r"```(?:bpl)?\s*\n(?P<code>[\s\S]*?)```", re.IGNORECASE)
_GENERIC_CODE_BLOCK_RE = re.compile(r"```\s*\n(?P<code>[\s\S]*?)```")

_SYSTEM_PROMPT = """
You generate valid Biology Programming Language (BPL) protocol source.

Rules:
1. Return only executable BPL and avoid placeholders.
2. Always use this protocol header shape: `protocol Name { ... }` (no parameter list).
3. For transfer calls use named args exactly: `from:`, `to:`, `volume:`.
4. Use unit form like `10 uL`, `30 s`, `5 m`, `1 h` (never `[uL]` or `[s]`).
5. Never emit variable declarations/constructors like `var`, `let`, `Fluid(...)`,
   `Plate(...)`, `Container(...)`, or assignment lines using `=`.
6. Use dense human-facing comments with `//`:
   - section header comments for every phase,
   - one short rationale comment before each executable statement whenever possible.
7. Do not emit markdown explanations outside BPL; output BPL only.
8. If diagnostics are provided, fix those exact issues with minimal edits.

Reference valid shape:
protocol SOP_Example {
  transfer(from: source_A1, to: dest_A1, volume: 10 uL)
  wait(duration: 30 s)
}

Analytical chromatography tools:
You have access to tools for selecting HPLC/UHPLC chromatography columns and
computing method parameters. When the SOP involves chromatographic analysis:
- `list_columns` — see all available columns grouped by stationary phase.
- `get_column_method` — detailed specs and method for a specific column.
- `get_phase_info` — selectivity guidance for a phase (C18, HILIC, PFP, etc.).
- `convert_column_method` — convert method between columns using ChP 0512
  formulas (scales flow rate, injection volume, gradient timing, checks L/dp,
  temperature, pH, backpressure, and detector compatibility).
- `create_custom_column` — register a column with arbitrary specs.
- `estimate_backpressure` — Darcy's law pressure ratio between two columns.
Include the selected column parameters (flow rate, injection volume, gradient,
detection wavelengths, temperature) as comments in the generated BPL.
""".strip()

_INITIAL_PROMPT_TEMPLATE = """
Convert the SOP markdown below into valid BPL.

SOP title: {title}
Sections: {sections}

Authoritative BPL grammar (use this syntax exactly):
```lark
{bpl_syntax}
```

SOP markdown:
```markdown
{sop_markdown}
```

Lab resources inventory (reagents / consumables / equipment):
```text
{lab_catalog_context}
```

{column_catalog_context}

Use only executable statements in protocol body.
Prefer this safe intent subset: `transfer`, `wait`, `mix`, `incubate`, `centrifuge`.
Do not emit declarations or custom type constructors.
When naming material/equipment sources and destinations, prefer names/IDs from
the provided inventory whenever possible.
If the SOP involves HPLC/UHPLC analysis, use the chromatography tools to select
appropriate columns and include method parameters as comments.
Include rich `//` comments to describe intent/inputs/expected outcome for human readers.
Return only BPL, preferably inside ```bpl fenced code.
""".strip()

_REPAIR_PROMPT_TEMPLATE = """
Repair the candidate BPL using the validation diagnostics.

SOP title: {title}

Previous candidate:
```bpl
{candidate_bpl}
```

Authoritative BPL grammar (use this syntax exactly):
```lark
{bpl_syntax}
```

Diagnostics JSON:
```json
{diagnostics_json}
```

SOP markdown:
```markdown
{sop_markdown}
```

Lab resources inventory (reagents / consumables / equipment):
```text
{lab_catalog_context}
```

{column_catalog_context}

Return corrected BPL only, preferably inside ```bpl fenced code.
Preserve and improve useful `//` comments that help a human follow the flow.
When naming material/equipment sources and destinations, prefer names/IDs from
the provided inventory whenever possible.
""".strip()


class SOPGenerationError(RuntimeError):
    """Raised when SOP generation workflow fails unexpectedly."""


class SOPConfigurationError(SOPGenerationError):
    """Raised when model/runtime settings are invalid."""


@dataclass(frozen=True)
class SOPGenerationSettings:
    """Runtime settings for SOP-to-BPL generation."""

    model: str
    openrouter_api_key: str | None
    max_attempts: int
    default_target: str
    model_retries: int
    http_max_retries: int
    http_retry_min_wait: float
    http_retry_max_wait: float
    http_timeout: float
    http_connect_timeout: float

    @classmethod
    def from_env(cls) -> SOPGenerationSettings:
        return cls(
            model=os.getenv("BPL_SOP_MODEL", _DEFAULT_MODEL).strip(),
            openrouter_api_key=(
                os.getenv("BPL_OPENROUTER_API_KEY") or os.getenv("OPENROUTER_API_KEY")
            ),
            max_attempts=_int_env("BPL_SOP_MAX_ATTEMPTS", _DEFAULT_MAX_ATTEMPTS, minimum=1),
            default_target=os.getenv("BPL_SOP_TARGET", _DEFAULT_TARGET).strip() or _DEFAULT_TARGET,
            model_retries=_int_env("BPL_SOP_MODEL_RETRIES", 1, minimum=0),
            http_max_retries=_int_env("BPL_SOP_HTTP_MAX_RETRIES", 3, minimum=0),
            http_retry_min_wait=_float_env("BPL_SOP_HTTP_RETRY_MIN_WAIT", 1.0, minimum=0.0),
            http_retry_max_wait=_float_env("BPL_SOP_HTTP_RETRY_MAX_WAIT", 30.0, minimum=0.0),
            http_timeout=_float_env("BPL_SOP_HTTP_TIMEOUT", 600.0, minimum=1.0),
            http_connect_timeout=_float_env(
                "BPL_SOP_HTTP_CONNECT_TIMEOUT",
                10.0,
                minimum=0.1,
            ),
        )


class BPLCandidateGenerator(Protocol):
    """Protocol for producing initial/repaired BPL candidates."""

    def generate_candidate(
        self,
        *,
        sop: SOPDocument,
        lab_catalog_context: str,
        attempt: int,
        max_attempts: int,
        previous_bpl: str | None,
        diagnostics: Sequence[Diagnostic],
    ) -> str: ...


@dataclass(frozen=True)
class SOPGenerationAttempt:
    """One attempted candidate and diagnostics produced for it."""

    attempt: int
    stage: str
    candidate_bpl: str
    diagnostics: list[dict[str, object]]

    def to_dict(self) -> dict[str, object]:
        return {
            "attempt": self.attempt,
            "stage": self.stage,
            "candidate_bpl": self.candidate_bpl,
            "diagnostics": self.diagnostics,
        }


@dataclass(frozen=True)
class SOPGenerationResult:
    """Structured result payload for SOP generation workflows."""

    success: bool
    sop_title: str
    final_bpl: str | None
    diagnostics_history: list[SOPGenerationAttempt]
    validation_warnings: list[Diagnostic]
    generation_metadata: dict[str, object]
    graph_artifact: str | None = None
    failure_diagnostics: list[Diagnostic] = field(default_factory=list)

    def metadata_payload(self) -> dict[str, object]:
        return {
            "sop_title": self.sop_title,
            "validation_passed": self.success,
            "final_bpl": self.final_bpl,
            "diagnostics_history": [item.to_dict() for item in self.diagnostics_history],
            "validation_warnings": [diag.to_dict() for diag in self.validation_warnings],
            "failure_diagnostics": [diag.to_dict() for diag in self.failure_diagnostics],
            "graph_generated": self.graph_artifact is not None,
            "generation_metadata": self.generation_metadata,
        }


class PydanticAIBPLGenerator:
    """OpenRouter + Pydantic AI candidate generator."""

    def __init__(self, settings: SOPGenerationSettings):
        self._settings = settings
        self._agent = create_generation_agent(settings)

    def generate_candidate(
        self,
        *,
        sop: SOPDocument,
        lab_catalog_context: str,
        attempt: int,
        max_attempts: int,
        previous_bpl: str | None,
        diagnostics: Sequence[Diagnostic],
    ) -> str:
        column_context = build_column_catalog_prompt_context()
        if previous_bpl is None:
            prompt = _INITIAL_PROMPT_TEMPLATE.format(
                title=sop.title,
                sections=_format_sections(sop.section_headings),
                bpl_syntax=_bpl_syntax_reference(),
                sop_markdown=sop.normalized_markdown,
                lab_catalog_context=lab_catalog_context,
                column_catalog_context=column_context,
            )
        else:
            prompt = _REPAIR_PROMPT_TEMPLATE.format(
                title=sop.title,
                candidate_bpl=previous_bpl,
                bpl_syntax=_bpl_syntax_reference(),
                diagnostics_json=json.dumps(
                    [diag.to_dict() for diag in diagnostics],
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                ),
                sop_markdown=sop.normalized_markdown,
                lab_catalog_context=lab_catalog_context,
                column_catalog_context=column_context,
            )

        prompt += (
            f"\n\nAttempt {attempt} of {max_attempts}. "
            "Output must be valid BPL accepted by parser and validation pipeline."
        )

        try:
            result = self._agent.run_sync(prompt)
        except Exception as exc:
            raise SOPGenerationError(f"Model call failed: {exc}") from exc

        output = result.output
        candidate = _extract_bpl_text(output if isinstance(output, str) else str(output))
        if not candidate.strip():
            raise SOPGenerationError("Model returned empty BPL candidate.")
        return _ensure_trailing_newline(candidate)


def create_generation_agent(settings: SOPGenerationSettings) -> Agent[None, str]:
    """Create generation agent with retry-enabled model transport."""
    model = _create_model_with_retry(settings)
    return Agent(
        model,
        instructions=_SYSTEM_PROMPT,
        output_type=str,
        retries=settings.model_retries,
        tools=[
            tool_list_columns,
            tool_get_column_method,
            tool_convert_column_method,
            tool_create_custom_column,
            tool_get_phase_info,
            tool_estimate_backpressure,
        ],
    )


def _create_model_with_retry(settings: SOPGenerationSettings):
    model_name = settings.model.strip()
    if not model_name:
        raise SOPConfigurationError("BPL_SOP_MODEL must be a non-empty model string.")

    if model_name.startswith("openrouter:"):
        if not settings.openrouter_api_key:
            raise SOPConfigurationError(
                "OPENROUTER_API_KEY (or BPL_OPENROUTER_API_KEY) is required for openrouter models."
            )

        provider = OpenRouterProvider(
            api_key=settings.openrouter_api_key,
            http_client=get_retry_http_client(
                max_retries=settings.http_max_retries,
                min_wait=settings.http_retry_min_wait,
                max_wait=settings.http_retry_max_wait,
                timeout=settings.http_timeout,
                connect_timeout=settings.http_connect_timeout,
            ),
        )
        return OpenRouterModel(model_name.removeprefix("openrouter:"), provider=provider)

    return model_name


def generate_bpl_from_sop(
    *,
    sop_path: Path,
    setup_path: Path | None = None,
    lab_catalog_path: Path | None = None,
    include_graph: bool = False,
    settings: SOPGenerationSettings | None = None,
    generator: BPLCandidateGenerator | None = None,
) -> SOPGenerationResult:
    """Run bounded SOP -> BPL generation with parse/check/validate/repair loop."""
    sop_doc = load_sop_document(sop_path)
    resolved_settings = settings or SOPGenerationSettings.from_env()

    resolved_catalog_path = lab_catalog_path or default_lab_catalog_path_for_sop(sop_path)
    lab_catalog_context = "No external lab catalog provided."
    lab_catalog_metadata: dict[str, object] = {"enabled": False}
    if resolved_catalog_path is not None:
        catalog = load_lab_catalog(resolved_catalog_path)
        lab_catalog_context, catalog_stats = build_lab_catalog_prompt_context(
            catalog=catalog,
            sop_markdown=sop_doc.normalized_markdown,
        )
        lab_catalog_metadata = {
            "enabled": True,
            "source_path": str(resolved_catalog_path),
            **catalog_stats,
        }

    setup = run_setup_gate(setup_path, plan=None) if setup_path is not None else None
    target = setup.backend if setup is not None else resolved_settings.default_target

    resolved_generator = generator or PydanticAIBPLGenerator(resolved_settings)
    history: list[SOPGenerationAttempt] = []
    latest_diagnostics: list[Diagnostic] = []
    previous_candidate: str | None = None

    for attempt in range(1, resolved_settings.max_attempts + 1):
        candidate_bpl = resolved_generator.generate_candidate(
            sop=sop_doc,
            lab_catalog_context=lab_catalog_context,
            attempt=attempt,
            max_attempts=resolved_settings.max_attempts,
            previous_bpl=previous_candidate,
            diagnostics=latest_diagnostics,
        )
        pipeline, diagnostics, stage = _validate_candidate_bpl(
            candidate_bpl=candidate_bpl,
            setup_path=setup_path,
            target=target,
        )
        if diagnostics:
            history.append(
                SOPGenerationAttempt(
                    attempt=attempt,
                    stage=stage,
                    candidate_bpl=candidate_bpl,
                    diagnostics=[diag.to_dict() for diag in diagnostics],
                )
            )
            latest_diagnostics = diagnostics
            previous_candidate = candidate_bpl
            continue

        assert pipeline is not None
        graph_artifact: str | None = None
        if include_graph:
            graph_artifact = render_workflow_graph(build_workflow_graph(pipeline.plan), "json")

        return SOPGenerationResult(
            success=True,
            sop_title=sop_doc.title,
            final_bpl=candidate_bpl,
            diagnostics_history=history,
            validation_warnings=pipeline.warnings,
            graph_artifact=graph_artifact,
            generation_metadata={
                "attempts_used": attempt,
                "max_attempts": resolved_settings.max_attempts,
                "model": resolved_settings.model,
                "target": target,
                "lab_catalog": lab_catalog_metadata,
            },
        )

    failure_diagnostics = latest_diagnostics or [
        Diagnostic(
            code="SOP_GENERATION_RETRY_EXHAUSTED",
            severity="error",
            message=(
                "SOP generation failed without a valid BPL candidate and no diagnostics were emitted."
            ),
            location=None,
            hint="Review SOP text and generation prompts.",
        )
    ]
    return SOPGenerationResult(
        success=False,
        sop_title=sop_doc.title,
        final_bpl=None,
        diagnostics_history=history,
        validation_warnings=[],
        graph_artifact=None,
        failure_diagnostics=failure_diagnostics,
        generation_metadata={
            "attempts_used": resolved_settings.max_attempts,
            "max_attempts": resolved_settings.max_attempts,
            "model": resolved_settings.model,
            "target": target,
            "lab_catalog": lab_catalog_metadata,
        },
    )


def _validate_candidate_bpl(
    *,
    candidate_bpl: str,
    setup_path: Path | None,
    target: str,
) -> tuple[ValidationPipelineResult | None, list[Diagnostic], str]:
    with TemporaryDirectory(prefix="bpl_sop_candidate_") as temp_dir:
        candidate_path = Path(temp_dir) / "candidate.bpl"
        candidate_path.write_text(_ensure_trailing_newline(candidate_bpl), encoding="utf-8")

        try:
            program = run_parse_gate(candidate_path)
        except OrchestrationError as exc:
            return None, exc.diagnostics, "parse"

        semantic_diagnostics = run_semantic_gate(program=program, input_path=candidate_path)
        if semantic_diagnostics:
            return None, semantic_diagnostics, "check"

        try:
            pipeline = run_pipeline_for_plan(
                input_path=candidate_path,
                target=target,
                strict=False,
                setup_path=setup_path,
            )
        except OrchestrationError as exc:
            return None, exc.diagnostics, "validate"
        return pipeline, [], "validate"


def _extract_bpl_text(raw_output: str) -> str:
    bpl_match = _BPL_CODE_BLOCK_RE.search(raw_output)
    if bpl_match:
        return bpl_match.group("code").strip()

    generic_match = _GENERIC_CODE_BLOCK_RE.search(raw_output)
    if generic_match:
        return generic_match.group("code").strip()

    return raw_output.strip()


@lru_cache(maxsize=1)
def _bpl_syntax_reference() -> str:
    """Load authoritative BPL grammar text for prompt grounding."""
    return GRAMMAR_PATH.read_text(encoding="utf-8").strip()


def _ensure_trailing_newline(text: str) -> str:
    return text if text.endswith("\n") else f"{text}\n"


def _format_sections(sections: Sequence[str]) -> str:
    if not sections:
        return "<none>"
    return ", ".join(sections)


def _int_env(name: str, default: int, *, minimum: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise SOPConfigurationError(f"{name} must be an integer, got {raw!r}.") from exc
    if value < minimum:
        raise SOPConfigurationError(f"{name} must be >= {minimum}, got {value}.")
    return value


def _float_env(name: str, default: float, *, minimum: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise SOPConfigurationError(f"{name} must be numeric, got {raw!r}.") from exc
    if value < minimum:
        raise SOPConfigurationError(f"{name} must be >= {minimum}, got {value}.")
    return value
