"""
BPL State Model - Core State Representation

Implements:
- StateProperty: Generic wrapper with value, uncertainty, trust, timestamp
- PlateContents: Sparse plate representation (default + overrides)
- StateTransition: Hash-based state changes with deltas
- StateDelta: Incremental changes for audit trail
"""

from dataclasses import dataclass, field
from typing import Generic, TypeVar, Optional, Dict, Any, List, cast
from datetime import datetime
import hashlib
import json
import math

from .trust import StateTrustLevel, min_trust


T = TypeVar('T')


@dataclass
class StateProperty(Generic[T]):
    """
    A state property with value, uncertainty, trust level, and timestamp.

    Tracks not just the value, but also:
    - Uncertainty bounds (± range)
    - Trust level (Declared/Calibrated/Verified)
    - When it was last updated

    Example:
        tube.volume = StateProperty(
            value=500.0,           # 500 uL
            unit="uL",
            uncertainty=50.0,      # ±50 uL
            trust=Declared(source=TrustSource.USER),
            last_updated=datetime.now()
        )
    """
    value: T
    unit: str
    trust: StateTrustLevel
    last_updated: datetime = field(default_factory=datetime.now)
    uncertainty: Optional[T] = None

    def with_uncertainty(self, uncertainty: T) -> 'StateProperty[T]':
        """Return a copy with updated uncertainty."""
        return StateProperty(
            value=self.value,
            unit=self.unit,
            trust=self.trust,
            last_updated=self.last_updated,
            uncertainty=uncertainty
        )

    def with_trust(self, trust: StateTrustLevel) -> 'StateProperty[T]':
        """Return a copy with updated trust level."""
        return StateProperty(
            value=self.value,
            unit=self.unit,
            trust=trust,
            last_updated=datetime.now(),
            uncertainty=self.uncertainty
        )

    def update(self, value: T, trust: StateTrustLevel) -> 'StateProperty[T]':
        """Return a copy with updated value and trust."""
        return StateProperty(
            value=value,
            unit=self.unit,
            trust=trust,
            last_updated=datetime.now(),
            uncertainty=self.uncertainty
        )

    @property
    def relative_uncertainty(self) -> Optional[float]:
        """Get the relative uncertainty (uncertainty/value) as a fraction."""
        if self.uncertainty is None or self.value == 0:
            return None
        return abs(float(cast(Any, self.uncertainty)) / float(cast(Any, self.value)))

    def has_high_uncertainty(self, threshold: float = 0.2) -> bool:
        """Check if relative uncertainty exceeds threshold (default 20%)."""
        rel = self.relative_uncertainty
        return rel is not None and rel > threshold

    def __repr__(self) -> str:
        unc = f" ± {self.uncertainty}" if self.uncertainty else ""
        return f"StateProperty({self.value}{unc} {self.unit}, {self.trust})"


def propagate_uncertainty_add(
    a: StateProperty[float],
    b: StateProperty[float]
) -> Optional[float]:
    """
    Propagate uncertainty through addition.

    Rule: (a ± δa) + (b ± δb) = (a + b) ± sqrt(δa² + δb²)
    """
    if a.uncertainty is None or b.uncertainty is None:
        return None

    delta_a = float(a.uncertainty)
    delta_b = float(b.uncertainty)

    return math.sqrt(delta_a ** 2 + delta_b ** 2)


def propagate_uncertainty_subtract(
    a: StateProperty[float],
    b: StateProperty[float]
) -> Optional[float]:
    """
    Propagate uncertainty through subtraction.

    Same rule as addition: uncertainties add in quadrature.
    """
    return propagate_uncertainty_add(a, b)


def propagate_uncertainty_multiply(
    a: StateProperty[float],
    b: StateProperty[float]
) -> Optional[float]:
    """
    Propagate uncertainty through multiplication.

    Rule: (a ± δa) * (b ± δb) = (a*b) ± (a*b) * sqrt((δa/a)² + (δb/b)²)
    """
    if a.uncertainty is None or b.uncertainty is None:
        return None

    if a.value == 0 or b.value == 0:
        return None

    rel_a = float(a.uncertainty) / float(a.value)
    rel_b = float(b.uncertainty) / float(b.value)

    result = float(a.value) * float(b.value)
    return abs(result) * math.sqrt(rel_a ** 2 + rel_b ** 2)


def propagate_uncertainty_divide(
    a: StateProperty[float],
    b: StateProperty[float]
) -> Optional[float]:
    """
    Propagate uncertainty through division.

    Rule: (a ± δa) / (b ± δb) = (a/b) ± (a/b) * sqrt((δa/a)² + (δb/b)²)
    """
    if a.uncertainty is None or b.uncertainty is None:
        return None

    if a.value == 0 or b.value == 0:
        return None

    rel_a = float(a.uncertainty) / float(a.value)
    rel_b = float(b.uncertainty) / float(b.value)

    result = float(a.value) / float(b.value)
    return abs(result) * math.sqrt(rel_a ** 2 + rel_b ** 2)


def combine_state_properties(
    a: StateProperty[float],
    b: StateProperty[float],
    operation: str,
    result_unit: str
) -> StateProperty[float]:
    """
    Combine two state properties through an arithmetic operation.

    Propagates both uncertainty and trust level.

    Args:
        a: First operand
        b: Second operand
        operation: One of "+", "-", "*", "/"
        result_unit: Unit for the result

    Returns:
        New StateProperty with combined value, uncertainty, and min trust.
    """
    # Calculate value
    if operation == "+":
        result_value = float(a.value) + float(b.value)
        uncertainty = propagate_uncertainty_add(a, b)
    elif operation == "-":
        result_value = float(a.value) - float(b.value)
        uncertainty = propagate_uncertainty_subtract(a, b)
    elif operation == "*":
        result_value = float(a.value) * float(b.value)
        uncertainty = propagate_uncertainty_multiply(a, b)
    elif operation == "/":
        if float(b.value) == 0:
            raise ValueError("Division by zero")
        result_value = float(a.value) / float(b.value)
        uncertainty = propagate_uncertainty_divide(a, b)
    else:
        raise ValueError(f"Unknown operation: {operation}")

    # Trust is minimum of inputs
    combined_trust = min_trust(a.trust, b.trust)

    return StateProperty(
        value=result_value,
        unit=result_unit,
        trust=combined_trust,
        last_updated=datetime.now(),
        uncertainty=uncertainty
    )


# ============================================================================
# Well and Container Contents
# ============================================================================

@dataclass
class WellContents:
    """Contents of a single well."""
    volume: Optional[StateProperty[float]] = None  # in uL
    concentration: Optional[StateProperty[float]] = None
    concentration_unit: Optional[str] = None
    components: Dict[str, float] = field(default_factory=dict)  # reagent_id -> amount
    temperature: Optional[StateProperty[float]] = None  # in degC
    ph: Optional[StateProperty[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def copy(self) -> 'WellContents':
        """Create a deep copy of well contents."""
        return WellContents(
            volume=self.volume,
            concentration=self.concentration,
            concentration_unit=self.concentration_unit,
            components=dict(self.components),
            temperature=self.temperature,
            ph=self.ph,
            metadata=dict(self.metadata)
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for hashing."""
        result: dict = {}
        if self.volume:
            result["volume"] = {"value": self.volume.value, "unit": self.volume.unit}
        if self.concentration:
            result["concentration"] = {
                "value": self.concentration.value,
                "unit": self.concentration_unit
            }
        if self.components:
            result["components"] = self.components
        if self.temperature:
            result["temperature"] = {"value": self.temperature.value, "unit": "degC"}
        if self.ph:
            result["ph"] = {"value": self.ph.value}
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class ContainerContents:
    """Contents of a container (tube, reservoir, etc.)."""
    container_id: str
    volume: Optional[StateProperty[float]] = None
    concentration: Optional[StateProperty[float]] = None
    concentration_unit: Optional[str] = None
    components: Dict[str, float] = field(default_factory=dict)
    temperature: Optional[StateProperty[float]] = None
    mass: Optional[StateProperty[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for hashing."""
        result: dict = {"id": self.container_id}
        if self.volume:
            result["volume"] = {"value": self.volume.value, "unit": self.volume.unit}
        if self.concentration:
            result["concentration"] = {
                "value": self.concentration.value,
                "unit": self.concentration_unit
            }
        if self.components:
            result["components"] = self.components
        if self.temperature:
            result["temperature"] = {"value": self.temperature.value, "unit": "degC"}
        if self.mass:
            result["mass"] = {"value": self.mass.value, "unit": self.mass.unit}
        if self.metadata:
            result["metadata"] = self.metadata
        return result


# ============================================================================
# Sparse Plate Representation
# ============================================================================

@dataclass
class PlateContents:
    """
    Sparse plate representation.

    Instead of storing 96 copies of well data, uses:
    - default_contents: Default for all wells
    - well_overrides: Only stores differences from default

    This is memory-efficient for plates where most wells are similar.
    """
    plate_id: str
    rows: int = 8  # A-H
    cols: int = 12  # 1-12
    default_contents: Optional[WellContents] = None
    well_overrides: Dict[str, WellContents] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def well_count(self) -> int:
        """Total number of wells."""
        return self.rows * self.cols

    def get_well_id(self, row: int, col: int) -> str:
        """Convert row/col indices to well ID (e.g., 'A1')."""
        if not (0 <= row < self.rows and 0 <= col < self.cols):
            raise ValueError(f"Invalid well position: row={row}, col={col}")
        row_letter = chr(ord('A') + row)
        return f"{row_letter}{col + 1}"

    def parse_well_id(self, well_id: str) -> tuple[int, int]:
        """Parse well ID (e.g., 'A1') to (row, col) indices."""
        if len(well_id) < 2:
            raise ValueError(f"Invalid well ID: {well_id}")

        row_letter = well_id[0].upper()
        col_str = well_id[1:]

        row = ord(row_letter) - ord('A')
        col = int(col_str) - 1

        if not (0 <= row < self.rows and 0 <= col < self.cols):
            raise ValueError(f"Well {well_id} out of range for {self.rows}x{self.cols} plate")

        return (row, col)

    def get_well(self, well_id: str) -> Optional[WellContents]:
        """
        Get contents of a well.

        If well has an override, returns that. Otherwise returns default.
        """
        if well_id in self.well_overrides:
            return self.well_overrides[well_id]
        return self.default_contents

    def set_well(self, well_id: str, contents: WellContents) -> None:
        """
        Set contents of a well.

        If contents match default, removes from overrides.
        Otherwise adds to overrides.
        """
        # Validate well ID
        self.parse_well_id(well_id)

        # Compare to default - if same, remove override
        if self.default_contents and self._contents_equal(contents, self.default_contents):
            self.well_overrides.pop(well_id, None)
        else:
            self.well_overrides[well_id] = contents

    def _contents_equal(self, a: WellContents, b: WellContents) -> bool:
        """Check if two well contents are equal."""
        return a.to_dict() == b.to_dict()

    def set_default(self, contents: WellContents) -> None:
        """Set the default contents for all wells."""
        self.default_contents = contents

    def get_all_wells(self) -> Dict[str, WellContents]:
        """
        Get all wells with their contents.

        Expands sparse representation to full dict.
        """
        result = {}
        for row in range(self.rows):
            for col in range(self.cols):
                well_id = self.get_well_id(row, col)
                contents = self.get_well(well_id)
                if contents:
                    result[well_id] = contents
        return result

    def get_modified_wells(self) -> Dict[str, WellContents]:
        """Get only wells that differ from default."""
        return dict(self.well_overrides)

    def compute_hash(self) -> str:
        """Compute a hash of the plate state."""
        data = {
            "plate_id": self.plate_id,
            "rows": self.rows,
            "cols": self.cols,
            "default": self.default_contents.to_dict() if self.default_contents else None,
            "overrides": {
                k: v.to_dict() for k, v in sorted(self.well_overrides.items())
            },
            "metadata": self.metadata
        }
        json_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def __repr__(self) -> str:
        modified = len(self.well_overrides)
        return f"PlateContents({self.plate_id}, {self.rows}x{self.cols}, {modified} modified)"


# ============================================================================
# State Deltas
# ============================================================================

@dataclass
class WellDelta:
    """Change to a single well."""
    plate_id: str
    well_id: str
    before: Optional[WellContents]
    after: Optional[WellContents]

    @property
    def volume_change(self) -> Optional[float]:
        """Calculate volume change (after - before)."""
        before_vol = self.before.volume.value if self.before and self.before.volume else 0
        after_vol = self.after.volume.value if self.after and self.after.volume else 0
        return after_vol - before_vol

    def to_dict(self) -> dict[str, Any]:
        return {
            "plate_id": self.plate_id,
            "well_id": self.well_id,
            "before": self.before.to_dict() if self.before else None,
            "after": self.after.to_dict() if self.after else None
        }


@dataclass
class ContainerDelta:
    """Change to a container."""
    container_id: str
    before: Optional[ContainerContents]
    after: Optional[ContainerContents]

    @property
    def volume_change(self) -> Optional[float]:
        """Calculate volume change (after - before)."""
        before_vol = self.before.volume.value if self.before and self.before.volume else 0
        after_vol = self.after.volume.value if self.after and self.after.volume else 0
        return after_vol - before_vol

    def to_dict(self) -> dict[str, Any]:
        return {
            "container_id": self.container_id,
            "before": self.before.to_dict() if self.before else None,
            "after": self.after.to_dict() if self.after else None
        }


@dataclass
class StateDelta:
    """
    Incremental state change.

    Records what changed, not the full snapshot.
    Used for efficient state reconstruction and audit trails.
    """
    containers_modified: List[ContainerDelta] = field(default_factory=list)
    wells_modified: List[WellDelta] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)
    description: str = ""

    @property
    def is_empty(self) -> bool:
        """Check if delta represents no change."""
        return not self.containers_modified and not self.wells_modified

    def to_dict(self) -> dict[str, Any]:
        return {
            "containers": [c.to_dict() for c in self.containers_modified],
            "wells": [w.to_dict() for w in self.wells_modified],
            "timestamp": self.timestamp.isoformat(),
            "description": self.description
        }

    def compute_hash(self) -> str:
        """Compute hash of this delta."""
        json_str = json.dumps(self.to_dict(), sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()


# ============================================================================
# State Transitions
# ============================================================================

@dataclass
class StateTransition:
    """
    A state transition with hash chain for audit trail.

    before_hash + delta → after_hash

    This enables:
    - Tamper detection (hash chain verification)
    - State reconstruction (initial + deltas → current)
    - Audit trail (sequence of deltas)
    """
    step_index: int
    before_hash: str
    after_hash: str
    delta: StateDelta
    action_description: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_index": self.step_index,
            "before_hash": self.before_hash,
            "after_hash": self.after_hash,
            "delta": self.delta.to_dict(),
            "action": self.action_description
        }

    def compute_chain_hash(self) -> str:
        """
        Compute incremental hash for audit chain.

        chain_hash[i] = sha256(chain_hash[i-1] + serialize(step[i]))
        """
        data = self.to_dict()
        json_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def verify_hashes(self, computed_before: str, computed_after: str) -> bool:
        """Verify that recorded hashes match computed hashes."""
        return (
            self.before_hash == computed_before and
            self.after_hash == computed_after
        )


class StateHistory:
    """
    Maintains the sequence of state transitions.

    Enables:
    - Hash chain verification
    - State reconstruction at any point
    - Audit trail export
    """

    def __init__(self, initial_hash: str):
        self.initial_hash = initial_hash
        self.transitions: List[StateTransition] = []

    @property
    def current_hash(self) -> str:
        """Get the current state hash."""
        if not self.transitions:
            return self.initial_hash
        return self.transitions[-1].after_hash

    @property
    def chain_hash(self) -> str:
        """Get the current chain hash (for tamper detection)."""
        if not self.transitions:
            return hashlib.sha256(self.initial_hash.encode()).hexdigest()

        # Compute incremental chain hash
        chain = hashlib.sha256(self.initial_hash.encode()).hexdigest()
        for transition in self.transitions:
            data = transition.to_dict()
            json_str = json.dumps(data, sort_keys=True, default=str)
            chain = hashlib.sha256((chain + json_str).encode()).hexdigest()
        return chain

    def add_transition(self, transition: StateTransition) -> None:
        """Add a transition to the history."""
        # Verify continuity
        if transition.before_hash != self.current_hash:
            raise ValueError(
                f"Transition before_hash ({transition.before_hash[:8]}...) "
                f"doesn't match current hash ({self.current_hash[:8]}...)"
            )
        self.transitions.append(transition)

    def verify_chain(self) -> tuple[bool, Optional[str]]:
        """
        Verify the entire hash chain.

        Returns:
            (is_valid, error_message or None)
        """
        if not self.transitions:
            return (True, None)

        # Check first transition
        if self.transitions[0].before_hash != self.initial_hash:
            return (False, "First transition doesn't start from initial hash")

        # Check chain continuity
        for i in range(len(self.transitions) - 1):
            curr = self.transitions[i]
            next_t = self.transitions[i + 1]

            if curr.after_hash != next_t.before_hash:
                return (
                    False,
                    f"Chain break between step {i} and {i+1}: "
                    f"{curr.after_hash[:8]}... != {next_t.before_hash[:8]}..."
                )

        return (True, None)

    def get_step_count(self) -> int:
        """Get the number of recorded steps."""
        return len(self.transitions)

    def get_transition(self, step_index: int) -> Optional[StateTransition]:
        """Get transition by step index."""
        for t in self.transitions:
            if t.step_index == step_index:
                return t
        return None

    def export_audit_trail(self) -> dict[str, Any]:
        """Export the full audit trail for compliance."""
        return {
            "initial_hash": self.initial_hash,
            "chain_hash": self.chain_hash,
            "step_count": len(self.transitions),
            "transitions": [t.to_dict() for t in self.transitions]
        }
