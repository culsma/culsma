"""
BPL State Model - Trust System

Implements tiered verification levels for GxP compliance:
- Declared: User/compiler declared, not verified (confidence: Low)
- Calibrated: Verified by sensor/instrument (confidence: Medium)
- Verified: Calibrated + operator sign-off (confidence: High)
"""

from dataclasses import dataclass, field
from typing import Optional, Union
from enum import Enum, auto
from datetime import datetime


class ConfidenceLevel(Enum):
    """Confidence levels for state values."""
    LOW = auto()      # Declared values
    MEDIUM = auto()   # Calibrated values
    HIGH = auto()     # Verified values


class TrustSource(Enum):
    """Source of a declared value."""
    USER = auto()      # Manually entered by user
    COMPILER = auto()  # Inferred by compiler


class CalibrationMethod(Enum):
    """Methods for calibrating/measuring state values."""
    BALANCE = auto()           # Gravimetric measurement
    PIPETTE = auto()           # Pipette volume tracking
    PLATE_READER = auto()      # Optical measurement
    PH_METER = auto()          # pH measurement
    TEMPERATURE_PROBE = auto() # Temperature measurement
    CELL_COUNTER = auto()      # Cell counting
    SPECTROPHOTOMETER = auto() # Absorbance/concentration
    VISUAL = auto()            # Visual inspection


class ProtocolContext(Enum):
    """Protocol regulatory context affecting trust requirements."""
    RESEARCH = auto()  # Basic research - Declared is acceptable
    GLP = auto()       # Good Laboratory Practice - Calibrated for critical props
    GMP = auto()       # Good Manufacturing Practice - Verified for all changes


@dataclass(frozen=True)
class Declared:
    """
    Trust level for user/compiler declared values.

    Not verified - lowest trust level. Acceptable for research context.
    """
    source: TrustSource
    confidence: ConfidenceLevel = field(default=ConfidenceLevel.LOW, init=False)

    def __str__(self) -> str:
        return f"Declared(source={self.source.name})"


@dataclass(frozen=True)
class Calibrated:
    """
    Trust level for sensor/instrument verified values.

    Medium confidence. Required for GLP critical properties.
    """
    method: CalibrationMethod
    timestamp: datetime
    confidence: ConfidenceLevel = field(default=ConfidenceLevel.MEDIUM, init=False)

    def __str__(self) -> str:
        return f"Calibrated(method={self.method.name}, at={self.timestamp.isoformat()})"


@dataclass(frozen=True)
class ComplianceSignature:
    """An electronic signature for Part 11 compliance."""
    signer_id: str
    meaning: str  # "Authorship", "Review", "Approval", "Witness"
    timestamp: datetime
    signature_hash: str

    def __str__(self) -> str:
        return f"Signature({self.signer_id}:{self.meaning})"


@dataclass(frozen=True)
class Verified:
    """
    Trust level for calibrated + operator sign-off values.

    Highest confidence. Required for GMP context.
    """
    calibration: Calibrated
    verified_by: str  # User ID
    signature: ComplianceSignature
    confidence: ConfidenceLevel = field(default=ConfidenceLevel.HIGH, init=False)

    def __str__(self) -> str:
        return f"Verified(by={self.verified_by}, method={self.calibration.method.name})"


# Union type for all trust levels
StateTrustLevel = Union[Declared, Calibrated, Verified]


def get_confidence(trust: StateTrustLevel) -> ConfidenceLevel:
    """Get the confidence level of a trust level."""
    return trust.confidence


def compare_trust(a: StateTrustLevel, b: StateTrustLevel) -> int:
    """
    Compare two trust levels.

    Returns:
        -1 if a < b
        0 if a == b
        1 if a > b
    """
    order = {
        ConfidenceLevel.LOW: 0,
        ConfidenceLevel.MEDIUM: 1,
        ConfidenceLevel.HIGH: 2,
    }
    a_order = order[a.confidence]
    b_order = order[b.confidence]

    if a_order < b_order:
        return -1
    elif a_order > b_order:
        return 1
    return 0


def min_trust(*trusts: StateTrustLevel) -> StateTrustLevel:
    """
    Get the minimum trust level from a collection.

    Used for trust propagation through calculations:
    concentration = mass / volume
    concentration.trust = min(mass.trust, volume.trust)
    """
    if not trusts:
        raise ValueError("At least one trust level required")

    result = trusts[0]
    for trust in trusts[1:]:
        if compare_trust(trust, result) < 0:
            result = trust
    return result


def max_trust(*trusts: StateTrustLevel) -> StateTrustLevel:
    """Get the maximum trust level from a collection."""
    if not trusts:
        raise ValueError("At least one trust level required")

    result = trusts[0]
    for trust in trusts[1:]:
        if compare_trust(trust, result) > 0:
            result = trust
    return result


def meets_minimum_trust(
    actual: StateTrustLevel,
    required: StateTrustLevel
) -> bool:
    """Check if actual trust level meets or exceeds required level."""
    return compare_trust(actual, required) >= 0


class CriticalProperty(Enum):
    """Properties that require higher trust in GLP/GMP contexts."""
    VOLUME = auto()
    CONCENTRATION = auto()
    CELL_COUNT = auto()
    MASS = auto()
    TEMPERATURE = auto()
    PH = auto()


def get_minimum_trust_for_context(
    context: ProtocolContext,
    property_type: Optional[CriticalProperty] = None
) -> type:
    """
    Get the minimum required trust level for a given context.

    Rules:
    - Research: Declared is acceptable
    - GLP: Calibrated required for critical properties
    - GMP: Verified required for all state changes

    Returns the trust level class (Declared, Calibrated, or Verified).
    """
    if context == ProtocolContext.RESEARCH:
        return Declared

    if context == ProtocolContext.GLP:
        critical_props = {
            CriticalProperty.VOLUME,
            CriticalProperty.CONCENTRATION,
            CriticalProperty.CELL_COUNT,
        }
        if property_type in critical_props:
            return Calibrated
        return Declared

    if context == ProtocolContext.GMP:
        return Verified

    return Declared


def validate_trust_for_context(
    trust: StateTrustLevel,
    context: ProtocolContext,
    property_type: Optional[CriticalProperty] = None
) -> tuple[bool, Optional[str]]:
    """
    Validate that a trust level meets requirements for a context.

    Returns:
        (is_valid, error_message or None)
    """
    min_class = get_minimum_trust_for_context(context, property_type)

    # Map classes to minimum confidence levels
    class_confidence = {
        Declared: ConfidenceLevel.LOW,
        Calibrated: ConfidenceLevel.MEDIUM,
        Verified: ConfidenceLevel.HIGH,
    }

    required_confidence = class_confidence[min_class]
    actual_confidence = trust.confidence

    # Check if actual meets required
    order = {
        ConfidenceLevel.LOW: 0,
        ConfidenceLevel.MEDIUM: 1,
        ConfidenceLevel.HIGH: 2,
    }

    if order[actual_confidence] >= order[required_confidence]:
        return (True, None)

    # Build error message
    prop_name = property_type.name if property_type else "value"
    return (
        False,
        f"{context.name} context requires {min_class.__name__} trust for {prop_name}, "
        f"but got {type(trust).__name__}"
    )


def upgrade_to_calibrated(
    declared: Declared,
    method: CalibrationMethod,
    timestamp: Optional[datetime] = None
) -> Calibrated:
    """
    Upgrade a Declared trust level to Calibrated.

    Used when a sensor/instrument verifies a value.
    """
    return Calibrated(
        method=method,
        timestamp=timestamp or datetime.now()
    )


def upgrade_to_verified(
    calibrated: Calibrated,
    verified_by: str,
    signature: ComplianceSignature
) -> Verified:
    """
    Upgrade a Calibrated trust level to Verified.

    Used when an operator confirms and signs off on a calibrated value.
    """
    return Verified(
        calibration=calibrated,
        verified_by=verified_by,
        signature=signature
    )


def create_signature(
    signer_id: str,
    meaning: str,
    data_hash: str,
    timestamp: Optional[datetime] = None
) -> ComplianceSignature:
    """Create a compliance signature for Part 11 compliance."""
    import hashlib

    ts = timestamp or datetime.now()

    # Create signature hash from signer + meaning + data + timestamp
    signature_input = f"{signer_id}:{meaning}:{data_hash}:{ts.isoformat()}"
    signature_hash = hashlib.sha256(signature_input.encode()).hexdigest()

    return ComplianceSignature(
        signer_id=signer_id,
        meaning=meaning,
        timestamp=ts,
        signature_hash=signature_hash
    )
