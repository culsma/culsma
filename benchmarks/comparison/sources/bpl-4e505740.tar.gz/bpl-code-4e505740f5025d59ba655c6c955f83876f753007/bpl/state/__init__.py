"""
BPL State Model - Sparse plate representation and trust model.

This module provides:
- Trust System: Tiered verification (Declared → Calibrated → Verified) for GxP
- State Properties: Values with uncertainty bounds and trust levels
- Sparse Plate: Memory-efficient plate representation
- State Transitions: Hash-based incremental changes for audit trail
"""

# Trust system
from .trust import (
    # Enums
    ConfidenceLevel,
    TrustSource,
    CalibrationMethod,
    ProtocolContext,
    CriticalProperty,
    # Trust level types
    Declared,
    Calibrated,
    Verified,
    ComplianceSignature,
    StateTrustLevel,
    # Functions
    get_confidence,
    compare_trust,
    min_trust,
    max_trust,
    meets_minimum_trust,
    get_minimum_trust_for_context,
    validate_trust_for_context,
    upgrade_to_calibrated,
    upgrade_to_verified,
    create_signature,
)

# State model
from .state_model import (
    # State properties with uncertainty
    StateProperty,
    propagate_uncertainty_add,
    propagate_uncertainty_subtract,
    propagate_uncertainty_multiply,
    propagate_uncertainty_divide,
    combine_state_properties,
    # Contents
    WellContents,
    ContainerContents,
    PlateContents,
    # Deltas
    WellDelta,
    ContainerDelta,
    StateDelta,
    # Transitions and history
    StateTransition,
    StateHistory,
)

__all__ = [
    # Trust enums
    "ConfidenceLevel",
    "TrustSource",
    "CalibrationMethod",
    "ProtocolContext",
    "CriticalProperty",
    # Trust levels
    "Declared",
    "Calibrated",
    "Verified",
    "ComplianceSignature",
    "StateTrustLevel",
    # Trust functions
    "get_confidence",
    "compare_trust",
    "min_trust",
    "max_trust",
    "meets_minimum_trust",
    "get_minimum_trust_for_context",
    "validate_trust_for_context",
    "upgrade_to_calibrated",
    "upgrade_to_verified",
    "create_signature",
    # State properties
    "StateProperty",
    "propagate_uncertainty_add",
    "propagate_uncertainty_subtract",
    "propagate_uncertainty_multiply",
    "propagate_uncertainty_divide",
    "combine_state_properties",
    # Contents
    "WellContents",
    "ContainerContents",
    "PlateContents",
    # Deltas
    "WellDelta",
    "ContainerDelta",
    "StateDelta",
    # Transitions
    "StateTransition",
    "StateHistory",
]
