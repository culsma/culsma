"""Shared capability registry for backend primitive support."""

from dataclasses import dataclass

from bpl.lowering import ExecutionPlan, PrimitiveType

SIMULATION_SUPPORTED_PRIMITIVES = {
    PrimitiveType.ASPIRATE,
    PrimitiveType.DISPENSE,
    PrimitiveType.MIX,
    PrimitiveType.PICK_TIPS,
    PrimitiveType.DROP_TIPS,
    PrimitiveType.WAIT,
    PrimitiveType.MOVE_LABWARE,
    PrimitiveType.SET_TEMPERATURE,
}

BIOMEK_SUPPORTED_PRIMITIVES = set(SIMULATION_SUPPORTED_PRIMITIVES)
BIOMEK_SUPPORTED_PRIMITIVES.update(
    {
        PrimitiveType.PAUSE,
        PrimitiveType.CHECKPOINT,
    }
)
EXPORT_SUPPORTED_PRIMITIVES = {
    PrimitiveType.ASPIRATE,
    PrimitiveType.DISPENSE,
}
HUMAN_SUPPORTED_PRIMITIVES = set(PrimitiveType)

_TARGET_ALIASES = {
    "human": "human",
    "biomek": "biomek",
    "simulation": "simulation",
    "simulate": "simulation",
    "export": "export",
}

_SUPPORTED_BY_TARGET: dict[str, set[PrimitiveType]] = {
    "human": HUMAN_SUPPORTED_PRIMITIVES,
    "biomek": BIOMEK_SUPPORTED_PRIMITIVES,
    "simulation": SIMULATION_SUPPORTED_PRIMITIVES,
    "export": EXPORT_SUPPORTED_PRIMITIVES,
}


@dataclass(frozen=True)
class CapabilityReport:
    """Capability report for one backend target."""

    target: str
    supported_primitives: list[str]
    unsupported_primitives: list[str]

    def to_dict(self) -> dict[str, object]:
        return {
            "target": self.target,
            "supported_primitives": self.supported_primitives,
            "unsupported_primitives": self.unsupported_primitives,
        }


class StrictCapabilityError(RuntimeError):
    """Raised when strict capability mode encounters unsupported primitives."""

    def __init__(self, target: str, unsupported_primitives: list[str]):
        self.target = target
        self.unsupported_primitives = unsupported_primitives
        message = (
            f"Strict capability failure for target '{target}': "
            f"{', '.join(unsupported_primitives)}"
        )
        super().__init__(message)


def normalize_target(target: str) -> str:
    """Normalize user/backend target aliases."""
    key = target.strip().lower()
    normalized = _TARGET_ALIASES.get(key)
    if normalized is None:
        supported = ", ".join(sorted(_SUPPORTED_BY_TARGET.keys()))
        raise ValueError(f"Unsupported target '{target}'. Supported targets: {supported}")
    return normalized


def primitive_identifier(primitive: PrimitiveType | str) -> str:
    """Convert primitive value into canonical identifier."""
    if isinstance(primitive, PrimitiveType):
        return primitive.name.lower()
    raw = primitive.strip().lower().replace("-", "_")
    return raw


def primitive_type_from_identifier(identifier: str) -> PrimitiveType:
    """Convert canonical primitive identifier to enum."""
    normalized = primitive_identifier(identifier).upper()
    return PrimitiveType[normalized]


def get_supported_primitive_types(target: str) -> set[PrimitiveType]:
    """Get supported primitive enum values for target."""
    normalized = normalize_target(target)
    return set(_SUPPORTED_BY_TARGET[normalized])


def get_capability_report(target: str) -> CapabilityReport:
    """Build deterministic capability report for target."""
    normalized = normalize_target(target)
    supported_types = get_supported_primitive_types(normalized)
    all_types = set(PrimitiveType)
    unsupported_types = all_types - supported_types
    return CapabilityReport(
        target=normalized,
        supported_primitives=sorted(primitive_identifier(p) for p in supported_types),
        unsupported_primitives=sorted(primitive_identifier(p) for p in unsupported_types),
    )


def is_primitive_supported(primitive: PrimitiveType | str, target: str) -> bool:
    """Check whether one primitive is supported by target."""
    primitive_type = (
        primitive if isinstance(primitive, PrimitiveType) else primitive_type_from_identifier(primitive)
    )
    return primitive_type in get_supported_primitive_types(target)


def get_unsupported_primitives_for_plan(plan: ExecutionPlan, target: str) -> list[str]:
    """Return deterministic unsupported primitive set encountered in plan."""
    unsupported: set[str] = set()
    for step in plan.steps.values():
        if not is_primitive_supported(step.primitive.primitive_type, target):
            unsupported.add(primitive_identifier(step.primitive.primitive_type))
    return sorted(unsupported)


def enforce_strict_capabilities(plan: ExecutionPlan, target: str) -> list[str]:
    """Validate plan capability support and raise in strict mode."""
    normalized = normalize_target(target)
    unsupported = get_unsupported_primitives_for_plan(plan, normalized)
    if unsupported:
        raise StrictCapabilityError(target=normalized, unsupported_primitives=unsupported)
    return unsupported
