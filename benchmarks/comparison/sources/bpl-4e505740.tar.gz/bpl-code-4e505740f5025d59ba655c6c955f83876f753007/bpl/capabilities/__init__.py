"""Capability registry public APIs."""

from bpl.capabilities.registry import (
    CapabilityReport,
    StrictCapabilityError,
    enforce_strict_capabilities,
    get_capability_report,
    get_supported_primitive_types,
    get_unsupported_primitives_for_plan,
    is_primitive_supported,
    normalize_target,
    primitive_identifier,
    primitive_type_from_identifier,
)

__all__ = [
    "CapabilityReport",
    "StrictCapabilityError",
    "enforce_strict_capabilities",
    "get_capability_report",
    "get_supported_primitive_types",
    "get_unsupported_primitives_for_plan",
    "is_primitive_supported",
    "normalize_target",
    "primitive_identifier",
    "primitive_type_from_identifier",
]
