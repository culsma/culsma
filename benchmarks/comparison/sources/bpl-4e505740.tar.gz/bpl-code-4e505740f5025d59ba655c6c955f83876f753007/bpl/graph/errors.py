"""Errors for workflow graph building and rendering."""


class GraphIntegrityError(ValueError):
    """Raised when the input plan cannot form a valid workflow graph."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
