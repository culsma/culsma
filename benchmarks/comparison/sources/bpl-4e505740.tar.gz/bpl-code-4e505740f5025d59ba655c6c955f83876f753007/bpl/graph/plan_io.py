"""Execution plan loading helpers for graph rendering flows."""

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Mapping, cast

from bpl.lowering import ExecutionPlan, PlanStep, Primitive, PrimitiveType


@dataclass(frozen=True)
class PrimitiveStub:
    """
    Lightweight primitive placeholder for plan JSON loading.

    Graph rendering only requires ``primitive_type`` and does not execute
    primitives, so this stub is sufficient for graph-building contracts.
    """

    primitive_type: PrimitiveType


def load_execution_plan(path: Path) -> ExecutionPlan:
    """Load an execution plan from JSON file."""

    if not path.exists():
        raise FileNotFoundError(f"Plan file not found: {path}")

    raw_text = path.read_text(encoding="utf-8")
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in plan file '{path}': {exc}") from exc

    if not isinstance(payload, Mapping):
        raise ValueError("Plan JSON must be an object at top-level.")

    return execution_plan_from_dict(payload)


def execution_plan_from_dict(payload: Mapping[str, Any]) -> ExecutionPlan:
    """Convert a mapping payload to ``ExecutionPlan``."""

    plan_id = str(payload.get("plan_id", "plan"))
    protocol_name = str(payload.get("protocol_name", ""))
    target = str(payload.get("target", "human"))
    plan = ExecutionPlan(plan_id=plan_id, protocol_name=protocol_name, target=target)

    raw_steps = payload.get("steps")
    if raw_steps is None:
        raise ValueError("Plan JSON must include a 'steps' field.")

    if isinstance(raw_steps, Mapping):
        step_entries = []
        for step_id in sorted(raw_steps.keys()):
            step_payload = raw_steps[step_id]
            if not isinstance(step_payload, Mapping):
                raise ValueError(f"Step '{step_id}' must be an object.")
            merged = dict(step_payload)
            merged.setdefault("step_id", step_id)
            step_entries.append(merged)
    elif isinstance(raw_steps, list):
        step_entries = raw_steps
    else:
        raise ValueError("Plan JSON 'steps' must be a list or object map.")

    for raw_step in step_entries:
        if not isinstance(raw_step, Mapping):
            raise ValueError("Each plan step must be an object.")

        step_id_raw = raw_step.get("step_id")
        if not isinstance(step_id_raw, str) or not step_id_raw:
            raise ValueError("Each plan step requires non-empty string 'step_id'.")
        step_id = step_id_raw

        if step_id in plan.steps:
            raise ValueError(f"Duplicate step_id '{step_id}' in plan JSON.")

        dependencies_raw = raw_step.get("dependencies", [])
        if not isinstance(dependencies_raw, list) or not all(
            isinstance(dep, str) for dep in dependencies_raw
        ):
            raise ValueError(
                f"Step '{step_id}' has invalid 'dependencies'; expected list[str]."
            )
        dependencies = list(dependencies_raw)

        primitive_type_name = _extract_primitive_type_name(raw_step)
        primitive_type = _parse_primitive_type(primitive_type_name)
        primitive = cast(Primitive, PrimitiveStub(primitive_type=primitive_type))

        source_intent_raw = raw_step.get("source_intent")
        source_intent = (
            source_intent_raw if isinstance(source_intent_raw, str) else None
        )

        annotations_raw = raw_step.get("annotations")
        annotations = annotations_raw if isinstance(annotations_raw, dict) else {}

        plan.add_step(
            PlanStep(
                step_id=step_id,
                primitive=primitive,
                dependencies=dependencies,
                source_intent=source_intent,
                annotations=annotations,
            )
        )

    return plan


def _extract_primitive_type_name(step_payload: Mapping[str, Any]) -> str:
    primitive_type = step_payload.get("primitive_type")
    if isinstance(primitive_type, str) and primitive_type:
        return primitive_type

    primitive_obj = step_payload.get("primitive")
    if isinstance(primitive_obj, Mapping):
        nested = primitive_obj.get("primitive_type")
        if isinstance(nested, str) and nested:
            return nested

    return PrimitiveType.HUMAN_STEP.name


def _parse_primitive_type(raw: str) -> PrimitiveType:
    normalized = raw.strip().upper().replace("-", "_")
    try:
        return PrimitiveType[normalized]
    except KeyError as exc:
        raise ValueError(f"Unknown primitive_type '{raw}'.") from exc
