"""Workflow graph model contract."""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class GraphNode:
    """A node in the rendered workflow graph."""

    node_id: str
    primitive_type: str
    source_intent: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.node_id,
            "primitive_type": self.primitive_type,
        }
        if self.source_intent is not None:
            payload["source_intent"] = self.source_intent
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


@dataclass(frozen=True)
class GraphEdge:
    """A directed edge in the rendered workflow graph."""

    from_node: str
    to_node: str

    def to_dict(self) -> dict[str, str]:
        return {
            "from": self.from_node,
            "to": self.to_node,
        }


@dataclass(frozen=True)
class WorkflowGraph:
    """Graph contract produced from an execution plan."""

    nodes: list[GraphNode]
    edges: list[GraphEdge]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": [node.to_dict() for node in self.nodes],
            "edges": [edge.to_dict() for edge in self.edges],
            "metadata": self.metadata,
        }
