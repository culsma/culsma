"""Build workflow graphs from execution plans."""

import bisect
from typing import Any

from bpl.graph.errors import GraphIntegrityError
from bpl.graph.model import GraphEdge, GraphNode, WorkflowGraph
from bpl.lowering import ExecutionPlan, PrimitiveType


def build_workflow_graph(plan: ExecutionPlan) -> WorkflowGraph:
    """
    Build a deterministic workflow graph from an execution plan.

    Node identity is the original ``PlanStep.step_id`` and edge direction is
    ``dependency -> dependent step``.
    """

    ordered_step_ids = _stable_topological_order(plan)

    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []

    for step_id in ordered_step_ids:
        step = plan.steps[step_id]
        primitive_type = _primitive_type_name(step.primitive.primitive_type)
        node_metadata: dict[str, Any] = {"diagnostic_step_id": step_id}
        if step.annotations:
            node_metadata["annotations"] = step.annotations

        nodes.append(
            GraphNode(
                node_id=step_id,
                primitive_type=primitive_type,
                source_intent=step.source_intent,
                metadata=node_metadata,
            )
        )

        for dependency in sorted(step.dependencies):
            edges.append(GraphEdge(from_node=dependency, to_node=step_id))

    graph_metadata: dict[str, Any] = {
        "plan_id": plan.plan_id,
        "protocol_name": plan.protocol_name,
        "target": plan.target,
        "step_count": len(plan.steps),
    }
    return WorkflowGraph(nodes=nodes, edges=edges, metadata=graph_metadata)


def _stable_topological_order(plan: ExecutionPlan) -> list[str]:
    """
    Return deterministic topological order.

    Independent roots are ordered lexicographically by ``step_id``.
    """

    step_ids = sorted(plan.steps.keys())
    indegree = {step_id: 0 for step_id in step_ids}
    dependents: dict[str, list[str]] = {step_id: [] for step_id in step_ids}

    for step_id in step_ids:
        step = plan.steps[step_id]
        for dependency in step.dependencies:
            if dependency not in plan.steps:
                raise GraphIntegrityError(
                    code="GRAPH_MISSING_DEPENDENCY",
                    message=(
                        f"Step '{step_id}' depends on missing step '{dependency}'."
                    ),
                )
            indegree[step_id] += 1
            dependents[dependency].append(step_id)

    for dependency_step in step_ids:
        dependents[dependency_step].sort()

    ready = sorted(step_id for step_id, degree in indegree.items() if degree == 0)
    ordered: list[str] = []

    while ready:
        current = ready.pop(0)
        ordered.append(current)
        for dependent in dependents[current]:
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                bisect.insort(ready, dependent)

    if len(ordered) != len(step_ids):
        remaining = sorted(set(step_ids) - set(ordered))
        raise GraphIntegrityError(
            code="GRAPH_CYCLE",
            message=f"Cycle detected in execution plan among steps: {remaining}.",
        )

    return ordered


def _primitive_type_name(primitive_type: PrimitiveType | str) -> str:
    if isinstance(primitive_type, PrimitiveType):
        return primitive_type.name
    return str(primitive_type)
