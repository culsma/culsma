"""Render workflow graphs into deterministic output formats."""

from collections import defaultdict, deque
import json
import re

from bpl.graph.model import GraphEdge, GraphNode, WorkflowGraph


def render_workflow_graph(graph: WorkflowGraph, output_format: str) -> str:
    """Render graph as ``json``, ``mermaid``, or ``reactflow-html``."""

    normalized = output_format.lower()
    if normalized == "json":
        return render_workflow_graph_json(graph)
    if normalized == "mermaid":
        return render_workflow_graph_mermaid(graph)
    if normalized in {"reactflow-html", "reactflow_html", "html"}:
        return render_workflow_graph_reactflow_html(graph)
    raise ValueError(f"Unsupported graph format: {output_format}")


def render_workflow_graph_json(graph: WorkflowGraph) -> str:
    """Render graph as stable pretty JSON."""

    return json.dumps(graph.to_dict(), indent=2, sort_keys=True) + "\n"


def render_workflow_graph_mermaid(graph: WorkflowGraph) -> str:
    """Render graph as deterministic Mermaid flowchart text."""

    aliases = _build_mermaid_aliases([node.node_id for node in graph.nodes])
    lines: list[str] = ["graph TD"]

    for node in graph.nodes:
        alias = aliases[node.node_id]
        label = f"{node.node_id} ({node.primitive_type})"
        if node.source_intent:
            label = f"{label}\\nintent: {node.source_intent}"
        annotation_text = _annotation_summary(node.metadata)
        if annotation_text:
            compact_annotation = annotation_text.replace("\n", "\\n")
            label = f"{label}\\n{compact_annotation}"
        lines.append(f'  {alias}["{_escape_mermaid_label(label)}"]')

    for edge in graph.edges:
        from_alias = aliases[edge.from_node]
        to_alias = aliases[edge.to_node]
        lines.append(f"  {from_alias} --> {to_alias}")

    return "\n".join(lines) + "\n"


def render_workflow_graph_reactflow_html(graph: WorkflowGraph) -> str:
    """Render graph as a standalone ReactFlow webpage artifact."""

    payload = _build_reactflow_payload(graph)
    payload_json = json.dumps(payload, indent=2, sort_keys=True)
    return (
        "<!doctype html>\n"
        "<html lang=\"en\">\n"
        "<head>\n"
        "  <meta charset=\"utf-8\" />\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n"
        "  <title>BPL Workflow Graph</title>\n"
        "  <link rel=\"stylesheet\" href=\"https://unpkg.com/reactflow@11/dist/style.css\" />\n"
        "  <style>\n"
        "    html, body { height: 100%; margin: 0; font-family: ui-sans-serif, system-ui; }\n"
        "    #root { height: 100%; }\n"
        "    .header {\n"
        "      padding: 10px 14px;\n"
        "      border-bottom: 1px solid #e5e7eb;\n"
        "      background: #f8fafc;\n"
        "      font-size: 13px;\n"
        "      color: #334155;\n"
        "    }\n"
        "    .layout { height: calc(100% - 42px); display: flex; min-height: 0; }\n"
        "    .canvas { flex: 1 1 auto; min-width: 0; }\n"
        "    .inspector {\n"
        "      width: 360px;\n"
        "      border-left: 1px solid #e5e7eb;\n"
        "      background: #ffffff;\n"
        "      overflow: auto;\n"
        "      padding: 12px;\n"
        "      color: #0f172a;\n"
        "      box-sizing: border-box;\n"
        "    }\n"
        "    .inspector h2 { margin: 0; font-size: 14px; }\n"
        "    .muted { color: #64748b; font-size: 12px; margin-top: 6px; }\n"
        "    .block-title {\n"
        "      margin-top: 12px;\n"
        "      margin-bottom: 6px;\n"
        "      font-size: 12px;\n"
        "      color: #334155;\n"
        "      font-weight: 600;\n"
        "    }\n"
        "    .codeblock {\n"
        "      white-space: pre-wrap;\n"
        "      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;\n"
        "      font-size: 11px;\n"
        "      line-height: 1.35;\n"
        "      background: #f8fafc;\n"
        "      border: 1px solid #e2e8f0;\n"
        "      border-radius: 8px;\n"
        "      padding: 10px;\n"
        "      margin: 0;\n"
        "    }\n"
        "    @media (max-width: 1200px) {\n"
        "      .inspector { width: 300px; }\n"
        "    }\n"
        "    @media (max-width: 900px) {\n"
        "      .layout { flex-direction: column; }\n"
        "      .inspector {\n"
        "        width: auto;\n"
        "        max-height: 40%;\n"
        "        border-left: none;\n"
        "        border-top: 1px solid #e5e7eb;\n"
        "      }\n"
        "    }\n"
        "  </style>\n"
        "</head>\n"
        "<body>\n"
        "  <div id=\"root\"></div>\n"
        "  <script>\n"
        f"    window.__BPL_GRAPH_PAYLOAD__ = {payload_json};\n"
        "  </script>\n"
        "  <script src=\"https://unpkg.com/react@18/umd/react.production.min.js\" "
        "crossorigin=\"anonymous\"></script>\n"
        "  <script src=\"https://unpkg.com/react-dom@18/umd/react-dom.production.min.js\" "
        "crossorigin=\"anonymous\"></script>\n"
        "  <script src=\"https://unpkg.com/reactflow@11/dist/umd/index.js\" "
        "crossorigin=\"anonymous\"></script>\n"
        "  <script>\n"
        "    (function () {\n"
        "      const React = window.React;\n"
        "      const ReactDOM = window.ReactDOM;\n"
        "      const RF = window.ReactFlow;\n"
        "      if (!React || !ReactDOM || !RF) {\n"
        "        document.body.innerHTML = \"<pre>Failed to load React/ReactFlow assets.</pre>\";\n"
        "        return;\n"
        "      }\n"
        "\n"
        "      const ReactFlowComponent = RF.default || RF.ReactFlow || RF;\n"
        "      const Background = RF.Background;\n"
        "      const Controls = RF.Controls;\n"
        "      const MiniMap = RF.MiniMap;\n"
        "      const MarkerType = RF.MarkerType || {};\n"
        "      const useMemo = React.useMemo;\n"
        "      const useState = React.useState;\n"
        "      const payload = window.__BPL_GRAPH_PAYLOAD__ || { nodes: [], edges: [], metadata: {} };\n"
        "      const nodes = Array.isArray(payload.nodes) ? payload.nodes : [];\n"
        "      const edges = (Array.isArray(payload.edges) ? payload.edges : []).map((edge) => {\n"
        "        const rendered = Object.assign({}, edge);\n"
        "        if (MarkerType.ArrowClosed) {\n"
        "          rendered.markerEnd = { type: MarkerType.ArrowClosed };\n"
        "        }\n"
        "        return rendered;\n"
        "      });\n"
        "\n"
        "      function App() {\n"
        "        const nodeCount = nodes.length;\n"
        "        const edgeCount = edges.length;\n"
        "        const [selectedNodeId, setSelectedNodeId] = useState(nodes.length ? nodes[0].id : null);\n"
        "        const selectedNode = useMemo(\n"
        "          () => nodes.find((node) => node.id === selectedNodeId) || null,\n"
        "          [selectedNodeId]\n"
        "        );\n"
        "        const renderedNodes = useMemo(\n"
        "          () => nodes.map((node) => {\n"
        "            if (node.id !== selectedNodeId) {\n"
        "              return node;\n"
        "            }\n"
        "            return Object.assign({}, node, {\n"
        "              style: Object.assign({}, node.style || {}, {\n"
        "                border: \"2px solid #0f766e\",\n"
        "                boxShadow: \"0 0 0 1px #99f6e4\",\n"
        "              }),\n"
        "            });\n"
        "          }),\n"
        "          [selectedNodeId]\n"
        "        );\n"
        "        const selectedData = selectedNode && selectedNode.data ? selectedNode.data : null;\n"
        "        const selectedType = selectedData && selectedData.primitive_type\n"
        "          ? selectedData.primitive_type\n"
        "          : \"\";\n"
        "        const selectedIntent = selectedData && selectedData.source_intent\n"
        "          ? selectedData.source_intent\n"
        "          : \"\";\n"
        "        const selectedAnnotation = selectedData && (selectedData.annotation_full || selectedData.annotation)\n"
        "          ? (selectedData.annotation_full || selectedData.annotation)\n"
        "          : \"No annotation data.\";\n"
        "        function handleNodeClick(_event, node) {\n"
        "          if (node && node.id) {\n"
        "            setSelectedNodeId(node.id);\n"
        "          }\n"
        "        }\n"
        "        return React.createElement(\n"
        "          React.Fragment,\n"
        "          null,\n"
        "          React.createElement(\n"
        "            \"div\",\n"
        "            { className: \"header\" },\n"
        "            `BPL Workflow Graph | nodes=${nodeCount} | edges=${edgeCount} | click node to inspect full annotations`\n"
        "          ),\n"
        "          React.createElement(\n"
        "            \"div\",\n"
        "            { className: \"layout\" },\n"
        "            React.createElement(\n"
        "              \"div\",\n"
        "              { className: \"canvas\" },\n"
        "              React.createElement(\n"
        "                ReactFlowComponent,\n"
        "                {\n"
        "                  nodes: renderedNodes,\n"
        "                  edges: edges,\n"
        "                  fitView: true,\n"
        "                  fitViewOptions: { padding: 0.2 },\n"
        "                  minZoom: 0.1,\n"
        "                  maxZoom: 1.8,\n"
        "                  onNodeClick: handleNodeClick,\n"
        "                },\n"
        "                Background ? React.createElement(Background, { gap: 24, size: 1 }) : null,\n"
        "                Controls ? React.createElement(Controls, null) : null,\n"
        "                MiniMap ? React.createElement(MiniMap, null) : null\n"
        "              )\n"
        "            ),\n"
        "            React.createElement(\n"
        "              \"aside\",\n"
        "              { className: \"inspector\" },\n"
        "              selectedNode\n"
        "                ? React.createElement(\n"
        "                    React.Fragment,\n"
        "                    null,\n"
        "                    React.createElement(\"h2\", null, selectedNode.id),\n"
        "                    React.createElement(\n"
        "                      \"div\",\n"
        "                      { className: \"muted\" },\n"
        "                      selectedType + (selectedIntent ? ` | intent: ${selectedIntent}` : \"\")\n"
        "                    ),\n"
        "                    React.createElement(\"div\", { className: \"block-title\" }, \"Annotations\"),\n"
        "                    React.createElement(\"pre\", { className: \"codeblock\" }, selectedAnnotation)\n"
        "                  )\n"
        "                : React.createElement(\n"
        "                    \"div\",\n"
        "                    { className: \"muted\" },\n"
        "                    \"Click any node to inspect full annotations.\"\n"
        "                  )\n"
        "            )\n"
        "          )\n"
        "        );\n"
        "      }\n"
        "\n"
        "      const mount = document.getElementById(\"root\");\n"
        "      if (ReactDOM.createRoot) {\n"
        "        ReactDOM.createRoot(mount).render(React.createElement(App));\n"
        "      } else if (ReactDOM.render) {\n"
        "        ReactDOM.render(React.createElement(App), mount);\n"
        "      }\n"
        "    })();\n"
        "  </script>\n"
        "</body>\n"
        "</html>\n"
    )


def render_workflow_graph_reactflow_html_from_dict(graph_payload: dict[str, object]) -> str:
    """Render ReactFlow HTML from graph JSON payload."""

    raw_nodes = graph_payload.get("nodes", [])
    raw_edges = graph_payload.get("edges", [])
    raw_metadata = graph_payload.get("metadata", {})

    nodes: list[GraphNode] = []
    for item in raw_nodes if isinstance(raw_nodes, list) else []:
        if not isinstance(item, dict):
            continue
        node_id = str(item.get("id", ""))
        primitive_type = str(item.get("primitive_type", "UNKNOWN"))
        source_intent = item.get("source_intent")
        metadata = item.get("metadata", {})
        nodes.append(
            GraphNode(
                node_id=node_id,
                primitive_type=primitive_type,
                source_intent=str(source_intent) if source_intent is not None else None,
                metadata=metadata if isinstance(metadata, dict) else {},
            )
        )

    edges: list[GraphEdge] = []
    for item in raw_edges if isinstance(raw_edges, list) else []:
        if not isinstance(item, dict):
            continue
        edges.append(
            GraphEdge(
                from_node=str(item.get("from", "")),
                to_node=str(item.get("to", "")),
            )
        )

    metadata = raw_metadata if isinstance(raw_metadata, dict) else {}
    graph = WorkflowGraph(nodes=nodes, edges=edges, metadata=metadata)
    return render_workflow_graph_reactflow_html(graph)


def _build_mermaid_aliases(node_ids: list[str]) -> dict[str, str]:
    aliases: dict[str, str] = {}
    used: set[str] = set()

    for node_id in node_ids:
        base = re.sub(r"[^A-Za-z0-9_]", "_", node_id)
        if not base:
            base = "node"
        if base[0].isdigit():
            base = f"n_{base}"

        alias = base
        suffix = 2
        while alias in used:
            alias = f"{base}_{suffix}"
            suffix += 1

        aliases[node_id] = alias
        used.add(alias)

    return aliases


def _escape_mermaid_label(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', '\\"')


def _build_reactflow_payload(graph: WorkflowGraph) -> dict[str, object]:
    positions = _deterministic_node_positions(graph)
    nodes: list[dict[str, object]] = []
    for node in graph.nodes:
        label = f"{node.node_id}\n{node.primitive_type}"
        if node.source_intent:
            label = f"{label}\nintent: {node.source_intent}"
        call_preview = _source_call_preview(node.metadata, max_chars=88)
        if call_preview:
            label = f"{label}\n{call_preview}"
        annotation_preview = _annotation_preview_line(node.metadata)
        if annotation_preview:
            label = f"{label}\n{annotation_preview}"
        annotation_text = _annotation_summary(node.metadata)
        annotation_full_text = _annotation_full_text(node.metadata)
        x, y = positions[node.node_id]
        nodes.append(
            {
                "id": node.node_id,
                "data": {
                    "label": label,
                    "annotation": annotation_text,
                    "annotation_full": annotation_full_text,
                    "primitive_type": node.primitive_type,
                    "source_intent": node.source_intent,
                },
                "position": {"x": x, "y": y},
                "style": {
                    "background": "#ffffff",
                    "border": "1px solid #94a3b8",
                    "borderRadius": "8px",
                    "fontFamily": "ui-monospace, SFMono-Regular, Menlo, monospace",
                    "fontSize": "11px",
                    "padding": "8px 10px",
                    "lineHeight": "1.3",
                    "width": "260px",
                    "whiteSpace": "pre-wrap",
                },
            }
        )

    edges: list[dict[str, object]] = []
    for edge in graph.edges:
        edge_id = f"{edge.from_node}__{edge.to_node}"
        edges.append(
            {
                "id": edge_id,
                "source": edge.from_node,
                "target": edge.to_node,
                "type": "smoothstep",
                "style": {"stroke": "#64748b", "strokeWidth": 1.2},
            }
        )

    return {
        "nodes": nodes,
        "edges": edges,
        "metadata": graph.metadata,
    }


def _deterministic_node_positions(graph: WorkflowGraph) -> dict[str, tuple[int, int]]:
    node_ids = [node.node_id for node in graph.nodes]
    if _is_chain_like_graph(graph):
        if len(graph.nodes) >= 24:
            return _timeline_positions(graph.nodes)
        return _snake_positions(node_ids)

    order_index = {node.node_id: index for index, node in enumerate(graph.nodes)}
    indegree: dict[str, int] = {node.node_id: 0 for node in graph.nodes}
    outgoing: dict[str, list[str]] = defaultdict(list)

    for edge in graph.edges:
        if edge.from_node not in indegree or edge.to_node not in indegree:
            continue
        indegree[edge.to_node] += 1
        outgoing[edge.from_node].append(edge.to_node)

    for source in list(outgoing.keys()):
        outgoing[source] = sorted(outgoing[source], key=lambda node_id: order_index[node_id])

    queue: deque[str] = deque(
        sorted(
            [node_id for node_id, degree in indegree.items() if degree == 0],
            key=lambda node_id: order_index[node_id],
        )
    )
    depth: dict[str, int] = {node.node_id: 0 for node in graph.nodes}

    visited_count = 0
    while queue:
        current = queue.popleft()
        visited_count += 1
        for child in outgoing.get(current, []):
            depth[child] = max(depth[child], depth[current] + 1)
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)

    # Fall back for cycles/unreachable leftovers: keep them in depth 0 with stable order.
    if visited_count != len(graph.nodes):
        for node in graph.nodes:
            depth.setdefault(node.node_id, 0)

    lanes: dict[int, list[str]] = defaultdict(list)
    for node in graph.nodes:
        lanes[depth[node.node_id]].append(node.node_id)

    positions: dict[str, tuple[int, int]] = {}
    x_spacing = 360
    y_spacing = 180
    max_depth_columns = 8
    group_gap = 180

    # For deep graphs, wrap depth into groups to avoid ultra-wide layouts.
    group_lane_counts: dict[int, int] = defaultdict(int)
    for lane_depth, lane_nodes in lanes.items():
        group = lane_depth // max_depth_columns
        group_lane_counts[group] = max(group_lane_counts[group], len(lane_nodes))

    group_offsets: dict[int, int] = {}
    offset = 0
    for group in sorted(group_lane_counts.keys()):
        group_offsets[group] = offset
        offset += (group_lane_counts[group] * y_spacing) + group_gap

    for lane_depth in sorted(lanes.keys()):
        lane_nodes = lanes[lane_depth]
        group = lane_depth // max_depth_columns
        column = lane_depth % max_depth_columns
        base_y = group_offsets[group]
        for lane_index, node_id in enumerate(lane_nodes):
            positions[node_id] = (column * x_spacing, base_y + (lane_index * y_spacing))
    return positions


def _is_chain_like_graph(graph: WorkflowGraph) -> bool:
    if not graph.nodes:
        return False
    if len(graph.edges) != len(graph.nodes) - 1:
        return False

    indegree: dict[str, int] = {node.node_id: 0 for node in graph.nodes}
    outdegree: dict[str, int] = {node.node_id: 0 for node in graph.nodes}
    node_ids = set(indegree.keys())

    for edge in graph.edges:
        if edge.from_node not in node_ids or edge.to_node not in node_ids:
            return False
        outdegree[edge.from_node] += 1
        indegree[edge.to_node] += 1

    return max(indegree.values()) <= 1 and max(outdegree.values()) <= 1


def _snake_positions(node_ids: list[str]) -> dict[str, tuple[int, int]]:
    count = len(node_ids)
    if count <= 6:
        columns = count
    else:
        columns = max(4, min(8, int(count ** 0.5)))

    x_spacing = 340
    y_spacing = 180
    positions: dict[str, tuple[int, int]] = {}

    for index, node_id in enumerate(node_ids):
        row = index // columns
        col_in_row = index % columns
        col = col_in_row if row % 2 == 0 else (columns - 1 - col_in_row)
        positions[node_id] = (col * x_spacing, row * y_spacing)
    return positions


def _timeline_positions(nodes: list[GraphNode]) -> dict[str, tuple[int, int]]:
    positions: dict[str, tuple[int, int]] = {}
    current_y = 0
    for node in nodes:
        positions[node.node_id] = (0, current_y)
        current_y += _estimate_node_height(node) + 36
    return positions


def _estimate_node_height(node: GraphNode) -> int:
    base_lines = 2  # node id + primitive type
    if node.source_intent:
        base_lines += 1
    if _source_call_preview(node.metadata):
        base_lines += 1
    if _annotation_preview_line(node.metadata):
        base_lines += 1
    estimated = 26 + (base_lines * 18)
    return max(90, min(160, estimated))


def _source_call_preview(metadata: dict[str, object], *, max_chars: int | None = None) -> str | None:
    annotations = metadata.get("annotations")
    if not isinstance(annotations, dict):
        return None
    source_call = annotations.get("source_call")
    if not isinstance(source_call, str):
        return None
    source_call = source_call.strip()
    if not source_call:
        return None
    if max_chars is not None:
        source_call = _truncate_text(source_call, max_chars)
    return f"call: {source_call}"


def _annotation_lines(
    metadata: dict[str, object],
    *,
    truncate_at: int | None = None,
    max_lines: int | None = None,
) -> list[str]:
    annotations = metadata.get("annotations")
    if not isinstance(annotations, dict):
        return []

    lines: list[str] = []
    comment = annotations.get("source_comment")
    if isinstance(comment, str) and comment.strip():
        for raw in comment.splitlines():
            entry = raw.strip()
            if entry:
                comment_text = _truncate_text(entry, truncate_at) if truncate_at else entry
                lines.append(f"// {comment_text}")

    source_call = annotations.get("source_call")
    if isinstance(source_call, str) and source_call.strip():
        call_text = source_call.strip()
        if truncate_at:
            call_text = _truncate_text(call_text, truncate_at)
        lines.append(f"src: {call_text}")

    if not lines:
        source_line = annotations.get("source_line")
        if isinstance(source_line, str) and source_line.strip():
            source_text = source_line.strip()
            if truncate_at:
                source_text = _truncate_text(source_text, truncate_at)
            lines.append(f"src: {source_text}")

    if max_lines is not None:
        return lines[:max_lines]
    return lines


def _annotation_summary(metadata: dict[str, object]) -> str | None:
    lines = _annotation_lines(metadata, truncate_at=90, max_lines=4)
    if not lines:
        return None
    return "\n".join(lines)


def _annotation_full_text(metadata: dict[str, object]) -> str | None:
    lines = _annotation_lines(metadata)
    if not lines:
        return None
    return "\n".join(lines)


def _annotation_preview_line(metadata: dict[str, object]) -> str | None:
    summary = _annotation_summary(metadata)
    if not summary:
        return None
    first_line = summary.splitlines()[0].strip()
    if not first_line:
        return None
    return _truncate_text(first_line, 80)


def _truncate_text(text: str, max_chars: int | None) -> str:
    if max_chars is None:
        return text
    if len(text) <= max_chars:
        return text
    return f"{text[: max_chars - 3].rstrip()}..."
