"""
BPL Checkpoint UI - UI generation for checkpoints during human execution.

Provides:
- CheckpointUI for generating checkpoint displays
- CheckpointDialog for interactive checkpoints
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime

from .execution_ir import HumanExecutionStep
from .data_capture import DataCapture, DataField
from .signatures import SignatureRequest, SignatureType


class CheckpointType(Enum):
    """Type of checkpoint."""
    PAUSE = auto()          # Simple pause point
    CONFIRMATION = auto()   # Requires confirmation to proceed
    DATA_ENTRY = auto()     # Requires data entry
    SIGNATURE = auto()      # Requires signature
    APPROVAL = auto()       # Requires supervisor approval
    VERIFICATION = auto()   # Requires verification check
    TIMER = auto()          # Wait for timer
    DECISION = auto()       # Branch point requiring decision


class CheckpointAction(Enum):
    """Actions available at a checkpoint."""
    CONTINUE = auto()
    PAUSE = auto()
    SKIP = auto()
    RETRY = auto()
    ABORT = auto()
    BRANCH = auto()


@dataclass
class CheckpointOption:
    """An option presented at a checkpoint."""
    option_id: str
    label: str
    action: CheckpointAction
    description: Optional[str] = None
    enabled: bool = True
    is_default: bool = False
    requires_confirmation: bool = False
    branch_target: Optional[str] = None  # For decision checkpoints


@dataclass
class CheckpointState:
    """Current state of a checkpoint."""
    checkpoint_id: str
    checkpoint_type: CheckpointType
    step_id: str

    # Status
    is_active: bool = False
    is_complete: bool = False
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Resolution
    selected_action: Optional[CheckpointAction] = None
    selected_option: Optional[str] = None

    # Associated data
    data_capture: Optional[DataCapture] = None
    signature_request: Optional[SignatureRequest] = None

    # Results
    results: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CheckpointUI:
    """UI representation of a checkpoint."""
    checkpoint_id: str
    checkpoint_type: CheckpointType
    title: str
    message: str

    # Options
    options: List[CheckpointOption] = field(default_factory=list)

    # Data fields (if data entry checkpoint)
    data_fields: List[DataField] = field(default_factory=list)

    # Timer (if timer checkpoint)
    timer_id: Optional[str] = None
    timer_duration_s: Optional[float] = None

    # UI hints
    icon: Optional[str] = None
    color: Optional[str] = None  # info, warning, error, success
    blocking: bool = True
    timeout_s: Optional[float] = None

    # Callbacks
    on_action: Optional[Callable[[CheckpointAction], None]] = None

    def add_option(
        self,
        option_id: str,
        label: str,
        action: CheckpointAction,
        description: Optional[str] = None,
        is_default: bool = False
    ) -> None:
        """Add an option to the checkpoint."""
        self.options.append(CheckpointOption(
            option_id=option_id,
            label=label,
            action=action,
            description=description,
            is_default=is_default,
        ))

    def add_data_field(self, field_def: DataField) -> None:
        """Add a data field to collect."""
        self.data_fields.append(field_def)


class CheckpointUIGenerator:
    """Generates checkpoint UI elements."""

    def __init__(self):
        self._templates: Dict[CheckpointType, Callable] = {
            CheckpointType.PAUSE: self._generate_pause,
            CheckpointType.CONFIRMATION: self._generate_confirmation,
            CheckpointType.DATA_ENTRY: self._generate_data_entry,
            CheckpointType.SIGNATURE: self._generate_signature,
            CheckpointType.APPROVAL: self._generate_approval,
            CheckpointType.VERIFICATION: self._generate_verification,
            CheckpointType.TIMER: self._generate_timer,
            CheckpointType.DECISION: self._generate_decision,
        }

    def generate(
        self,
        checkpoint_type: CheckpointType,
        step: HumanExecutionStep,
        **kwargs
    ) -> CheckpointUI:
        """Generate checkpoint UI for a step."""
        generator = self._templates.get(checkpoint_type, self._generate_default)
        return generator(step, **kwargs)

    def _generate_pause(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate pause checkpoint UI."""
        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.PAUSE,
            title="Pause Point",
            message=kwargs.get("message", "Protocol paused. Press Continue when ready."),
            icon="⏸️",
            color="info",
        )

        ui.add_option("continue", "Continue", CheckpointAction.CONTINUE, is_default=True)
        ui.add_option("abort", "Abort Protocol", CheckpointAction.ABORT,
                     description="Stop execution and save progress")

        return ui

    def _generate_confirmation(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate confirmation checkpoint UI."""
        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.CONFIRMATION,
            title="Confirmation Required",
            message=kwargs.get("message", f"Please confirm: {step.instruction}"),
            icon="❓",
            color="warning",
        )

        ui.add_option("confirm", "Confirm & Continue", CheckpointAction.CONTINUE, is_default=True)
        ui.add_option("skip", "Skip This Step", CheckpointAction.SKIP,
                     description="Mark as skipped and continue")
        ui.add_option("retry", "Go Back", CheckpointAction.RETRY,
                     description="Return to previous step")

        return ui

    def _generate_data_entry(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate data entry checkpoint UI."""
        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.DATA_ENTRY,
            title="Data Entry Required",
            message=kwargs.get("message", "Please enter the required data."),
            icon="📝",
            color="info",
        )

        # Add data fields from kwargs
        fields = kwargs.get("fields", [])
        for f in fields:
            ui.add_data_field(f)

        ui.add_option("submit", "Submit Data", CheckpointAction.CONTINUE, is_default=True)
        ui.add_option("skip", "Skip (if allowed)", CheckpointAction.SKIP)

        return ui

    def _generate_signature(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate signature checkpoint UI."""
        signature_type = kwargs.get("signature_type", SignatureType.INITIALS)

        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.SIGNATURE,
            title="Signature Required",
            message=kwargs.get("message", f"Please provide your {signature_type.name.lower()}."),
            icon="✍️",
            color="warning",
        )

        if signature_type == SignatureType.INITIALS:
            ui.add_option("initial", "Initial", CheckpointAction.CONTINUE, is_default=True)
        else:
            ui.add_option("sign", "Sign", CheckpointAction.CONTINUE, is_default=True)

        return ui

    def _generate_approval(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate approval checkpoint UI."""
        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.APPROVAL,
            title="Supervisor Approval Required",
            message=kwargs.get("message", "This step requires supervisor approval."),
            icon="👤",
            color="warning",
            blocking=True,
        )

        ui.add_option("approve", "Approve", CheckpointAction.CONTINUE,
                     description="Approve and continue execution")
        ui.add_option("reject", "Reject", CheckpointAction.ABORT,
                     description="Reject and stop execution")
        ui.add_option("defer", "Defer Decision", CheckpointAction.PAUSE,
                     description="Pause and wait for later decision")

        return ui

    def _generate_verification(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate verification checkpoint UI."""
        checks = kwargs.get("checks", [])

        message = "Please verify the following:\n"
        for check in checks:
            message += f"• {check}\n"

        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.VERIFICATION,
            title="Verification Required",
            message=message,
            icon="✓",
            color="info",
        )

        ui.add_option("verified", "All Verified", CheckpointAction.CONTINUE, is_default=True)
        ui.add_option("issue", "Report Issue", CheckpointAction.PAUSE,
                     description="Report a verification issue")

        return ui

    def _generate_timer(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate timer checkpoint UI."""
        duration_s = kwargs.get("duration_s", 0)
        timer_name = kwargs.get("timer_name", "Timer")

        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.TIMER,
            title=f"Wait: {timer_name}",
            message=f"Waiting for {format_duration(duration_s)}",
            icon="⏱️",
            color="info",
            timer_id=kwargs.get("timer_id"),
            timer_duration_s=duration_s,
        )

        ui.add_option("wait", "Wait for Timer", CheckpointAction.PAUSE, is_default=True)
        ui.add_option("skip", "Skip Timer", CheckpointAction.CONTINUE,
                     description="Continue without waiting")

        return ui

    def _generate_decision(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate decision checkpoint UI."""
        ui = CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.DECISION,
            title="Decision Required",
            message=kwargs.get("message", "Please select how to proceed."),
            icon="🔀",
            color="info",
        )

        # Add decision branches from kwargs
        branches = kwargs.get("branches", {})
        for branch_id, branch_info in branches.items():
            ui.add_option(
                branch_id,
                branch_info.get("label", branch_id),
                CheckpointAction.BRANCH,
                description=branch_info.get("description"),
            )
            ui.options[-1].branch_target = branch_info.get("target")

        return ui

    def _generate_default(self, step: HumanExecutionStep, **kwargs) -> CheckpointUI:
        """Generate default checkpoint UI."""
        return CheckpointUI(
            checkpoint_id=f"cp_{step.step_id}",
            checkpoint_type=CheckpointType.CONFIRMATION,
            title="Checkpoint",
            message=step.instruction,
            icon="📌",
            color="info",
        )


class CheckpointManager:
    """Manages checkpoints during protocol execution."""

    def __init__(self):
        self.checkpoints: Dict[str, CheckpointState] = {}
        self.active_checkpoint: Optional[str] = None
        self.generator = CheckpointUIGenerator()
        self.history: List[CheckpointState] = []

    def create_checkpoint(
        self,
        checkpoint_type: CheckpointType,
        step: HumanExecutionStep,
        **kwargs
    ) -> tuple[CheckpointState, CheckpointUI]:
        """Create a new checkpoint."""
        checkpoint_id = f"cp_{step.step_id}"

        state = CheckpointState(
            checkpoint_id=checkpoint_id,
            checkpoint_type=checkpoint_type,
            step_id=step.step_id,
        )
        self.checkpoints[checkpoint_id] = state

        ui = self.generator.generate(checkpoint_type, step, **kwargs)

        return state, ui

    def activate(self, checkpoint_id: str) -> Optional[CheckpointState]:
        """Activate a checkpoint."""
        state = self.checkpoints.get(checkpoint_id)
        if state:
            state.is_active = True
            state.started_at = datetime.now()
            self.active_checkpoint = checkpoint_id
        return state

    def resolve(
        self,
        checkpoint_id: str,
        action: CheckpointAction,
        option_id: Optional[str] = None,
        results: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Resolve a checkpoint with an action."""
        state = self.checkpoints.get(checkpoint_id)
        if not state or not state.is_active:
            return False

        state.is_active = False
        state.is_complete = True
        state.completed_at = datetime.now()
        state.selected_action = action
        state.selected_option = option_id
        if results:
            state.results.update(results)

        self.history.append(state)
        self.active_checkpoint = None

        return True

    def get_checkpoint(self, checkpoint_id: str) -> Optional[CheckpointState]:
        """Get checkpoint state."""
        return self.checkpoints.get(checkpoint_id)

    def get_active(self) -> Optional[CheckpointState]:
        """Get the currently active checkpoint."""
        if self.active_checkpoint:
            return self.checkpoints.get(self.active_checkpoint)
        return None

    def is_blocked(self) -> bool:
        """Check if execution is blocked by a checkpoint."""
        return self.active_checkpoint is not None

    def get_summary(self) -> Dict[str, Any]:
        """Get checkpoint manager summary."""
        return {
            "total_checkpoints": len(self.checkpoints),
            "completed": len([c for c in self.checkpoints.values() if c.is_complete]),
            "active": self.active_checkpoint,
            "history_count": len(self.history),
        }


def format_duration(seconds: float) -> str:
    """Format duration for display."""
    if seconds >= 3600:
        hours = int(seconds // 3600)
        mins = int((seconds % 3600) // 60)
        return f"{hours}h {mins}m"
    elif seconds >= 60:
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m {secs}s"
    return f"{int(seconds)}s"


# Convenience functions
def create_pause_checkpoint(step: HumanExecutionStep, message: str = "") -> CheckpointUI:
    """Create a simple pause checkpoint."""
    generator = CheckpointUIGenerator()
    return generator.generate(CheckpointType.PAUSE, step, message=message)


def create_confirmation_checkpoint(step: HumanExecutionStep, message: str = "") -> CheckpointUI:
    """Create a confirmation checkpoint."""
    generator = CheckpointUIGenerator()
    return generator.generate(CheckpointType.CONFIRMATION, step, message=message)


def create_signature_checkpoint(
    step: HumanExecutionStep,
    signature_type: SignatureType = SignatureType.INITIALS
) -> CheckpointUI:
    """Create a signature checkpoint."""
    generator = CheckpointUIGenerator()
    return generator.generate(CheckpointType.SIGNATURE, step, signature_type=signature_type)
