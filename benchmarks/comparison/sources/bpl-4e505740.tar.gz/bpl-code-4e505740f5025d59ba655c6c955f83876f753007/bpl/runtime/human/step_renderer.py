"""
BPL Step Renderer - Renders execution steps to various formats.

Provides:
- StepRenderer for generating human-readable instructions
- Multiple output formats (text, HTML, markdown)
"""

from dataclasses import dataclass
from typing import Dict, Optional, Any, Callable
from enum import Enum, auto

from .execution_ir import (
    HumanExecutionStep,
    HumanExecutionPlan,
    StepType,
    StepStatus,
)


class RenderFormat(Enum):
    """Output format for rendered steps."""
    TEXT = auto()
    MARKDOWN = auto()
    HTML = auto()
    JSON = auto()


@dataclass
class RenderOptions:
    """Options for step rendering."""
    show_step_numbers: bool = True
    show_status: bool = True
    show_notes: bool = True
    show_warnings: bool = True
    show_timing: bool = True
    show_data_fields: bool = True
    compact: bool = False
    include_header: bool = True
    include_footer: bool = True
    highlight_current: bool = True


class StepRenderer:
    """Renders human execution steps to various formats."""

    def __init__(self, options: Optional[RenderOptions] = None):
        self.options = options or RenderOptions()
        self._formatters: Dict[RenderFormat, Callable] = {
            RenderFormat.TEXT: self._render_text,
            RenderFormat.MARKDOWN: self._render_markdown,
            RenderFormat.HTML: self._render_html,
            RenderFormat.JSON: self._render_json,
        }

    def render_step(
        self,
        step: HumanExecutionStep,
        format: RenderFormat = RenderFormat.TEXT
    ) -> str:
        """Render a single step."""
        formatter = self._formatters.get(format, self._render_text)
        return formatter(step)

    def render_plan(
        self,
        plan: HumanExecutionPlan,
        format: RenderFormat = RenderFormat.TEXT
    ) -> str:
        """Render an entire plan."""
        lines = []

        if self.options.include_header:
            lines.append(self._render_header(plan, format))

        for step_id in plan.step_order:
            step = plan.steps[step_id]
            is_current = (step_id == plan.step_order[plan.current_step_index]
                         if plan.current_step_index < len(plan.step_order) else False)

            if is_current and self.options.highlight_current:
                lines.append(self._highlight(self.render_step(step, format), format))
            else:
                lines.append(self.render_step(step, format))

        if self.options.include_footer:
            lines.append(self._render_footer(plan, format))

        separator = "\n\n" if format == RenderFormat.TEXT else "\n"
        return separator.join(lines)

    def _render_text(self, step: HumanExecutionStep) -> str:
        """Render step as plain text."""
        lines = []

        # Step number and type
        if self.options.show_step_numbers:
            prefix = f"Step {step.step_number}: "
        else:
            prefix = ""

        if self.options.show_status:
            status = f"[{step.status.name}] "
        else:
            status = ""

        lines.append(f"{status}{prefix}{step.instruction}")

        if not self.options.compact:
            # Location info
            if step.source:
                lines.append(f"  From: {step.source}")
            if step.destination:
                lines.append(f"  To: {step.destination}")

            # Parameters
            if step.parameters:
                params = []
                if step.parameters.volume_ul:
                    params.append(f"Volume: {step.parameters.format_volume()}")
                if step.parameters.temperature_c:
                    params.append(f"Temp: {step.parameters.format_temperature()}")
                if step.parameters.duration_s:
                    params.append(f"Time: {step.parameters.format_duration()}")
                if step.parameters.cycles:
                    params.append(f"Cycles: {step.parameters.cycles}")
                if params:
                    lines.append(f"  {', '.join(params)}")

            # Warnings
            if self.options.show_warnings and step.warnings:
                for warning in step.warnings:
                    lines.append(f"  ⚠️ WARNING: {warning}")

            # Notes
            if self.options.show_notes and step.notes:
                for note in step.notes:
                    lines.append(f"  📝 Note: {note}")

            # Data fields
            if self.options.show_data_fields and step.data_fields:
                lines.append(f"  📊 Record: {', '.join(step.data_fields)}")

            # Signature required
            if step.requires_signature:
                lines.append("  ✍️ Signature required")

        return "\n".join(lines)

    def _render_markdown(self, step: HumanExecutionStep) -> str:
        """Render step as markdown."""
        lines = []

        # Step header
        prefix = f"**Step {step.step_number}:** " if self.options.show_step_numbers else ""
        status_badge = self._status_badge(step.status) if self.options.show_status else ""

        lines.append(f"### {prefix}{step.instruction} {status_badge}")

        if not self.options.compact:
            # Location table
            if step.source or step.destination:
                lines.append("")
                lines.append("| | Location |")
                lines.append("|---|---|")
                if step.source:
                    lines.append(f"| From | {step.source} |")
                if step.destination:
                    lines.append(f"| To | {step.destination} |")

            # Parameters
            if step.parameters:
                params = []
                if step.parameters.volume_ul:
                    params.append(f"**Volume:** {step.parameters.format_volume()}")
                if step.parameters.temperature_c:
                    params.append(f"**Temp:** {step.parameters.format_temperature()}")
                if step.parameters.duration_s:
                    params.append(f"**Time:** {step.parameters.format_duration()}")
                if step.parameters.cycles:
                    params.append(f"**Cycles:** {step.parameters.cycles}")
                if params:
                    lines.append("")
                    lines.append(" | ".join(params))

            # Warnings as callouts
            if self.options.show_warnings and step.warnings:
                lines.append("")
                for warning in step.warnings:
                    lines.append(f"> ⚠️ **WARNING:** {warning}")

            # Notes
            if self.options.show_notes and step.notes:
                lines.append("")
                for note in step.notes:
                    lines.append(f"> 📝 {note}")

            # Data fields
            if self.options.show_data_fields and step.data_fields:
                lines.append("")
                lines.append(f"📊 **Record:** {', '.join(step.data_fields)}")

            if step.requires_signature:
                lines.append("")
                lines.append("✍️ **Signature required**")

        return "\n".join(lines)

    def _render_html(self, step: HumanExecutionStep) -> str:
        """Render step as HTML."""
        status_class = step.status.name.lower()
        critical_class = " critical" if step.critical else ""

        html = [f'<div class="step step-{status_class}{critical_class}" data-step-id="{step.step_id}">']

        # Header
        if self.options.show_step_numbers:
            html.append(f'  <span class="step-number">{step.step_number}</span>')

        if self.options.show_status:
            html.append(f'  <span class="step-status status-{status_class}">{step.status.name}</span>')

        html.append(f'  <h3 class="step-instruction">{step.instruction}</h3>')

        if not self.options.compact:
            # Locations
            if step.source or step.destination:
                html.append('  <div class="step-locations">')
                if step.source:
                    html.append(f'    <div class="source">From: {step.source}</div>')
                if step.destination:
                    html.append(f'    <div class="destination">To: {step.destination}</div>')
                html.append('  </div>')

            # Parameters
            if step.parameters:
                html.append('  <div class="step-params">')
                if step.parameters.volume_ul:
                    html.append(f'    <span class="param volume">{step.parameters.format_volume()}</span>')
                if step.parameters.temperature_c:
                    html.append(f'    <span class="param temp">{step.parameters.format_temperature()}</span>')
                if step.parameters.duration_s:
                    html.append(f'    <span class="param duration">{step.parameters.format_duration()}</span>')
                html.append('  </div>')

            # Warnings
            if self.options.show_warnings and step.warnings:
                html.append('  <div class="step-warnings">')
                for warning in step.warnings:
                    html.append(f'    <div class="warning">⚠️ {warning}</div>')
                html.append('  </div>')

            # Notes
            if self.options.show_notes and step.notes:
                html.append('  <div class="step-notes">')
                for note in step.notes:
                    html.append(f'    <div class="note">📝 {note}</div>')
                html.append('  </div>')

            # Data fields
            if self.options.show_data_fields and step.data_fields:
                html.append('  <div class="data-fields">')
                for field_name in step.data_fields:
                    html.append(f'    <input type="text" name="{field_name}" placeholder="{field_name}">')
                html.append('  </div>')

            if step.requires_signature:
                html.append('  <div class="signature-required">✍️ Signature required</div>')

        html.append('</div>')
        return "\n".join(html)

    def _render_json(self, step: HumanExecutionStep) -> str:
        """Render step as JSON."""
        import json

        data = {
            "step_id": step.step_id,
            "step_number": step.step_number,
            "step_type": step.step_type.name,
            "instruction": step.instruction,
            "status": step.status.name,
        }

        if step.source:
            data["source"] = str(step.source)
        if step.destination:
            data["destination"] = str(step.destination)
        if step.parameters:
            data["parameters"] = {
                "volume_ul": step.parameters.volume_ul,
                "temperature_c": step.parameters.temperature_c,
                "duration_s": step.parameters.duration_s,
                "cycles": step.parameters.cycles,
            }
        if step.warnings:
            data["warnings"] = step.warnings
        if step.notes:
            data["notes"] = step.notes
        if step.data_fields:
            data["data_fields"] = step.data_fields
        if step.requires_signature:
            data["requires_signature"] = True

        return json.dumps(data, indent=2)

    def _render_header(self, plan: HumanExecutionPlan, format: RenderFormat) -> str:
        """Render plan header."""
        if format == RenderFormat.TEXT:
            lines = [
                "=" * 60,
                f"Protocol: {plan.protocol_name}",
                f"Version: {plan.version}",
                f"Total Steps: {plan.total_steps}",
                "=" * 60,
            ]
            return "\n".join(lines)

        elif format == RenderFormat.MARKDOWN:
            return f"""# {plan.protocol_name}

**Version:** {plan.version}
**Total Steps:** {plan.total_steps}
**Progress:** {plan.progress_percent:.1f}%

---
"""

        elif format == RenderFormat.HTML:
            return f"""<div class="protocol-header">
  <h1>{plan.protocol_name}</h1>
  <div class="meta">
    <span class="version">v{plan.version}</span>
    <span class="steps">{plan.total_steps} steps</span>
    <span class="progress">{plan.progress_percent:.1f}%</span>
  </div>
</div>"""

        return ""

    def _render_footer(self, plan: HumanExecutionPlan, format: RenderFormat) -> str:
        """Render plan footer."""
        summary = plan.summary()

        if format == RenderFormat.TEXT:
            lines = [
                "-" * 60,
                f"Progress: {summary['completed']}/{summary['total_steps']} ({summary['progress']})",
                f"Pending: {summary['pending']} | In Progress: {summary['in_progress']} | Failed: {summary['failed']}",
                "-" * 60,
            ]
            return "\n".join(lines)

        elif format == RenderFormat.MARKDOWN:
            return f"""---

**Progress:** {summary['completed']}/{summary['total_steps']} ({summary['progress']})

| Pending | In Progress | Failed |
|---------|-------------|--------|
| {summary['pending']} | {summary['in_progress']} | {summary['failed']} |
"""

        elif format == RenderFormat.HTML:
            return f"""<div class="protocol-footer">
  <div class="progress-bar" style="width: {plan.progress_percent}%"></div>
  <div class="summary">
    <span>Completed: {summary['completed']}/{summary['total_steps']}</span>
    <span>Pending: {summary['pending']}</span>
    <span>Failed: {summary['failed']}</span>
  </div>
</div>"""

        return ""

    def _highlight(self, content: str, format: RenderFormat) -> str:
        """Highlight current step."""
        if format == RenderFormat.TEXT:
            lines = content.split("\n")
            return "\n".join([f">>> {line}" for line in lines])
        elif format == RenderFormat.MARKDOWN:
            return f"**[CURRENT]**\n\n{content}"
        elif format == RenderFormat.HTML:
            return content.replace('class="step', 'class="step current')
        return content

    def _status_badge(self, status: StepStatus) -> str:
        """Get markdown status badge."""
        badges = {
            StepStatus.PENDING: "⬜",
            StepStatus.IN_PROGRESS: "🔄",
            StepStatus.COMPLETED: "✅",
            StepStatus.VERIFIED: "✅✓",
            StepStatus.SKIPPED: "⏭️",
            StepStatus.FAILED: "❌",
        }
        return badges.get(status, "")


def render_step_instruction(step_type: StepType, params: Dict[str, Any]) -> str:
    """Generate instruction text from step type and parameters."""
    templates = {
        StepType.PIPETTE: "Transfer {volume} from {source} to {destination}",
        StepType.ASPIRATE: "Aspirate {volume} from {source}",
        StepType.DISPENSE: "Dispense {volume} into {destination}",
        StepType.MIX: "Mix {cycles}x at {location}",
        StepType.GET_TIPS: "Get new tips from {tip_rack}",
        StepType.DROP_TIPS: "Discard tips to waste",
        StepType.MOVE_LABWARE: "Move {labware} to {destination}",
        StepType.SET_TEMPERATURE: "Set {module} to {temperature}",
        StepType.INCUBATE: "Incubate at {temperature} for {duration}",
        StepType.WAIT: "Wait for {duration}",
        StepType.START_TIMER: "Start timer: {timer_name}",
        StepType.STOP_TIMER: "Stop timer: {timer_name}",
        StepType.RECORD_DATA: "Record {field_name}",
        StepType.CHECKPOINT: "CHECKPOINT: {message}",
        StepType.VERIFY: "Verify: {message}",
        StepType.SIGN_OFF: "Sign off: {message}",
        StepType.NOTE: "Note: {message}",
        StepType.WARNING: "⚠️ Warning: {message}",
        StepType.CRITICAL: "🚨 CRITICAL: {message}",
    }

    template = templates.get(step_type, "{message}")
    return template.format(**params)
