"""
BPL Human Runtime - Step-by-step human execution.

Provides:
- HumanExecutionStep for individual steps
- StepRenderer for formatting output
- TimerManager for timing operations
- DataCapture for recording data
- SignatureManager for electronic signatures
- CheckpointUI for interactive checkpoints
"""

from .execution_ir import (
    StepType,
    StepStatus,
    StepLocation,
    StepParameters,
    HumanExecutionStep,
    StepGroup,
    HumanExecutionPlan,
)

from .step_renderer import (
    RenderFormat,
    RenderOptions,
    StepRenderer,
    render_step_instruction,
)

from .timer import (
    TimerStatus,
    TimerType,
    TimerState,
    TimerEvent,
    TimerManager,
    format_duration,
    create_countdown_timer,
    create_stopwatch,
)

from .data_capture import (
    FieldType,
    ValidationStatus,
    FieldConstraint,
    DataField,
    CapturedValue,
    DataCapture,
    DataCaptureManager,
    create_volume_field,
    create_temperature_field,
    create_text_field,
    create_choice_field,
    create_barcode_field,
)

from .signatures import (
    SignatureType,
    SignatureStatus,
    SignatureRequest,
    Signature,
    SignaturePolicy,
    SignatureManager,
    require_initials,
    require_approval,
    create_standard_policy,
    create_gmp_policy,
)

from .checkpoint_ui import (
    CheckpointType,
    CheckpointAction,
    CheckpointOption,
    CheckpointState,
    CheckpointUI,
    CheckpointUIGenerator,
    CheckpointManager,
    create_pause_checkpoint,
    create_confirmation_checkpoint,
    create_signature_checkpoint,
)

from .protocol_generator import (
    ConversionOptions,
    PlanToHumanConverter,
    generate_human_protocol,
    convert_plan_to_human,
)

__all__ = [
    # Execution IR
    "StepType",
    "StepStatus",
    "StepLocation",
    "StepParameters",
    "HumanExecutionStep",
    "StepGroup",
    "HumanExecutionPlan",
    # Step Renderer
    "RenderFormat",
    "RenderOptions",
    "StepRenderer",
    "render_step_instruction",
    # Timer
    "TimerStatus",
    "TimerType",
    "TimerState",
    "TimerEvent",
    "TimerManager",
    "format_duration",
    "create_countdown_timer",
    "create_stopwatch",
    # Data Capture
    "FieldType",
    "ValidationStatus",
    "FieldConstraint",
    "DataField",
    "CapturedValue",
    "DataCapture",
    "DataCaptureManager",
    "create_volume_field",
    "create_temperature_field",
    "create_text_field",
    "create_choice_field",
    "create_barcode_field",
    # Signatures
    "SignatureType",
    "SignatureStatus",
    "SignatureRequest",
    "Signature",
    "SignaturePolicy",
    "SignatureManager",
    "require_initials",
    "require_approval",
    "create_standard_policy",
    "create_gmp_policy",
    # Checkpoint UI
    "CheckpointType",
    "CheckpointAction",
    "CheckpointOption",
    "CheckpointState",
    "CheckpointUI",
    "CheckpointUIGenerator",
    "CheckpointManager",
    "create_pause_checkpoint",
    "create_confirmation_checkpoint",
    "create_signature_checkpoint",
    # Protocol Generator
    "ConversionOptions",
    "PlanToHumanConverter",
    "generate_human_protocol",
    "convert_plan_to_human",
]
