"""
BPL Data Capture - Data recording during human execution.

Provides:
- DataField definitions
- DataCapture for collecting recorded values
- Validation of captured data
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import re


class FieldType(Enum):
    """Type of data field."""
    TEXT = auto()
    NUMBER = auto()
    INTEGER = auto()
    DECIMAL = auto()
    BOOLEAN = auto()
    CHOICE = auto()
    MULTI_CHOICE = auto()
    DATE = auto()
    TIME = auto()
    DATETIME = auto()
    VOLUME = auto()
    TEMPERATURE = auto()
    CONCENTRATION = auto()
    BARCODE = auto()
    PHOTO = auto()
    SIGNATURE = auto()


class ValidationStatus(Enum):
    """Status of field validation."""
    VALID = auto()
    INVALID = auto()
    WARNING = auto()
    PENDING = auto()


@dataclass
class FieldConstraint:
    """Constraint on a data field."""
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    pattern: Optional[str] = None
    allowed_values: Optional[List[str]] = None
    required: bool = True
    custom_validator: Optional[Callable[[Any], bool]] = None

    def validate(self, value: Any, field_type: FieldType) -> tuple[ValidationStatus, Optional[str]]:
        """Validate a value against constraints."""
        if value is None or value == "":
            if self.required:
                return ValidationStatus.INVALID, "Field is required"
            return ValidationStatus.VALID, None

        # Type-specific validation
        if field_type in (FieldType.NUMBER, FieldType.INTEGER, FieldType.DECIMAL,
                         FieldType.VOLUME, FieldType.TEMPERATURE, FieldType.CONCENTRATION):
            try:
                num_value = float(value)
                if self.min_value is not None and num_value < self.min_value:
                    return ValidationStatus.INVALID, f"Value must be >= {self.min_value}"
                if self.max_value is not None and num_value > self.max_value:
                    return ValidationStatus.INVALID, f"Value must be <= {self.max_value}"
            except (ValueError, TypeError):
                return ValidationStatus.INVALID, "Invalid number format"

        if field_type == FieldType.INTEGER:
            try:
                int(value)
            except (ValueError, TypeError):
                return ValidationStatus.INVALID, "Must be an integer"

        if field_type == FieldType.TEXT:
            str_value = str(value)
            if self.min_length is not None and len(str_value) < self.min_length:
                return ValidationStatus.INVALID, f"Minimum length is {self.min_length}"
            if self.max_length is not None and len(str_value) > self.max_length:
                return ValidationStatus.INVALID, f"Maximum length is {self.max_length}"
            if self.pattern and not re.match(self.pattern, str_value):
                return ValidationStatus.INVALID, "Value does not match required pattern"

        if field_type in (FieldType.CHOICE, FieldType.MULTI_CHOICE):
            if self.allowed_values:
                if field_type == FieldType.MULTI_CHOICE:
                    values = value if isinstance(value, list) else [value]
                    invalid = [v for v in values if v not in self.allowed_values]
                    if invalid:
                        return ValidationStatus.INVALID, f"Invalid choices: {invalid}"
                else:
                    if value not in self.allowed_values:
                        return ValidationStatus.INVALID, f"Must be one of: {self.allowed_values}"

        if self.custom_validator:
            try:
                if not self.custom_validator(value):
                    return ValidationStatus.INVALID, "Custom validation failed"
            except Exception as e:
                return ValidationStatus.INVALID, f"Validation error: {e}"

        return ValidationStatus.VALID, None


@dataclass
class DataField:
    """Definition of a data field to capture."""
    field_id: str
    name: str
    field_type: FieldType
    description: Optional[str] = None
    unit: Optional[str] = None

    # Constraints
    constraint: Optional[FieldConstraint] = None

    # UI hints
    placeholder: Optional[str] = None
    help_text: Optional[str] = None
    choices: Optional[List[str]] = None  # For CHOICE type

    # Default value
    default_value: Optional[Any] = None

    # Grouping
    group: Optional[str] = None
    order: int = 0

    # Computed fields
    formula: Optional[str] = None  # For calculated fields

    def validate(self, value: Any) -> tuple[ValidationStatus, Optional[str]]:
        """Validate a value for this field."""
        if self.constraint:
            return self.constraint.validate(value, self.field_type)
        return ValidationStatus.VALID, None

    def format_value(self, value: Any) -> str:
        """Format value for display."""
        if value is None:
            return ""

        if self.field_type == FieldType.VOLUME:
            return f"{value} {self.unit or 'µL'}"
        elif self.field_type == FieldType.TEMPERATURE:
            return f"{value}°C"
        elif self.field_type == FieldType.CONCENTRATION:
            return f"{value} {self.unit or 'mM'}"
        elif self.field_type == FieldType.BOOLEAN:
            return "Yes" if value else "No"
        elif self.field_type == FieldType.MULTI_CHOICE:
            if isinstance(value, list):
                return ", ".join(str(v) for v in value)

        return str(value)


@dataclass
class CapturedValue:
    """A captured data value."""
    field_id: str
    value: Any
    captured_at: datetime = field(default_factory=datetime.now)
    captured_by: Optional[str] = None
    validation_status: ValidationStatus = ValidationStatus.PENDING
    validation_message: Optional[str] = None

    # Audit
    original_value: Optional[Any] = None  # If edited
    edit_history: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class DataCapture:
    """Data capture session for a protocol step or execution."""
    capture_id: str
    step_id: Optional[str] = None

    # Field definitions
    fields: Dict[str, DataField] = field(default_factory=dict)
    field_order: List[str] = field(default_factory=list)

    # Captured values
    values: Dict[str, CapturedValue] = field(default_factory=dict)

    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    def add_field(self, data_field: DataField) -> None:
        """Add a field definition."""
        self.fields[data_field.field_id] = data_field
        self.field_order.append(data_field.field_id)

    def capture(
        self,
        field_id: str,
        value: Any,
        captured_by: Optional[str] = None
    ) -> CapturedValue:
        """Capture a value for a field."""
        data_field = self.fields.get(field_id)
        if not data_field:
            raise ValueError(f"Unknown field: {field_id}")

        # Validate
        status, message = data_field.validate(value)

        # Check if updating existing value
        existing = self.values.get(field_id)
        if existing:
            existing.edit_history.append({
                "previous_value": existing.value,
                "edited_at": datetime.now(),
                "edited_by": captured_by,
            })
            existing.value = value
            existing.captured_at = datetime.now()
            existing.captured_by = captured_by
            existing.validation_status = status
            existing.validation_message = message
            return existing
        else:
            captured = CapturedValue(
                field_id=field_id,
                value=value,
                captured_by=captured_by,
                validation_status=status,
                validation_message=message,
            )
            self.values[field_id] = captured
            return captured

    def get_value(self, field_id: str) -> Optional[Any]:
        """Get captured value for a field."""
        captured = self.values.get(field_id)
        return captured.value if captured else None

    def get_formatted_value(self, field_id: str) -> str:
        """Get formatted value for display."""
        data_field = self.fields.get(field_id)
        value = self.get_value(field_id)
        if data_field and value is not None:
            return data_field.format_value(value)
        return ""

    def validate_all(self) -> Dict[str, tuple[ValidationStatus, Optional[str]]]:
        """Validate all captured values."""
        results = {}
        for field_id, data_field in self.fields.items():
            value = self.get_value(field_id)
            status, message = data_field.validate(value)

            # Update stored validation status
            if field_id in self.values:
                self.values[field_id].validation_status = status
                self.values[field_id].validation_message = message

            results[field_id] = (status, message)
        return results

    def is_complete(self) -> bool:
        """Check if all required fields have valid values."""
        for field_id, data_field in self.fields.items():
            if data_field.constraint and data_field.constraint.required:
                captured = self.values.get(field_id)
                if not captured or captured.validation_status != ValidationStatus.VALID:
                    return False
        return True

    def get_missing_fields(self) -> List[str]:
        """Get list of missing required fields."""
        missing = []
        for field_id, data_field in self.fields.items():
            if data_field.constraint and data_field.constraint.required:
                if field_id not in self.values:
                    missing.append(field_id)
        return missing

    def get_invalid_fields(self) -> List[str]:
        """Get list of invalid fields."""
        invalid = []
        for field_id, captured in self.values.items():
            if captured.validation_status == ValidationStatus.INVALID:
                invalid.append(field_id)
        return invalid

    def complete(self) -> bool:
        """Mark capture as complete if valid."""
        if self.is_complete():
            self.completed_at = datetime.now()
            return True
        return False

    def to_dict(self) -> Dict[str, Any]:
        """Export captured data as dictionary."""
        return {
            field_id: self.get_value(field_id)
            for field_id in self.fields
        }

    def summary(self) -> Dict[str, Any]:
        """Get capture summary."""
        return {
            "capture_id": self.capture_id,
            "total_fields": len(self.fields),
            "captured": len(self.values),
            "valid": len([v for v in self.values.values() if v.validation_status == ValidationStatus.VALID]),
            "invalid": len(self.get_invalid_fields()),
            "missing": len(self.get_missing_fields()),
            "complete": self.is_complete(),
        }


class DataCaptureManager:
    """Manages data capture across a protocol execution."""

    def __init__(self):
        self.captures: Dict[str, DataCapture] = {}
        self.step_captures: Dict[str, List[str]] = {}  # step_id -> capture_ids

    def create_capture(
        self,
        capture_id: str,
        step_id: Optional[str] = None,
        fields: Optional[List[DataField]] = None
    ) -> DataCapture:
        """Create a new data capture."""
        capture = DataCapture(capture_id=capture_id, step_id=step_id)
        if fields:
            for f in fields:
                capture.add_field(f)

        self.captures[capture_id] = capture

        if step_id:
            if step_id not in self.step_captures:
                self.step_captures[step_id] = []
            self.step_captures[step_id].append(capture_id)

        return capture

    def get_capture(self, capture_id: str) -> Optional[DataCapture]:
        """Get a capture by ID."""
        return self.captures.get(capture_id)

    def get_step_captures(self, step_id: str) -> List[DataCapture]:
        """Get all captures for a step."""
        capture_ids = self.step_captures.get(step_id, [])
        return [self.captures[cid] for cid in capture_ids if cid in self.captures]

    def capture_value(
        self,
        capture_id: str,
        field_id: str,
        value: Any,
        captured_by: Optional[str] = None
    ) -> Optional[CapturedValue]:
        """Capture a value."""
        capture = self.captures.get(capture_id)
        if capture:
            return capture.capture(field_id, value, captured_by)
        return None

    def export_all(self) -> Dict[str, Dict[str, Any]]:
        """Export all captured data."""
        return {
            capture_id: capture.to_dict()
            for capture_id, capture in self.captures.items()
        }

    def get_summary(self) -> Dict[str, Any]:
        """Get manager summary."""
        return {
            "total_captures": len(self.captures),
            "complete": len([c for c in self.captures.values() if c.is_complete()]),
            "incomplete": len([c for c in self.captures.values() if not c.is_complete()]),
        }


# Convenience factory functions
def create_volume_field(
    field_id: str,
    name: str,
    min_ul: float = 0,
    max_ul: float = 10000,
    required: bool = True
) -> DataField:
    """Create a volume data field."""
    return DataField(
        field_id=field_id,
        name=name,
        field_type=FieldType.VOLUME,
        unit="µL",
        constraint=FieldConstraint(
            min_value=min_ul,
            max_value=max_ul,
            required=required
        )
    )


def create_temperature_field(
    field_id: str,
    name: str,
    min_c: float = -80,
    max_c: float = 100,
    required: bool = True
) -> DataField:
    """Create a temperature data field."""
    return DataField(
        field_id=field_id,
        name=name,
        field_type=FieldType.TEMPERATURE,
        unit="°C",
        constraint=FieldConstraint(
            min_value=min_c,
            max_value=max_c,
            required=required
        )
    )


def create_text_field(
    field_id: str,
    name: str,
    max_length: int = 500,
    required: bool = True
) -> DataField:
    """Create a text data field."""
    return DataField(
        field_id=field_id,
        name=name,
        field_type=FieldType.TEXT,
        constraint=FieldConstraint(
            max_length=max_length,
            required=required
        )
    )


def create_choice_field(
    field_id: str,
    name: str,
    choices: List[str],
    required: bool = True
) -> DataField:
    """Create a choice data field."""
    return DataField(
        field_id=field_id,
        name=name,
        field_type=FieldType.CHOICE,
        choices=choices,
        constraint=FieldConstraint(
            allowed_values=choices,
            required=required
        )
    )


def create_barcode_field(
    field_id: str,
    name: str,
    pattern: Optional[str] = None,
    required: bool = True
) -> DataField:
    """Create a barcode data field."""
    return DataField(
        field_id=field_id,
        name=name,
        field_type=FieldType.BARCODE,
        constraint=FieldConstraint(
            pattern=pattern,
            required=required
        ),
        placeholder="Scan or enter barcode"
    )
