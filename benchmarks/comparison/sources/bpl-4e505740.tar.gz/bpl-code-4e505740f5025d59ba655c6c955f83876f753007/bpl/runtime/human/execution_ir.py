"""
BPL Human Execution IR - Intermediate representation for human execution.

Provides:
- HumanExecutionStep for step-by-step instructions
- StepType enumeration
- HumanExecutionPlan container
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum, auto
from datetime import datetime


class StepType(Enum):
    """Type of human execution step."""
    # Liquid handling
    PIPETTE = auto()
    ASPIRATE = auto()
    DISPENSE = auto()
    MIX = auto()

    # Tip management
    GET_TIPS = auto()
    DROP_TIPS = auto()

    # Labware operations
    MOVE_LABWARE = auto()
    SEAL_PLATE = auto()
    UNSEAL_PLATE = auto()

    # Equipment control
    SET_TEMPERATURE = auto()
    INCUBATE = auto()
    CENTRIFUGE = auto()

    # Timing
    WAIT = auto()
    START_TIMER = auto()
    STOP_TIMER = auto()

    # Data collection
    RECORD_DATA = auto()
    MEASURE = auto()

    # Protocol control
    CHECKPOINT = auto()
    VERIFY = auto()
    SIGN_OFF = auto()

    # Information
    NOTE = auto()
    WARNING = auto()
    CRITICAL = auto()


class StepStatus(Enum):
    """Status of a human execution step."""
    PENDING = auto()
    IN_PROGRESS = auto()
    COMPLETED = auto()
    SKIPPED = auto()
    FAILED = auto()
    VERIFIED = auto()


@dataclass
class StepLocation:
    """Location reference for a step."""
    labware_id: str
    well_id: Optional[str] = None
    position: Optional[str] = None

    def __str__(self) -> str:
        if self.well_id:
            return f"{self.labware_id} well {self.well_id}"
        elif self.position:
            return f"{self.labware_id} at position {self.position}"
        return self.labware_id


@dataclass
class StepParameters:
    """Parameters for a human execution step."""
    volume_ul: Optional[float] = None
    temperature_c: Optional[float] = None
    duration_s: Optional[float] = None
    cycles: Optional[int] = None
    speed: Optional[str] = None  # slow, normal, fast
    tip_type: Optional[str] = None
    additional: Dict[str, Any] = field(default_factory=dict)

    def format_volume(self) -> str:
        """Format volume for display."""
        if self.volume_ul is None:
            return ""
        if self.volume_ul >= 1000:
            return f"{self.volume_ul / 1000:.2f} mL"
        return f"{self.volume_ul:.1f} µL"

    def format_temperature(self) -> str:
        """Format temperature for display."""
        if self.temperature_c is None:
            return ""
        return f"{self.temperature_c:.1f}°C"

    def format_duration(self) -> str:
        """Format duration for display."""
        if self.duration_s is None:
            return ""
        if self.duration_s >= 3600:
            hours = int(self.duration_s // 3600)
            mins = int((self.duration_s % 3600) // 60)
            return f"{hours}h {mins}m"
        elif self.duration_s >= 60:
            mins = int(self.duration_s // 60)
            secs = int(self.duration_s % 60)
            return f"{mins}m {secs}s"
        return f"{self.duration_s:.0f}s"


@dataclass
class HumanExecutionStep:
    """A single step in human execution."""
    step_id: str
    step_number: int
    step_type: StepType
    instruction: str

    # Optional details
    source: Optional[StepLocation] = None
    destination: Optional[StepLocation] = None
    parameters: Optional[StepParameters] = None

    # Execution tracking
    status: StepStatus = StepStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Verification
    requires_signature: bool = False
    requires_verification: bool = False
    signature_id: Optional[str] = None

    # Data collection
    data_fields: List[str] = field(default_factory=list)
    recorded_data: Dict[str, Any] = field(default_factory=dict)

    # Notes and warnings
    notes: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    critical: bool = False

    # Grouping
    group_id: Optional[str] = None
    group_name: Optional[str] = None

    def start(self) -> None:
        """Mark step as started."""
        self.status = StepStatus.IN_PROGRESS
        self.started_at = datetime.now()

    def complete(self, verified: bool = False) -> None:
        """Mark step as completed."""
        self.status = StepStatus.VERIFIED if verified else StepStatus.COMPLETED
        self.completed_at = datetime.now()

    def skip(self) -> None:
        """Mark step as skipped."""
        self.status = StepStatus.SKIPPED
        self.completed_at = datetime.now()

    def fail(self) -> None:
        """Mark step as failed."""
        self.status = StepStatus.FAILED
        self.completed_at = datetime.now()

    def record_value(self, field_name: str, value: Any) -> None:
        """Record a data value."""
        self.recorded_data[field_name] = value

    @property
    def duration_s(self) -> Optional[float]:
        """Get step duration in seconds."""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def is_complete(self) -> bool:
        """Check if step is complete."""
        return self.status in (StepStatus.COMPLETED, StepStatus.VERIFIED, StepStatus.SKIPPED)


@dataclass
class StepGroup:
    """A group of related steps."""
    group_id: str
    name: str
    description: Optional[str] = None
    step_ids: List[str] = field(default_factory=list)
    collapsed: bool = False


@dataclass
class HumanExecutionPlan:
    """Complete plan for human execution."""
    plan_id: str
    protocol_name: str
    version: str = "1.0"

    # Steps
    steps: Dict[str, HumanExecutionStep] = field(default_factory=dict)
    step_order: List[str] = field(default_factory=list)

    # Groups
    groups: Dict[str, StepGroup] = field(default_factory=dict)

    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    author: Optional[str] = None
    description: Optional[str] = None

    # Progress tracking
    current_step_index: int = 0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    def add_step(self, step: HumanExecutionStep) -> None:
        """Add a step to the plan."""
        self.steps[step.step_id] = step
        self.step_order.append(step.step_id)

    def get_current_step(self) -> Optional[HumanExecutionStep]:
        """Get the current step."""
        if 0 <= self.current_step_index < len(self.step_order):
            step_id = self.step_order[self.current_step_index]
            return self.steps.get(step_id)
        return None

    def advance(self) -> Optional[HumanExecutionStep]:
        """Advance to next step."""
        self.current_step_index += 1
        return self.get_current_step()

    def go_back(self) -> Optional[HumanExecutionStep]:
        """Go back to previous step."""
        if self.current_step_index > 0:
            self.current_step_index -= 1
        return self.get_current_step()

    def jump_to_step(self, step_id: str) -> Optional[HumanExecutionStep]:
        """Jump to a specific step."""
        if step_id in self.step_order:
            self.current_step_index = self.step_order.index(step_id)
            return self.get_current_step()
        return None

    @property
    def total_steps(self) -> int:
        """Get total number of steps."""
        return len(self.step_order)

    @property
    def completed_steps(self) -> int:
        """Get number of completed steps."""
        return sum(1 for step in self.steps.values() if step.is_complete)

    @property
    def progress_percent(self) -> float:
        """Get progress as percentage."""
        if not self.step_order:
            return 100.0
        return (self.completed_steps / len(self.step_order)) * 100

    @property
    def is_complete(self) -> bool:
        """Check if plan is complete."""
        return all(step.is_complete for step in self.steps.values())

    def start(self) -> None:
        """Start execution of the plan."""
        self.started_at = datetime.now()
        self.current_step_index = 0

    def complete(self) -> None:
        """Mark plan as complete."""
        self.completed_at = datetime.now()

    def get_steps_by_status(self, status: StepStatus) -> List[HumanExecutionStep]:
        """Get all steps with given status."""
        return [step for step in self.steps.values() if step.status == status]

    def get_steps_in_group(self, group_id: str) -> List[HumanExecutionStep]:
        """Get all steps in a group."""
        return [step for step in self.steps.values() if step.group_id == group_id]

    def summary(self) -> Dict[str, Any]:
        """Get plan summary."""
        return {
            "plan_id": self.plan_id,
            "protocol": self.protocol_name,
            "total_steps": self.total_steps,
            "completed": self.completed_steps,
            "progress": f"{self.progress_percent:.1f}%",
            "pending": len(self.get_steps_by_status(StepStatus.PENDING)),
            "in_progress": len(self.get_steps_by_status(StepStatus.IN_PROGRESS)),
            "failed": len(self.get_steps_by_status(StepStatus.FAILED)),
        }
