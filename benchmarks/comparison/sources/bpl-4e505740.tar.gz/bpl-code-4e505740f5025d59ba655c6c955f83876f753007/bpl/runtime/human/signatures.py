"""
BPL Signatures - Electronic signature support for human execution.

Provides:
- SignatureType definitions
- Signature collection and verification
- SignatureManager for protocol sign-offs
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import hashlib
import hmac
import json
import secrets
import uuid


class SignatureType(Enum):
    """Type of signature."""
    INITIALS = auto()       # Quick initial sign-off
    FULL_SIGNATURE = auto() # Full electronic signature
    WITNESS = auto()        # Witnessed signature
    APPROVAL = auto()       # Supervisor approval
    REVIEW = auto()         # QC/QA review
    VERIFICATION = auto()   # Step verification


class SignatureStatus(Enum):
    """Status of a signature request."""
    PENDING = auto()
    SIGNED = auto()
    REJECTED = auto()
    EXPIRED = auto()
    REVOKED = auto()


@dataclass
class SignatureRequest:
    """Request for a signature."""
    request_id: str
    signature_type: SignatureType
    reason: str

    # Who can sign
    required_role: Optional[str] = None
    required_user: Optional[str] = None
    allowed_users: Optional[List[str]] = None

    # Context
    step_id: Optional[str] = None
    data_reference: Optional[str] = None

    # Status
    status: SignatureStatus = SignatureStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Signature:
    """An electronic signature."""
    signature_id: str
    request_id: str
    signature_type: SignatureType

    # Signer information
    signer_id: str
    signer_name: str
    signer_role: Optional[str] = None

    # Signature data
    signed_at: datetime = field(default_factory=datetime.now)
    reason: str = ""
    comment: Optional[str] = None

    # Verification
    signature_hash: str = ""
    data_hash: Optional[str] = None  # Hash of data being signed

    # Witness (if applicable)
    witness_id: Optional[str] = None
    witness_name: Optional[str] = None
    witnessed_at: Optional[datetime] = None

    # Status
    verified: bool = False
    revoked: bool = False
    revoked_at: Optional[datetime] = None
    revoked_reason: Optional[str] = None

    def compute_hash(self, secret: str) -> str:
        """Compute signature hash for verification."""
        if not secret:
            raise ValueError("Signature secret must be non-empty")
        data = json.dumps(
            {
                "signature_id": self.signature_id,
                "request_id": self.request_id,
                "signature_type": self.signature_type.name,
                "signer_id": self.signer_id,
                "signed_at": self.signed_at.isoformat(),
                "reason": self.reason,
                "data_hash": self.data_hash,
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        return hmac.new(secret.encode(), data.encode(), hashlib.sha256).hexdigest()

    def verify_hash(self, secret: str) -> bool:
        """Verify signature hash."""
        expected = self.compute_hash(secret)
        return hmac.compare_digest(self.signature_hash, expected)

    def add_witness(self, witness_id: str, witness_name: str) -> None:
        """Add witness to signature."""
        self.witness_id = witness_id
        self.witness_name = witness_name
        self.witnessed_at = datetime.now()

    def revoke(self, reason: str) -> None:
        """Revoke the signature."""
        self.revoked = True
        self.revoked_at = datetime.now()
        self.revoked_reason = reason


@dataclass
class SignaturePolicy:
    """Policy for signature requirements."""
    policy_id: str
    name: str

    # Requirements
    required_signatures: int = 1
    required_types: List[SignatureType] = field(default_factory=list)
    required_roles: List[str] = field(default_factory=list)

    # Rules
    require_witness: bool = False
    require_dual_control: bool = False  # Two different people
    allow_self_witness: bool = False
    expiration_hours: Optional[int] = None

    # Validation
    validate_data_hash: bool = True


class SignatureManager:
    """Manages signatures for a protocol execution."""

    def __init__(self, secret: Optional[str] = None):
        self.requests: Dict[str, SignatureRequest] = {}
        self.signatures: Dict[str, Signature] = {}
        self.step_signatures: Dict[str, List[str]] = {}  # step_id -> signature_ids
        self.policies: Dict[str, SignaturePolicy] = {}
        self._secret = secret or secrets.token_urlsafe(32)

    def create_request(
        self,
        signature_type: SignatureType,
        reason: str,
        step_id: Optional[str] = None,
        required_role: Optional[str] = None,
        expires_hours: Optional[int] = None,
    ) -> SignatureRequest:
        """Create a signature request."""
        request_id = str(uuid.uuid4())[:8]

        expires_at = None
        if expires_hours:
            from datetime import timedelta
            expires_at = datetime.now() + timedelta(hours=expires_hours)

        request = SignatureRequest(
            request_id=request_id,
            signature_type=signature_type,
            reason=reason,
            step_id=step_id,
            required_role=required_role,
            expires_at=expires_at,
        )

        self.requests[request_id] = request
        return request

    def sign(
        self,
        request_id: str,
        signer_id: str,
        signer_name: str,
        signer_role: Optional[str] = None,
        comment: Optional[str] = None,
        data_hash: Optional[str] = None,
    ) -> Optional[Signature]:
        """Sign a pending request."""
        request = self.requests.get(request_id)
        if not request:
            return None

        # Check if already signed
        if request.status == SignatureStatus.SIGNED:
            return None

        # Check expiration
        if request.expires_at and datetime.now() > request.expires_at:
            request.status = SignatureStatus.EXPIRED
            return None

        # Check authorization
        if request.required_user and signer_id != request.required_user:
            return None
        if request.allowed_users and signer_id not in request.allowed_users:
            return None
        if request.required_role and signer_role != request.required_role:
            return None

        # Create signature
        signature_id = str(uuid.uuid4())[:8]
        signature = Signature(
            signature_id=signature_id,
            request_id=request_id,
            signature_type=request.signature_type,
            signer_id=signer_id,
            signer_name=signer_name,
            signer_role=signer_role,
            reason=request.reason,
            comment=comment,
            data_hash=data_hash,
        )

        # Compute hash
        signature.signature_hash = signature.compute_hash(self._secret)
        signature.verified = True

        # Store
        self.signatures[signature_id] = signature
        request.status = SignatureStatus.SIGNED

        # Track by step
        if request.step_id:
            if request.step_id not in self.step_signatures:
                self.step_signatures[request.step_id] = []
            self.step_signatures[request.step_id].append(signature_id)

        return signature

    def reject(self, request_id: str, reason: str = "") -> bool:
        """Reject a signature request."""
        request = self.requests.get(request_id)
        if request and request.status == SignatureStatus.PENDING:
            request.status = SignatureStatus.REJECTED
            request.metadata["rejection_reason"] = reason
            return True
        return False

    def witness(
        self,
        signature_id: str,
        witness_id: str,
        witness_name: str
    ) -> bool:
        """Add witness to a signature."""
        signature = self.signatures.get(signature_id)
        if signature and not signature.witness_id:
            signature.add_witness(witness_id, witness_name)
            return True
        return False

    def revoke(self, signature_id: str, reason: str) -> bool:
        """Revoke a signature."""
        signature = self.signatures.get(signature_id)
        if signature and not signature.revoked:
            signature.revoke(reason)
            return True
        return False

    def verify(self, signature_id: str) -> bool:
        """Verify a signature's integrity."""
        signature = self.signatures.get(signature_id)
        if signature:
            return signature.verify_hash(self._secret)
        return False

    def get_request(self, request_id: str) -> Optional[SignatureRequest]:
        """Get a signature request."""
        return self.requests.get(request_id)

    def get_signature(self, signature_id: str) -> Optional[Signature]:
        """Get a signature."""
        return self.signatures.get(signature_id)

    def get_step_signatures(self, step_id: str) -> List[Signature]:
        """Get all signatures for a step."""
        sig_ids = self.step_signatures.get(step_id, [])
        return [self.signatures[sid] for sid in sig_ids if sid in self.signatures]

    def get_pending_requests(self) -> List[SignatureRequest]:
        """Get all pending signature requests."""
        return [r for r in self.requests.values() if r.status == SignatureStatus.PENDING]

    def check_policy(
        self,
        policy_id: str,
        step_id: str
    ) -> tuple[bool, List[str]]:
        """Check if a step meets signature policy requirements."""
        policy = self.policies.get(policy_id)
        if not policy:
            return True, []

        signatures = self.get_step_signatures(step_id)
        issues = []

        # Check count
        valid_signatures = [s for s in signatures if not s.revoked]
        if len(valid_signatures) < policy.required_signatures:
            issues.append(f"Need {policy.required_signatures} signatures, have {len(valid_signatures)}")

        # Check types
        if policy.required_types:
            types_present = {s.signature_type for s in valid_signatures}
            missing = set(policy.required_types) - types_present
            if missing:
                issues.append(f"Missing signature types: {[t.name for t in missing]}")

        # Check roles
        if policy.required_roles:
            roles_present = {s.signer_role for s in valid_signatures if s.signer_role}
            missing = set(policy.required_roles) - roles_present
            if missing:
                issues.append(f"Missing signatures from roles: {list(missing)}")

        # Check witness requirement
        if policy.require_witness:
            witnessed = [s for s in valid_signatures if s.witness_id]
            if not witnessed:
                issues.append("At least one signature requires a witness")

        # Check dual control
        if policy.require_dual_control:
            signers = {s.signer_id for s in valid_signatures}
            if len(signers) < 2:
                issues.append("Dual control requires signatures from two different people")

        return len(issues) == 0, issues

    def add_policy(self, policy: SignaturePolicy) -> None:
        """Add a signature policy."""
        self.policies[policy.policy_id] = policy

    def get_summary(self) -> Dict[str, Any]:
        """Get signature manager summary."""
        return {
            "total_requests": len(self.requests),
            "pending": len([r for r in self.requests.values() if r.status == SignatureStatus.PENDING]),
            "signed": len([r for r in self.requests.values() if r.status == SignatureStatus.SIGNED]),
            "rejected": len([r for r in self.requests.values() if r.status == SignatureStatus.REJECTED]),
            "total_signatures": len(self.signatures),
            "verified": len([s for s in self.signatures.values() if s.verified]),
            "revoked": len([s for s in self.signatures.values() if s.revoked]),
        }


# Convenience functions
def require_initials(
    reason: str,
    step_id: Optional[str] = None
) -> SignatureRequest:
    """Create a request for initials."""
    return SignatureRequest(
        request_id=str(uuid.uuid4())[:8],
        signature_type=SignatureType.INITIALS,
        reason=reason,
        step_id=step_id,
    )


def require_approval(
    reason: str,
    required_role: str,
    step_id: Optional[str] = None
) -> SignatureRequest:
    """Create a request for supervisor approval."""
    return SignatureRequest(
        request_id=str(uuid.uuid4())[:8],
        signature_type=SignatureType.APPROVAL,
        reason=reason,
        required_role=required_role,
        step_id=step_id,
    )


def create_standard_policy() -> SignaturePolicy:
    """Create standard signature policy."""
    return SignaturePolicy(
        policy_id="standard",
        name="Standard Protocol Signature",
        required_signatures=1,
        required_types=[SignatureType.INITIALS],
    )


def create_gmp_policy() -> SignaturePolicy:
    """Create GMP-compliant signature policy."""
    return SignaturePolicy(
        policy_id="gmp",
        name="GMP Compliant Signature",
        required_signatures=2,
        required_types=[SignatureType.FULL_SIGNATURE, SignatureType.REVIEW],
        required_roles=["operator", "reviewer"],
        require_dual_control=True,
        validate_data_hash=True,
    )
