"""
BPL Timer Support - Timer management for human execution.

Provides:
- TimerState for individual timer tracking
- TimerManager for managing multiple timers
- Timer events and notifications
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import threading


class TimerStatus(Enum):
    """Status of a timer."""
    IDLE = auto()
    RUNNING = auto()
    PAUSED = auto()
    COMPLETED = auto()
    EXPIRED = auto()
    CANCELLED = auto()


class TimerType(Enum):
    """Type of timer."""
    COUNTDOWN = auto()  # Count down to zero
    COUNTUP = auto()    # Count up from zero
    INTERVAL = auto()   # Repeating interval


@dataclass
class TimerState:
    """State of a single timer."""
    timer_id: str
    name: str
    timer_type: TimerType = TimerType.COUNTDOWN
    status: TimerStatus = TimerStatus.IDLE

    # Duration settings
    target_duration_s: float = 0.0
    warning_threshold_s: Optional[float] = None

    # Timestamps
    started_at: Optional[datetime] = None
    paused_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Accumulated time (for pause/resume)
    accumulated_s: float = 0.0

    # Callbacks
    on_complete: Optional[Callable] = None
    on_warning: Optional[Callable] = None

    # Metadata
    step_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def start(self) -> None:
        """Start the timer."""
        if self.status in (TimerStatus.IDLE, TimerStatus.PAUSED):
            self.started_at = datetime.now()
            self.status = TimerStatus.RUNNING

    def pause(self) -> None:
        """Pause the timer."""
        if self.status == TimerStatus.RUNNING:
            self.paused_at = datetime.now()
            self.accumulated_s += self.elapsed_since_start
            self.status = TimerStatus.PAUSED

    def resume(self) -> None:
        """Resume the timer."""
        if self.status == TimerStatus.PAUSED:
            self.started_at = datetime.now()
            self.status = TimerStatus.RUNNING

    def stop(self) -> None:
        """Stop the timer."""
        if self.status == TimerStatus.RUNNING:
            self.accumulated_s += self.elapsed_since_start
        self.completed_at = datetime.now()
        self.status = TimerStatus.COMPLETED

    def cancel(self) -> None:
        """Cancel the timer."""
        self.status = TimerStatus.CANCELLED
        self.completed_at = datetime.now()

    def reset(self) -> None:
        """Reset the timer."""
        self.status = TimerStatus.IDLE
        self.started_at = None
        self.paused_at = None
        self.completed_at = None
        self.accumulated_s = 0.0

    @property
    def elapsed_since_start(self) -> float:
        """Get seconds elapsed since last start."""
        if self.started_at is None:
            return 0.0
        return (datetime.now() - self.started_at).total_seconds()

    @property
    def elapsed_s(self) -> float:
        """Get total elapsed seconds."""
        if self.status == TimerStatus.RUNNING:
            return self.accumulated_s + self.elapsed_since_start
        return self.accumulated_s

    @property
    def remaining_s(self) -> float:
        """Get remaining seconds (for countdown)."""
        if self.timer_type != TimerType.COUNTDOWN:
            return 0.0
        remaining = self.target_duration_s - self.elapsed_s
        return max(0.0, remaining)

    @property
    def is_expired(self) -> bool:
        """Check if countdown timer has expired."""
        if self.timer_type != TimerType.COUNTDOWN:
            return False
        return self.elapsed_s >= self.target_duration_s

    @property
    def is_warning(self) -> bool:
        """Check if timer is in warning threshold."""
        if self.warning_threshold_s is None:
            return False
        return self.remaining_s <= self.warning_threshold_s

    @property
    def progress_percent(self) -> float:
        """Get progress percentage (for countdown)."""
        if self.timer_type != TimerType.COUNTDOWN or self.target_duration_s == 0:
            return 0.0
        progress = (self.elapsed_s / self.target_duration_s) * 100
        return min(100.0, progress)

    def format_elapsed(self) -> str:
        """Format elapsed time as string."""
        return format_duration(self.elapsed_s)

    def format_remaining(self) -> str:
        """Format remaining time as string."""
        return format_duration(self.remaining_s)


@dataclass
class TimerEvent:
    """Event from a timer."""
    timer_id: str
    event_type: str  # started, paused, resumed, completed, expired, warning
    timestamp: datetime = field(default_factory=datetime.now)
    data: Dict[str, Any] = field(default_factory=dict)


class TimerManager:
    """Manages multiple timers for a protocol execution."""

    def __init__(self):
        self.timers: Dict[str, TimerState] = {}
        self.events: List[TimerEvent] = []
        self._event_handlers: List[Callable[[TimerEvent], None]] = []
        self._lock = threading.Lock()

    def create_timer(
        self,
        timer_id: str,
        name: str,
        duration_s: float = 0.0,
        timer_type: TimerType = TimerType.COUNTDOWN,
        warning_threshold_s: Optional[float] = None,
        step_id: Optional[str] = None,
        on_complete: Optional[Callable] = None,
    ) -> TimerState:
        """Create a new timer."""
        with self._lock:
            timer = TimerState(
                timer_id=timer_id,
                name=name,
                timer_type=timer_type,
                target_duration_s=duration_s,
                warning_threshold_s=warning_threshold_s,
                step_id=step_id,
                on_complete=on_complete,
            )
            self.timers[timer_id] = timer
            return timer

    def get_timer(self, timer_id: str) -> Optional[TimerState]:
        """Get a timer by ID."""
        return self.timers.get(timer_id)

    def start_timer(self, timer_id: str) -> bool:
        """Start a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.start()
            self._emit_event(timer_id, "started")
            return True
        return False

    def pause_timer(self, timer_id: str) -> bool:
        """Pause a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.pause()
            self._emit_event(timer_id, "paused")
            return True
        return False

    def resume_timer(self, timer_id: str) -> bool:
        """Resume a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.resume()
            self._emit_event(timer_id, "resumed")
            return True
        return False

    def stop_timer(self, timer_id: str) -> bool:
        """Stop a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.stop()
            self._emit_event(timer_id, "completed")
            if timer.on_complete:
                timer.on_complete()
            return True
        return False

    def cancel_timer(self, timer_id: str) -> bool:
        """Cancel a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.cancel()
            self._emit_event(timer_id, "cancelled")
            return True
        return False

    def reset_timer(self, timer_id: str) -> bool:
        """Reset a timer."""
        timer = self.timers.get(timer_id)
        if timer:
            timer.reset()
            self._emit_event(timer_id, "reset")
            return True
        return False

    def check_timers(self) -> List[TimerEvent]:
        """Check all running timers for expirations/warnings."""
        new_events = []

        for timer_id, timer in self.timers.items():
            if timer.status == TimerStatus.RUNNING:
                # Check for expiration
                if timer.is_expired and timer.status != TimerStatus.EXPIRED:
                    timer.status = TimerStatus.EXPIRED
                    event = self._emit_event(timer_id, "expired")
                    new_events.append(event)
                    if timer.on_complete:
                        timer.on_complete()

                # Check for warning threshold
                elif timer.is_warning:
                    event = self._emit_event(timer_id, "warning", {
                        "remaining_s": timer.remaining_s
                    })
                    new_events.append(event)
                    if timer.on_warning:
                        timer.on_warning()

        return new_events

    def get_active_timers(self) -> List[TimerState]:
        """Get all active (running/paused) timers."""
        return [t for t in self.timers.values()
                if t.status in (TimerStatus.RUNNING, TimerStatus.PAUSED)]

    def get_expired_timers(self) -> List[TimerState]:
        """Get all expired timers."""
        return [t for t in self.timers.values() if t.status == TimerStatus.EXPIRED]

    def add_event_handler(self, handler: Callable[[TimerEvent], None]) -> None:
        """Add an event handler."""
        self._event_handlers.append(handler)

    def _emit_event(
        self,
        timer_id: str,
        event_type: str,
        data: Optional[Dict] = None
    ) -> TimerEvent:
        """Emit a timer event."""
        event = TimerEvent(
            timer_id=timer_id,
            event_type=event_type,
            data=data or {}
        )
        self.events.append(event)

        for handler in self._event_handlers:
            try:
                handler(event)
            except Exception:
                pass  # Ignore handler errors

        return event

    def get_summary(self) -> Dict[str, Any]:
        """Get timer manager summary."""
        return {
            "total_timers": len(self.timers),
            "running": len([t for t in self.timers.values() if t.status == TimerStatus.RUNNING]),
            "paused": len([t for t in self.timers.values() if t.status == TimerStatus.PAUSED]),
            "expired": len([t for t in self.timers.values() if t.status == TimerStatus.EXPIRED]),
            "completed": len([t for t in self.timers.values() if t.status == TimerStatus.COMPLETED]),
            "total_events": len(self.events),
        }


def format_duration(seconds: float) -> str:
    """Format duration in seconds to human-readable string."""
    if seconds < 0:
        return "-" + format_duration(-seconds)

    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes}:{secs:02d}"


def create_countdown_timer(
    timer_id: str,
    name: str,
    duration_s: float,
    warning_s: Optional[float] = None
) -> TimerState:
    """Convenience function to create a countdown timer."""
    return TimerState(
        timer_id=timer_id,
        name=name,
        timer_type=TimerType.COUNTDOWN,
        target_duration_s=duration_s,
        warning_threshold_s=warning_s,
    )


def create_stopwatch(timer_id: str, name: str) -> TimerState:
    """Convenience function to create a stopwatch (count-up timer)."""
    return TimerState(
        timer_id=timer_id,
        name=name,
        timer_type=TimerType.COUNTUP,
    )
