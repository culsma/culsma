"""
BPL Protocol Generator - Generates human-executable protocols from execution plans.

Provides:
- PlanToHumanConverter for converting ExecutionPlans to HumanExecutionPlans
- generate_human_protocol convenience function
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple

from .execution_ir import (
    HumanExecutionStep,
    HumanExecutionPlan,
    StepType,
    StepLocation,
    StepParameters,
)
from .step_renderer import StepRenderer, RenderFormat

from ...lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    PrimitiveType,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    Wait,
    MoveLabware,
    SetTemperature,
    WellRef,
    Location,
)


@dataclass
class ConversionOptions:
    """Options for plan to human protocol conversion."""
    include_tip_steps: bool = True
    group_transfers: bool = True
    add_checkpoints: bool = True
    checkpoint_interval: int = 10  # Steps between checkpoints
    require_signatures: bool = False
    signature_interval: int = 0  # 0 = no automatic signatures
    add_timing_estimates: bool = True
    verbose_instructions: bool = True


class PlanToHumanConverter:
    """Converts ExecutionPlan to HumanExecutionPlan."""

    def __init__(self, options: Optional[ConversionOptions] = None):
        self.options = options or ConversionOptions()
        self._step_counter = 0
        self._current_group: Optional[str] = None

    def convert(
        self,
        plan: ExecutionPlan,
        protocol_name: str = "Protocol",
        version: str = "1.0"
    ) -> HumanExecutionPlan:
        """Convert an execution plan to human execution plan."""
        human_plan = HumanExecutionPlan(
            plan_id=plan.plan_id,
            protocol_name=protocol_name,
            version=version,
        )

        self._step_counter = 0

        # Convert steps in execution order
        step_order = plan.topological_order()

        for step_id in step_order:
            plan_step = plan.steps[step_id]
            human_steps = self._convert_step(plan_step)

            for human_step in human_steps:
                human_plan.add_step(human_step)

                # Add checkpoints at intervals
                if self.options.add_checkpoints:
                    if self._step_counter % self.options.checkpoint_interval == 0:
                        checkpoint = self._create_checkpoint_step(human_step)
                        human_plan.add_step(checkpoint)

                # Add signature requirements
                if self.options.require_signatures and self.options.signature_interval > 0:
                    if self._step_counter % self.options.signature_interval == 0:
                        human_step.requires_signature = True

        return human_plan

    def _convert_step(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert a single plan step to human steps."""
        primitive = step.primitive
        ptype = primitive.primitive_type

        converters = {
            PrimitiveType.ASPIRATE: self._convert_aspirate,
            PrimitiveType.DISPENSE: self._convert_dispense,
            PrimitiveType.MIX: self._convert_mix,
            PrimitiveType.PICK_TIPS: self._convert_pick_tips,
            PrimitiveType.DROP_TIPS: self._convert_drop_tips,
            PrimitiveType.WAIT: self._convert_wait,
            PrimitiveType.MOVE_LABWARE: self._convert_move_labware,
            PrimitiveType.SET_TEMPERATURE: self._convert_set_temperature,
        }

        converter = converters.get(ptype, self._convert_generic)
        return converter(step)

    def _convert_aspirate(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert aspirate primitive."""
        if not isinstance(step.primitive, Aspirate):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        source_text, labware_id, well_id = self._format_location(primitive.source)

        instruction = self._format_instruction(
            "Aspirate {volume} from {source}",
            volume=self._format_volume(primitive.volume_ul),
            source=source_text
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.ASPIRATE,
            instruction=instruction,
            source=StepLocation(
                labware_id=labware_id,
                well_id=well_id
            ),
            parameters=StepParameters(volume_ul=primitive.volume_ul),
        )]

    def _convert_dispense(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert dispense primitive."""
        if not isinstance(step.primitive, Dispense):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        dest_text, labware_id, well_id = self._format_location(primitive.destination)

        instruction = self._format_instruction(
            "Dispense {volume} into {destination}",
            volume=self._format_volume(primitive.volume_ul),
            destination=dest_text
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.DISPENSE,
            instruction=instruction,
            destination=StepLocation(
                labware_id=labware_id,
                well_id=well_id
            ),
            parameters=StepParameters(volume_ul=primitive.volume_ul),
        )]

    def _convert_mix(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert mix primitive."""
        if not isinstance(step.primitive, Mix):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        loc_text, labware_id, well_id = self._format_location(primitive.location)

        instruction = self._format_instruction(
            "Mix {cycles} times at {location}",
            cycles=primitive.cycles,
            location=loc_text
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.MIX,
            instruction=instruction,
            destination=StepLocation(
                labware_id=labware_id,
                well_id=well_id
            ),
            parameters=StepParameters(cycles=primitive.cycles),
        )]

    def _convert_pick_tips(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert pick tips primitive."""
        if not self.options.include_tip_steps:
            return []

        if not isinstance(step.primitive, PickTips):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        positions = primitive.tip_positions
        if len(positions) == 1:
            pos_text = f"position {positions[0]}"
        else:
            pos_text = f"positions {', '.join(positions)}"

        instruction = self._format_instruction(
            "Get new tips from {rack} at {positions}",
            rack=primitive.tip_rack.rack_id,
            positions=pos_text
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.GET_TIPS,
            instruction=instruction,
            source=StepLocation(labware_id=primitive.tip_rack.rack_id),
            parameters=StepParameters(tip_type=primitive.tip_rack.tip_type),
        )]

    def _convert_drop_tips(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert drop tips primitive."""
        if not self.options.include_tip_steps:
            return []

        self._step_counter += 1

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.DROP_TIPS,
            instruction="Discard tips to waste",
        )]

    def _convert_wait(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert wait primitive."""
        if not isinstance(step.primitive, Wait):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        instruction = self._format_instruction(
            "Wait for {duration}",
            duration=self._format_duration(primitive.duration_s)
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.WAIT,
            instruction=instruction,
            parameters=StepParameters(duration_s=primitive.duration_s),
        )]

    def _convert_move_labware(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert move labware primitive."""
        if not isinstance(step.primitive, MoveLabware):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        instruction = self._format_instruction(
            "Move {labware} to {position}",
            labware=primitive.labware_id,
            position=primitive.to_position
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.MOVE_LABWARE,
            instruction=instruction,
            destination=StepLocation(
                labware_id=primitive.labware_id,
                position=primitive.to_position
            ),
        )]

    def _convert_set_temperature(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert set temperature primitive."""
        if not isinstance(step.primitive, SetTemperature):
            return self._convert_generic(step)
        primitive = step.primitive
        self._step_counter += 1

        instruction = self._format_instruction(
            "Set {module} temperature to {temp}",
            module=primitive.device_id,
            temp=f"{primitive.temperature_c}°C"
        )

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.SET_TEMPERATURE,
            instruction=instruction,
            parameters=StepParameters(temperature_c=primitive.temperature_c),
        )]

    def _convert_generic(self, step: PlanStep) -> List[HumanExecutionStep]:
        """Convert generic/unknown primitive."""
        self._step_counter += 1

        return [HumanExecutionStep(
            step_id=step.step_id,
            step_number=self._step_counter,
            step_type=StepType.NOTE,
            instruction=f"Execute: {step.primitive.primitive_type.name}",
        )]

    def _create_checkpoint_step(self, after_step: HumanExecutionStep) -> HumanExecutionStep:
        """Create a checkpoint step."""
        self._step_counter += 1

        return HumanExecutionStep(
            step_id=f"checkpoint_{after_step.step_id}",
            step_number=self._step_counter,
            step_type=StepType.CHECKPOINT,
            instruction="Checkpoint: Verify steps completed correctly",
            requires_verification=True,
        )

    def _format_instruction(self, template: str, **kwargs) -> str:
        """Format instruction with parameters."""
        return template.format(**kwargs)

    def _format_volume(self, volume_ul: float) -> str:
        """Format volume for display."""
        if volume_ul >= 1000:
            return f"{volume_ul / 1000:.2f} mL"
        return f"{volume_ul:.1f} µL"

    def _format_duration(self, seconds: float) -> str:
        """Format duration for display."""
        if seconds >= 3600:
            hours = int(seconds // 3600)
            mins = int((seconds % 3600) // 60)
            return f"{hours}h {mins}m"
        elif seconds >= 60:
            mins = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{mins}m {secs}s"
        return f"{int(seconds)}s"

    def _format_location(self, location: Location) -> Tuple[str, str, Optional[str]]:
        """
        Format a location for display.

        Args:
            location: A WellRef or ContainerRef location

        Returns:
            Tuple of (display_text, labware_id, well_id or None)
        """
        if isinstance(location, WellRef):
            display_text = f"{location.plate_id} well {location.well_id}"
            return display_text, location.plate_id, location.well_id
        else:
            # ContainerRef
            display_text = location.container_id
            return display_text, location.container_id, None


def generate_human_protocol(
    plan: ExecutionPlan,
    protocol_name: str = "Protocol",
    format: RenderFormat = RenderFormat.TEXT,
    options: Optional[ConversionOptions] = None
) -> str:
    """
    Generate human-readable protocol from execution plan.

    Args:
        plan: The execution plan to convert
        protocol_name: Name for the protocol
        format: Output format (TEXT, MARKDOWN, HTML)
        options: Conversion options

    Returns:
        Formatted protocol as string
    """
    converter = PlanToHumanConverter(options)
    human_plan = converter.convert(plan, protocol_name)

    renderer = StepRenderer()
    return renderer.render_plan(human_plan, format)


def convert_plan_to_human(
    plan: ExecutionPlan,
    protocol_name: str = "Protocol",
    options: Optional[ConversionOptions] = None
) -> HumanExecutionPlan:
    """
    Convert execution plan to human execution plan.

    Args:
        plan: The execution plan to convert
        protocol_name: Name for the protocol
        options: Conversion options

    Returns:
        HumanExecutionPlan ready for execution
    """
    converter = PlanToHumanConverter(options)
    return converter.convert(plan, protocol_name)
