"""
BPL Hybrid Execution - Mixed human/robot execution support.

Provides:
- HybridExecutor for coordinating human and robot steps
- Step classification (human vs robot)
- Handoff management
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum, auto
from datetime import datetime

from ....capabilities import get_supported_primitive_types
from .biomek_ir import BiomekProgram
from .biomek_translator import (
    PlanToBiomekTranslator,
    DeckMapping,
    TranslationOptions,
)
from ...human import (
    HumanExecutionPlan,
    PlanToHumanConverter,
    ConversionOptions,
)
from ....lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    PrimitiveType,
)


class ExecutionTarget(Enum):
    """Target for step execution."""
    HUMAN = auto()
    ROBOT = auto()
    HYBRID = auto()  # Requires both


class HandoffType(Enum):
    """Type of handoff between human and robot."""
    ROBOT_TO_HUMAN = auto()  # Robot completes, human takes over
    HUMAN_TO_ROBOT = auto()  # Human completes, robot takes over
    PARALLEL = auto()        # Both execute in parallel
    CHECKPOINT = auto()      # Synchronization point


@dataclass
class HandoffPoint:
    """A handoff point between execution modes."""
    handoff_id: str
    handoff_type: HandoffType
    before_step_id: str
    after_step_id: str
    description: str = ""

    # State verification
    verify_deck_state: bool = True
    required_confirmations: List[str] = field(default_factory=list)

    # Status
    completed: bool = False
    completed_at: Optional[datetime] = None
    completed_by: Optional[str] = None


@dataclass
class StepClassification:
    """Classification of a step for execution."""
    step_id: str
    target: ExecutionTarget
    reason: str = ""
    can_parallelize: bool = False


@dataclass
class HybridExecutionPlan:
    """A plan with both human and robot components."""
    plan_id: str
    protocol_name: str

    # Original plan
    source_plan: Optional[ExecutionPlan] = field(default=None)

    # Split plans
    robot_program: Optional[BiomekProgram] = None
    human_plan: Optional[HumanExecutionPlan] = None

    # Step classifications
    step_classifications: Dict[str, StepClassification] = field(default_factory=dict)

    # Handoffs
    handoffs: List[HandoffPoint] = field(default_factory=list)

    # Execution order (mixed)
    execution_sequence: List[tuple[str, ExecutionTarget]] = field(default_factory=list)

    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    warnings: List[str] = field(default_factory=list)


class StepClassifier:
    """Classifies steps as human or robot executable."""

    def __init__(self, robot_capable_primitives: Optional[List[PrimitiveType]] = None):
        default_robot_capable = sorted(
            get_supported_primitive_types("biomek"),
            key=lambda primitive_type: primitive_type.name,
        )
        self.robot_capable = robot_capable_primitives or default_robot_capable

        # Primitives that require human interaction
        self.human_required = [
            PrimitiveType.SEAL_PLATE,
            PrimitiveType.UNSEAL_PLATE,
        ]

    def classify(self, step: PlanStep) -> StepClassification:
        """Classify a step for execution."""
        ptype = step.primitive.primitive_type

        # Check if robot can handle it
        if ptype in self.robot_capable:
            # Check for human-only annotations
            if step.annotations.get("human_only", False):
                return StepClassification(
                    step_id=step.step_id,
                    target=ExecutionTarget.HUMAN,
                    reason="Marked human_only in annotations"
                )

            return StepClassification(
                step_id=step.step_id,
                target=ExecutionTarget.ROBOT,
                reason=f"Robot can execute {ptype.name}"
            )

        # Check if human required
        if ptype in self.human_required:
            return StepClassification(
                step_id=step.step_id,
                target=ExecutionTarget.HUMAN,
                reason=f"Human required for {ptype.name}"
            )

        # Default to human for unknown primitives
        return StepClassification(
            step_id=step.step_id,
            target=ExecutionTarget.HUMAN,
            reason=f"Unknown primitive {ptype.name} defaults to human"
        )

    def classify_plan(self, plan: ExecutionPlan) -> Dict[str, StepClassification]:
        """Classify all steps in a plan."""
        classifications = {}
        for step_id, step in plan.steps.items():
            classifications[step_id] = self.classify(step)
        return classifications


class HybridExecutor:
    """Coordinates hybrid human/robot execution."""

    def __init__(
        self,
        deck_mapping: Optional[DeckMapping] = None,
        biomek_options: Optional[TranslationOptions] = None,
        human_options: Optional[ConversionOptions] = None
    ):
        self.classifier = StepClassifier()
        self.deck_mapping = deck_mapping or DeckMapping()
        self.biomek_options = biomek_options or TranslationOptions()
        self.human_options = human_options or ConversionOptions()

    def create_hybrid_plan(
        self,
        plan: ExecutionPlan,
        protocol_name: str = "Hybrid Protocol"
    ) -> HybridExecutionPlan:
        """Create a hybrid execution plan from an execution plan."""
        hybrid = HybridExecutionPlan(
            plan_id=plan.plan_id,
            protocol_name=protocol_name,
            source_plan=plan
        )

        # Classify all steps
        hybrid.step_classifications = self.classifier.classify_plan(plan)

        # Determine execution sequence with handoffs
        self._build_execution_sequence(plan, hybrid)

        # Create robot program for robot steps
        robot_steps = self._filter_steps(plan, hybrid, ExecutionTarget.ROBOT)
        if robot_steps:
            robot_plan = self._create_sub_plan(plan, robot_steps)
            translator = PlanToBiomekTranslator(self.deck_mapping, self.biomek_options)
            result = translator.translate(robot_plan, f"{protocol_name}_Robot")
            hybrid.robot_program = result.program
            hybrid.warnings.extend(result.warnings)

        # Create human plan for human steps
        human_steps = self._filter_steps(plan, hybrid, ExecutionTarget.HUMAN)
        if human_steps:
            human_plan = self._create_sub_plan(plan, human_steps)
            converter = PlanToHumanConverter(self.human_options)
            hybrid.human_plan = converter.convert(human_plan, f"{protocol_name}_Human")

        return hybrid

    def _build_execution_sequence(
        self,
        plan: ExecutionPlan,
        hybrid: HybridExecutionPlan
    ) -> None:
        """Build the execution sequence with handoffs."""
        step_order = plan.topological_order()
        current_target = None
        handoff_counter = 0

        for i, step_id in enumerate(step_order):
            classification = hybrid.step_classifications[step_id]
            target = classification.target

            # Add step to sequence
            hybrid.execution_sequence.append((step_id, target))

            # Check for handoff
            if current_target is not None and current_target != target:
                # Determine handoff type
                if current_target == ExecutionTarget.ROBOT:
                    handoff_type = HandoffType.ROBOT_TO_HUMAN
                else:
                    handoff_type = HandoffType.HUMAN_TO_ROBOT

                handoff_counter += 1
                prev_step_id = step_order[i - 1] if i > 0 else step_id

                handoff = HandoffPoint(
                    handoff_id=f"handoff_{handoff_counter}",
                    handoff_type=handoff_type,
                    before_step_id=prev_step_id,
                    after_step_id=step_id,
                    description=f"Transition from {current_target.name} to {target.name}"
                )
                hybrid.handoffs.append(handoff)

            current_target = target

    def _filter_steps(
        self,
        plan: ExecutionPlan,
        hybrid: HybridExecutionPlan,
        target: ExecutionTarget
    ) -> List[str]:
        """Filter steps by execution target."""
        return [
            step_id for step_id, classification in hybrid.step_classifications.items()
            if classification.target == target
        ]

    def _create_sub_plan(
        self,
        plan: ExecutionPlan,
        step_ids: List[str]
    ) -> ExecutionPlan:
        """Create a sub-plan containing only specified steps."""
        sub_plan = ExecutionPlan(plan_id=f"{plan.plan_id}_sub")

        for step_id in step_ids:
            if step_id in plan.steps:
                sub_plan.steps[step_id] = plan.steps[step_id]

        return sub_plan

    def get_next_execution_block(
        self,
        hybrid: HybridExecutionPlan,
        current_index: int = 0
    ) -> tuple[ExecutionTarget, List[str], int]:
        """
        Get the next block of steps to execute.

        Returns: (target, step_ids, next_index)
        """
        if current_index >= len(hybrid.execution_sequence):
            return (ExecutionTarget.HUMAN, [], len(hybrid.execution_sequence))

        current_target = hybrid.execution_sequence[current_index][1]
        step_ids = []

        # Collect all consecutive steps with same target
        i = current_index
        while i < len(hybrid.execution_sequence):
            step_id, target = hybrid.execution_sequence[i]
            if target != current_target:
                break
            step_ids.append(step_id)
            i += 1

        return (current_target, step_ids, i)

    def get_handoff_at_index(
        self,
        hybrid: HybridExecutionPlan,
        index: int
    ) -> Optional[HandoffPoint]:
        """Get handoff that occurs before the step at given index."""
        if index <= 0 or index >= len(hybrid.execution_sequence):
            return None

        prev_step = hybrid.execution_sequence[index - 1][0]
        curr_step = hybrid.execution_sequence[index][0]

        for handoff in hybrid.handoffs:
            if handoff.before_step_id == prev_step and handoff.after_step_id == curr_step:
                return handoff

        return None


@dataclass
class HybridExecutionState:
    """State of hybrid execution."""
    hybrid_plan: HybridExecutionPlan
    current_index: int = 0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Tracking
    completed_robot_steps: List[str] = field(default_factory=list)
    completed_human_steps: List[str] = field(default_factory=list)
    pending_handoffs: List[str] = field(default_factory=list)

    @property
    def is_complete(self) -> bool:
        """Check if execution is complete."""
        return self.current_index >= len(self.hybrid_plan.execution_sequence)

    @property
    def progress_percent(self) -> float:
        """Get progress percentage."""
        total = len(self.hybrid_plan.execution_sequence)
        if total == 0:
            return 100.0
        completed = len(self.completed_robot_steps) + len(self.completed_human_steps)
        return (completed / total) * 100

    def complete_step(self, step_id: str, target: ExecutionTarget) -> None:
        """Mark a step as complete."""
        if target == ExecutionTarget.ROBOT:
            self.completed_robot_steps.append(step_id)
        else:
            self.completed_human_steps.append(step_id)


class HybridExecutionManager:
    """Manages hybrid execution sessions."""

    def __init__(self):
        self.executor = HybridExecutor()
        self.sessions: Dict[str, HybridExecutionState] = {}

    def create_session(
        self,
        plan: ExecutionPlan,
        protocol_name: str = "Protocol"
    ) -> HybridExecutionState:
        """Create a new hybrid execution session."""
        hybrid_plan = self.executor.create_hybrid_plan(plan, protocol_name)

        state = HybridExecutionState(
            hybrid_plan=hybrid_plan,
            started_at=datetime.now()
        )

        session_id = hybrid_plan.plan_id
        self.sessions[session_id] = state

        return state

    def get_session(self, session_id: str) -> Optional[HybridExecutionState]:
        """Get a session by ID."""
        return self.sessions.get(session_id)

    def advance_session(
        self,
        session_id: str
    ) -> tuple[Optional[ExecutionTarget], List[str], Optional[HandoffPoint]]:
        """
        Advance to the next execution block.

        Returns: (target, step_ids, handoff_if_applicable)
        """
        state = self.sessions.get(session_id)
        if not state:
            return (None, [], None)

        # Check for handoff
        handoff = self.executor.get_handoff_at_index(
            state.hybrid_plan,
            state.current_index
        )

        # Get next block
        target, step_ids, next_index = self.executor.get_next_execution_block(
            state.hybrid_plan,
            state.current_index
        )

        state.current_index = next_index

        return (target, step_ids, handoff)

    def complete_session(self, session_id: str) -> Optional[HybridExecutionState]:
        """Mark a session as complete."""
        state = self.sessions.get(session_id)
        if state:
            state.completed_at = datetime.now()
        return state


def create_hybrid_plan(
    plan: ExecutionPlan,
    protocol_name: str = "Hybrid Protocol",
    deck_mapping: Optional[DeckMapping] = None
) -> HybridExecutionPlan:
    """Convenience function to create a hybrid plan."""
    executor = HybridExecutor(deck_mapping=deck_mapping)
    return executor.create_hybrid_plan(plan, protocol_name)
