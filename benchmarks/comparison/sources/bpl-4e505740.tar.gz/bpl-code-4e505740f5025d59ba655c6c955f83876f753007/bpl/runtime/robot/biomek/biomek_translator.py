"""
BPL Biomek Translator - Translates Plan IR to Biomek IR.

Provides:
- PlanToBiomekTranslator for converting execution plans
- Translation options and mappings
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ....capabilities import is_primitive_supported
from .biomek_ir import (
    BiomekProgram,
    BiomekCommand,
    BiomekPosition,
    LiquidClass,
    TipType,
    AspirateCommand,
    DispenseCommand,
    MixCommand,
    GetTipsCommand,
    DropTipsCommand,
    MoveLabwareCommand,
    SetTemperatureCommand,
    DelayCommand,
    PauseCommand,
    CommentCommand,
)

from ....lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    PrimitiveType,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    Pause,
    Checkpoint,
    Wait,
    MoveLabware,
    SetTemperature,
    WellRef,
)


@dataclass
class DeckMapping:
    """Mapping from BPL labware IDs to Biomek deck positions."""
    labware_to_position: Dict[str, int] = field(default_factory=dict)
    position_to_labware: Dict[int, str] = field(default_factory=dict)

    def add_mapping(self, labware_id: str, deck_position: int) -> None:
        """Add a labware to deck position mapping."""
        self.labware_to_position[labware_id] = deck_position
        self.position_to_labware[deck_position] = labware_id

    def get_position(self, labware_id: str) -> Optional[int]:
        """Get deck position for labware."""
        return self.labware_to_position.get(labware_id)

    def get_labware(self, deck_position: int) -> Optional[str]:
        """Get labware ID at deck position."""
        return self.position_to_labware.get(deck_position)


@dataclass
class TranslationOptions:
    """Options for translation."""
    # Tip handling
    auto_change_tips: bool = True
    tip_type: TipType = TipType.TIPS_200
    tip_rack_positions: List[int] = field(default_factory=lambda: [9, 10])
    waste_position: int = 20

    # Liquid handling
    default_liquid_class: str = "Default"
    aspirate_offset_z: float = 1.0  # mm above well bottom
    dispense_offset_z: float = 1.0

    # Multi-channel
    use_multichannel: bool = False
    active_channels: List[int] = field(default_factory=lambda: [1])

    # Safety
    add_pauses_on_error: bool = True
    validate_volumes: bool = True
    max_volume_ul: float = 1000.0
    strict_capabilities: bool = False

    # Comments
    add_step_comments: bool = True
    verbose_comments: bool = False


@dataclass
class TranslationResult:
    """Result of translation."""
    success: bool
    program: Optional[BiomekProgram] = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    step_mapping: Dict[str, List[str]] = field(default_factory=dict)  # plan_step_id -> command_ids


class PlanToBiomekTranslator:
    """Translates ExecutionPlan to BiomekProgram."""

    def __init__(
        self,
        deck_mapping: Optional[DeckMapping] = None,
        options: Optional[TranslationOptions] = None
    ):
        self.deck_mapping = deck_mapping or DeckMapping()
        self.options = options or TranslationOptions()
        self._liquid_classes: Dict[str, LiquidClass] = {}
        self._command_counter = 0
        self._current_tip_position = 0

    def translate(
        self,
        plan: ExecutionPlan,
        program_name: str = "BPL_Program"
    ) -> TranslationResult:
        """Translate an execution plan to a Biomek program."""
        result = TranslationResult(success=True)

        program = BiomekProgram(
            program_id=plan.plan_id,
            name=program_name
        )

        # Initialize liquid classes
        self._setup_liquid_classes(program)

        # Translate steps in order
        try:
            step_order = plan.topological_order()

            for step_id in step_order:
                plan_step = plan.steps[step_id]
                commands = self._translate_step(plan_step, result)

                # Track mapping
                result.step_mapping[step_id] = [c.command_id for c in commands]

                # Add to program
                for cmd in commands:
                    program.add_command(cmd)

        except Exception as e:
            result.success = False
            result.errors.append(f"Translation error: {str(e)}")

        result.program = program
        return result

    def _setup_liquid_classes(self, program: BiomekProgram) -> None:
        """Set up default liquid classes."""
        program.add_liquid_class(LiquidClass.default())
        program.add_liquid_class(LiquidClass.for_aqueous())
        program.add_liquid_class(LiquidClass.for_viscous())
        program.add_liquid_class(LiquidClass.for_volatile())

    def _translate_step(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate a single plan step."""
        primitive = step.primitive
        ptype = primitive.primitive_type

        translators = {
            PrimitiveType.ASPIRATE: self._translate_aspirate,
            PrimitiveType.DISPENSE: self._translate_dispense,
            PrimitiveType.MIX: self._translate_mix,
            PrimitiveType.PICK_TIPS: self._translate_pick_tips,
            PrimitiveType.DROP_TIPS: self._translate_drop_tips,
            PrimitiveType.WAIT: self._translate_wait,
            PrimitiveType.PAUSE: self._translate_pause,
            PrimitiveType.CHECKPOINT: self._translate_checkpoint,
            PrimitiveType.MOVE_LABWARE: self._translate_move_labware,
            PrimitiveType.SET_TEMPERATURE: self._translate_set_temperature,
        }

        translator = translators.get(ptype)
        commands: List[BiomekCommand]
        if translator and is_primitive_supported(ptype, "biomek"):
            commands = translator(step, result)
        else:
            if self.options.strict_capabilities:
                raise ValueError(f"Unsupported primitive type for biomek strict mode: {ptype.name}")

            # Add comment for unsupported primitive
            commands = [CommentCommand(
                command_id=self._next_command_id(),
                text=f"Unsupported primitive: {ptype.name}"
            )]
            result.warnings.append(f"Unsupported primitive type: {ptype.name}")

        # Add step comment if enabled
        if self.options.add_step_comments and commands:
            comment: BiomekCommand = CommentCommand(
                command_id=self._next_command_id(),
                text=f"Step: {step.step_id}"
            )
            commands = [comment] + commands

        return commands

    def _translate_aspirate(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate aspirate primitive."""
        primitive = step.primitive
        if not isinstance(primitive, Aspirate):
            result.warnings.append(f"Expected Aspirate primitive, got {type(primitive).__name__}")
            return []

        source = primitive.source

        # Get deck position - handle WellRef vs ContainerRef
        if isinstance(source, WellRef):
            plate_id = source.plate_id
            well_id = source.well_id
        else:
            # ContainerRef - use container_id as plate_id and default well
            plate_id = source.container_id
            well_id = "A1"

        deck_pos = self.deck_mapping.get_position(plate_id)
        if deck_pos is None:
            result.warnings.append(f"No deck mapping for {plate_id}, using position 1")
            deck_pos = 1

        # Parse well
        position = self._parse_well_to_position(deck_pos, well_id)

        # Validate volume
        if self.options.validate_volumes and primitive.volume_ul > self.options.max_volume_ul:
            result.warnings.append(
                f"Volume {primitive.volume_ul}uL exceeds max {self.options.max_volume_ul}uL"
            )

        # Get liquid class
        liquid_class = LiquidClass.default()

        position.offset_z = self.options.aspirate_offset_z

        return [AspirateCommand(
            command_id=self._next_command_id(),
            source=position,
            volume_ul=primitive.volume_ul,
            liquid_class=liquid_class,
            channels=self.options.active_channels,
            comment=f"Aspirate {primitive.volume_ul}uL from {plate_id}:{well_id}"
        )]

    def _translate_dispense(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate dispense primitive."""
        primitive = step.primitive
        if not isinstance(primitive, Dispense):
            result.warnings.append(f"Expected Dispense primitive, got {type(primitive).__name__}")
            return []

        dest = primitive.destination

        # Get deck position - handle WellRef vs ContainerRef
        if isinstance(dest, WellRef):
            plate_id = dest.plate_id
            well_id = dest.well_id
        else:
            # ContainerRef - use container_id as plate_id and default well
            plate_id = dest.container_id
            well_id = "A1"

        deck_pos = self.deck_mapping.get_position(plate_id)
        if deck_pos is None:
            result.warnings.append(f"No deck mapping for {plate_id}, using position 2")
            deck_pos = 2

        # Parse well
        position = self._parse_well_to_position(deck_pos, well_id)
        position.offset_z = self.options.dispense_offset_z

        return [DispenseCommand(
            command_id=self._next_command_id(),
            destination=position,
            volume_ul=primitive.volume_ul,
            liquid_class=LiquidClass.default(),
            channels=self.options.active_channels,
            comment=f"Dispense {primitive.volume_ul}uL to {plate_id}:{well_id}"
        )]

    def _translate_mix(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate mix primitive."""
        primitive = step.primitive
        if not isinstance(primitive, Mix):
            result.warnings.append(f"Expected Mix primitive, got {type(primitive).__name__}")
            return []

        location = primitive.location

        # Get deck position - handle WellRef vs ContainerRef
        if isinstance(location, WellRef):
            plate_id = location.plate_id
            well_id = location.well_id
        else:
            # ContainerRef - use container_id as plate_id and default well
            plate_id = location.container_id
            well_id = "A1"

        deck_pos = self.deck_mapping.get_position(plate_id)
        if deck_pos is None:
            deck_pos = 1

        position = self._parse_well_to_position(deck_pos, well_id)

        # Use the volume from primitive
        mix_volume = primitive.volume_ul

        return [MixCommand(
            command_id=self._next_command_id(),
            position=position,
            volume_ul=mix_volume,
            cycles=primitive.cycles,
            channels=self.options.active_channels,
            comment=f"Mix {primitive.cycles}x at {plate_id}:{well_id}"
        )]

    def _translate_pick_tips(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate pick tips primitive."""
        primitive = step.primitive
        if not isinstance(primitive, PickTips):
            result.warnings.append(f"Expected PickTips primitive, got {type(primitive).__name__}")
            return []

        # Get tip rack position
        rack_id = primitive.tip_rack.rack_id
        deck_pos = self.deck_mapping.get_position(rack_id)
        if deck_pos is None:
            # Use default tip rack position
            deck_pos = self.options.tip_rack_positions[0] if self.options.tip_rack_positions else 9

        # Parse tip positions
        positions = primitive.tip_positions
        if positions:
            well_id = positions[0]  # Take first position
            position = self._parse_well_to_position(deck_pos, well_id)
        else:
            position = BiomekPosition(deck_pos)

        return [GetTipsCommand(
            command_id=self._next_command_id(),
            tip_rack_position=position,
            tip_type=self.options.tip_type,
            channels=self.options.active_channels,
            comment=f"Get tips from {rack_id}"
        )]

    def _translate_drop_tips(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate drop tips primitive."""
        waste_pos = BiomekPosition(self.options.waste_position)

        return [DropTipsCommand(
            command_id=self._next_command_id(),
            waste_position=waste_pos,
            channels=self.options.active_channels,
            comment="Drop tips to waste"
        )]

    def _translate_wait(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate wait primitive."""
        primitive = step.primitive
        if not isinstance(primitive, Wait):
            result.warnings.append(f"Expected Wait primitive, got {type(primitive).__name__}")
            return []

        return [DelayCommand(
            command_id=self._next_command_id(),
            duration_s=primitive.duration_s,
            comment=f"Wait {primitive.duration_s}s"
        )]

    def _translate_pause(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate pause primitive into an explicit Biomek pause command."""
        primitive = step.primitive
        if not isinstance(primitive, Pause):
            result.warnings.append(f"Expected Pause primitive, got {type(primitive).__name__}")
            return []

        return [PauseCommand(
            command_id=self._next_command_id(),
            message=primitive.reason,
            comment=f"Manual pause for {step.step_id}"
        )]

    def _translate_checkpoint(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate checkpoint primitive into a deterministic marker comment."""
        primitive = step.primitive
        if not isinstance(primitive, Checkpoint):
            result.warnings.append(f"Expected Checkpoint primitive, got {type(primitive).__name__}")
            return []

        return [CommentCommand(
            command_id=self._next_command_id(),
            text=f"CHECKPOINT {primitive.checkpoint_id}"
        )]

    def _translate_move_labware(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate move labware primitive."""
        primitive = step.primitive
        if not isinstance(primitive, MoveLabware):
            result.warnings.append(f"Expected MoveLabware primitive, got {type(primitive).__name__}")
            return []

        # Get current position
        from_deck = self.deck_mapping.get_position(primitive.labware_id)
        if from_deck is None:
            result.warnings.append(f"No deck mapping for {primitive.labware_id}")
            from_deck = 1

        # Parse destination
        to_deck = int(primitive.to_position.replace("position_", "").replace("deck_", ""))

        # Update deck mapping
        self.deck_mapping.add_mapping(primitive.labware_id, to_deck)

        return [MoveLabwareCommand(
            command_id=self._next_command_id(),
            from_position=BiomekPosition(from_deck),
            to_position=BiomekPosition(to_deck),
            comment=f"Move {primitive.labware_id} to position {to_deck}"
        )]

    def _translate_set_temperature(
        self,
        step: PlanStep,
        result: TranslationResult
    ) -> List[BiomekCommand]:
        """Translate set temperature primitive."""
        primitive = step.primitive
        if not isinstance(primitive, SetTemperature):
            result.warnings.append(f"Expected SetTemperature primitive, got {type(primitive).__name__}")
            return []

        # Get module position
        deck_pos = self.deck_mapping.get_position(primitive.device_id)
        if deck_pos is None:
            result.warnings.append(f"No deck mapping for {primitive.device_id}")
            deck_pos = 1

        return [SetTemperatureCommand(
            command_id=self._next_command_id(),
            module_position=BiomekPosition(deck_pos),
            temperature_c=primitive.temperature_c,
            wait=True,
            comment=f"Set {primitive.device_id} to {primitive.temperature_c}C"
        )]

    def _parse_well_to_position(
        self,
        deck_position: int,
        well_id: str
    ) -> BiomekPosition:
        """Parse well ID to BiomekPosition."""
        if not well_id:
            return BiomekPosition(deck_position)

        # Parse A1, B12, etc.
        row = well_id[0].upper()
        try:
            column = int(well_id[1:])
        except (ValueError, IndexError):
            column = 1

        return BiomekPosition(
            deck_position=deck_position,
            row=row,
            column=column
        )

    def _next_command_id(self) -> str:
        """Generate next command ID."""
        self._command_counter += 1
        return f"cmd_{self._command_counter}"


def translate_plan_to_biomek(
    plan: ExecutionPlan,
    deck_mapping: Optional[DeckMapping] = None,
    options: Optional[TranslationOptions] = None,
    program_name: str = "BPL_Program"
) -> TranslationResult:
    """Convenience function to translate a plan to Biomek."""
    translator = PlanToBiomekTranslator(deck_mapping, options)
    return translator.translate(plan, program_name)


def create_default_deck_mapping() -> DeckMapping:
    """Create a default deck mapping."""
    mapping = DeckMapping()
    # Common positions
    mapping.add_mapping("source_plate", 1)
    mapping.add_mapping("dest_plate", 2)
    mapping.add_mapping("reagent_reservoir", 3)
    mapping.add_mapping("tips_200", 9)
    mapping.add_mapping("tips_1000", 10)
    mapping.add_mapping("waste", 20)
    return mapping
