"""
BPL Biomek Code Generator - Generates executable Biomek code.

Provides:
- BiomekCodeGenerator for generating Biomek-compatible output
- Multiple output formats (Biomek script, XML, JSON)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, TextIO
from enum import Enum, auto
from datetime import datetime
import json
import xml.etree.ElementTree as ET
from xml.dom import minidom

from .biomek_ir import (
    BiomekProgram,
    BiomekCommand,
    BiomekCommandType,
    BiomekPosition,
    LiquidClass,
    AspirateCommand,
    DispenseCommand,
    MixCommand,
    GetTipsCommand,
    DropTipsCommand,
    MoveToCommand,
    MoveLabwareCommand,
    SetTemperatureCommand,
    DelayCommand,
    PauseCommand,
    CommentCommand,
    LoopStartCommand,
    LoopEndCommand,
)


class OutputFormat(Enum):
    """Output format for generated code."""
    BIOMEK_SCRIPT = auto()  # Native Biomek script format
    XML = auto()            # Biomek XML format
    JSON = auto()           # JSON for debugging/import
    PYTHON = auto()         # Python using Biomek API


@dataclass
class GenerationOptions:
    """Options for code generation."""
    format: OutputFormat = OutputFormat.BIOMEK_SCRIPT
    include_header: bool = True
    include_deck_layout: bool = True
    include_liquid_classes: bool = True
    indent: str = "  "
    line_ending: str = "\n"
    add_error_handling: bool = True
    add_logging: bool = False
    dry_run: bool = False
    generated_at: Optional[datetime] = None


@dataclass
class GenerationResult:
    """Result of code generation."""
    success: bool
    code: str = ""
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    line_count: int = 0
    command_count: int = 0


class BiomekCodeGenerator:
    """Generates executable Biomek code from BiomekProgram."""

    def __init__(self, options: Optional[GenerationOptions] = None):
        self.options = options or GenerationOptions()

    def _generated_at(self) -> Optional[str]:
        return (
            self.options.generated_at.isoformat()
            if self.options.generated_at is not None
            else None
        )

    def generate(self, program: BiomekProgram) -> GenerationResult:
        """Generate code for a Biomek program."""
        generators = {
            OutputFormat.BIOMEK_SCRIPT: self._generate_biomek_script,
            OutputFormat.XML: self._generate_xml,
            OutputFormat.JSON: self._generate_json,
            OutputFormat.PYTHON: self._generate_python,
        }

        generator = generators.get(self.options.format, self._generate_biomek_script)
        return generator(program)

    def _generate_biomek_script(self, program: BiomekProgram) -> GenerationResult:
        """Generate native Biomek script format."""
        result = GenerationResult(success=True)
        lines = []
        nl = self.options.line_ending

        # Header
        if self.options.include_header:
            lines.append(f"; Biomek Program: {program.name}")
            lines.append(f"; Version: {program.version}")
            generated_at = self._generated_at()
            if generated_at:
                lines.append(f"; Generated: {generated_at}")
            if program.description:
                lines.append(f"; Description: {program.description}")
            lines.append(";")
            lines.append("")

        # Deck layout
        if self.options.include_deck_layout and program.deck_layout:
            lines.append("; Deck Layout:")
            for pos, labware in sorted(program.deck_layout.items()):
                lines.append(f";   Position {pos}: {labware}")
            lines.append("")

        # Liquid classes
        if self.options.include_liquid_classes and program.liquid_classes:
            lines.append("; Liquid Classes:")
            for name, lc in program.liquid_classes.items():
                lines.append(f";   {name}: ASP={lc.aspirate_speed}, DISP={lc.dispense_speed}")
            lines.append("")

        # Commands
        lines.append("; === BEGIN PROGRAM ===")
        lines.append("")

        for cmd in program.commands:
            cmd_lines = self._format_command_biomek(cmd)
            lines.extend(cmd_lines)
            result.command_count += 1

        lines.append("")
        lines.append("; === END PROGRAM ===")

        result.code = nl.join(lines)
        result.line_count = len(lines)
        return result

    def _format_command_biomek(self, cmd: BiomekCommand) -> List[str]:
        """Format a single command for Biomek script."""
        lines = []
        indent = self.options.indent

        if cmd.comment:
            lines.append(f"; {cmd.comment}")

        if isinstance(cmd, CommentCommand):
            lines.append(f"; {cmd.text}")

        elif isinstance(cmd, AspirateCommand):
            well = cmd.source.well_id or "A1"
            lines.append(
                f"Aspirate({cmd.source.deck_position}, \"{well}\", "
                f"{cmd.volume_ul}, \"{cmd.liquid_class.name}\")"
            )

        elif isinstance(cmd, DispenseCommand):
            well = cmd.destination.well_id or "A1"
            lines.append(
                f"Dispense({cmd.destination.deck_position}, \"{well}\", "
                f"{cmd.volume_ul}, \"{cmd.liquid_class.name}\")"
            )

        elif isinstance(cmd, MixCommand):
            well = cmd.position.well_id or "A1"
            lines.append(
                f"Mix({cmd.position.deck_position}, \"{well}\", "
                f"{cmd.volume_ul}, {cmd.cycles})"
            )

        elif isinstance(cmd, GetTipsCommand):
            well = cmd.tip_rack_position.well_id or "A1"
            lines.append(
                f"GetTips({cmd.tip_rack_position.deck_position}, \"{well}\", "
                f"\"{cmd.tip_type.value}\")"
            )

        elif isinstance(cmd, DropTipsCommand):
            lines.append(f"DropTips({cmd.waste_position.deck_position if cmd.waste_position else 20})")

        elif isinstance(cmd, MoveToCommand):
            lines.append(f"MoveTo({cmd.position.deck_position}, {cmd.speed})")

        elif isinstance(cmd, MoveLabwareCommand):
            lines.append(
                f"MoveLabware({cmd.from_position.deck_position}, "
                f"{cmd.to_position.deck_position}, \"{cmd.labware_type}\")"
            )

        elif isinstance(cmd, SetTemperatureCommand):
            wait_str = "True" if cmd.wait else "False"
            lines.append(
                f"SetTemperature({cmd.module_position.deck_position}, "
                f"{cmd.temperature_c}, {wait_str})"
            )

        elif isinstance(cmd, DelayCommand):
            lines.append(f"Delay({cmd.duration_s})")

        elif isinstance(cmd, PauseCommand):
            lines.append(f'Pause("{cmd.message}")')

        elif isinstance(cmd, LoopStartCommand):
            lines.append(f"For({cmd.loop_id}, 1, {cmd.iterations})")

        elif isinstance(cmd, LoopEndCommand):
            lines.append(f"Next({cmd.loop_id})")

        else:
            lines.append(f"; Unknown command: {cmd.command_type.name}")

        return lines

    def _generate_xml(self, program: BiomekProgram) -> GenerationResult:
        """Generate Biomek XML format."""
        result = GenerationResult(success=True)

        # Create root element
        root = ET.Element("BiomekProgram")
        root.set("id", program.program_id)
        root.set("name", program.name)
        root.set("version", program.version)

        # Metadata
        meta = ET.SubElement(root, "Metadata")
        if program.description:
            desc = ET.SubElement(meta, "Description")
            desc.text = program.description
        generated_at = self._generated_at()
        if generated_at:
            gen_time = ET.SubElement(meta, "GeneratedAt")
            gen_time.text = generated_at

        # Deck layout
        if program.deck_layout:
            deck = ET.SubElement(root, "DeckLayout")
            for pos, labware in sorted(program.deck_layout.items()):
                position = ET.SubElement(deck, "Position")
                position.set("id", str(pos))
                position.set("labware", labware)

        # Liquid classes
        if program.liquid_classes:
            lc_section = ET.SubElement(root, "LiquidClasses")
            for name, lc in program.liquid_classes.items():
                lc_elem = ET.SubElement(lc_section, "LiquidClass")
                lc_elem.set("name", name)
                lc_elem.set("aspirateSpeed", str(lc.aspirate_speed))
                lc_elem.set("dispenseSpeed", str(lc.dispense_speed))

        # Commands
        commands = ET.SubElement(root, "Commands")
        for cmd in program.commands:
            cmd_elem = self._format_command_xml(cmd)
            commands.append(cmd_elem)
            result.command_count += 1

        # Format nicely
        xml_str = ET.tostring(root, encoding='unicode')
        dom = minidom.parseString(xml_str)
        result.code = dom.toprettyxml(indent=self.options.indent)
        result.line_count = result.code.count('\n')

        return result

    def _format_command_xml(self, cmd: BiomekCommand) -> ET.Element:
        """Format a command as XML element."""
        elem = ET.Element("Command")
        elem.set("id", cmd.command_id)
        elem.set("type", cmd.command_type.name)

        if cmd.comment:
            comment = ET.SubElement(elem, "Comment")
            comment.text = cmd.comment

        if isinstance(cmd, AspirateCommand):
            elem.set("position", str(cmd.source.deck_position))
            elem.set("well", cmd.source.well_id or "A1")
            elem.set("volume", str(cmd.volume_ul))
            elem.set("liquidClass", cmd.liquid_class.name)

        elif isinstance(cmd, DispenseCommand):
            elem.set("position", str(cmd.destination.deck_position))
            elem.set("well", cmd.destination.well_id or "A1")
            elem.set("volume", str(cmd.volume_ul))
            elem.set("liquidClass", cmd.liquid_class.name)

        elif isinstance(cmd, MixCommand):
            elem.set("position", str(cmd.position.deck_position))
            elem.set("well", cmd.position.well_id or "A1")
            elem.set("volume", str(cmd.volume_ul))
            elem.set("cycles", str(cmd.cycles))

        elif isinstance(cmd, GetTipsCommand):
            elem.set("position", str(cmd.tip_rack_position.deck_position))
            elem.set("tipType", cmd.tip_type.value)

        elif isinstance(cmd, DropTipsCommand):
            elem.set("wastePosition", str(cmd.waste_position.deck_position if cmd.waste_position else 20))

        elif isinstance(cmd, DelayCommand):
            elem.set("duration", str(cmd.duration_s))

        elif isinstance(cmd, SetTemperatureCommand):
            elem.set("position", str(cmd.module_position.deck_position))
            elem.set("temperature", str(cmd.temperature_c))
            elem.set("wait", str(cmd.wait).lower())

        elif isinstance(cmd, CommentCommand):
            elem.set("text", cmd.text)

        return elem

    def _generate_json(self, program: BiomekProgram) -> GenerationResult:
        """Generate JSON format for debugging/import."""
        result = GenerationResult(success=True)

        data = {
            "program_id": program.program_id,
            "name": program.name,
            "version": program.version,
            "description": program.description,
            "deck_layout": {
                str(pos): labware
                for pos, labware in program.deck_layout.items()
            },
            "liquid_classes": {
                name: {
                    "aspirate_speed": lc.aspirate_speed,
                    "dispense_speed": lc.dispense_speed,
                    "prewet_volume": lc.prewet_volume,
                    "blowout_volume": lc.blowout_volume,
                }
                for name, lc in program.liquid_classes.items()
            },
            "commands": []
        }

        for cmd in program.commands:
            cmd_data = self._format_command_json(cmd)
            data["commands"].append(cmd_data)
            result.command_count += 1

        result.code = json.dumps(data, indent=2)
        result.line_count = result.code.count('\n')

        return result

    def _format_command_json(self, cmd: BiomekCommand) -> Dict[str, Any]:
        """Format a command as JSON dict."""
        data: Dict[str, Any] = {
            "id": cmd.command_id,
            "type": cmd.command_type.name,
        }

        if cmd.comment:
            data["comment"] = cmd.comment

        if isinstance(cmd, AspirateCommand):
            data["position"] = cmd.source.deck_position
            data["well"] = cmd.source.well_id
            data["volume_ul"] = cmd.volume_ul
            data["liquid_class"] = cmd.liquid_class.name
            data["channels"] = cmd.channels

        elif isinstance(cmd, DispenseCommand):
            data["position"] = cmd.destination.deck_position
            data["well"] = cmd.destination.well_id
            data["volume_ul"] = cmd.volume_ul
            data["liquid_class"] = cmd.liquid_class.name

        elif isinstance(cmd, MixCommand):
            data["position"] = cmd.position.deck_position
            data["well"] = cmd.position.well_id
            data["volume_ul"] = cmd.volume_ul
            data["cycles"] = cmd.cycles

        elif isinstance(cmd, GetTipsCommand):
            data["position"] = cmd.tip_rack_position.deck_position
            data["tip_type"] = cmd.tip_type.value

        elif isinstance(cmd, DropTipsCommand):
            data["waste_position"] = cmd.waste_position.deck_position if cmd.waste_position else 20

        elif isinstance(cmd, DelayCommand):
            data["duration_s"] = cmd.duration_s

        elif isinstance(cmd, SetTemperatureCommand):
            data["position"] = cmd.module_position.deck_position
            data["temperature_c"] = cmd.temperature_c
            data["wait"] = cmd.wait

        elif isinstance(cmd, CommentCommand):
            data["text"] = cmd.text

        return data

    def _generate_python(self, program: BiomekProgram) -> GenerationResult:
        """Generate Python code using hypothetical Biomek API."""
        result = GenerationResult(success=True)
        lines = []
        nl = self.options.line_ending
        indent = self.options.indent

        # Header
        lines.append('"""')
        lines.append(f"Biomek Program: {program.name}")
        generated_at = self._generated_at()
        if generated_at:
            lines.append(f"Generated: {generated_at}")
        lines.append('"""')
        lines.append("")
        lines.append("from biomek_api import BiomekController, LiquidClass, TipType")
        lines.append("")
        lines.append("")
        lines.append(f"def run_{program.program_id.replace('-', '_')}(biomek: BiomekController):")
        lines.append(f'{indent}"""Execute the {program.name} protocol."""')
        lines.append("")

        # Liquid class setup
        if program.liquid_classes:
            lines.append(f"{indent}# Setup liquid classes")
            for name, lc in program.liquid_classes.items():
                var_name = name.lower().replace(" ", "_")
                lines.append(
                    f'{indent}{var_name} = LiquidClass("{name}", '
                    f'aspirate_speed={lc.aspirate_speed}, '
                    f'dispense_speed={lc.dispense_speed})'
                )
            lines.append("")

        # Commands
        lines.append(f"{indent}# Execute commands")
        for cmd in program.commands:
            cmd_lines = self._format_command_python(cmd, indent)
            lines.extend(cmd_lines)
            result.command_count += 1

        lines.append("")
        lines.append(f"{indent}print('Protocol complete!')")
        lines.append("")
        lines.append("")
        lines.append('if __name__ == "__main__":')
        lines.append(f"{indent}biomek = BiomekController()")
        lines.append(f"{indent}biomek.connect()")
        lines.append(f"{indent}try:")
        lines.append(f"{indent}{indent}run_{program.program_id.replace('-', '_')}(biomek)")
        lines.append(f"{indent}finally:")
        lines.append(f"{indent}{indent}biomek.disconnect()")

        result.code = nl.join(lines)
        result.line_count = len(lines)
        return result

    def _format_command_python(self, cmd: BiomekCommand, indent: str) -> List[str]:
        """Format a command as Python code."""
        lines = []

        if cmd.comment:
            lines.append(f"{indent}# {cmd.comment}")

        if isinstance(cmd, CommentCommand):
            lines.append(f"{indent}# {cmd.text}")

        elif isinstance(cmd, AspirateCommand):
            well = cmd.source.well_id or "A1"
            lines.append(
                f'{indent}biomek.aspirate({cmd.source.deck_position}, "{well}", '
                f'{cmd.volume_ul}, liquid_class="{cmd.liquid_class.name}")'
            )

        elif isinstance(cmd, DispenseCommand):
            well = cmd.destination.well_id or "A1"
            lines.append(
                f'{indent}biomek.dispense({cmd.destination.deck_position}, "{well}", '
                f'{cmd.volume_ul}, liquid_class="{cmd.liquid_class.name}")'
            )

        elif isinstance(cmd, MixCommand):
            well = cmd.position.well_id or "A1"
            lines.append(
                f'{indent}biomek.mix({cmd.position.deck_position}, "{well}", '
                f'{cmd.volume_ul}, cycles={cmd.cycles})'
            )

        elif isinstance(cmd, GetTipsCommand):
            lines.append(
                f'{indent}biomek.get_tips({cmd.tip_rack_position.deck_position}, '
                f'tip_type=TipType.{cmd.tip_type.name})'
            )

        elif isinstance(cmd, DropTipsCommand):
            pos = cmd.waste_position.deck_position if cmd.waste_position else 20
            lines.append(f"{indent}biomek.drop_tips({pos})")

        elif isinstance(cmd, DelayCommand):
            lines.append(f"{indent}biomek.delay({cmd.duration_s})")

        elif isinstance(cmd, PauseCommand):
            lines.append(f'{indent}biomek.pause("{cmd.message}")')

        elif isinstance(cmd, SetTemperatureCommand):
            lines.append(
                f'{indent}biomek.set_temperature({cmd.module_position.deck_position}, '
                f'{cmd.temperature_c}, wait={cmd.wait})'
            )

        elif isinstance(cmd, MoveLabwareCommand):
            lines.append(
                f'{indent}biomek.move_labware({cmd.from_position.deck_position}, '
                f'{cmd.to_position.deck_position}, "{cmd.labware_type}")'
            )

        else:
            lines.append(f"{indent}# Unsupported: {cmd.command_type.name}")

        return lines


def generate_biomek_code(
    program: BiomekProgram,
    format: OutputFormat = OutputFormat.BIOMEK_SCRIPT,
    options: Optional[GenerationOptions] = None
) -> GenerationResult:
    """Convenience function to generate Biomek code."""
    if options is None:
        options = GenerationOptions(format=format)
    else:
        options.format = format

    generator = BiomekCodeGenerator(options)
    return generator.generate(program)


def write_biomek_code(
    program: BiomekProgram,
    output_file: TextIO,
    format: OutputFormat = OutputFormat.BIOMEK_SCRIPT
) -> GenerationResult:
    """Generate and write Biomek code to a file."""
    result = generate_biomek_code(program, format)
    if result.success:
        output_file.write(result.code)
    return result
