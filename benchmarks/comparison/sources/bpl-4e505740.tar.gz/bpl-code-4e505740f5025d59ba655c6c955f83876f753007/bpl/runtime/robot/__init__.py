"""
BPL Robot Runtime - Automation execution.

Provides:
- Biomek integration for liquid handling robots
- Translation from execution plans to robot commands
- Hybrid human/robot execution support
"""

from .biomek import (
    # Biomek IR
    BiomekCommandType,
    BiomekPosition,
    LiquidClass,
    BiomekCommand,
    AspirateCommand,
    DispenseCommand,
    MixCommand,
    GetTipsCommand,
    DropTipsCommand,
    BiomekProgram,
    # Translator
    DeckMapping,
    TranslationOptions,
    TranslationResult,
    PlanToBiomekTranslator,
    translate_plan_to_biomek,
    create_default_deck_mapping,
    # Code Generator
    OutputFormat,
    GenerationResult,
    BiomekCodeGenerator,
    generate_biomek_code,
    # Hybrid
    ExecutionTarget,
    HybridExecutionPlan,
    HybridExecutor,
    create_hybrid_plan,
)

__all__ = [
    # Biomek IR
    "BiomekCommandType",
    "BiomekPosition",
    "LiquidClass",
    "BiomekCommand",
    "AspirateCommand",
    "DispenseCommand",
    "MixCommand",
    "GetTipsCommand",
    "DropTipsCommand",
    "BiomekProgram",
    # Translator
    "DeckMapping",
    "TranslationOptions",
    "TranslationResult",
    "PlanToBiomekTranslator",
    "translate_plan_to_biomek",
    "create_default_deck_mapping",
    # Code Generator
    "OutputFormat",
    "GenerationResult",
    "BiomekCodeGenerator",
    "generate_biomek_code",
    # Hybrid
    "ExecutionTarget",
    "HybridExecutionPlan",
    "HybridExecutor",
    "create_hybrid_plan",
]
