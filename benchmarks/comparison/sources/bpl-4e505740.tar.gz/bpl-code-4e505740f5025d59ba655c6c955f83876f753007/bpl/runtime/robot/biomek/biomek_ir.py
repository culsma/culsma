"""
BPL Biomek IR - Biomek-specific intermediate representation.

Provides:
- BiomekCommand base class and specific commands
- BiomekProgram container
- Biomek-specific parameters and settings
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum, auto
from abc import ABC, abstractmethod


class BiomekCommandType(Enum):
    """Types of Biomek commands."""
    # Liquid handling
    ASPIRATE = auto()
    DISPENSE = auto()
    MIX = auto()
    BLOWOUT = auto()

    # Tip management
    GET_TIPS = auto()
    DROP_TIPS = auto()
    EJECT_TIPS = auto()

    # Movement
    MOVE_TO = auto()
    MOVE_LABWARE = auto()

    # Plate operations
    SEAL_PLATE = auto()
    UNSEAL_PLATE = auto()

    # Temperature control
    SET_TEMPERATURE = auto()
    WAIT_FOR_TEMPERATURE = auto()

    # Timing
    DELAY = auto()
    PAUSE = auto()

    # Program control
    LOOP_START = auto()
    LOOP_END = auto()
    CONDITIONAL = auto()
    COMMENT = auto()


class AspirateMode(Enum):
    """Aspiration mode."""
    STANDARD = auto()
    REVERSE = auto()
    MULTI_DISPENSE = auto()


class DispenseMode(Enum):
    """Dispense mode."""
    STANDARD = auto()
    BLOWOUT = auto()
    TOUCH_OFF = auto()
    AIR_GAP = auto()


class TipType(Enum):
    """Tip types available."""
    TIPS_50 = "50uL"
    TIPS_200 = "200uL"
    TIPS_1000 = "1000uL"
    TIPS_50_FILTERED = "50uL Filtered"
    TIPS_200_FILTERED = "200uL Filtered"
    TIPS_1000_FILTERED = "1000uL Filtered"


@dataclass
class BiomekPosition:
    """A position on the Biomek deck."""
    deck_position: int  # 1-20 typically
    row: Optional[str] = None  # A-H for 96-well
    column: Optional[int] = None  # 1-12 for 96-well
    offset_x: float = 0.0  # mm offset
    offset_y: float = 0.0
    offset_z: float = 0.0

    @property
    def well_id(self) -> Optional[str]:
        """Get well ID if row and column are specified."""
        if self.row and self.column:
            return f"{self.row}{self.column}"
        return None

    def __str__(self) -> str:
        well = self.well_id
        if well:
            return f"P{self.deck_position}:{well}"
        return f"P{self.deck_position}"


@dataclass
class LiquidClass:
    """Biomek liquid class definition."""
    name: str
    aspirate_speed: float = 50.0  # uL/s
    dispense_speed: float = 50.0
    prewet_volume: float = 0.0
    postmix_volume: float = 0.0
    postmix_cycles: int = 0
    blowout_volume: float = 0.0
    air_gap: float = 0.0
    delay_aspirate_ms: int = 0
    delay_dispense_ms: int = 0
    touch_off: bool = False
    touch_off_offset: float = 0.0

    @classmethod
    def default(cls) -> 'LiquidClass':
        """Get default liquid class."""
        return cls(name="Default")

    @classmethod
    def for_aqueous(cls) -> 'LiquidClass':
        """Get liquid class for aqueous solutions."""
        return cls(
            name="Aqueous",
            aspirate_speed=100.0,
            dispense_speed=100.0,
            touch_off=True
        )

    @classmethod
    def for_viscous(cls) -> 'LiquidClass':
        """Get liquid class for viscous solutions."""
        return cls(
            name="Viscous",
            aspirate_speed=20.0,
            dispense_speed=20.0,
            delay_aspirate_ms=500,
            delay_dispense_ms=500,
            blowout_volume=5.0
        )

    @classmethod
    def for_volatile(cls) -> 'LiquidClass':
        """Get liquid class for volatile solutions."""
        return cls(
            name="Volatile",
            aspirate_speed=30.0,
            dispense_speed=50.0,
            air_gap=5.0,
            blowout_volume=0.0
        )


@dataclass
class BiomekCommand(ABC):
    """Base class for Biomek commands."""
    command_type: BiomekCommandType
    command_id: str = ""
    comment: Optional[str] = None

    @abstractmethod
    def to_biomek_string(self) -> str:
        """Convert to Biomek command string."""
        pass


@dataclass
class AspirateCommand(BiomekCommand):
    """Aspirate liquid command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.ASPIRATE, init=False)
    source: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    volume_ul: float = 0.0
    liquid_class: LiquidClass = field(default_factory=LiquidClass.default)
    aspirate_mode: AspirateMode = AspirateMode.STANDARD
    channels: List[int] = field(default_factory=lambda: [1])  # 1-8 for 8-channel

    def to_biomek_string(self) -> str:
        channels_str = ",".join(str(c) for c in self.channels)
        return (
            f"ASPIRATE {self.source} VOL={self.volume_ul} "
            f"LC={self.liquid_class.name} CH=[{channels_str}]"
        )


@dataclass
class DispenseCommand(BiomekCommand):
    """Dispense liquid command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.DISPENSE, init=False)
    destination: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    volume_ul: float = 0.0
    liquid_class: LiquidClass = field(default_factory=LiquidClass.default)
    dispense_mode: DispenseMode = DispenseMode.STANDARD
    channels: List[int] = field(default_factory=lambda: [1])

    def to_biomek_string(self) -> str:
        channels_str = ",".join(str(c) for c in self.channels)
        return (
            f"DISPENSE {self.destination} VOL={self.volume_ul} "
            f"LC={self.liquid_class.name} CH=[{channels_str}]"
        )


@dataclass
class MixCommand(BiomekCommand):
    """Mix liquid command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.MIX, init=False)
    position: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    volume_ul: float = 0.0
    cycles: int = 3
    aspirate_speed: float = 50.0
    dispense_speed: float = 50.0
    channels: List[int] = field(default_factory=lambda: [1])

    def to_biomek_string(self) -> str:
        return (
            f"MIX {self.position} VOL={self.volume_ul} CYCLES={self.cycles} "
            f"ASP_SPEED={self.aspirate_speed} DISP_SPEED={self.dispense_speed}"
        )


@dataclass
class GetTipsCommand(BiomekCommand):
    """Get tips command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.GET_TIPS, init=False)
    tip_rack_position: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    tip_type: TipType = TipType.TIPS_200
    channels: List[int] = field(default_factory=lambda: [1])

    def to_biomek_string(self) -> str:
        channels_str = ",".join(str(c) for c in self.channels)
        return f"GET_TIPS {self.tip_rack_position} TYPE={self.tip_type.value} CH=[{channels_str}]"


@dataclass
class DropTipsCommand(BiomekCommand):
    """Drop tips command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.DROP_TIPS, init=False)
    waste_position: Optional[BiomekPosition] = None
    channels: List[int] = field(default_factory=lambda: [1])

    def to_biomek_string(self) -> str:
        pos = self.waste_position or BiomekPosition(20)  # Default waste position
        return f"DROP_TIPS {pos}"


@dataclass
class MoveToCommand(BiomekCommand):
    """Move to position command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.MOVE_TO, init=False)
    position: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    speed: float = 100.0  # percent of max speed

    def to_biomek_string(self) -> str:
        return f"MOVE_TO {self.position} SPEED={self.speed}%"


@dataclass
class MoveLabwareCommand(BiomekCommand):
    """Move labware command (for gripper)."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.MOVE_LABWARE, init=False)
    from_position: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    to_position: BiomekPosition = field(default_factory=lambda: BiomekPosition(2))
    labware_type: str = "96_well_plate"
    grip_force: float = 50.0  # percent

    def to_biomek_string(self) -> str:
        return f"MOVE_LABWARE FROM={self.from_position} TO={self.to_position} TYPE={self.labware_type}"


@dataclass
class SetTemperatureCommand(BiomekCommand):
    """Set temperature command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.SET_TEMPERATURE, init=False)
    module_position: BiomekPosition = field(default_factory=lambda: BiomekPosition(1))
    temperature_c: float = 25.0
    wait: bool = True

    def to_biomek_string(self) -> str:
        wait_str = "WAIT=TRUE" if self.wait else "WAIT=FALSE"
        return f"SET_TEMP {self.module_position} TEMP={self.temperature_c}C {wait_str}"


@dataclass
class DelayCommand(BiomekCommand):
    """Delay command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.DELAY, init=False)
    duration_s: float = 0.0

    def to_biomek_string(self) -> str:
        return f"DELAY {self.duration_s}s"


@dataclass
class PauseCommand(BiomekCommand):
    """Pause command (user interaction required)."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.PAUSE, init=False)
    message: str = ""

    def to_biomek_string(self) -> str:
        return f'PAUSE "{self.message}"'


@dataclass
class CommentCommand(BiomekCommand):
    """Comment command."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.COMMENT, init=False)
    text: str = ""

    def to_biomek_string(self) -> str:
        return f"// {self.text}"


@dataclass
class LoopStartCommand(BiomekCommand):
    """Start of loop."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.LOOP_START, init=False)
    loop_id: str = ""
    iterations: int = 1

    def to_biomek_string(self) -> str:
        return f"LOOP_START ID={self.loop_id} COUNT={self.iterations}"


@dataclass
class LoopEndCommand(BiomekCommand):
    """End of loop."""
    command_type: BiomekCommandType = field(default=BiomekCommandType.LOOP_END, init=False)
    loop_id: str = ""

    def to_biomek_string(self) -> str:
        return f"LOOP_END ID={self.loop_id}"


@dataclass
class BiomekProgram:
    """A complete Biomek program."""
    program_id: str
    name: str
    version: str = "1.0"

    # Commands
    commands: List[BiomekCommand] = field(default_factory=list)

    # Deck configuration
    deck_layout: Dict[int, str] = field(default_factory=dict)  # position -> labware_type

    # Liquid classes
    liquid_classes: Dict[str, LiquidClass] = field(default_factory=dict)

    # Metadata
    author: Optional[str] = None
    description: Optional[str] = None
    created_at: Optional[str] = None

    def add_command(self, command: BiomekCommand) -> None:
        """Add a command to the program."""
        if not command.command_id:
            command.command_id = f"cmd_{len(self.commands) + 1}"
        self.commands.append(command)

    def add_liquid_class(self, liquid_class: LiquidClass) -> None:
        """Add a liquid class definition."""
        self.liquid_classes[liquid_class.name] = liquid_class

    def set_deck_position(self, position: int, labware_type: str) -> None:
        """Set labware at a deck position."""
        self.deck_layout[position] = labware_type

    def to_biomek_string(self) -> str:
        """Convert entire program to Biomek string format."""
        lines = []

        # Header
        lines.append(f"// Program: {self.name}")
        lines.append(f"// Version: {self.version}")
        if self.description:
            lines.append(f"// Description: {self.description}")
        lines.append("")

        # Deck layout
        lines.append("// Deck Layout:")
        for pos, labware in sorted(self.deck_layout.items()):
            lines.append(f"//   P{pos}: {labware}")
        lines.append("")

        # Commands
        lines.append("// Commands:")
        for cmd in self.commands:
            if cmd.comment:
                lines.append(f"// {cmd.comment}")
            lines.append(cmd.to_biomek_string())

        return "\n".join(lines)

    @property
    def command_count(self) -> int:
        """Get total command count."""
        return len(self.commands)

    def get_commands_by_type(self, cmd_type: BiomekCommandType) -> List[BiomekCommand]:
        """Get all commands of a specific type."""
        return [c for c in self.commands if c.command_type == cmd_type]

    def summary(self) -> Dict[str, Any]:
        """Get program summary."""
        type_counts = {}
        for cmd in self.commands:
            type_name = cmd.command_type.name
            type_counts[type_name] = type_counts.get(type_name, 0) + 1

        return {
            "program_id": self.program_id,
            "name": self.name,
            "total_commands": self.command_count,
            "command_types": type_counts,
            "deck_positions_used": len(self.deck_layout),
            "liquid_classes": list(self.liquid_classes.keys()),
        }
