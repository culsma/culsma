"""
BPL Biomek Integration - Biomek i7 API wrapper.

Provides:
- BiomekProgram for program representation
- PlanToBiomekTranslator for plan translation
- BiomekCodeGenerator for code generation
- HybridExecutor for mixed human/robot execution
"""

from .biomek_ir import (
    BiomekCommandType,
    AspirateMode,
    DispenseMode,
    TipType,
    BiomekPosition,
    LiquidClass,
    BiomekCommand,
    AspirateCommand,
    DispenseCommand,
    MixCommand,
    GetTipsCommand,
    DropTipsCommand,
    MoveToCommand,
    MoveLabwareCommand,
    SetTemperatureCommand,
    DelayCommand,
    PauseCommand,
    CommentCommand,
    LoopStartCommand,
    LoopEndCommand,
    BiomekProgram,
)

from .biomek_translator import (
    DeckMapping,
    TranslationOptions,
    TranslationResult,
    PlanToBiomekTranslator,
    translate_plan_to_biomek,
    create_default_deck_mapping,
)

from .biomek_codegen import (
    OutputFormat,
    GenerationOptions,
    GenerationResult,
    BiomekCodeGenerator,
    generate_biomek_code,
    write_biomek_code,
)

from .hybrid import (
    ExecutionTarget,
    HandoffType,
    HandoffPoint,
    StepClassification,
    HybridExecutionPlan,
    StepClassifier,
    HybridExecutor,
    HybridExecutionState,
    HybridExecutionManager,
    create_hybrid_plan,
)

__all__ = [
    # Biomek IR
    "BiomekCommandType",
    "AspirateMode",
    "DispenseMode",
    "TipType",
    "BiomekPosition",
    "LiquidClass",
    "BiomekCommand",
    "AspirateCommand",
    "DispenseCommand",
    "MixCommand",
    "GetTipsCommand",
    "DropTipsCommand",
    "MoveToCommand",
    "MoveLabwareCommand",
    "SetTemperatureCommand",
    "DelayCommand",
    "PauseCommand",
    "CommentCommand",
    "LoopStartCommand",
    "LoopEndCommand",
    "BiomekProgram",
    # Translator
    "DeckMapping",
    "TranslationOptions",
    "TranslationResult",
    "PlanToBiomekTranslator",
    "translate_plan_to_biomek",
    "create_default_deck_mapping",
    # Code Generator
    "OutputFormat",
    "GenerationOptions",
    "GenerationResult",
    "BiomekCodeGenerator",
    "generate_biomek_code",
    "write_biomek_code",
    # Hybrid Execution
    "ExecutionTarget",
    "HandoffType",
    "HandoffPoint",
    "StepClassification",
    "HybridExecutionPlan",
    "StepClassifier",
    "HybridExecutor",
    "HybridExecutionState",
    "HybridExecutionManager",
    "create_hybrid_plan",
]
