"""
BPL Parser Error Handling.

This module provides error types and formatting for parser errors.
"""

from dataclasses import dataclass
from typing import Optional, List
from bpl.ast.base import SourceSpan


@dataclass
class BPLSyntaxError(Exception):
    """
    A syntax error in BPL source code.

    Provides formatted error messages with source location.
    """
    message: str
    code: str = "SYNTAX_PARSE_ERROR"
    span: Optional[SourceSpan] = None
    source_line: Optional[str] = None
    suggestions: Optional[List[str]] = None

    def __post_init__(self):
        if self.suggestions is None:
            self.suggestions = []
        super().__init__(self.format())

    def format(self) -> str:
        """Format the error message with location and context."""
        lines = []

        # Error header with location
        if self.span:
            location = f"{self.span.file}:{self.span.start_line}:{self.span.start_col}"
            lines.append(f"error: {self.message}")
            lines.append(f"  --> {location}")
        else:
            lines.append(f"error: {self.message}")

        # Source context
        if self.source_line and self.span:
            lines.append("   |")
            lines.append(f" {self.span.start_line:>3} | {self.source_line}")
            # Underline the error position
            padding = " " * (self.span.start_col + 5)
            length = max(1, self.span.end_col - self.span.start_col) if self.span.end_col else 1
            lines.append(f"   | {padding}{'^' * length}")

        # Suggestions
        for suggestion in self.suggestions or []:
            lines.append(f"   = help: {suggestion}")

        return "\n".join(lines)


@dataclass
class BPLParseError(Exception):
    """
    A parse error that may contain multiple syntax errors.
    """
    errors: List[BPLSyntaxError]

    def __post_init__(self):
        msg = "\n\n".join(e.format() for e in self.errors)
        super().__init__(msg)

    @property
    def count(self) -> int:
        """Return the number of errors."""
        return len(self.errors)


def format_lark_error(lark_error, source: Optional[str] = None, filename: str = "<input>") -> BPLSyntaxError:
    """
    Convert a Lark exception to a BPLSyntaxError.

    Args:
        lark_error: The Lark exception (UnexpectedToken, UnexpectedCharacters, etc.)
        source: The source code being parsed
        filename: The filename for error reporting

    Returns:
        A formatted BPLSyntaxError
    """
    from lark.exceptions import UnexpectedToken, UnexpectedCharacters, UnexpectedEOF

    message = str(lark_error)
    span = None
    source_line = None
    suggestions = []

    if isinstance(lark_error, UnexpectedToken):
        token = lark_error.token
        span = SourceSpan(
            file=filename,
            start_line=token.line,
            start_col=token.column,
            end_line=token.end_line or token.line,
            end_col=token.end_column or token.column,
        )
        message = f"Unexpected token '{token.value}' (type: {token.type})"

        # Add expected tokens as suggestions
        if lark_error.expected:
            expected = list(lark_error.expected)[:5]  # Limit to 5 suggestions
            if len(expected) == 1:
                suggestions.append(f"expected {expected[0]}")
            else:
                suggestions.append(f"expected one of: {', '.join(expected)}")

    elif isinstance(lark_error, UnexpectedCharacters):
        span = SourceSpan(
            file=filename,
            start_line=lark_error.line,
            start_col=lark_error.column,
            end_line=lark_error.line,
            end_col=lark_error.column + 1,
        )
        message = f"Unexpected character '{lark_error.char}'"

        if lark_error.allowed:
            suggestions.append(f"expected one of: {', '.join(list(lark_error.allowed)[:5])}")

    elif isinstance(lark_error, UnexpectedEOF):
        message = "Unexpected end of file"
        if lark_error.expected:
            expected = list(lark_error.expected)[:5]
            suggestions.append(f"expected one of: {', '.join(expected)}")

    # Get source line for context
    if source and span:
        lines = source.splitlines()
        if 0 < span.start_line <= len(lines):
            source_line = lines[span.start_line - 1]

    code = "SYNTAX_PARSE_ERROR"
    if isinstance(lark_error, UnexpectedToken):
        code = "SYNTAX_UNEXPECTED_TOKEN"
    elif isinstance(lark_error, UnexpectedCharacters):
        code = "SYNTAX_UNEXPECTED_CHARACTER"
    elif isinstance(lark_error, UnexpectedEOF):
        code = "SYNTAX_UNEXPECTED_EOF"

    return BPLSyntaxError(
        code=code,
        message=message,
        span=span,
        source_line=source_line,
        suggestions=suggestions,
    )
