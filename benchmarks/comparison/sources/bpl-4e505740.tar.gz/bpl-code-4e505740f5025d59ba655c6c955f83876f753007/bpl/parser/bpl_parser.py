"""
BPL Parser - High-level parsing API.

This module provides the main BPLParser class for parsing BPL source code.
"""

from pathlib import Path
from typing import Union, Optional
from lark import Lark
from lark.exceptions import LarkError

from bpl.ast.program import Program
from bpl.transformer.bpl_transformer import BPLTransformer, KeywordAsIdentifierError
from bpl.parser.errors import BPLSyntaxError, format_lark_error


# Path to the grammar file
GRAMMAR_PATH = Path(__file__).parent.parent / "grammar" / "bpl.lark"


class BPLParser:
    """
    Parser for BPL source code.

    Provides methods to parse BPL code from strings or files into AST.

    Example:
        parser = BPLParser()
        ast = parser.parse('''
            protocol Hello {
                let x = 10 mL
            }
        ''')
    """

    def __init__(self, grammar_path: Optional[Path] = None):
        """
        Initialize the parser.

        Args:
            grammar_path: Optional path to custom grammar file.
                         Defaults to the bundled grammar.
        """
        self._grammar_path = grammar_path or GRAMMAR_PATH
        self._lark: Optional[Lark] = None

    @property
    def lark(self) -> Lark:
        """Lazy-load and cache the Lark parser."""
        if self._lark is None:
            grammar_text = self._grammar_path.read_text(encoding='utf-8')
            self._lark = Lark(
                grammar_text,
                start='start',
                parser='earley',
                propagate_positions=True,
            )
        return self._lark

    def parse(self, source: str, filename: str = "<input>") -> Program:
        """
        Parse BPL source code into an AST.

        Args:
            source: The BPL source code to parse.
            filename: Optional filename for error messages.

        Returns:
            The parsed Program AST.

        Raises:
            BPLSyntaxError: If the source contains syntax errors.
        """
        try:
            tree = self.lark.parse(source)
            transformer = BPLTransformer(filename=filename)
            return transformer.transform(tree)
        except LarkError as e:
            raise format_lark_error(e, source=source, filename=filename)
        except KeywordAsIdentifierError as e:
            raise BPLSyntaxError(message=str(e))

    def parse_file(self, path: Union[str, Path]) -> Program:
        """
        Parse a BPL source file into an AST.

        Args:
            path: Path to the BPL file.

        Returns:
            The parsed Program AST.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            BPLSyntaxError: If the file contains syntax errors.
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"BPL file not found: {path}")

        source = path.read_text(encoding='utf-8')
        return self.parse(source, filename=str(path))

    def check_syntax(self, source: str, filename: str = "<input>") -> Optional[BPLSyntaxError]:
        """
        Check source code for syntax errors without building full AST.

        This is faster than parse() when you only want to validate syntax.

        Args:
            source: The BPL source code to check.
            filename: Optional filename for error messages.

        Returns:
            None if valid, or the BPLSyntaxError if invalid.
        """
        try:
            self.lark.parse(source)
            return None
        except LarkError as e:
            return format_lark_error(e, source=source, filename=filename)


# Module-level convenience functions
_default_parser: Optional[BPLParser] = None


def get_parser() -> BPLParser:
    """Get the default parser instance (lazy singleton)."""
    global _default_parser
    if _default_parser is None:
        _default_parser = BPLParser()
    return _default_parser


def parse(source: str, filename: str = "<input>") -> Program:
    """
    Parse BPL source code into an AST.

    This is a convenience function that uses the default parser.

    Args:
        source: The BPL source code to parse.
        filename: Optional filename for error messages.

    Returns:
        The parsed Program AST.

    Raises:
        BPLSyntaxError: If the source contains syntax errors.
    """
    return get_parser().parse(source, filename)


def parse_file(path: Union[str, Path]) -> Program:
    """
    Parse a BPL source file into an AST.

    This is a convenience function that uses the default parser.

    Args:
        path: Path to the BPL file.

    Returns:
        The parsed Program AST.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        BPLSyntaxError: If the file contains syntax errors.
    """
    return get_parser().parse_file(path)


def check_syntax(source: str, filename: str = "<input>") -> Optional[BPLSyntaxError]:
    """
    Check source code for syntax errors.

    This is a convenience function that uses the default parser.

    Args:
        source: The BPL source code to check.
        filename: Optional filename for error messages.

    Returns:
        None if valid, or the BPLSyntaxError if invalid.
    """
    return get_parser().check_syntax(source, filename)
