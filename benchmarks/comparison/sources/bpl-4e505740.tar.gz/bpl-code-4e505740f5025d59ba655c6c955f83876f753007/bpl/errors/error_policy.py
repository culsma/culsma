"""
BPL Error Policy - Error handling strategies and policy matching.

Policies:
- Stop: Halt execution immediately
- Retry: Retry the failed operation
- Skip: Skip the failed step
- AlertAndContinue: Alert operator and continue
- Fallback: Use fallback behavior
- Escalate: Escalate to higher authority
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any, Union
from enum import Enum, auto

from .error_types import (
    BPLError,
    ErrorCategory,
    ErrorSeverity,
    PipetteErrorType,
    PipetteError,
    MotionErrorType,
    MotionError,
    SensorErrorType,
    SensorError,
    HumanErrorType,
    HumanError,
)


class ErrorAction(Enum):
    """Actions that can be taken in response to errors."""
    STOP = auto()              # Halt execution immediately
    RETRY = auto()             # Retry the operation
    SKIP = auto()              # Skip the failed step
    ALERT_AND_CONTINUE = auto() # Alert and continue
    FALLBACK = auto()          # Use fallback behavior
    ESCALATE = auto()          # Escalate to authority
    IGNORE = auto()            # Ignore the error (dangerous)


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_attempts: int = 3
    delay_s: float = 1.0
    backoff_multiplier: float = 2.0
    max_delay_s: float = 30.0


@dataclass
class FallbackConfig:
    """Configuration for fallback behavior."""
    fallback_action: str
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EscalationConfig:
    """Configuration for error escalation."""
    escalate_to: str  # Role or user ID
    timeout_s: float = 300.0
    default_action_on_timeout: ErrorAction = ErrorAction.STOP


@dataclass
class ErrorPolicy:
    """Policy for handling a specific error type."""
    action: ErrorAction
    retry_config: Optional[RetryConfig] = None
    fallback_config: Optional[FallbackConfig] = None
    escalation_config: Optional[EscalationConfig] = None
    message_template: Optional[str] = None
    log_level: str = "ERROR"

    @staticmethod
    def stop(message: Optional[str] = None) -> 'ErrorPolicy':
        """Create a stop policy."""
        return ErrorPolicy(
            action=ErrorAction.STOP,
            message_template=message or "Execution stopped due to error"
        )

    @staticmethod
    def retry(
        max_attempts: int = 3,
        delay_s: float = 1.0,
        backoff: float = 2.0
    ) -> 'ErrorPolicy':
        """Create a retry policy."""
        return ErrorPolicy(
            action=ErrorAction.RETRY,
            retry_config=RetryConfig(
                max_attempts=max_attempts,
                delay_s=delay_s,
                backoff_multiplier=backoff
            )
        )

    @staticmethod
    def skip(message: Optional[str] = None) -> 'ErrorPolicy':
        """Create a skip policy."""
        return ErrorPolicy(
            action=ErrorAction.SKIP,
            message_template=message or "Step skipped due to error",
            log_level="WARNING"
        )

    @staticmethod
    def alert_and_continue(message: Optional[str] = None) -> 'ErrorPolicy':
        """Create an alert-and-continue policy."""
        return ErrorPolicy(
            action=ErrorAction.ALERT_AND_CONTINUE,
            message_template=message or "Alert: Error occurred, continuing",
            log_level="WARNING"
        )

    @staticmethod
    def fallback(action: str, **params) -> 'ErrorPolicy':
        """Create a fallback policy."""
        return ErrorPolicy(
            action=ErrorAction.FALLBACK,
            fallback_config=FallbackConfig(
                fallback_action=action,
                parameters=params
            )
        )

    @staticmethod
    def escalate(
        to: str,
        timeout_s: float = 300.0,
        default: ErrorAction = ErrorAction.STOP
    ) -> 'ErrorPolicy':
        """Create an escalation policy."""
        return ErrorPolicy(
            action=ErrorAction.ESCALATE,
            escalation_config=EscalationConfig(
                escalate_to=to,
                timeout_s=timeout_s,
                default_action_on_timeout=default
            )
        )


# Type alias for error type keys
ErrorTypeKey = Union[
    ErrorCategory,
    PipetteErrorType,
    MotionErrorType,
    SensorErrorType,
    HumanErrorType,
    str
]


class PolicyMatcher:
    """Matches errors to policies based on type and severity."""

    def __init__(self):
        # Policies by specific error type
        self._type_policies: Dict[ErrorTypeKey, ErrorPolicy] = {}

        # Policies by category
        self._category_policies: Dict[ErrorCategory, ErrorPolicy] = {}

        # Policies by severity
        self._severity_policies: Dict[ErrorSeverity, ErrorPolicy] = {}

        # Default policy
        self._default_policy: ErrorPolicy = ErrorPolicy.stop()

        # Custom matchers (predicates)
        self._custom_matchers: List[tuple[Callable[[BPLError], bool], ErrorPolicy]] = []

    def set_policy_for_type(
        self,
        error_type: ErrorTypeKey,
        policy: ErrorPolicy
    ) -> None:
        """Set policy for a specific error type."""
        self._type_policies[error_type] = policy

    def set_policy_for_category(
        self,
        category: ErrorCategory,
        policy: ErrorPolicy
    ) -> None:
        """Set policy for an error category."""
        self._category_policies[category] = policy

    def set_policy_for_severity(
        self,
        severity: ErrorSeverity,
        policy: ErrorPolicy
    ) -> None:
        """Set policy for an error severity."""
        self._severity_policies[severity] = policy

    def set_default_policy(self, policy: ErrorPolicy) -> None:
        """Set the default policy."""
        self._default_policy = policy

    def add_custom_matcher(
        self,
        predicate: Callable[[BPLError], bool],
        policy: ErrorPolicy
    ) -> None:
        """Add a custom matcher with predicate."""
        self._custom_matchers.append((predicate, policy))

    def match(self, error: BPLError) -> ErrorPolicy:
        """Find the best matching policy for an error."""
        result = self._match_internal(error)
        return result[1] if result[0] else self._default_policy

    def has_specific_match(self, error: BPLError) -> bool:
        """Check if there's a specific policy match (not just default)."""
        return self._match_internal(error)[0]

    def _match_internal(self, error: BPLError) -> tuple[bool, ErrorPolicy]:
        """Internal matching returning (found_specific, policy)."""
        # Priority 1: Custom matchers
        for predicate, policy in self._custom_matchers:
            if predicate(error):
                return (True, policy)

        # Priority 2: Specific error type
        # Check for specific pipette error type
        if isinstance(error, PipetteError):
            if error.pipette_error_type in self._type_policies:
                return (True, self._type_policies[error.pipette_error_type])

        # Check for specific motion error type
        if isinstance(error, MotionError):
            if error.motion_error_type in self._type_policies:
                return (True, self._type_policies[error.motion_error_type])

        # Check for specific sensor error type
        if isinstance(error, SensorError):
            if error.sensor_error_type in self._type_policies:
                return (True, self._type_policies[error.sensor_error_type])

        # Check for specific human error type
        if isinstance(error, HumanError):
            if error.human_error_type in self._type_policies:
                return (True, self._type_policies[error.human_error_type])

        # Priority 3: Error category
        if error.category in self._category_policies:
            return (True, self._category_policies[error.category])

        # Priority 4: Error severity
        if error.severity in self._severity_policies:
            return (True, self._severity_policies[error.severity])

        # Priority 5: Default (no specific match)
        return (False, self._default_policy)


class ErrorPolicyManager:
    """
    Manages error policies for a protocol execution.

    Handles:
    - Policy registration
    - Policy matching
    - Policy execution coordination
    """

    def __init__(self):
        self.matcher = PolicyMatcher()
        self._step_overrides: Dict[str, PolicyMatcher] = {}

    def register_default_policies(self) -> None:
        """Register sensible default policies."""
        # Severity-based defaults
        self.matcher.set_policy_for_severity(
            ErrorSeverity.WARNING,
            ErrorPolicy.alert_and_continue()
        )
        self.matcher.set_policy_for_severity(
            ErrorSeverity.ERROR,
            ErrorPolicy.retry(max_attempts=3)
        )
        self.matcher.set_policy_for_severity(
            ErrorSeverity.CRITICAL,
            ErrorPolicy.stop()
        )
        self.matcher.set_policy_for_severity(
            ErrorSeverity.FATAL,
            ErrorPolicy.stop("Fatal error - protocol aborted")
        )

        # Category-based defaults
        self.matcher.set_policy_for_category(
            ErrorCategory.PIPETTE,
            ErrorPolicy.retry(max_attempts=3, delay_s=2.0)
        )
        self.matcher.set_policy_for_category(
            ErrorCategory.MOTION,
            ErrorPolicy.stop("Motion error - manual intervention required")
        )

        # Specific error type policies
        self.matcher.set_policy_for_type(
            PipetteErrorType.TIP_CLOG,
            ErrorPolicy.retry(max_attempts=2, delay_s=5.0)
        )
        self.matcher.set_policy_for_type(
            PipetteErrorType.LIQUID_NOT_FOUND,
            ErrorPolicy.alert_and_continue("Warning: Liquid not detected")
        )
        self.matcher.set_policy_for_type(
            MotionErrorType.COLLISION_DETECTED,
            ErrorPolicy.stop("Collision detected - check for damage")
        )
        self.matcher.set_policy_for_type(
            SensorErrorType.TEMPERATURE_OUT_OF_RANGE,
            ErrorPolicy.retry(max_attempts=5, delay_s=30.0)
        )

    def set_step_override(
        self,
        step_id: str,
        error_type: ErrorTypeKey,
        policy: ErrorPolicy
    ) -> None:
        """Set a policy override for a specific step."""
        if step_id not in self._step_overrides:
            self._step_overrides[step_id] = PolicyMatcher()
        self._step_overrides[step_id].set_policy_for_type(error_type, policy)

    def get_policy(
        self,
        error: BPLError,
        step_id: Optional[str] = None
    ) -> ErrorPolicy:
        """Get the policy for handling an error."""
        # Check step-specific override first
        if step_id and step_id in self._step_overrides:
            override_matcher = self._step_overrides[step_id]
            # Use override if it has a specific match for this error
            if override_matcher.has_specific_match(error):
                return override_matcher.match(error)

        # Fall back to global matcher
        return self.matcher.match(error)

    def apply_from_annotation(
        self,
        step_id: str,
        annotation_args: Dict[str, Any]
    ) -> None:
        """
        Apply policy from @on_error annotation.

        Example annotation args:
        {
            "action": "retry",
            "max_attempts": 3,
            "fallback": "skip"
        }
        """
        action_str = annotation_args.get("action", "stop").upper()
        action = ErrorAction[action_str] if action_str in ErrorAction.__members__ else ErrorAction.STOP

        if action == ErrorAction.RETRY:
            policy = ErrorPolicy.retry(
                max_attempts=annotation_args.get("max_attempts", 3),
                delay_s=annotation_args.get("delay_s", 1.0),
                backoff=annotation_args.get("backoff", 2.0)
            )
        elif action == ErrorAction.SKIP:
            policy = ErrorPolicy.skip(annotation_args.get("message"))
        elif action == ErrorAction.ALERT_AND_CONTINUE:
            policy = ErrorPolicy.alert_and_continue(annotation_args.get("message"))
        elif action == ErrorAction.FALLBACK:
            fallback_action = annotation_args.get("fallback_action", "skip")
            policy = ErrorPolicy.fallback(fallback_action)
        elif action == ErrorAction.ESCALATE:
            policy = ErrorPolicy.escalate(
                to=annotation_args.get("escalate_to", "supervisor"),
                timeout_s=annotation_args.get("timeout_s", 300.0)
            )
        else:
            policy = ErrorPolicy.stop(annotation_args.get("message"))

        # Apply to specific error types if specified
        error_types = annotation_args.get("error_types", [])
        if error_types:
            for et in error_types:
                self.set_step_override(step_id, et, policy)
        else:
            # Apply to all error categories for this step
            if step_id not in self._step_overrides:
                self._step_overrides[step_id] = PolicyMatcher()
            for cat in ErrorCategory:
                self._step_overrides[step_id].set_policy_for_category(cat, policy)


# Convenience functions for creating common policies

def on_error_stop() -> ErrorPolicy:
    """Create a policy that stops on error."""
    return ErrorPolicy.stop()


def on_error_retry(attempts: int = 3) -> ErrorPolicy:
    """Create a policy that retries on error."""
    return ErrorPolicy.retry(max_attempts=attempts)


def on_error_skip() -> ErrorPolicy:
    """Create a policy that skips on error."""
    return ErrorPolicy.skip()


def on_error_continue() -> ErrorPolicy:
    """Create a policy that alerts and continues on error."""
    return ErrorPolicy.alert_and_continue()
