"""
BPL Error Types - Domain-specific error classifications.

Error categories:
- PipetteError: Liquid handling errors
- MotionError: Robotic movement errors
- SensorError: Sensor/reader errors
- HumanError: Human operator errors
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from enum import Enum, auto
from datetime import datetime


class ErrorSeverity(Enum):
    """Severity levels for errors."""
    WARNING = auto()      # Non-blocking, informational
    ERROR = auto()        # Blocking, recoverable
    CRITICAL = auto()     # Blocking, may not be recoverable
    FATAL = auto()        # Protocol must abort


class ErrorCategory(Enum):
    """High-level error categories."""
    PIPETTE = auto()
    MOTION = auto()
    SENSOR = auto()
    HUMAN = auto()
    SYSTEM = auto()
    VALIDATION = auto()


@dataclass
class BPLError:
    """Base error class for BPL runtime errors."""
    error_id: str
    category: ErrorCategory
    severity: ErrorSeverity
    message: str
    step_id: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)
    details: Dict[str, Any] = field(default_factory=dict)
    recoverable: bool = True
    suggested_action: Optional[str] = None

    def __str__(self) -> str:
        return f"[{self.category.name}:{self.severity.name}] {self.message}"


# === Pipette Errors ===

class PipetteErrorType(Enum):
    """Types of pipette errors."""
    TIP_CLOG = auto()
    LIQUID_NOT_FOUND = auto()
    OVER_ASPIRATION = auto()
    TIP_PICKUP_FAIL = auto()
    TIP_DROP_FAIL = auto()
    AIR_GAP_DETECTED = auto()
    PRESSURE_OUT_OF_RANGE = auto()
    CHANNEL_MALFUNCTION = auto()


@dataclass
class PipetteError(BPLError):
    """Error during pipetting operations."""
    pipette_error_type: PipetteErrorType = PipetteErrorType.TIP_CLOG
    channel_id: Optional[str] = None
    expected_volume_ul: Optional[float] = None
    actual_volume_ul: Optional[float] = None
    well_location: Optional[str] = None

    def __post_init__(self):
        self.category = ErrorCategory.PIPETTE
        if not self.error_id:
            self.error_id = f"PIP_{self.pipette_error_type.name}_{id(self)}"


def tip_clog_error(
    step_id: str,
    channel_id: str,
    well_location: str
) -> PipetteError:
    """Create a tip clog error."""
    return PipetteError(
        error_id=f"TIP_CLOG_{step_id}",
        category=ErrorCategory.PIPETTE,
        severity=ErrorSeverity.ERROR,
        message=f"Tip clog detected on channel {channel_id} at {well_location}",
        step_id=step_id,
        pipette_error_type=PipetteErrorType.TIP_CLOG,
        channel_id=channel_id,
        well_location=well_location,
        suggested_action="Replace tip and retry aspiration"
    )


def liquid_not_found_error(
    step_id: str,
    well_location: str,
    expected_volume_ul: float
) -> PipetteError:
    """Create a liquid not found error."""
    return PipetteError(
        error_id=f"LIQUID_NOT_FOUND_{step_id}",
        category=ErrorCategory.PIPETTE,
        severity=ErrorSeverity.ERROR,
        message=f"No liquid detected at {well_location} (expected {expected_volume_ul} uL)",
        step_id=step_id,
        pipette_error_type=PipetteErrorType.LIQUID_NOT_FOUND,
        well_location=well_location,
        expected_volume_ul=expected_volume_ul,
        suggested_action="Verify well contents and retry"
    )


def over_aspiration_error(
    step_id: str,
    well_location: str,
    requested_ul: float,
    available_ul: float
) -> PipetteError:
    """Create an over-aspiration error."""
    return PipetteError(
        error_id=f"OVER_ASPIRATION_{step_id}",
        category=ErrorCategory.PIPETTE,
        severity=ErrorSeverity.WARNING,
        message=f"Requested {requested_ul} uL but only {available_ul} uL available at {well_location}",
        step_id=step_id,
        pipette_error_type=PipetteErrorType.OVER_ASPIRATION,
        well_location=well_location,
        expected_volume_ul=requested_ul,
        actual_volume_ul=available_ul,
        suggested_action="Adjust volume or replenish source"
    )


def tip_pickup_fail_error(
    step_id: str,
    channel_id: str,
    tip_position: str
) -> PipetteError:
    """Create a tip pickup failure error."""
    return PipetteError(
        error_id=f"TIP_PICKUP_FAIL_{step_id}",
        category=ErrorCategory.PIPETTE,
        severity=ErrorSeverity.ERROR,
        message=f"Failed to pick up tip from {tip_position} on channel {channel_id}",
        step_id=step_id,
        pipette_error_type=PipetteErrorType.TIP_PICKUP_FAIL,
        channel_id=channel_id,
        well_location=tip_position,
        suggested_action="Check tip rack and retry"
    )


# === Motion Errors ===

class MotionErrorType(Enum):
    """Types of motion errors."""
    COLLISION_DETECTED = auto()
    POSITION_UNREACHABLE = auto()
    LABWARE_NOT_FOUND = auto()
    DECK_POSITION_OCCUPIED = auto()
    GRIPPER_FAIL = auto()
    HOMING_FAIL = auto()
    TIMEOUT = auto()


@dataclass
class MotionError(BPLError):
    """Error during robotic movement."""
    motion_error_type: MotionErrorType = MotionErrorType.COLLISION_DETECTED
    position: Optional[str] = None
    target_position: Optional[str] = None
    labware_id: Optional[str] = None

    def __post_init__(self):
        self.category = ErrorCategory.MOTION
        if not self.error_id:
            self.error_id = f"MOT_{self.motion_error_type.name}_{id(self)}"


def collision_detected_error(
    step_id: str,
    position: str,
    labware_id: Optional[str] = None
) -> MotionError:
    """Create a collision detection error."""
    return MotionError(
        error_id=f"COLLISION_{step_id}",
        category=ErrorCategory.MOTION,
        severity=ErrorSeverity.CRITICAL,
        message=f"Collision detected at position {position}",
        step_id=step_id,
        motion_error_type=MotionErrorType.COLLISION_DETECTED,
        position=position,
        labware_id=labware_id,
        recoverable=False,
        suggested_action="Stop robot, inspect for damage, and recalibrate"
    )


def position_unreachable_error(
    step_id: str,
    target_position: str
) -> MotionError:
    """Create a position unreachable error."""
    return MotionError(
        error_id=f"UNREACHABLE_{step_id}",
        category=ErrorCategory.MOTION,
        severity=ErrorSeverity.ERROR,
        message=f"Position {target_position} is unreachable",
        step_id=step_id,
        motion_error_type=MotionErrorType.POSITION_UNREACHABLE,
        target_position=target_position,
        suggested_action="Check deck configuration and labware placement"
    )


def labware_not_found_error(
    step_id: str,
    labware_id: str,
    expected_position: str
) -> MotionError:
    """Create a labware not found error."""
    return MotionError(
        error_id=f"LABWARE_NOT_FOUND_{step_id}",
        category=ErrorCategory.MOTION,
        severity=ErrorSeverity.ERROR,
        message=f"Labware {labware_id} not found at expected position {expected_position}",
        step_id=step_id,
        motion_error_type=MotionErrorType.LABWARE_NOT_FOUND,
        labware_id=labware_id,
        target_position=expected_position,
        suggested_action="Verify labware placement or update deck state"
    )


# === Sensor Errors ===

class SensorErrorType(Enum):
    """Types of sensor errors."""
    READER_TIMEOUT = auto()
    TEMPERATURE_OUT_OF_RANGE = auto()
    LIQUID_SENSE_FAIL = auto()
    BARCODE_READ_FAIL = auto()
    CALIBRATION_REQUIRED = auto()
    SENSOR_MALFUNCTION = auto()


@dataclass
class SensorError(BPLError):
    """Error from sensors or readers."""
    sensor_error_type: SensorErrorType = SensorErrorType.READER_TIMEOUT
    device_id: Optional[str] = None
    expected_value: Optional[float] = None
    actual_value: Optional[float] = None
    tolerance: Optional[float] = None

    def __post_init__(self):
        self.category = ErrorCategory.SENSOR
        if not self.error_id:
            self.error_id = f"SEN_{self.sensor_error_type.name}_{id(self)}"


def reader_timeout_error(
    step_id: str,
    device_id: str,
    timeout_s: float
) -> SensorError:
    """Create a reader timeout error."""
    return SensorError(
        error_id=f"READER_TIMEOUT_{step_id}",
        category=ErrorCategory.SENSOR,
        severity=ErrorSeverity.ERROR,
        message=f"Plate reader {device_id} timed out after {timeout_s}s",
        step_id=step_id,
        sensor_error_type=SensorErrorType.READER_TIMEOUT,
        device_id=device_id,
        details={"timeout_s": timeout_s},
        suggested_action="Check reader status and retry"
    )


def temperature_out_of_range_error(
    step_id: str,
    device_id: str,
    target_temp: float,
    actual_temp: float,
    tolerance: float
) -> SensorError:
    """Create a temperature out of range error."""
    return SensorError(
        error_id=f"TEMP_OUT_OF_RANGE_{step_id}",
        category=ErrorCategory.SENSOR,
        severity=ErrorSeverity.WARNING,
        message=f"Temperature on {device_id}: {actual_temp}°C (target: {target_temp}±{tolerance}°C)",
        step_id=step_id,
        sensor_error_type=SensorErrorType.TEMPERATURE_OUT_OF_RANGE,
        device_id=device_id,
        expected_value=target_temp,
        actual_value=actual_temp,
        tolerance=tolerance,
        suggested_action="Wait for temperature stabilization"
    )


def liquid_sense_fail_error(
    step_id: str,
    well_location: str
) -> SensorError:
    """Create a liquid sense failure error."""
    return SensorError(
        error_id=f"LIQUID_SENSE_FAIL_{step_id}",
        category=ErrorCategory.SENSOR,
        severity=ErrorSeverity.WARNING,
        message=f"Liquid level sensing failed at {well_location}",
        step_id=step_id,
        sensor_error_type=SensorErrorType.LIQUID_SENSE_FAIL,
        details={"well_location": well_location},
        suggested_action="Use default aspiration height"
    )


# === Human Errors ===

class HumanErrorType(Enum):
    """Types of human operator errors."""
    CONFIRMATION_TIMEOUT = auto()
    INVALID_DATA_ENTRY = auto()
    STEP_SKIPPED = auto()
    SAFETY_VIOLATION = auto()
    SIGNATURE_MISSING = auto()
    WRONG_LABWARE = auto()


@dataclass
class HumanError(BPLError):
    """Error from human operator actions."""
    human_error_type: HumanErrorType = HumanErrorType.CONFIRMATION_TIMEOUT
    operator_id: Optional[str] = None
    expected_input: Optional[str] = None
    actual_input: Optional[str] = None

    def __post_init__(self):
        self.category = ErrorCategory.HUMAN
        if not self.error_id:
            self.error_id = f"HUM_{self.human_error_type.name}_{id(self)}"


def confirmation_timeout_error(
    step_id: str,
    timeout_s: float
) -> HumanError:
    """Create a confirmation timeout error."""
    return HumanError(
        error_id=f"CONFIRM_TIMEOUT_{step_id}",
        category=ErrorCategory.HUMAN,
        severity=ErrorSeverity.WARNING,
        message=f"Operator confirmation not received within {timeout_s}s",
        step_id=step_id,
        human_error_type=HumanErrorType.CONFIRMATION_TIMEOUT,
        details={"timeout_s": timeout_s},
        suggested_action="Re-prompt operator for confirmation"
    )


def invalid_data_entry_error(
    step_id: str,
    field_name: str,
    expected_format: str,
    actual_value: str
) -> HumanError:
    """Create an invalid data entry error."""
    return HumanError(
        error_id=f"INVALID_DATA_{step_id}",
        category=ErrorCategory.HUMAN,
        severity=ErrorSeverity.ERROR,
        message=f"Invalid entry for {field_name}: '{actual_value}' (expected: {expected_format})",
        step_id=step_id,
        human_error_type=HumanErrorType.INVALID_DATA_ENTRY,
        expected_input=expected_format,
        actual_input=actual_value,
        suggested_action="Re-enter data in correct format"
    )


def safety_violation_error(
    step_id: str,
    violation_description: str
) -> HumanError:
    """Create a safety violation error."""
    return HumanError(
        error_id=f"SAFETY_VIOLATION_{step_id}",
        category=ErrorCategory.HUMAN,
        severity=ErrorSeverity.CRITICAL,
        message=f"Safety violation: {violation_description}",
        step_id=step_id,
        human_error_type=HumanErrorType.SAFETY_VIOLATION,
        recoverable=False,
        suggested_action="Stop protocol and review safety procedures"
    )


# === Error Registry ===

class ErrorRegistry:
    """Registry for tracking errors during execution."""

    def __init__(self):
        self.errors: List[BPLError] = []
        self._error_counts: Dict[ErrorCategory, int] = {
            cat: 0 for cat in ErrorCategory
        }

    def record(self, error: BPLError) -> None:
        """Record an error."""
        self.errors.append(error)
        self._error_counts[error.category] += 1

    def get_errors_by_category(self, category: ErrorCategory) -> List[BPLError]:
        """Get all errors of a specific category."""
        return [e for e in self.errors if e.category == category]

    def get_errors_by_severity(self, severity: ErrorSeverity) -> List[BPLError]:
        """Get all errors of a specific severity."""
        return [e for e in self.errors if e.severity == severity]

    def get_errors_for_step(self, step_id: str) -> List[BPLError]:
        """Get all errors for a specific step."""
        return [e for e in self.errors if e.step_id == step_id]

    def has_critical_errors(self) -> bool:
        """Check if any critical or fatal errors occurred."""
        return any(
            e.severity in (ErrorSeverity.CRITICAL, ErrorSeverity.FATAL)
            for e in self.errors
        )

    def error_count(self, category: Optional[ErrorCategory] = None) -> int:
        """Get error count, optionally filtered by category."""
        if category:
            return self._error_counts[category]
        return len(self.errors)

    def clear(self) -> None:
        """Clear all recorded errors."""
        self.errors.clear()
        self._error_counts = {cat: 0 for cat in ErrorCategory}

    def summary(self) -> str:
        """Get a summary of recorded errors."""
        lines = ["Error Summary:"]
        for cat in ErrorCategory:
            count = self._error_counts[cat]
            if count > 0:
                lines.append(f"  {cat.name}: {count}")
        if not any(self._error_counts.values()):
            lines.append("  No errors recorded")
        return "\n".join(lines)
