"""
BPL Recovery Procedures - Automated and guided error recovery.

Provides:
- Recovery procedure definitions
- Recovery execution framework
- Common recovery patterns
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum, auto
from abc import ABC, abstractmethod
from datetime import datetime

from .error_types import (
    BPLError,
    PipetteError,
    SensorError,
    PipetteErrorType,
)


class RecoveryStatus(Enum):
    """Status of a recovery attempt."""
    NOT_STARTED = auto()
    IN_PROGRESS = auto()
    SUCCEEDED = auto()
    FAILED = auto()
    PARTIAL = auto()
    SKIPPED = auto()


@dataclass
class RecoveryStep:
    """A single step in a recovery procedure."""
    step_id: str
    description: str
    action: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    requires_human: bool = False
    timeout_s: Optional[float] = None


@dataclass
class RecoveryResult:
    """Result of a recovery attempt."""
    status: RecoveryStatus
    steps_completed: List[str] = field(default_factory=list)
    steps_failed: List[str] = field(default_factory=list)
    error_resolved: bool = False
    message: str = ""
    duration_s: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def success(self) -> bool:
        return self.status == RecoveryStatus.SUCCEEDED


class RecoveryProcedure(ABC):
    """Base class for recovery procedures."""

    def __init__(self, procedure_id: str, name: str):
        self.procedure_id = procedure_id
        self.name = name
        self.steps: List[RecoveryStep] = []

    @abstractmethod
    def can_recover(self, error: BPLError) -> bool:
        """Check if this procedure can recover from the error."""
        pass

    @abstractmethod
    def execute(
        self,
        error: BPLError,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        """Execute the recovery procedure."""
        pass

    def add_step(self, step: RecoveryStep) -> None:
        """Add a step to the procedure."""
        self.steps.append(step)


class TipClogRecovery(RecoveryProcedure):
    """Recovery procedure for tip clog errors."""

    def __init__(self):
        super().__init__("tip_clog_recovery", "Tip Clog Recovery")
        self.steps = [
            RecoveryStep(
                step_id="eject_tip",
                description="Eject the clogged tip",
                action="drop_tips"
            ),
            RecoveryStep(
                step_id="pick_new_tip",
                description="Pick up a new tip",
                action="pick_tips"
            ),
            RecoveryStep(
                step_id="retry_aspiration",
                description="Retry the aspiration",
                action="aspirate"
            )
        ]

    def can_recover(self, error: BPLError) -> bool:
        if isinstance(error, PipetteError):
            return error.pipette_error_type == PipetteErrorType.TIP_CLOG
        return False

    def execute(
        self,
        error: BPLError,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        start_time = datetime.now()
        completed = []
        failed = []

        for step in self.steps:
            # Simulate step execution
            try:
                # In real implementation, would call runtime
                completed.append(step.step_id)
            except Exception as e:
                failed.append(step.step_id)
                return RecoveryResult(
                    status=RecoveryStatus.FAILED,
                    steps_completed=completed,
                    steps_failed=failed,
                    error_resolved=False,
                    message=f"Recovery failed at {step.step_id}: {e}",
                    duration_s=(datetime.now() - start_time).total_seconds()
                )

        return RecoveryResult(
            status=RecoveryStatus.SUCCEEDED,
            steps_completed=completed,
            steps_failed=failed,
            error_resolved=True,
            message="Tip clog resolved, operation resumed",
            duration_s=(datetime.now() - start_time).total_seconds()
        )


class TipPickupRecovery(RecoveryProcedure):
    """Recovery procedure for tip pickup failures."""

    def __init__(self):
        super().__init__("tip_pickup_recovery", "Tip Pickup Recovery")
        self.steps = [
            RecoveryStep(
                step_id="retry_pickup",
                description="Retry tip pickup at same position",
                action="pick_tips"
            ),
            RecoveryStep(
                step_id="try_next_tip",
                description="Try picking from next available position",
                action="pick_tips",
                parameters={"offset": 1}
            ),
            RecoveryStep(
                step_id="alert_operator",
                description="Alert operator to check tip rack",
                action="alert",
                requires_human=True,
                timeout_s=60.0
            )
        ]

    def can_recover(self, error: BPLError) -> bool:
        if isinstance(error, PipetteError):
            return error.pipette_error_type == PipetteErrorType.TIP_PICKUP_FAIL
        return False

    def execute(
        self,
        error: BPLError,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        start_time = datetime.now()
        completed = []

        # Try each step in sequence
        for step in self.steps:
            try:
                # Step would be executed here
                completed.append(step.step_id)

                # If step succeeds and can verify resolution, return
                if step.step_id in ("retry_pickup", "try_next_tip"):
                    return RecoveryResult(
                        status=RecoveryStatus.SUCCEEDED,
                        steps_completed=completed,
                        error_resolved=True,
                        message=f"Recovery succeeded at {step.step_id}",
                        duration_s=(datetime.now() - start_time).total_seconds()
                    )
            except Exception:
                # Continue to next step on failure
                continue

        return RecoveryResult(
            status=RecoveryStatus.FAILED,
            steps_completed=completed,
            error_resolved=False,
            message="All recovery steps exhausted",
            duration_s=(datetime.now() - start_time).total_seconds()
        )


class TemperatureRecovery(RecoveryProcedure):
    """Recovery for temperature out of range errors."""

    def __init__(self):
        super().__init__("temperature_recovery", "Temperature Recovery")
        self.steps = [
            RecoveryStep(
                step_id="wait_stabilize",
                description="Wait for temperature to stabilize",
                action="wait",
                parameters={"duration_s": 60.0}
            ),
            RecoveryStep(
                step_id="check_temp",
                description="Check temperature again",
                action="read_temperature"
            ),
            RecoveryStep(
                step_id="adjust_setpoint",
                description="Re-send temperature setpoint",
                action="set_temperature"
            )
        ]

    def can_recover(self, error: BPLError) -> bool:
        if isinstance(error, SensorError):
            from .error_types import SensorErrorType
            return error.sensor_error_type == SensorErrorType.TEMPERATURE_OUT_OF_RANGE
        return False

    def execute(
        self,
        error: BPLError,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        start_time = datetime.now()
        completed = []

        for step in self.steps:
            completed.append(step.step_id)

        return RecoveryResult(
            status=RecoveryStatus.SUCCEEDED,
            steps_completed=completed,
            error_resolved=True,
            message="Temperature stabilized",
            duration_s=(datetime.now() - start_time).total_seconds()
        )


class HumanInterventionRecovery(RecoveryProcedure):
    """Recovery requiring human intervention."""

    def __init__(self, intervention_type: str = "general"):
        super().__init__(
            f"human_intervention_{intervention_type}",
            "Human Intervention Required"
        )
        self.intervention_type = intervention_type
        self.steps = [
            RecoveryStep(
                step_id="pause_system",
                description="Pause automated execution",
                action="pause"
            ),
            RecoveryStep(
                step_id="notify_operator",
                description="Notify operator of issue",
                action="alert",
                requires_human=True
            ),
            RecoveryStep(
                step_id="await_confirmation",
                description="Wait for operator confirmation",
                action="await_confirmation",
                requires_human=True,
                timeout_s=300.0
            ),
            RecoveryStep(
                step_id="resume_system",
                description="Resume execution",
                action="resume"
            )
        ]

    def can_recover(self, error: BPLError) -> bool:
        # Can attempt human recovery for any non-fatal error
        return error.recoverable

    def execute(
        self,
        error: BPLError,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        start_time = datetime.now()
        completed = []

        for step in self.steps:
            completed.append(step.step_id)
            if step.requires_human:
                # In real implementation, would wait for human
                pass

        return RecoveryResult(
            status=RecoveryStatus.SUCCEEDED,
            steps_completed=completed,
            error_resolved=True,
            message="Operator resolved issue manually",
            duration_s=(datetime.now() - start_time).total_seconds()
        )


class RecoveryManager:
    """
    Manages recovery procedures for errors.

    Coordinates:
    - Recovery procedure registration
    - Matching errors to procedures
    - Recovery execution
    """

    def __init__(self):
        self._procedures: Dict[str, RecoveryProcedure] = {}
        self._history: List[tuple[BPLError, RecoveryResult]] = []

    def register_procedure(self, procedure: RecoveryProcedure) -> None:
        """Register a recovery procedure."""
        self._procedures[procedure.procedure_id] = procedure

    def register_default_procedures(self) -> None:
        """Register default recovery procedures."""
        self.register_procedure(TipClogRecovery())
        self.register_procedure(TipPickupRecovery())
        self.register_procedure(TemperatureRecovery())
        self.register_procedure(HumanInterventionRecovery())

    def find_procedure(self, error: BPLError) -> Optional[RecoveryProcedure]:
        """Find a suitable recovery procedure for an error."""
        for procedure in self._procedures.values():
            if procedure.can_recover(error):
                return procedure
        return None

    def attempt_recovery(
        self,
        error: BPLError,
        context: Optional[Dict[str, Any]] = None
    ) -> RecoveryResult:
        """
        Attempt to recover from an error.

        Returns RecoveryResult with status and details.
        """
        context = context or {}

        # Check if error is recoverable
        if not error.recoverable:
            result = RecoveryResult(
                status=RecoveryStatus.SKIPPED,
                error_resolved=False,
                message="Error marked as non-recoverable"
            )
            self._history.append((error, result))
            return result

        # Find suitable procedure
        procedure = self.find_procedure(error)
        if not procedure:
            result = RecoveryResult(
                status=RecoveryStatus.FAILED,
                error_resolved=False,
                message="No recovery procedure found for error"
            )
            self._history.append((error, result))
            return result

        # Execute recovery
        result = procedure.execute(error, context)
        self._history.append((error, result))
        return result

    def get_recovery_history(self) -> List[tuple[BPLError, RecoveryResult]]:
        """Get history of recovery attempts."""
        return self._history.copy()

    def clear_history(self) -> None:
        """Clear recovery history."""
        self._history.clear()


# Convenience function

def create_recovery_manager() -> RecoveryManager:
    """Create a recovery manager with default procedures."""
    manager = RecoveryManager()
    manager.register_default_procedures()
    return manager
