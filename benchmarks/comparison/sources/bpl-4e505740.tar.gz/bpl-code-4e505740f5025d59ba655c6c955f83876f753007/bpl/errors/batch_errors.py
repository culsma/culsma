"""
BPL Batch Errors - Error handling for batch/multi-well operations.

Features:
- BatchResult tracking successful/failed wells
- Failure threshold checking
- Completion rate calculations
- @batch_error_policy handling
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any, Tuple
from enum import Enum, auto
from datetime import datetime

from .error_types import BPLError, ErrorSeverity


class BatchContinuationPolicy(Enum):
    """Policy for continuing after batch item failures."""
    STOP_ON_FIRST = auto()      # Stop on first failure
    STOP_ON_THRESHOLD = auto()   # Stop when threshold exceeded
    CONTINUE_ALL = auto()        # Continue regardless of failures
    COMPLETE_ROW = auto()        # Complete current row, then evaluate
    COMPLETE_COLUMN = auto()     # Complete current column, then evaluate


@dataclass
class WellResult:
    """Result of a single well operation."""
    well_id: str
    success: bool
    volume_ul: Optional[float] = None
    error: Optional[BPLError] = None
    timestamp: datetime = field(default_factory=datetime.now)
    retry_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchResult:
    """Result of a batch operation across multiple wells."""
    batch_id: str
    operation: str  # e.g., "transfer", "distribute"
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    # Results tracking
    results: Dict[str, WellResult] = field(default_factory=dict)
    _successful_wells: Set[str] = field(default_factory=set)
    _failed_wells: Set[str] = field(default_factory=set)
    _skipped_wells: Set[str] = field(default_factory=set)

    # Aggregate errors
    errors: List[BPLError] = field(default_factory=list)

    def record_success(
        self,
        well_id: str,
        volume_ul: Optional[float] = None,
        **metadata
    ) -> None:
        """Record a successful well operation."""
        self.results[well_id] = WellResult(
            well_id=well_id,
            success=True,
            volume_ul=volume_ul,
            metadata=metadata
        )
        self._successful_wells.add(well_id)
        self._failed_wells.discard(well_id)

    def record_failure(
        self,
        well_id: str,
        error: BPLError,
        retry_count: int = 0
    ) -> None:
        """Record a failed well operation."""
        self.results[well_id] = WellResult(
            well_id=well_id,
            success=False,
            error=error,
            retry_count=retry_count
        )
        self._failed_wells.add(well_id)
        self._successful_wells.discard(well_id)
        self.errors.append(error)

    def record_skip(self, well_id: str, reason: str = "") -> None:
        """Record a skipped well."""
        self.results[well_id] = WellResult(
            well_id=well_id,
            success=False,
            metadata={"skipped": True, "reason": reason}
        )
        self._skipped_wells.add(well_id)

    @property
    def successful_wells(self) -> List[str]:
        """Get list of successful wells."""
        return list(self._successful_wells)

    @property
    def failed_wells(self) -> List[str]:
        """Get list of failed wells."""
        return list(self._failed_wells)

    @property
    def skipped_wells(self) -> List[str]:
        """Get list of skipped wells."""
        return list(self._skipped_wells)

    @property
    def total_wells(self) -> int:
        """Total number of wells processed."""
        return len(self.results)

    @property
    def success_count(self) -> int:
        """Number of successful wells."""
        return len(self._successful_wells)

    @property
    def failure_count(self) -> int:
        """Number of failed wells."""
        return len(self._failed_wells)

    @property
    def skip_count(self) -> int:
        """Number of skipped wells."""
        return len(self._skipped_wells)

    @property
    def completion_rate(self) -> float:
        """Percentage of wells completed successfully."""
        if self.total_wells == 0:
            return 0.0
        return (self.success_count / self.total_wells) * 100.0

    @property
    def failure_rate(self) -> float:
        """Percentage of wells that failed."""
        if self.total_wells == 0:
            return 0.0
        return (self.failure_count / self.total_wells) * 100.0

    def complete(self) -> None:
        """Mark batch as complete."""
        self.completed_at = datetime.now()

    @property
    def duration_s(self) -> Optional[float]:
        """Duration of batch operation in seconds."""
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    def is_above_threshold(self, min_success_rate: float) -> bool:
        """Check if success rate is above threshold."""
        return self.completion_rate >= min_success_rate

    def summary(self) -> str:
        """Get a summary of batch results."""
        status = "COMPLETE" if self.completed_at else "IN_PROGRESS"
        return (
            f"Batch {self.batch_id} [{status}]: "
            f"{self.success_count}/{self.total_wells} successful "
            f"({self.completion_rate:.1f}%), "
            f"{self.failure_count} failed, {self.skip_count} skipped"
        )


@dataclass
class BatchErrorPolicy:
    """Policy for handling errors in batch operations."""
    continuation_policy: BatchContinuationPolicy = BatchContinuationPolicy.STOP_ON_THRESHOLD
    failure_threshold: float = 10.0  # Percentage
    min_success_rate: float = 90.0   # Minimum acceptable success rate
    max_consecutive_failures: int = 3
    retry_failed_at_end: bool = False
    collect_all_errors: bool = True

    @staticmethod
    def strict() -> 'BatchErrorPolicy':
        """Create a strict policy that stops on first failure."""
        return BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.STOP_ON_FIRST,
            failure_threshold=0.0,
            min_success_rate=100.0
        )

    @staticmethod
    def lenient() -> 'BatchErrorPolicy':
        """Create a lenient policy that continues through failures."""
        return BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.CONTINUE_ALL,
            failure_threshold=50.0,
            min_success_rate=50.0
        )

    @staticmethod
    def standard() -> 'BatchErrorPolicy':
        """Create a standard policy with reasonable thresholds."""
        return BatchErrorPolicy(
            continuation_policy=BatchContinuationPolicy.STOP_ON_THRESHOLD,
            failure_threshold=10.0,
            min_success_rate=90.0,
            max_consecutive_failures=3
        )


class BatchErrorHandler:
    """
    Handles errors in batch operations.

    Tracks:
    - Per-well success/failure
    - Threshold checking
    - Continuation decisions
    """

    def __init__(self, policy: Optional[BatchErrorPolicy] = None):
        self.policy = policy or BatchErrorPolicy.standard()
        self._current_batch: Optional[BatchResult] = None
        self._consecutive_failures = 0
        self._batch_history: List[BatchResult] = []

    def start_batch(
        self,
        batch_id: str,
        operation: str
    ) -> BatchResult:
        """Start a new batch operation."""
        self._current_batch = BatchResult(
            batch_id=batch_id,
            operation=operation
        )
        self._consecutive_failures = 0
        return self._current_batch

    def record_well_success(
        self,
        well_id: str,
        volume_ul: Optional[float] = None,
        **metadata
    ) -> None:
        """Record successful well operation."""
        if self._current_batch:
            self._current_batch.record_success(well_id, volume_ul, **metadata)
            self._consecutive_failures = 0

    def record_well_failure(
        self,
        well_id: str,
        error: BPLError,
        retry_count: int = 0
    ) -> Tuple[bool, str]:
        """
        Record failed well operation.

        Returns:
            (should_continue, message)
        """
        if not self._current_batch:
            return (False, "No active batch")

        self._current_batch.record_failure(well_id, error, retry_count)
        self._consecutive_failures += 1

        # Check continuation policy
        return self._check_continuation()

    def skip_well(self, well_id: str, reason: str = "") -> None:
        """Skip a well."""
        if self._current_batch:
            self._current_batch.record_skip(well_id, reason)

    def _check_continuation(self) -> Tuple[bool, str]:
        """Check if batch should continue based on policy."""
        if not self._current_batch:
            return (False, "No active batch")

        policy = self.policy
        batch = self._current_batch

        # Stop on first failure
        if policy.continuation_policy == BatchContinuationPolicy.STOP_ON_FIRST:
            return (False, "Stopping on first failure (strict policy)")

        # Check consecutive failures
        if self._consecutive_failures >= policy.max_consecutive_failures:
            return (
                False,
                f"Consecutive failures ({self._consecutive_failures}) "
                f"exceeded limit ({policy.max_consecutive_failures})"
            )

        # Check failure threshold
        if policy.continuation_policy == BatchContinuationPolicy.STOP_ON_THRESHOLD:
            if batch.failure_rate > policy.failure_threshold:
                return (
                    False,
                    f"Failure rate ({batch.failure_rate:.1f}%) "
                    f"exceeded threshold ({policy.failure_threshold}%)"
                )

        # Continue all
        if policy.continuation_policy == BatchContinuationPolicy.CONTINUE_ALL:
            return (True, "Continuing (lenient policy)")

        return (True, "Within acceptable failure limits")

    def complete_batch(self) -> BatchResult:
        """Complete the current batch and return results."""
        if not self._current_batch:
            raise ValueError("No active batch to complete")

        batch = self._current_batch
        batch.complete()

        # Check final success rate
        if batch.completion_rate < self.policy.min_success_rate:
            # Add warning error
            from .error_types import ErrorCategory
            warning = BPLError(
                error_id=f"BATCH_BELOW_THRESHOLD_{batch.batch_id}",
                category=ErrorCategory.VALIDATION,
                severity=ErrorSeverity.WARNING,
                message=(
                    f"Batch completion rate ({batch.completion_rate:.1f}%) "
                    f"below minimum ({self.policy.min_success_rate}%)"
                )
            )
            batch.errors.append(warning)

        self._batch_history.append(batch)
        self._current_batch = None
        return batch

    def get_current_batch(self) -> Optional[BatchResult]:
        """Get the current active batch."""
        return self._current_batch

    def get_batch_history(self) -> List[BatchResult]:
        """Get history of completed batches."""
        return self._batch_history.copy()

    def get_aggregate_stats(self) -> Dict[str, Any]:
        """Get aggregate statistics across all batches."""
        total_wells = 0
        total_success = 0
        total_failure = 0
        total_skipped = 0

        for batch in self._batch_history:
            total_wells += batch.total_wells
            total_success += batch.success_count
            total_failure += batch.failure_count
            total_skipped += batch.skip_count

        success_rate = (total_success / total_wells * 100) if total_wells > 0 else 0

        return {
            "total_batches": len(self._batch_history),
            "total_wells": total_wells,
            "total_success": total_success,
            "total_failure": total_failure,
            "total_skipped": total_skipped,
            "overall_success_rate": success_rate
        }


# Convenience functions

def create_batch_handler(policy_type: str = "standard") -> BatchErrorHandler:
    """Create a batch error handler with specified policy type."""
    policies = {
        "strict": BatchErrorPolicy.strict(),
        "lenient": BatchErrorPolicy.lenient(),
        "standard": BatchErrorPolicy.standard()
    }
    policy = policies.get(policy_type, BatchErrorPolicy.standard())
    return BatchErrorHandler(policy)


def check_batch_threshold(
    result: BatchResult,
    min_success_rate: float = 90.0
) -> Tuple[bool, str]:
    """Check if batch result meets success threshold."""
    if result.completion_rate >= min_success_rate:
        return (True, f"Batch passed ({result.completion_rate:.1f}% >= {min_success_rate}%)")
    else:
        return (False, f"Batch failed ({result.completion_rate:.1f}% < {min_success_rate}%)")
