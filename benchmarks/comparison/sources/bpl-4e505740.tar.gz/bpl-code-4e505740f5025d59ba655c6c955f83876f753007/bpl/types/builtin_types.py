"""
BPL Type System - Builtin Types

Defines the built-in types for BPL including quantity types,
concentration types, and reference types.
"""

from dataclasses import dataclass
from typing import Optional, Set
from enum import Enum, auto

from .dimensions import (
    DimensionVector,
    MASS, VOLUME, TIME, TEMPERATURE, AMOUNT, LENGTH, PRESSURE, SPEED,
    MASS_CONCENTRATION, MOLAR_CONCENTRATION, DIMENSIONLESS,
)


class TypeKind(Enum):
    """Kinds of types in the BPL type system."""
    # Primitive types
    NUMBER = auto()
    STRING = auto()
    BOOLEAN = auto()

    # Quantity types (number + unit)
    QUANTITY = auto()

    # Composite types
    LIST = auto()
    MAP = auto()
    PRODUCT = auto()  # Record/struct
    SUM = auto()  # Union/variant

    # Reference types
    REAGENT_REF = auto()
    STOCK_REF = auto()
    CONTAINER_REF = auto()
    WELL_REF = auto()
    WELL_SET_REF = auto()
    PLATE_REF = auto()

    # Special types
    SOURCE = auto()
    DESTINATION = auto()
    SAMPLE = auto()
    STATE_TRANSITION = auto()

    # Any type (for type inference)
    ANY = auto()

    # Error type
    ERROR = auto()


@dataclass(frozen=True)
class BPLType:
    """Base class for all BPL types."""
    kind: TypeKind
    name: str

    def is_subtype_of(self, other: 'BPLType') -> bool:
        """Check if this type is a subtype of another."""
        if other.kind == TypeKind.ANY:
            return True
        return self == other

    def __str__(self) -> str:
        return self.name


@dataclass(frozen=True)
class PrimitiveType(BPLType):
    """Primitive types: Number, String, Boolean."""
    pass


@dataclass(frozen=True)
class QuantityType(BPLType):
    """A quantity type (number with unit dimension)."""
    dimension: DimensionVector
    allowed_units: Optional[Set[str]] = None  # If None, any unit of this dimension is allowed

    def __str__(self) -> str:
        if self.allowed_units:
            return f"{self.name}[{', '.join(sorted(self.allowed_units))}]"
        return self.name


@dataclass(frozen=True)
class ListType(BPLType):
    """A list type with element type."""
    element_type: BPLType

    def __str__(self) -> str:
        return f"List<{self.element_type}>"


@dataclass(frozen=True)
class MapType(BPLType):
    """A map type with key and value types."""
    key_type: BPLType
    value_type: BPLType

    def __str__(self) -> str:
        return f"Map<{self.key_type}, {self.value_type}>"


@dataclass(frozen=True)
class ProductType(BPLType):
    """A product type (record/struct) with named fields."""
    fields: tuple  # Tuple of (name, type) pairs

    def get_field_type(self, name: str) -> Optional[BPLType]:
        """Get the type of a field by name."""
        for field_name, field_type in self.fields:
            if field_name == name:
                return field_type
        return None

    def __str__(self) -> str:
        field_strs = [f"{name}: {typ}" for name, typ in self.fields]
        return f"{{ {', '.join(field_strs)} }}"


@dataclass(frozen=True)
class SumType(BPLType):
    """A sum type (union/variant) with multiple variants."""
    variants: tuple  # Tuple of BPLType

    def __str__(self) -> str:
        return " | ".join(str(v) for v in self.variants)


@dataclass(frozen=True)
class FunctionType(BPLType):
    """A function type with parameter and return types."""
    param_types: tuple  # Tuple of (name, type, optional) triples
    return_type: Optional[BPLType]

    def __str__(self) -> str:
        params = ", ".join(
            f"{name}: {typ}{'?' if optional else ''}"
            for name, typ, optional in self.param_types
        )
        ret = f" -> {self.return_type}" if self.return_type else ""
        return f"({params}){ret}"


# ============================================================================
# Builtin Type Instances
# ============================================================================

# Primitive types
NUMBER = PrimitiveType(kind=TypeKind.NUMBER, name="Number")
STRING = PrimitiveType(kind=TypeKind.STRING, name="String")
BOOLEAN = PrimitiveType(kind=TypeKind.BOOLEAN, name="Boolean")
ANY = BPLType(kind=TypeKind.ANY, name="Any")
ERROR = BPLType(kind=TypeKind.ERROR, name="Error")

# Quantity types
MASS_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Mass",
    dimension=MASS,
    allowed_units={"kg", "g", "mg", "ug", "ng", "pg"}
)

VOLUME_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Volume",
    dimension=VOLUME,
    allowed_units={"L", "mL", "uL", "nL"}
)

TIME_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Time",
    dimension=TIME,
    allowed_units={"d", "h", "min", "s", "ms"}
)

TEMPERATURE_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Temperature",
    dimension=TEMPERATURE,
    allowed_units={"degC", "K"}
)

AMOUNT_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Moles",
    dimension=AMOUNT,
    allowed_units={"mol", "mmol", "umol", "nmol", "pmol"}
)

LENGTH_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Length",
    dimension=LENGTH,
    allowed_units={"m", "cm", "mm", "um", "nm", "bp", "kb", "Mb"}
)

PRESSURE_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Pressure",
    dimension=PRESSURE,
    allowed_units={"atm", "psi", "kPa", "bar"}
)

SPEED_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Speed",
    dimension=SPEED,
    allowed_units={"rpm", "rcf"}
)

MASS_CONCENTRATION_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="MassConcentration",
    dimension=MASS_CONCENTRATION,
    allowed_units={"g/L", "mg/mL", "ug/mL", "ng/uL", "pg/uL", "mg/L", "ug/L", "ng/mL"}
)

MOLAR_CONCENTRATION_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="MolarConcentration",
    dimension=MOLAR_CONCENTRATION,
    allowed_units={"M", "mM", "uM", "nM", "pM", "mol/L", "mmol/L", "umol/L"}
)

# Concentration is a sum type of mass and molar concentration
CONCENTRATION_TYPE = SumType(
    kind=TypeKind.SUM,
    name="Concentration",
    variants=(MASS_CONCENTRATION_TYPE, MOLAR_CONCENTRATION_TYPE)
)

PERCENTAGE_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="Percentage",
    dimension=DIMENSIONLESS,
    allowed_units={"%", "percent"}
)

FOLD_FACTOR_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="FoldFactor",
    dimension=DIMENSIONLESS,
    allowed_units={"X"}
)

# Flow rate types
VOLUME_RATE_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="VolumeRate",
    dimension=VOLUME / TIME,
    allowed_units={"uL/s", "mL/min"}
)

MOLAR_MASS_TYPE = QuantityType(
    kind=TypeKind.QUANTITY,
    name="MolarMass",
    dimension=MASS / AMOUNT,
    allowed_units={"g/mol"}
)

# Reference types
REAGENT_REF_TYPE = BPLType(kind=TypeKind.REAGENT_REF, name="ReagentRef")
STOCK_REF_TYPE = BPLType(kind=TypeKind.STOCK_REF, name="StockRef")
CONTAINER_REF_TYPE = BPLType(kind=TypeKind.CONTAINER_REF, name="ContainerRef")
WELL_REF_TYPE = BPLType(kind=TypeKind.WELL_REF, name="WellRef")
WELL_SET_REF_TYPE = BPLType(kind=TypeKind.WELL_SET_REF, name="WellSetRef")
PLATE_REF_TYPE = BPLType(kind=TypeKind.PLATE_REF, name="PlateRef")

# Source type (sum of reference types that can provide liquid)
SOURCE_TYPE = SumType(
    kind=TypeKind.SOURCE,
    name="Source",
    variants=(
        REAGENT_REF_TYPE,
        STOCK_REF_TYPE,
        CONTAINER_REF_TYPE,
        WELL_REF_TYPE,
        WELL_SET_REF_TYPE,
    )
)

# Destination type (sum of reference types that can receive liquid)
DESTINATION_TYPE = SumType(
    kind=TypeKind.DESTINATION,
    name="Destination",
    variants=(
        CONTAINER_REF_TYPE,
        WELL_REF_TYPE,
        WELL_SET_REF_TYPE,
    )
)

# State transition type (returned by intents)
STATE_TRANSITION_TYPE = BPLType(kind=TypeKind.STATE_TRANSITION, name="StateTransition")


# ============================================================================
# Type Registry
# ============================================================================

class TypeRegistry:
    """Registry of known types."""

    def __init__(self):
        self._types: dict[str, BPLType] = {}
        self._register_builtin_types()

    def _register_builtin_types(self):
        """Register all built-in types."""
        # Primitives
        self.register(NUMBER)
        self.register(STRING)
        self.register(BOOLEAN)
        self.register(ANY)

        # Quantity types
        self.register(MASS_TYPE)
        self.register(VOLUME_TYPE)
        self.register(TIME_TYPE)
        self.register(TEMPERATURE_TYPE)
        self.register(AMOUNT_TYPE)
        self.register(LENGTH_TYPE)
        self.register(PRESSURE_TYPE)
        self.register(SPEED_TYPE)
        self.register(MASS_CONCENTRATION_TYPE)
        self.register(MOLAR_CONCENTRATION_TYPE)
        self.register(CONCENTRATION_TYPE)
        self.register(PERCENTAGE_TYPE)
        self.register(FOLD_FACTOR_TYPE)
        self.register(VOLUME_RATE_TYPE)
        self.register(MOLAR_MASS_TYPE)

        # Reference types
        self.register(REAGENT_REF_TYPE)
        self.register(STOCK_REF_TYPE)
        self.register(CONTAINER_REF_TYPE)
        self.register(WELL_REF_TYPE)
        self.register(WELL_SET_REF_TYPE)
        self.register(PLATE_REF_TYPE)
        self.register(SOURCE_TYPE)
        self.register(DESTINATION_TYPE)
        self.register(STATE_TRANSITION_TYPE)

    def register(self, typ: BPLType) -> None:
        """Register a type."""
        self._types[typ.name] = typ

    def get(self, name: str) -> Optional[BPLType]:
        """Get a type by name."""
        return self._types.get(name)

    def resolve_type_name(self, name: str) -> Optional[BPLType]:
        """Resolve a type name to a type, including aliases."""
        # Direct lookup
        typ = self.get(name)
        if typ:
            return typ

        # Common aliases
        aliases = {
            "Volume": VOLUME_TYPE,
            "Mass": MASS_TYPE,
            "Time": TIME_TYPE,
            "Temperature": TEMPERATURE_TYPE,
            "Moles": AMOUNT_TYPE,
            "Length": LENGTH_TYPE,
            "Pressure": PRESSURE_TYPE,
            "Speed": SPEED_TYPE,
            "Concentration": CONCENTRATION_TYPE,
            "MassConcentration": MASS_CONCENTRATION_TYPE,
            "MolarConcentration": MOLAR_CONCENTRATION_TYPE,
            "Percentage": PERCENTAGE_TYPE,
            "FoldFactor": FOLD_FACTOR_TYPE,
            "VolumeRate": VOLUME_RATE_TYPE,
            "MolarMass": MOLAR_MASS_TYPE,
            "Source": SOURCE_TYPE,
            "Destination": DESTINATION_TYPE,
            "StateTransition": STATE_TRANSITION_TYPE,
            "ReagentRef": REAGENT_REF_TYPE,
            "StockRef": STOCK_REF_TYPE,
            "ContainerRef": CONTAINER_REF_TYPE,
            "WellRef": WELL_REF_TYPE,
            "WellSetRef": WELL_SET_REF_TYPE,
            "PlateRef": PLATE_REF_TYPE,
        }
        return aliases.get(name)


# Global type registry
_type_registry = TypeRegistry()


def get_type(name: str) -> Optional[BPLType]:
    """Get a type by name from the global registry."""
    return _type_registry.resolve_type_name(name)


def get_type_registry() -> TypeRegistry:
    """Get the global type registry."""
    return _type_registry
