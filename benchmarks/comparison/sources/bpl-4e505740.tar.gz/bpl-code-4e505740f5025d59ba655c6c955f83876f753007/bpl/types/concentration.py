"""
BPL Type System - Concentration Derivation

Handles MW-aware concentration type conversions and derivations.
"""

from dataclasses import dataclass
from typing import Optional, Tuple
from enum import Enum, auto

from .unit_engine import Quantity, Unit, get_unit, create_quantity
from .dimensions import MASS, VOLUME, AMOUNT, MASS_CONCENTRATION, MOLAR_CONCENTRATION


class ConcentrationType(Enum):
    """Types of concentration."""
    MASS = auto()  # g/L, mg/mL, etc.
    MOLAR = auto()  # M, mM, etc.


@dataclass
class ConcentrationValue:
    """
    A concentration value that knows its type (mass or molar).
    """
    value: float
    unit: Unit
    concentration_type: ConcentrationType

    def to_mass_concentration(self, mw: Optional[Quantity] = None) -> 'ConcentrationValue':
        """
        Convert to mass concentration.

        If already mass concentration, returns self.
        If molar concentration, requires molecular weight (MW).
        """
        if self.concentration_type == ConcentrationType.MASS:
            return self

        if mw is None:
            raise TypeError(
                "Cannot convert molar concentration to mass concentration: "
                "molecular weight (MW) required"
            )

        # Molar to Mass: mass_conc = molar_conc * MW
        # e.g., 1 M * 58.44 g/mol = 58.44 g/L
        mw_value = mw.value  # Assume MW is in g/mol
        new_value = self.value * mw_value

        # Determine appropriate unit
        new_unit = get_unit("g/L")
        return ConcentrationValue(
            value=new_value,
            unit=new_unit,
            concentration_type=ConcentrationType.MASS
        )

    def to_molar_concentration(self, mw: Optional[Quantity] = None) -> 'ConcentrationValue':
        """
        Convert to molar concentration.

        If already molar concentration, returns self.
        If mass concentration, requires molecular weight (MW).
        """
        if self.concentration_type == ConcentrationType.MOLAR:
            return self

        if mw is None:
            raise TypeError(
                "Cannot convert mass concentration to molar concentration: "
                "molecular weight (MW) required"
            )

        # Mass to Molar: molar_conc = mass_conc / MW
        # e.g., 58.44 g/L / (58.44 g/mol) = 1 M
        mw_value = mw.value  # Assume MW is in g/mol
        new_value = self.value / mw_value

        # Determine appropriate unit
        new_unit = get_unit("M")
        return ConcentrationValue(
            value=new_value,
            unit=new_unit,
            concentration_type=ConcentrationType.MOLAR
        )

    def __repr__(self) -> str:
        return f"{self.value} {self.unit}"


def is_mass_concentration_unit(unit: Unit) -> bool:
    """Check if a unit is a mass concentration unit."""
    return unit.dimension == MASS_CONCENTRATION


def is_molar_concentration_unit(unit: Unit) -> bool:
    """Check if a unit is a molar concentration unit."""
    return unit.dimension == MOLAR_CONCENTRATION


def classify_concentration_unit(unit_name: str) -> Optional[ConcentrationType]:
    """Classify a concentration unit as mass or molar."""
    mass_units = {"g/L", "mg/mL", "ug/mL", "ng/uL", "pg/uL", "mg/L", "ug/L", "ng/mL"}
    molar_units = {"M", "mM", "uM", "nM", "pM", "mol/L", "mmol/L", "umol/L"}

    if unit_name in mass_units:
        return ConcentrationType.MASS
    elif unit_name in molar_units:
        return ConcentrationType.MOLAR
    return None


def create_concentration(value: float, unit_name: str) -> ConcentrationValue:
    """Create a concentration value from a value and unit name."""
    conc_type = classify_concentration_unit(unit_name)
    if conc_type is None:
        raise ValueError(f"'{unit_name}' is not a concentration unit")

    unit = get_unit(unit_name)
    return ConcentrationValue(
        value=value,
        unit=unit,
        concentration_type=conc_type
    )


def derive_concentration_from_division(
    numerator: Quantity,
    denominator: Quantity
) -> Optional[Tuple[float, ConcentrationType]]:
    """
    Derive concentration type from a division operation.

    Returns (value, ConcentrationType) if the division produces a concentration,
    None otherwise.

    Rules:
    - Mass / Volume → MassConcentration
    - Moles / Volume → MolarConcentration
    """
    num_dim = numerator.unit.dimension
    denom_dim = denominator.unit.dimension

    # Mass / Volume → MassConcentration
    if num_dim == MASS and denom_dim == VOLUME:
        # Calculate value (need to normalize to g/L)
        # Mass in kg, Volume in L → kg/L, need to convert to g/L
        mass_in_g = numerator.value * numerator.unit.scale * 1000  # Convert to g
        volume_in_L = denominator.value * denominator.unit.scale  # Convert to L
        value = mass_in_g / volume_in_L
        return (value, ConcentrationType.MASS)

    # Moles / Volume → MolarConcentration
    if num_dim == AMOUNT and denom_dim == VOLUME:
        moles_in_mol = numerator.value * numerator.unit.scale  # Convert to mol
        volume_in_L = denominator.value * denominator.unit.scale  # Convert to L
        value = moles_in_mol / volume_in_L
        return (value, ConcentrationType.MOLAR)

    return None


def calculate_mass_from_molar(
    molar_amount: Quantity,
    mw: Quantity
) -> Quantity:
    """
    Calculate mass from molar amount and molecular weight.

    mass = moles * MW
    e.g., 1 mol * 58.44 g/mol = 58.44 g
    """
    if molar_amount.unit.dimension != AMOUNT:
        raise TypeError(f"Expected moles, got {molar_amount.unit}")

    moles_in_mol = molar_amount.value * molar_amount.unit.scale
    mw_in_g_per_mol = mw.value * mw.unit.scale * 1000  # Convert kg/mol to g/mol
    mass_in_g = moles_in_mol * mw_in_g_per_mol

    return create_quantity(mass_in_g, "g")


def calculate_moles_from_mass(
    mass: Quantity,
    mw: Quantity
) -> Quantity:
    """
    Calculate moles from mass and molecular weight.

    moles = mass / MW
    e.g., 58.44 g / (58.44 g/mol) = 1 mol
    """
    if mass.unit.dimension != MASS:
        raise TypeError(f"Expected mass, got {mass.unit}")

    mass_in_g = mass.value * mass.unit.scale * 1000  # Convert kg to g
    mw_in_g_per_mol = mw.value * mw.unit.scale * 1000  # Convert kg/mol to g/mol
    moles_in_mol = mass_in_g / mw_in_g_per_mol

    return create_quantity(moles_in_mol, "mol")


def calculate_volume_for_concentration(
    source_amount: Quantity,
    target_concentration: ConcentrationValue,
    source_mw: Optional[Quantity] = None
) -> Quantity:
    """
    Calculate the volume needed to achieve a target concentration.

    volume = amount / concentration

    For mass source → mass concentration: volume = mass / conc
    For mass source → molar concentration: volume = (mass/MW) / conc (requires MW)
    For moles source → molar concentration: volume = moles / conc
    For moles source → mass concentration: volume = (moles*MW) / conc (requires MW)
    """
    source_dim = source_amount.unit.dimension

    if target_concentration.concentration_type == ConcentrationType.MASS:
        if source_dim == MASS:
            # Mass / MassConc → Volume
            # Normalize mass to g and conc to g/L
            mass_in_g = source_amount.value * source_amount.unit.scale * 1000
            conc_in_g_per_L = target_concentration.value * target_concentration.unit.scale
            volume_in_L = mass_in_g / conc_in_g_per_L
            return create_quantity(volume_in_L * 1000, "mL")  # Return in mL
        elif source_dim == AMOUNT:
            if source_mw is None:
                raise TypeError("MW required to calculate volume from moles for mass concentration")
            # Convert moles to mass, then mass / conc
            mass = calculate_mass_from_molar(source_amount, source_mw)
            return calculate_volume_for_concentration(mass, target_concentration)

    elif target_concentration.concentration_type == ConcentrationType.MOLAR:
        if source_dim == AMOUNT:
            # Moles / MolarConc → Volume
            moles_in_mol = source_amount.value * source_amount.unit.scale
            conc_in_M = target_concentration.value * target_concentration.unit.scale
            volume_in_L = moles_in_mol / conc_in_M
            return create_quantity(volume_in_L * 1000, "mL")
        elif source_dim == MASS:
            if source_mw is None:
                raise TypeError("MW required to calculate volume from mass for molar concentration")
            # Convert mass to moles, then moles / conc
            moles = calculate_moles_from_mass(source_amount, source_mw)
            return calculate_volume_for_concentration(moles, target_concentration)

    raise TypeError(
        f"Cannot calculate volume from {source_amount.unit} to {target_concentration}"
    )
