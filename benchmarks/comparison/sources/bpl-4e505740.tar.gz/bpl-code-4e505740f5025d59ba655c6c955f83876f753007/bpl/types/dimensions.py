"""
BPL Type System - Physical Dimensions

Defines the fundamental physical dimensions for unit checking.
"""

from dataclasses import dataclass
from enum import Enum, auto
from typing import Dict, Tuple, Optional


class Dimension(Enum):
    """Base physical dimensions."""
    DIMENSIONLESS = auto()
    MASS = auto()
    VOLUME = auto()
    LENGTH = auto()
    TIME = auto()
    TEMPERATURE = auto()
    AMOUNT = auto()  # moles
    PRESSURE = auto()
    SPEED = auto()  # rotational speed (rpm, rcf)

    # Derived dimensions
    CONCENTRATION = auto()  # mass/volume or moles/volume
    RATE = auto()  # volume/time
    FOLD = auto()  # dimensionless but typed


@dataclass(frozen=True)
class DimensionVector:
    """
    Represents a compound dimension as a vector of base dimensions.

    For example:
    - Volume: {VOLUME: 1}
    - Concentration (g/L): {MASS: 1, VOLUME: -1}
    - Flow rate (uL/s): {VOLUME: 1, TIME: -1}
    """
    exponents: Tuple[Tuple[Dimension, int], ...]

    def __init__(self, exponents: Optional[Dict[Dimension, int]] = None):
        if exponents is None:
            exponents = {}
        # Filter out zero exponents and sort for consistent hashing
        filtered = {k: v for k, v in exponents.items() if v != 0}
        object.__setattr__(self, 'exponents', tuple(sorted(filtered.items(), key=lambda x: x[0].value)))

    @property
    def is_dimensionless(self) -> bool:
        return len(self.exponents) == 0

    def __mul__(self, other: 'DimensionVector') -> 'DimensionVector':
        """Multiply dimensions (add exponents)."""
        result = dict(self.exponents)
        for dim, exp in other.exponents:
            result[dim] = result.get(dim, 0) + exp
        return DimensionVector(result)

    def __truediv__(self, other: 'DimensionVector') -> 'DimensionVector':
        """Divide dimensions (subtract exponents)."""
        result = dict(self.exponents)
        for dim, exp in other.exponents:
            result[dim] = result.get(dim, 0) - exp
        return DimensionVector(result)

    def __eq__(self, other) -> bool:
        if not isinstance(other, DimensionVector):
            return False
        return self.exponents == other.exponents

    def __hash__(self) -> int:
        return hash(self.exponents)

    def __repr__(self) -> str:
        if self.is_dimensionless:
            return "Dimensionless"
        parts = []
        for dim, exp in self.exponents:
            if exp == 1:
                parts.append(dim.name)
            else:
                parts.append(f"{dim.name}^{exp}")
        return " * ".join(parts)


# Common dimension vectors
DIMENSIONLESS = DimensionVector()
MASS = DimensionVector({Dimension.MASS: 1})
VOLUME = DimensionVector({Dimension.VOLUME: 1})
LENGTH = DimensionVector({Dimension.LENGTH: 1})
TIME = DimensionVector({Dimension.TIME: 1})
TEMPERATURE = DimensionVector({Dimension.TEMPERATURE: 1})
AMOUNT = DimensionVector({Dimension.AMOUNT: 1})
PRESSURE = DimensionVector({Dimension.PRESSURE: 1})
SPEED = DimensionVector({Dimension.SPEED: 1})

# Derived dimensions
MASS_CONCENTRATION = MASS / VOLUME  # g/L, mg/mL
MOLAR_CONCENTRATION = AMOUNT / VOLUME  # M, mM
FLOW_RATE = VOLUME / TIME  # uL/s, mL/min
TEMPERATURE_RATE = TEMPERATURE / TIME  # degC/min
MOLAR_MASS = MASS / AMOUNT  # g/mol
