"""
BPL Type System - Unit Engine

Handles unit parsing, arithmetic, conversion, and normalization.
"""

from dataclasses import dataclass
import math
from typing import Dict, Optional, Tuple
from enum import Enum, auto

from .dimensions import (
    DimensionVector,
    DIMENSIONLESS, MASS, VOLUME, LENGTH, TIME, TEMPERATURE, AMOUNT, PRESSURE, SPEED,
    MASS_CONCENTRATION, MOLAR_CONCENTRATION, FLOW_RATE, TEMPERATURE_RATE, MOLAR_MASS,
)


class UnitCategory(Enum):
    """Categories of units."""
    MASS = auto()
    VOLUME = auto()
    TIME = auto()
    TEMPERATURE = auto()
    AMOUNT = auto()
    LENGTH = auto()
    PRESSURE = auto()
    SPEED = auto()
    CONCENTRATION = auto()
    MOLAR = auto()
    FLOW_RATE = auto()
    PERCENT = auto()
    FOLD = auto()
    MOLAR_MASS = auto()
    DERIVED = auto()


class UnitDimensionError(TypeError):
    """Deterministic arithmetic/conversion dimension mismatch diagnostic."""

    def __init__(
        self,
        *,
        code: str,
        operation: str,
        left: DimensionVector,
        right: DimensionVector,
    ) -> None:
        self.code = code
        self.operation = operation
        self.left = left
        self.right = right
        super().__init__(
            f"[{code}] incompatible dimensions for '{operation}': {left} vs {right}"
        )


@dataclass(frozen=True)
class Unit:
    """
    Represents a physical unit with its dimension and scale factor.

    The scale factor is relative to the base SI unit.
    For example:
    - mL has scale 1e-3 (relative to L)
    - mg has scale 1e-6 (relative to kg)
    """
    name: str
    dimension: DimensionVector
    scale: float  # Scale factor relative to base unit
    category: UnitCategory

    def __repr__(self) -> str:
        return self.name


@dataclass
class Quantity:
    """A value with an associated unit."""
    value: float
    unit: Unit

    def to(self, target_unit: Unit) -> 'Quantity':
        """Convert to another unit of the same dimension."""
        if self.unit.dimension != target_unit.dimension:
            raise UnitDimensionError(
                code="UNIT_DIMENSION_MISMATCH_CONVERSION",
                operation="convert",
                left=self.unit.dimension,
                right=target_unit.dimension,
            )
        # Convert: value * source_scale / target_scale
        new_value = self.value * self.unit.scale / target_unit.scale
        return Quantity(value=new_value, unit=target_unit)

    def __add__(self, other: 'Quantity') -> 'Quantity':
        """Add two quantities of the same dimension."""
        if not are_compatible(self.unit, other.unit):
            raise UnitDimensionError(
                code="UNIT_DIMENSION_MISMATCH_ARITHMETIC",
                operation="+",
                left=self.unit.dimension,
                right=other.unit.dimension,
            )
        # Convert both to a common unit (use self's unit)
        other_converted = other.to(self.unit)
        return Quantity(value=self.value + other_converted.value, unit=self.unit)

    def __sub__(self, other: 'Quantity') -> 'Quantity':
        """Subtract two quantities of the same dimension."""
        if not are_compatible(self.unit, other.unit):
            raise UnitDimensionError(
                code="UNIT_DIMENSION_MISMATCH_ARITHMETIC",
                operation="-",
                left=self.unit.dimension,
                right=other.unit.dimension,
            )
        other_converted = other.to(self.unit)
        return Quantity(value=self.value - other_converted.value, unit=self.unit)

    def __mul__(self, other) -> 'Quantity':
        """Multiply by a scalar or another quantity."""
        if isinstance(other, (int, float)):
            return Quantity(value=self.value * other, unit=self.unit)
        elif isinstance(other, Quantity):
            # Multiply quantities: multiply values and combine dimensions
            new_dimension = self.unit.dimension * other.unit.dimension
            new_scale = self.unit.scale * other.unit.scale
            new_unit = get_registry().simplify_derived_unit(
                dimension=new_dimension,
                scale=new_scale,
                expression=f"{self.unit.name}*{other.unit.name}",
            )
            return Quantity(value=self.value * other.value, unit=new_unit)
        else:
            raise TypeError(f"Cannot multiply Quantity by {type(other)}")

    def __truediv__(self, other) -> 'Quantity':
        """Divide by a scalar or another quantity."""
        if isinstance(other, (int, float)):
            return Quantity(value=self.value / other, unit=self.unit)
        elif isinstance(other, Quantity):
            # Divide quantities: divide values and combine dimensions
            new_dimension = self.unit.dimension / other.unit.dimension
            new_scale = self.unit.scale / other.unit.scale
            new_unit = get_registry().simplify_derived_unit(
                dimension=new_dimension,
                scale=new_scale,
                expression=f"{self.unit.name}/{other.unit.name}",
            )
            return Quantity(value=self.value / other.value, unit=new_unit)
        else:
            raise TypeError(f"Cannot divide Quantity by {type(other)}")

    def __repr__(self) -> str:
        return f"{self.value} {self.unit}"


class UnitRegistry:
    """Registry of known units."""

    def __init__(self):
        self._units: Dict[str, Unit] = {}
        self._register_builtin_units()

    def _register_builtin_units(self):
        """Register all built-in units."""
        # Mass units (base: kg)
        self.register(Unit("kg", MASS, 1.0, UnitCategory.MASS))
        self.register(Unit("g", MASS, 1e-3, UnitCategory.MASS))
        self.register(Unit("mg", MASS, 1e-6, UnitCategory.MASS))
        self.register(Unit("ug", MASS, 1e-9, UnitCategory.MASS))
        self.register(Unit("ng", MASS, 1e-12, UnitCategory.MASS))
        self.register(Unit("pg", MASS, 1e-15, UnitCategory.MASS))

        # Volume units (base: L)
        self.register(Unit("L", VOLUME, 1.0, UnitCategory.VOLUME))
        self.register(Unit("mL", VOLUME, 1e-3, UnitCategory.VOLUME))
        self.register(Unit("uL", VOLUME, 1e-6, UnitCategory.VOLUME))
        self.register(Unit("nL", VOLUME, 1e-9, UnitCategory.VOLUME))

        # Time units (base: s)
        self.register(Unit("s", TIME, 1.0, UnitCategory.TIME))
        self.register(Unit("ms", TIME, 1e-3, UnitCategory.TIME))
        self.register(Unit("min", TIME, 60.0, UnitCategory.TIME))
        self.register(Unit("h", TIME, 3600.0, UnitCategory.TIME))
        self.register(Unit("d", TIME, 86400.0, UnitCategory.TIME))

        # Temperature units (base: K, but we use degC as practical base)
        self.register(Unit("degC", TEMPERATURE, 1.0, UnitCategory.TEMPERATURE))
        self.register(Unit("K", TEMPERATURE, 1.0, UnitCategory.TEMPERATURE))

        # Amount units (base: mol)
        self.register(Unit("mol", AMOUNT, 1.0, UnitCategory.AMOUNT))
        self.register(Unit("mmol", AMOUNT, 1e-3, UnitCategory.AMOUNT))
        self.register(Unit("umol", AMOUNT, 1e-6, UnitCategory.AMOUNT))
        self.register(Unit("nmol", AMOUNT, 1e-9, UnitCategory.AMOUNT))
        self.register(Unit("pmol", AMOUNT, 1e-12, UnitCategory.AMOUNT))

        # Length units (base: m)
        self.register(Unit("m", LENGTH, 1.0, UnitCategory.LENGTH))
        self.register(Unit("cm", LENGTH, 1e-2, UnitCategory.LENGTH))
        self.register(Unit("mm", LENGTH, 1e-3, UnitCategory.LENGTH))
        self.register(Unit("um", LENGTH, 1e-6, UnitCategory.LENGTH))
        self.register(Unit("nm", LENGTH, 1e-9, UnitCategory.LENGTH))
        self.register(Unit("bp", LENGTH, 3.4e-10, UnitCategory.LENGTH))  # base pairs
        self.register(Unit("kb", LENGTH, 3.4e-7, UnitCategory.LENGTH))
        self.register(Unit("Mb", LENGTH, 3.4e-4, UnitCategory.LENGTH))

        # Pressure units (base: Pa)
        self.register(Unit("atm", PRESSURE, 101325.0, UnitCategory.PRESSURE))
        self.register(Unit("psi", PRESSURE, 6894.76, UnitCategory.PRESSURE))
        self.register(Unit("kPa", PRESSURE, 1000.0, UnitCategory.PRESSURE))
        self.register(Unit("bar", PRESSURE, 100000.0, UnitCategory.PRESSURE))

        # Speed units (rpm, rcf)
        self.register(Unit("rpm", SPEED, 1.0, UnitCategory.SPEED))
        self.register(Unit("rcf", SPEED, 1.0, UnitCategory.SPEED))

        # Mass concentration units (base: g/L)
        self.register(Unit("g/L", MASS_CONCENTRATION, 1.0, UnitCategory.CONCENTRATION))
        self.register(Unit("mg/mL", MASS_CONCENTRATION, 1.0, UnitCategory.CONCENTRATION))  # = g/L
        self.register(Unit("ug/mL", MASS_CONCENTRATION, 1e-3, UnitCategory.CONCENTRATION))
        self.register(Unit("ng/uL", MASS_CONCENTRATION, 1.0, UnitCategory.CONCENTRATION))  # = mg/mL
        self.register(Unit("pg/uL", MASS_CONCENTRATION, 1e-3, UnitCategory.CONCENTRATION))
        self.register(Unit("mg/L", MASS_CONCENTRATION, 1e-3, UnitCategory.CONCENTRATION))
        self.register(Unit("ug/L", MASS_CONCENTRATION, 1e-6, UnitCategory.CONCENTRATION))
        self.register(Unit("ng/mL", MASS_CONCENTRATION, 1e-6, UnitCategory.CONCENTRATION))

        # Molar concentration units (base: M = mol/L)
        self.register(Unit("M", MOLAR_CONCENTRATION, 1.0, UnitCategory.MOLAR))
        self.register(Unit("mM", MOLAR_CONCENTRATION, 1e-3, UnitCategory.MOLAR))
        self.register(Unit("uM", MOLAR_CONCENTRATION, 1e-6, UnitCategory.MOLAR))
        self.register(Unit("nM", MOLAR_CONCENTRATION, 1e-9, UnitCategory.MOLAR))
        self.register(Unit("pM", MOLAR_CONCENTRATION, 1e-12, UnitCategory.MOLAR))
        self.register(Unit("mol/L", MOLAR_CONCENTRATION, 1.0, UnitCategory.MOLAR))
        self.register(Unit("mmol/L", MOLAR_CONCENTRATION, 1e-3, UnitCategory.MOLAR))
        self.register(Unit("umol/L", MOLAR_CONCENTRATION, 1e-6, UnitCategory.MOLAR))

        # Flow rate units (base: L/s)
        self.register(Unit("uL/s", FLOW_RATE, 1e-6, UnitCategory.FLOW_RATE))
        self.register(Unit("mL/min", FLOW_RATE, 1e-3 / 60.0, UnitCategory.FLOW_RATE))

        # Temperature rate units (base: K/s)
        self.register(Unit("degC/min", TEMPERATURE_RATE, 1.0 / 60.0, UnitCategory.FLOW_RATE))

        # Molar mass units (base: kg/mol)
        self.register(Unit("g/mol", MOLAR_MASS, 1e-3, UnitCategory.MOLAR_MASS))

        # Percent
        self.register(Unit("%", DIMENSIONLESS, 0.01, UnitCategory.PERCENT))
        self.register(Unit("percent", DIMENSIONLESS, 0.01, UnitCategory.PERCENT))

        # Fold factor
        self.register(Unit("X", DIMENSIONLESS, 1.0, UnitCategory.FOLD))

    def register(self, unit: Unit) -> None:
        """Register a unit."""
        self._units[unit.name] = unit

    def get(self, name: str) -> Optional[Unit]:
        """Get a unit by name."""
        return self._units.get(name)

    def parse(self, unit_text: str) -> Unit:
        """Parse a unit from text."""
        unit = self.get(unit_text)
        if unit is None:
            raise ValueError(f"Unknown unit: {unit_text}")
        return unit

    def normalize(self, quantity: Quantity) -> Quantity:
        """
        Normalize a quantity to its preferred display unit.

        For example:
        - 0.001 g → 1 mg
        - 1000 uL → 1 mL
        """
        # Find the best unit for this dimension
        best_unit = self._find_best_unit(quantity)
        if best_unit:
            return quantity.to(best_unit)
        return quantity

    def _find_best_unit(self, quantity: Quantity) -> Optional[Unit]:
        """Find the best unit for a quantity based on its value."""
        dimension = quantity.unit.dimension
        category = quantity.unit.category

        # Find all units with the same dimension and category
        candidates = [
            u for u in self._units.values()
            if u.dimension == dimension and u.category == category
        ]

        if not candidates:
            return None

        # Convert value to each unit and pick the one with value in [1, 1000)
        best_unit = quantity.unit
        best_value = quantity.value

        for unit in candidates:
            converted = quantity.to(unit)
            if 1 <= abs(converted.value) < 1000:
                if abs(converted.value) < abs(best_value) or abs(best_value) < 1:
                    best_unit = unit
                    best_value = converted.value

        return best_unit

    def find_unit_by_dimension_scale(
        self,
        *,
        dimension: DimensionVector,
        scale: float,
    ) -> Optional[Unit]:
        """Resolve deterministic canonical unit identity by dimension and scale."""
        candidates = sorted(
            (
                unit
                for unit in self._units.values()
                if unit.dimension == dimension
                and math.isclose(unit.scale, scale, rel_tol=1e-12, abs_tol=1e-12)
            ),
            key=lambda unit: unit.name,
        )
        return candidates[0] if candidates else None

    def simplify_derived_unit(
        self,
        *,
        dimension: DimensionVector,
        scale: float,
        expression: str,
    ) -> Unit:
        """
        Simplify derived arithmetic results into canonical units when possible.

        Falls back to a deterministic derived representation when no built-in unit
        exactly matches the computed dimension+scale pair.
        """
        canonical = self.find_unit_by_dimension_scale(dimension=dimension, scale=scale)
        if canonical is not None:
            return canonical

        return Unit(
            name=_format_derived_unit_name(dimension=dimension, scale=scale, expression=expression),
            dimension=dimension,
            scale=scale,
            category=UnitCategory.DERIVED,
        )


def _format_derived_unit_name(*, dimension: DimensionVector, scale: float, expression: str) -> str:
    """Build deterministic canonical names for non-reducible derived units."""
    if dimension.is_dimensionless:
        dim_label = "dimensionless"
    else:
        dim_label = "*".join(
            f"{base.name.lower()}^{power}" if power != 1 else base.name.lower()
            for base, power in dimension.exponents
        )

    rounded_scale = format(scale, ".12g")
    return f"derived[{dim_label}]@{rounded_scale}<{expression}>"


# Global unit registry
_registry = UnitRegistry()


def get_unit(name: str) -> Unit:
    """Get a unit by name from the global registry."""
    return _registry.parse(name)


def get_registry() -> UnitRegistry:
    """Get the global unit registry."""
    return _registry


def create_quantity(value: float, unit_name: str) -> Quantity:
    """Create a quantity from a value and unit name."""
    unit = get_unit(unit_name)
    return Quantity(value=value, unit=unit)


def are_compatible(unit1: Unit, unit2: Unit) -> bool:
    """Check if two units are dimensionally compatible by dimension vector."""
    return unit1.dimension == unit2.dimension


def derive_unit_from_operation(left: Unit, op: str, right: Unit) -> Tuple[DimensionVector, float]:
    """
    Derive the resulting dimension and scale from an arithmetic operation.

    Returns (dimension, scale) for the result.
    """
    if op == '+' or op == '-':
        if not are_compatible(left, right):
            raise UnitDimensionError(
                code="UNIT_DIMENSION_MISMATCH_ARITHMETIC",
                operation=op,
                left=left.dimension,
                right=right.dimension,
            )
        return left.dimension, left.scale
    elif op == '*':
        new_dimension = left.dimension * right.dimension
        new_scale = left.scale * right.scale
        return new_dimension, new_scale
    elif op == '/':
        new_dimension = left.dimension / right.dimension
        new_scale = left.scale / right.scale
        return new_dimension, new_scale
    else:
        raise ValueError(f"Unknown operation: {op}")
