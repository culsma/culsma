"""
BPL Plan IR - Intermediate Representation for Execution Plans.

The Plan IR represents a protocol as a DAG (Directed Acyclic Graph) of steps.
Each step is either:
- A Primitive action (directly executable by robot/human)
- A compound step containing other steps

The Plan IR is the output of intent lowering and input to the scheduler.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Union
from enum import Enum, auto
from datetime import datetime
import bisect
import hashlib
import json

from bpl.location import normalize_well_id, plan_well_ref_to_canonical


# ============================================================================
# Enums
# ============================================================================

class PrimitiveType(Enum):
    """Types of primitive operations."""
    # Liquid handling
    ASPIRATE = auto()
    DISPENSE = auto()
    MIX = auto()

    # Tip handling
    PICK_TIPS = auto()
    DROP_TIPS = auto()

    # Plate handling
    MOVE_LABWARE = auto()
    SEAL_PLATE = auto()
    UNSEAL_PLATE = auto()

    # Measurement
    READ_ABSORBANCE = auto()
    READ_FLUORESCENCE = auto()
    WEIGH = auto()

    # Temperature
    SET_TEMPERATURE = auto()
    INCUBATE = auto()

    # Centrifugation
    CENTRIFUGE = auto()

    # Human steps
    HUMAN_STEP = auto()
    PAUSE = auto()
    RESUME = auto()

    # Control flow
    WAIT = auto()
    CHECKPOINT = auto()

    # Colony operations
    PICK_COLONIES = auto()

    # pH adjustment
    ADJUST_PH = auto()

    # Heat treatment
    HEAT_SHOCK = auto()
    ON_ICE = auto()

    # PCR
    RUN_PCR = auto()


class StepStatus(Enum):
    """Status of a step in execution."""
    PENDING = auto()
    READY = auto()  # All dependencies met
    IN_PROGRESS = auto()
    COMPLETED = auto()
    FAILED = auto()
    SKIPPED = auto()


class TipPolicy(Enum):
    """Tip usage policy for transfers."""
    SINGLE_USE = auto()     # New tip per transfer
    REUSE_SOURCE = auto()   # Reuse tip for same source
    REUSE_DEST = auto()     # Reuse tip for same dest (e.g., distribute)
    ALWAYS_REUSE = auto()   # Never change tips (for serial dilution)


class MixMethod(Enum):
    """Methods for mixing."""
    PIPETTE = auto()        # Aspirate/dispense cycles
    SHAKE = auto()          # Orbital shaker
    VORTEX = auto()         # Vortex mixer
    STIR = auto()           # Magnetic stir bar


# ============================================================================
# References
# ============================================================================

@dataclass(frozen=True)
class WellRef:
    """Reference to a specific well."""
    plate_id: str
    well_id: str  # e.g., "A1", "H12"

    def __post_init__(self) -> None:
        object.__setattr__(self, "well_id", normalize_well_id(self.well_id))

    def __str__(self) -> str:
        return f"{self.plate_id}:{self.well_id}"

    def to_canonical(self, plate_format: str | None = None):
        """Convert to canonical location DTO."""
        return plan_well_ref_to_canonical(self, plate_format=plate_format)

    @classmethod
    def from_canonical(cls, address) -> "WellRef":
        """Create WellRef from canonical location DTO."""
        return cls(plate_id=address.labware_id, well_id=address.well)


@dataclass(frozen=True)
class ContainerRef:
    """Reference to a container (tube, reservoir, etc.)."""
    container_id: str
    container_type: str = "tube"

    def __str__(self) -> str:
        return self.container_id


@dataclass(frozen=True)
class TipRackRef:
    """Reference to a tip rack."""
    rack_id: str
    tip_type: str  # e.g., "tips_300", "tips_1000"

    def __str__(self) -> str:
        return f"{self.rack_id}({self.tip_type})"


Location = Union[WellRef, ContainerRef]


# ============================================================================
# Primitives
# ============================================================================

@dataclass
class Aspirate:
    """Aspirate liquid from a location."""
    source: Location
    volume_ul: float
    flow_rate_ul_s: Optional[float] = None
    air_gap_ul: Optional[float] = None
    touch_tip: bool = False

    primitive_type: PrimitiveType = field(default=PrimitiveType.ASPIRATE, init=False)


@dataclass
class Dispense:
    """Dispense liquid to a location."""
    destination: Location
    volume_ul: float
    flow_rate_ul_s: Optional[float] = None
    touch_tip: bool = False
    blow_out: bool = False

    primitive_type: PrimitiveType = field(default=PrimitiveType.DISPENSE, init=False)


@dataclass
class Mix:
    """Mix contents at a location."""
    location: Location
    volume_ul: float
    cycles: int = 3
    flow_rate_ul_s: Optional[float] = None
    method: MixMethod = MixMethod.PIPETTE

    primitive_type: PrimitiveType = field(default=PrimitiveType.MIX, init=False)


@dataclass
class PickTips:
    """Pick up tips from a tip rack."""
    tip_rack: TipRackRef
    tip_positions: List[str]  # e.g., ["A1", "A2"]

    primitive_type: PrimitiveType = field(default=PrimitiveType.PICK_TIPS, init=False)


@dataclass
class DropTips:
    """Drop tips to waste or back to rack."""
    to_waste: bool = True
    return_rack: Optional[TipRackRef] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.DROP_TIPS, init=False)


@dataclass
class MoveLabware:
    """Move labware from one deck position to another."""
    labware_id: str
    from_position: str
    to_position: str

    primitive_type: PrimitiveType = field(default=PrimitiveType.MOVE_LABWARE, init=False)


@dataclass
class SealPlate:
    """Seal a plate."""
    plate_id: str
    seal_type: str = "adhesive"  # adhesive, foil, lid

    primitive_type: PrimitiveType = field(default=PrimitiveType.SEAL_PLATE, init=False)


@dataclass
class UnsealPlate:
    """Remove seal from a plate."""
    plate_id: str

    primitive_type: PrimitiveType = field(default=PrimitiveType.UNSEAL_PLATE, init=False)


@dataclass
class ReadAbsorbance:
    """Read absorbance on plate reader."""
    plate_id: str
    wavelength_nm: float
    wells: Optional[List[str]] = None  # None = all wells

    primitive_type: PrimitiveType = field(default=PrimitiveType.READ_ABSORBANCE, init=False)


@dataclass
class ReadFluorescence:
    """Read fluorescence on plate reader."""
    plate_id: str
    excitation_nm: float
    emission_nm: float
    wells: Optional[List[str]] = None
    gain: Optional[float] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.READ_FLUORESCENCE, init=False)


@dataclass
class Weigh:
    """Weigh a container on a balance."""
    container_id: str
    tare: bool = False

    primitive_type: PrimitiveType = field(default=PrimitiveType.WEIGH, init=False)


@dataclass
class SetTemperature:
    """Set temperature of a thermal block/incubator."""
    device_id: str
    temperature_c: float

    primitive_type: PrimitiveType = field(default=PrimitiveType.SET_TEMPERATURE, init=False)


@dataclass
class Incubate:
    """Incubate at temperature for duration."""
    device_id: str
    temperature_c: float
    duration_s: float
    shake_rpm: Optional[float] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.INCUBATE, init=False)


@dataclass
class Centrifuge:
    """Centrifuge samples."""
    device_id: str
    speed_rcf: float
    duration_s: float
    temperature_c: Optional[float] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.CENTRIFUGE, init=False)


@dataclass
class HumanStep:
    """A step requiring human intervention."""
    instruction: str
    expected_time_s: Optional[float] = None
    checklist: List[str] = field(default_factory=list)
    data_fields: Dict[str, str] = field(default_factory=dict)
    safety_tags: List[str] = field(default_factory=list)
    requires_confirmation: bool = True

    primitive_type: PrimitiveType = field(default=PrimitiveType.HUMAN_STEP, init=False)


@dataclass
class Pause:
    """Pause execution for human intervention."""
    reason: str
    requires_deck_confirmation: bool = True

    primitive_type: PrimitiveType = field(default=PrimitiveType.PAUSE, init=False)


@dataclass
class Resume:
    """Resume execution after pause."""
    deck_state_verified: bool = False

    primitive_type: PrimitiveType = field(default=PrimitiveType.RESUME, init=False)


@dataclass
class Wait:
    """Wait for specified duration."""
    duration_s: float

    primitive_type: PrimitiveType = field(default=PrimitiveType.WAIT, init=False)


@dataclass
class Checkpoint:
    """Create a recoverable checkpoint."""
    checkpoint_id: str
    state_hash: Optional[str] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.CHECKPOINT, init=False)


@dataclass
class PickColonies:
    """Pick colonies from a plate."""
    source_plate: str
    well_id: str
    destination: Location
    count: int = 1
    selection_criteria: str = "largest"  # largest, random, morphology

    primitive_type: PrimitiveType = field(default=PrimitiveType.PICK_COLONIES, init=False)


@dataclass
class AdjustPH:
    """Adjust pH of a solution."""
    container_id: str
    target_ph: float
    tolerance: float = 0.1
    acid_reagent: Optional[str] = None
    base_reagent: Optional[str] = None

    primitive_type: PrimitiveType = field(default=PrimitiveType.ADJUST_PH, init=False)


@dataclass
class HeatShock:
    """Heat shock transformation step."""
    target: Location
    temperature_c: float = 42.0
    duration_s: float = 60.0
    device_id: str = "water_bath"

    primitive_type: PrimitiveType = field(default=PrimitiveType.HEAT_SHOCK, init=False)


@dataclass
class OnIce:
    """Place sample on ice."""
    target: Location
    duration_s: float = 120.0

    primitive_type: PrimitiveType = field(default=PrimitiveType.ON_ICE, init=False)


@dataclass
class PcrCycleStep:
    """A single step within PCR cycling."""
    name: str  # denature, anneal, extend
    temperature_c: float
    duration_s: float


@dataclass
class RunPCR:
    """Run a PCR program."""
    plate_id: str
    device_id: str = "thermocycler"
    initial_temp_c: Optional[float] = None
    initial_duration_s: Optional[float] = None
    cycle_count: int = 30
    cycle_steps: List[PcrCycleStep] = field(default_factory=list)
    final_temp_c: Optional[float] = None
    final_duration_s: Optional[float] = None
    hold_temp_c: Optional[float] = 4.0
    lid_temp_c: Optional[float] = 105.0

    primitive_type: PrimitiveType = field(default=PrimitiveType.RUN_PCR, init=False)


# Union of all primitive types
Primitive = Union[
    Aspirate, Dispense, Mix,
    PickTips, DropTips,
    MoveLabware, SealPlate, UnsealPlate,
    ReadAbsorbance, ReadFluorescence, Weigh,
    SetTemperature, Incubate, Centrifuge,
    HumanStep, Pause, Resume, Wait, Checkpoint,
    PickColonies, AdjustPH, HeatShock, OnIce, RunPCR
]


# ============================================================================
# Plan Steps
# ============================================================================

@dataclass
class PlanStep:
    """A single step in the execution plan."""
    step_id: str
    primitive: Primitive
    dependencies: List[str] = field(default_factory=list)  # step_ids
    status: StepStatus = StepStatus.PENDING

    # Execution tracking
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    # Metadata
    source_intent: Optional[str] = None  # Original intent that generated this step
    annotations: Dict[str, Any] = field(default_factory=dict)

    def is_ready(self, completed_steps: set) -> bool:
        """Check if all dependencies are met."""
        return all(dep in completed_steps for dep in self.dependencies)

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "step_id": self.step_id,
            "primitive_type": self.primitive.primitive_type.name,
            "dependencies": self.dependencies,
            "status": self.status.name,
            "source_intent": self.source_intent,
        }


@dataclass
class StepGroup:
    """A group of steps that can be executed in parallel."""
    group_id: str
    steps: List[PlanStep]
    description: str = ""

    @property
    def all_completed(self) -> bool:
        return all(s.status == StepStatus.COMPLETED for s in self.steps)


# ============================================================================
# Execution Plan
# ============================================================================

@dataclass
class ExecutionPlan:
    """
    A complete execution plan as a DAG of steps.

    The plan is generated by lowering intents to primitives and can be:
    - Executed by robot runtime
    - Executed by human runtime
    - Simulated for validation
    """
    plan_id: str
    steps: Dict[str, PlanStep] = field(default_factory=dict)

    # Metadata
    protocol_name: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    target: str = "human"  # "human" | "robot" | "hybrid"

    # Execution state
    current_step: Optional[str] = None
    completed_steps: set = field(default_factory=set)

    def add_step(self, step: PlanStep) -> None:
        """Add a step to the plan."""
        if step.step_id in self.steps:
            raise ValueError(f"Duplicate step_id '{step.step_id}' in execution plan.")
        self.steps[step.step_id] = step

    def get_ready_steps(self) -> List[PlanStep]:
        """Get all steps that are ready to execute."""
        return [
            step for step in self.steps.values()
            if step.status == StepStatus.PENDING and step.is_ready(self.completed_steps)
        ]

    def mark_completed(self, step_id: str, result: Optional[Dict] = None) -> None:
        """Mark a step as completed."""
        if step_id in self.steps:
            self.steps[step_id].status = StepStatus.COMPLETED
            self.steps[step_id].completed_at = datetime.now()
            self.steps[step_id].result = result
            self.completed_steps.add(step_id)

    def mark_failed(self, step_id: str, error: str) -> None:
        """Mark a step as failed."""
        if step_id in self.steps:
            self.steps[step_id].status = StepStatus.FAILED
            self.steps[step_id].error = error

    @property
    def is_complete(self) -> bool:
        """Check if all steps are completed."""
        return all(s.status == StepStatus.COMPLETED for s in self.steps.values())

    @property
    def has_failures(self) -> bool:
        """Check if any steps failed."""
        return any(s.status == StepStatus.FAILED for s in self.steps.values())

    def topological_order(self) -> List[str]:
        """Get a deterministic topological order respecting dependencies."""
        step_ids = sorted(self.steps)
        indegree = {step_id: 0 for step_id in step_ids}
        dependents: Dict[str, List[str]] = {step_id: [] for step_id in step_ids}

        for step_id in step_ids:
            for dependency in sorted(self.steps[step_id].dependencies):
                if dependency in self.steps:
                    indegree[step_id] += 1
                    dependents[dependency].append(step_id)

        for dependent_ids in dependents.values():
            dependent_ids.sort()

        ready = sorted(step_id for step_id, degree in indegree.items() if degree == 0)
        order: List[str] = []

        while ready:
            current = ready.pop(0)
            order.append(current)
            for dependent in dependents[current]:
                indegree[dependent] -= 1
                if indegree[dependent] == 0:
                    bisect.insort(ready, dependent)

        if len(order) != len(step_ids):
            remaining = sorted(set(step_ids) - set(order))
            raise ValueError(f"Cycle detected in execution plan among steps: {remaining}")

        return order

    def compute_hash(self) -> str:
        """Compute hash of the plan for integrity checking."""
        steps_data = [
            self.steps[sid].to_dict()
            for sid in self.topological_order()
        ]
        data = {
            "plan_id": self.plan_id,
            "protocol_name": self.protocol_name,
            "target": self.target,
            "steps": steps_data,
        }
        json_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def get_step_count(self) -> int:
        """Get total number of steps."""
        return len(self.steps)

    def get_primitive_counts(self) -> Dict[str, int]:
        """Get count of each primitive type."""
        counts: Dict[str, int] = {}
        for step in self.steps.values():
            ptype = step.primitive.primitive_type.name
            counts[ptype] = counts.get(ptype, 0) + 1
        return counts

    def __repr__(self) -> str:
        return f"ExecutionPlan({self.plan_id}, {len(self.steps)} steps, target={self.target})"
