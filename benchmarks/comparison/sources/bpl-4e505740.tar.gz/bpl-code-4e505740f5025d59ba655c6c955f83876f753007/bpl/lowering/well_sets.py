"""
BPL Well Sets - Library functions for well addressing.

Provides runtime functions for specifying wells without grammar changes:
- well_range(): Select a rectangular range of wells
- cherry_pick(): Select specific individual wells
- column(): Select all wells in a column
- row(): Select all wells in a row
- quadrant(): Select a quadrant (for 384->96 stamping)
- wells(): General-purpose well specification
"""

from dataclasses import dataclass, field
from typing import List, Optional, Union, Iterator, Tuple
from enum import Enum

from bpl.location import (
    normalize_well_id,
    row_index_to_label,
    row_label_to_index,
    well_from_coordinates,
    well_to_coordinates,
)


class PlateFormat(Enum):
    """Standard plate formats."""
    PLATE_6 = (2, 3)      # 2 rows x 3 cols
    PLATE_12 = (3, 4)     # 3 rows x 4 cols
    PLATE_24 = (4, 6)     # 4 rows x 6 cols
    PLATE_48 = (6, 8)     # 6 rows x 8 cols
    PLATE_96 = (8, 12)    # 8 rows x 12 cols
    PLATE_384 = (16, 24)  # 16 rows x 24 cols
    PLATE_1536 = (32, 48) # 32 rows x 48 cols

    @property
    def rows(self) -> int:
        return self.value[0]

    @property
    def cols(self) -> int:
        return self.value[1]

    @property
    def well_count(self) -> int:
        return self.rows * self.cols


@dataclass
class WellSet:
    """
    A set of wells on a plate.

    Supports iteration, containment checks, and set operations.
    Wells are stored in row-major order (A1, A2, ..., B1, B2, ...).
    """
    plate_id: str
    wells: List[str] = field(default_factory=list)
    plate_format: PlateFormat = PlateFormat.PLATE_96

    def __post_init__(self):
        # Normalize well IDs to canonical uppercase + non-padded columns
        self.wells = [normalize_well_id(w) for w in self.wells]

    def __iter__(self) -> Iterator[str]:
        return iter(self.wells)

    def __len__(self) -> int:
        return len(self.wells)

    def __contains__(self, well: str) -> bool:
        return well.upper() in self.wells

    def __add__(self, other: "WellSet") -> "WellSet":
        """Union of two well sets (must be same plate)."""
        if self.plate_id != other.plate_id:
            raise ValueError(f"Cannot combine wells from different plates: {self.plate_id} vs {other.plate_id}")
        combined = list(dict.fromkeys(self.wells + other.wells))  # Preserve order, remove duplicates
        return WellSet(self.plate_id, combined, self.plate_format)

    def __sub__(self, other: "WellSet") -> "WellSet":
        """Difference of two well sets."""
        if self.plate_id != other.plate_id:
            raise ValueError("Cannot subtract wells from different plates")
        remaining = [w for w in self.wells if w not in other.wells]
        return WellSet(self.plate_id, remaining, self.plate_format)

    def __and__(self, other: "WellSet") -> "WellSet":
        """Intersection of two well sets."""
        if self.plate_id != other.plate_id:
            raise ValueError("Cannot intersect wells from different plates")
        common = [w for w in self.wells if w in other.wells]
        return WellSet(self.plate_id, common, self.plate_format)

    def __repr__(self) -> str:
        if len(self.wells) <= 5:
            return f"WellSet({self.plate_id}, {self.wells})"
        return f"WellSet({self.plate_id}, [{self.wells[0]}...{self.wells[-1]}], n={len(self.wells)})"

    @property
    def first(self) -> Optional[str]:
        """Get first well in set."""
        return self.wells[0] if self.wells else None

    @property
    def last(self) -> Optional[str]:
        """Get last well in set."""
        return self.wells[-1] if self.wells else None

    def as_tuples(self) -> List[Tuple[str, str]]:
        """Return as list of (plate_id, well_id) tuples."""
        return [(self.plate_id, w) for w in self.wells]


class WellAddressingError(Exception):
    """Error in well addressing."""
    pass


def _parse_well(well_id: str) -> Tuple[int, int]:
    """Parse well ID to (row_index, col_index), 0-based."""
    try:
        return well_to_coordinates(well_id)
    except ValueError as exc:
        raise WellAddressingError(str(exc)) from exc


def _format_well(row: int, col: int) -> str:
    """Format (row_index, col_index) to well ID."""
    try:
        return well_from_coordinates(row, col)
    except ValueError as exc:
        raise WellAddressingError(str(exc)) from exc


def _validate_well(row: int, col: int, plate_format: PlateFormat) -> None:
    """Validate well is within plate bounds."""
    if row < 0 or row >= plate_format.rows:
        row_label = row_index_to_label(row) if row >= 0 else f"index_{row}"
        raise WellAddressingError(
            f"Row {row_label} out of range for {plate_format.name} "
            f"(max row: {row_index_to_label(plate_format.rows - 1)})"
        )
    if col < 0 or col >= plate_format.cols:
        raise WellAddressingError(
            f"Column {col + 1} out of range for {plate_format.name} "
            f"(max column: {plate_format.cols})"
        )


# =============================================================================
# Library Functions
# =============================================================================

def well_range(
    plate_id: str,
    start: str,
    end: str,
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select a rectangular range of wells.

    Args:
        plate_id: Plate identifier
        start: Top-left well (e.g., "A1")
        end: Bottom-right well (e.g., "H12")
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing all wells in the rectangle

    Examples:
        well_range("Plate1", "A1", "A12")  # Row A
        well_range("Plate1", "A1", "H1")   # Column 1
        well_range("Plate1", "A1", "D6")   # 4x6 block
    """
    start_row, start_col = _parse_well(start)
    end_row, end_col = _parse_well(end)

    _validate_well(start_row, start_col, plate_format)
    _validate_well(end_row, end_col, plate_format)

    if start_row > end_row:
        raise WellAddressingError(f"Start row must be <= end row: {start} to {end}")
    if start_col > end_col:
        raise WellAddressingError(f"Start column must be <= end column: {start} to {end}")

    wells = []
    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            wells.append(_format_well(row, col))

    return WellSet(plate_id, wells, plate_format)


def cherry_pick(
    plate_id: str,
    wells: List[str],
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select specific individual wells (cherry-picking).

    Args:
        plate_id: Plate identifier
        wells: List of well IDs to select
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing the specified wells

    Examples:
        cherry_pick("Plate1", ["A1", "B3", "D5", "H12"])
        cherry_pick("Plate1", ["A1", "A3", "A5"])  # Every other well in row A
    """
    validated_wells = []
    for well in wells:
        row, col = _parse_well(well)
        _validate_well(row, col, plate_format)
        validated_wells.append(_format_well(row, col))

    return WellSet(plate_id, validated_wells, plate_format)


def column(
    plate_id: str,
    col_num: int,
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select all wells in a column.

    Args:
        plate_id: Plate identifier
        col_num: Column number (1-based)
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing all wells in the column

    Examples:
        column("Plate1", 1)   # A1, B1, C1, ..., H1
        column("Plate1", 12)  # A12, B12, ..., H12
    """
    col_idx = col_num - 1
    if col_idx < 0 or col_idx >= plate_format.cols:
        raise WellAddressingError(
            f"Column {col_num} out of range for {plate_format.name} (1-{plate_format.cols})"
        )

    wells = [_format_well(row, col_idx) for row in range(plate_format.rows)]
    return WellSet(plate_id, wells, plate_format)


def row(
    plate_id: str,
    row_id: Union[str, int],
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select all wells in a row.

    Args:
        plate_id: Plate identifier
        row_id: Row letter ('A'-'P') or number (1-16)
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing all wells in the row

    Examples:
        row("Plate1", "A")  # A1, A2, A3, ..., A12
        row("Plate1", 1)    # Same as row("Plate1", "A")
    """
    if isinstance(row_id, str):
        try:
            row_idx = row_label_to_index(row_id)
        except ValueError as exc:
            raise WellAddressingError(str(exc)) from exc
    else:
        row_idx = row_id - 1

    if row_idx < 0 or row_idx >= plate_format.rows:
        raise WellAddressingError(
            f"Row {row_id} out of range for {plate_format.name} "
            f"(A-{row_index_to_label(plate_format.rows - 1)})"
        )

    wells = [_format_well(row_idx, col) for col in range(plate_format.cols)]
    return WellSet(plate_id, wells, plate_format)


def quadrant(
    plate_id: str,
    quadrant_num: int,
    source_format: PlateFormat = PlateFormat.PLATE_384,
    dest_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select a quadrant for 384->96 (or similar) stamping.

    Quadrant numbering:
        1 = Top-left (A1, A3, A5, ... C1, C3, C5, ...)
        2 = Top-right (A2, A4, A6, ... C2, C4, C6, ...)
        3 = Bottom-left (B1, B3, B5, ... D1, D3, D5, ...)
        4 = Bottom-right (B2, B4, B6, ... D2, D4, D6, ...)

    Args:
        plate_id: Plate identifier
        quadrant_num: Quadrant number (1-4)
        source_format: Source plate format (default 384-well)
        dest_format: Destination plate format (default 96-well)

    Returns:
        WellSet containing wells in the quadrant

    Examples:
        quadrant("Plate384", 1)  # Top-left quadrant
        quadrant("Plate384", 4)  # Bottom-right quadrant
    """
    if quadrant_num < 1 or quadrant_num > 4:
        raise WellAddressingError(f"Quadrant must be 1-4, got {quadrant_num}")

    # Determine row/col offsets based on quadrant
    row_offset = 0 if quadrant_num in (1, 2) else 1
    col_offset = 0 if quadrant_num in (1, 3) else 1

    wells = []
    for r in range(dest_format.rows):
        for c in range(dest_format.cols):
            # Map to 384-well position
            src_row = r * 2 + row_offset
            src_col = c * 2 + col_offset
            if src_row < source_format.rows and src_col < source_format.cols:
                wells.append(_format_well(src_row, src_col))

    return WellSet(plate_id, wells, source_format)


def wells(
    plate_id: str,
    spec: str,
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    General-purpose well specification parser.

    Supports:
        - Single well: "A1"
        - Range: "A1:H12"
        - Column: "Column1" or "Col1"
        - Row: "RowA" or "Row1"
        - All: "All"
        - Comma-separated: "A1,B2,C3"

    Args:
        plate_id: Plate identifier
        spec: Well specification string
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet based on specification

    Examples:
        wells("Plate1", "A1:A12")      # Row A
        wells("Plate1", "Column1")     # Column 1
        wells("Plate1", "A1,B3,D5")    # Cherry-pick
        wells("Plate1", "All")         # All wells
    """
    spec = spec.strip()

    # Comma-separated (cherry-pick)
    if ',' in spec:
        well_list = [w.strip() for w in spec.split(',')]
        return cherry_pick(plate_id, well_list, plate_format)

    # Range (A1:H12)
    if ':' in spec:
        parts = spec.split(':')
        if len(parts) == 2:
            return well_range(plate_id, parts[0].strip(), parts[1].strip(), plate_format)

    # Column
    if spec.lower().startswith('col'):
        col_str = spec[3:] if spec.lower().startswith('col') else spec[6:]
        col_str = ''.join(filter(str.isdigit, col_str))
        if col_str:
            return column(plate_id, int(col_str), plate_format)

    # Row
    if spec.lower().startswith('row'):
        row_str = spec[3:]
        if row_str.isalpha():
            return row(plate_id, row_str, plate_format)
        elif row_str.isdigit():
            return row(plate_id, int(row_str), plate_format)

    # All wells
    if spec.lower() == 'all':
        return well_range(
            plate_id,
            "A1",
            _format_well(plate_format.rows - 1, plate_format.cols - 1),
            plate_format
        )

    # Single well
    if len(spec) <= 3 and spec[0].isalpha() and spec[1:].isdigit():
        return cherry_pick(plate_id, [spec], plate_format)

    raise WellAddressingError(f"Invalid well specification: {spec}")


def all_wells(
    plate_id: str,
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select all wells on a plate.

    Args:
        plate_id: Plate identifier
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing all wells
    """
    return wells(plate_id, "All", plate_format)


def every_nth_well(
    plate_id: str,
    n: int,
    start: str = "A1",
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> WellSet:
    """
    Select every Nth well starting from a given position.

    Useful for replicates or interleaved patterns.

    Args:
        plate_id: Plate identifier
        n: Step size
        start: Starting well
        plate_format: Plate format (default 96-well)

    Returns:
        WellSet containing every Nth well
    """
    start_row, start_col = _parse_well(start)
    start_idx = start_row * plate_format.cols + start_col

    selected_wells = []
    total_wells = plate_format.well_count

    for idx in range(start_idx, total_wells, n):
        row = idx // plate_format.cols
        col = idx % plate_format.cols
        if row < plate_format.rows:
            selected_wells.append(_format_well(row, col))

    return WellSet(plate_id, selected_wells, plate_format)


def stamp_pattern(
    source_plate: str,
    dest_plate: str,
    source_start: str = "A1",
    dest_start: str = "A1",
    rows: int = 8,
    cols: int = 12,
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> List[Tuple[WellSet, WellSet]]:
    """
    Generate source/destination pairs for a stamp transfer.

    A stamp transfers a rectangular block of wells maintaining relative positions.

    Args:
        source_plate: Source plate ID
        dest_plate: Destination plate ID
        source_start: Top-left well of source block
        dest_start: Top-left well of destination block
        rows: Number of rows to stamp
        cols: Number of columns to stamp
        plate_format: Plate format

    Returns:
        List of (source_wellset, dest_wellset) pairs for the stamp operation
    """
    src_row, src_col = _parse_well(source_start)
    dst_row, dst_col = _parse_well(dest_start)

    source_end = _format_well(src_row + rows - 1, src_col + cols - 1)
    dest_end = _format_well(dst_row + rows - 1, dst_col + cols - 1)

    source_wells = well_range(source_plate, source_start, source_end, plate_format)
    dest_wells = well_range(dest_plate, dest_start, dest_end, plate_format)

    return [(source_wells, dest_wells)]


def serial_dilution_wells(
    plate_id: str,
    start_col: int = 1,
    end_col: int = 12,
    rows: Union[str, List[str]] = "A",
    plate_format: PlateFormat = PlateFormat.PLATE_96
) -> List[Tuple[WellSet, WellSet]]:
    """
    Generate well pairs for serial dilution across columns.

    Args:
        plate_id: Plate identifier
        start_col: Starting column (1-based)
        end_col: Ending column (1-based)
        rows: Row(s) to dilute - single row letter or list
        plate_format: Plate format

    Returns:
        List of (source_wellset, dest_wellset) pairs for each dilution step
    """
    if isinstance(rows, str):
        rows = [rows]

    pairs = []
    for col in range(start_col, end_col):
        source_wells = []
        dest_wells = []
        for r in rows:
            row_idx = ord(r.upper()) - ord('A')
            source_wells.append(_format_well(row_idx, col - 1))
            dest_wells.append(_format_well(row_idx, col))

        pairs.append((
            WellSet(plate_id, source_wells, plate_format),
            WellSet(plate_id, dest_wells, plate_format)
        ))

    return pairs
