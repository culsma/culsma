"""
BPL Collection Semantics - Handles WellSet/WellRef operations.

Defines how operations behave when sources/destinations are collections:
- Zip: 1:1 mapping (default for transfer)
- Broadcast: 1:N replication (default for distribute)
- Product: M×N cartesian product (advanced)
"""

from dataclasses import dataclass
from typing import List, Tuple, Optional
from enum import Enum, auto

from bpl.location import (
    normalize_well_id,
    row_label_to_index,
    well_from_coordinates,
    well_to_coordinates,
)


class Semantics(Enum):
    """Collection operation semantics."""
    ZIP = auto()        # 1:1 mapping (source[i] → dest[i])
    BROADCAST = auto()  # 1:N replication (source → each dest)
    PRODUCT = auto()    # M×N cartesian (each source → each dest)


@dataclass
class WellPair:
    """A source-destination well pair for a transfer operation."""
    source_plate: str
    source_well: str
    dest_plate: str
    dest_well: str

    def __str__(self) -> str:
        return f"{self.source_plate}:{self.source_well} → {self.dest_plate}:{self.dest_well}"


class CollectionSemanticsError(Exception):
    """Error in collection semantics processing."""
    pass


def expand_well_range(start: str, end: str) -> List[str]:
    """
    Expand a well range like 'A1:H12' to list of wells.

    Examples:
        'A1:A12' → ['A1', 'A2', ..., 'A12']
        'A1:H1' → ['A1', 'B1', ..., 'H1']
        'A1:H12' → ['A1', 'A2', ..., 'H12'] (row-major)
    """
    try:
        start_row, start_col = well_to_coordinates(start)
        end_row, end_col = well_to_coordinates(end)
    except ValueError as exc:
        raise CollectionSemanticsError(str(exc)) from exc

    # Validate
    if start_row > end_row or start_col > end_col:
        raise CollectionSemanticsError(
            f"Invalid well range: {start}:{end} (start must be <= end)"
        )

    # Generate wells (row-major order)
    wells = []
    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            well_id = well_from_coordinates(row, col)
            wells.append(well_id)

    return wells


def expand_wells(wells_spec: str) -> List[str]:
    """
    Expand a wells specification to a list of well IDs.

    Supports:
    - Single well: 'A1'
    - Range: 'A1:H12'
    - Column: 'Column1' or 'Col1'
    - Row: 'RowA' or 'Row1'
    - All: 'All'

    Returns list of well IDs.
    """
    wells_spec = wells_spec.strip()

    # Range (A1:H12)
    if ':' in wells_spec:
        parts = wells_spec.split(':')
        if len(parts) == 2:
            return expand_well_range(parts[0], parts[1])

    # Column (Column1, Col1)
    lower_spec = wells_spec.lower()
    if lower_spec.startswith('column') or lower_spec.startswith('col'):
        col_str = wells_spec[6:] if lower_spec.startswith('column') else wells_spec[3:]
        col_str = ''.join(filter(str.isdigit, col_str))
        if col_str:
            col = int(col_str)
            return [well_from_coordinates(row, col - 1) for row in range(8)]

    # Row (RowA, Row1)
    if wells_spec.lower().startswith('row'):
        row_str = wells_spec[3:]
        if row_str.isalpha():
            try:
                row_index = row_label_to_index(row_str)
            except ValueError as exc:
                raise CollectionSemanticsError(str(exc)) from exc
            return [well_from_coordinates(row_index, col) for col in range(12)]
        elif row_str.isdigit():
            row_index = int(row_str) - 1
            if row_index < 0:
                raise CollectionSemanticsError(f"Invalid row index in spec: {wells_spec}")
            return [well_from_coordinates(row_index, col) for col in range(12)]

    # All wells (96-well plate default)
    if wells_spec.lower() == 'all':
        return expand_well_range('A1', 'H12')

    # Single well
    try:
        return [normalize_well_id(wells_spec)]
    except ValueError:
        pass

    raise CollectionSemanticsError(f"Invalid wells specification: {wells_spec}")


def apply_zip_semantics(
    source_wells: List[str],
    dest_wells: List[str],
    source_plate: str,
    dest_plate: str
) -> List[WellPair]:
    """
    Apply ZIP semantics: source[i] → dest[i].

    Requires source and destination to have equal counts.
    """
    if len(source_wells) != len(dest_wells):
        raise CollectionSemanticsError(
            f"Zip semantics requires equal counts: "
            f"source has {len(source_wells)} wells, dest has {len(dest_wells)} wells"
        )

    return [
        WellPair(source_plate, src, dest_plate, dst)
        for src, dst in zip(source_wells, dest_wells)
    ]


def apply_broadcast_semantics(
    source_wells: List[str],
    dest_wells: List[str],
    source_plate: str,
    dest_plate: str
) -> List[WellPair]:
    """
    Apply BROADCAST semantics: each source → all destinations.

    If multiple sources, each source is broadcast to all destinations.
    """
    pairs = []
    for src in source_wells:
        for dst in dest_wells:
            pairs.append(WellPair(source_plate, src, dest_plate, dst))
    return pairs


def apply_product_semantics(
    source_wells: List[str],
    dest_wells: List[str],
    source_plate: str,
    dest_plate: str,
    max_operations: int = 1536
) -> List[WellPair]:
    """
    Apply PRODUCT semantics: M sources × N destinations.

    Generates all combinations. Warns if large, errors if too large.
    """
    total = len(source_wells) * len(dest_wells)

    if total > max_operations:
        raise CollectionSemanticsError(
            f"Product semantics would generate {total} operations (max {max_operations})"
        )

    pairs = []
    for src in source_wells:
        for dst in dest_wells:
            pairs.append(WellPair(source_plate, src, dest_plate, dst))
    return pairs


def infer_semantics(
    intent_type: str,
    source_count: int,
    dest_count: int
) -> Semantics:
    """
    Infer default semantics based on intent type and counts.

    Rules:
    - transfer: ZIP (1:1 required)
    - distribute: BROADCAST (1:N)
    - consolidate: Special case (N:1)
    """
    if intent_type == 'transfer':
        if source_count == 1 and dest_count > 1:
            raise CollectionSemanticsError(
                "transfer() cannot be used for one-to-many. "
                "Use distribute() instead."
            )
        return Semantics.ZIP

    if intent_type == 'distribute':
        return Semantics.BROADCAST

    if intent_type == 'consolidate':
        return Semantics.BROADCAST  # All sources to single dest

    # Default to ZIP
    return Semantics.ZIP


def expand_collection_operation(
    intent_type: str,
    source_spec: str,
    source_plate: str,
    dest_spec: str,
    dest_plate: str,
    semantics: Optional[Semantics] = None
) -> List[WellPair]:
    """
    Expand a collection operation to individual well pairs.

    Args:
        intent_type: 'transfer', 'distribute', or 'consolidate'
        source_spec: Source wells specification
        source_plate: Source plate ID
        dest_spec: Destination wells specification
        dest_plate: Destination plate ID
        semantics: Explicit semantics override (or None to infer)

    Returns:
        List of WellPair for each individual operation
    """
    source_wells = expand_wells(source_spec)
    dest_wells = expand_wells(dest_spec)

    # Infer semantics if not explicit
    if semantics is None:
        semantics = infer_semantics(intent_type, len(source_wells), len(dest_wells))

    # Apply semantics
    if semantics == Semantics.ZIP:
        return apply_zip_semantics(source_wells, dest_wells, source_plate, dest_plate)
    elif semantics == Semantics.BROADCAST:
        return apply_broadcast_semantics(source_wells, dest_wells, source_plate, dest_plate)
    elif semantics == Semantics.PRODUCT:
        return apply_product_semantics(source_wells, dest_wells, source_plate, dest_plate)
    else:
        raise CollectionSemanticsError(f"Unknown semantics: {semantics}")


def validate_collection_semantics(
    semantics: Semantics,
    source_count: int,
    dest_count: int
) -> Tuple[bool, Optional[str]]:
    """
    Validate that the semantics makes sense for the given counts.

    Returns:
        (is_valid, error_message or None)
    """
    if semantics == Semantics.ZIP:
        if source_count != dest_count:
            return (False, f"Zip semantics requires equal counts ({source_count} vs {dest_count})")
        return (True, None)

    if semantics == Semantics.BROADCAST:
        if source_count > 1 and dest_count > 1:
            # M:N broadcast is really product semantics
            return (True, f"Warning: Broadcasting {source_count} sources to {dest_count} "
                         f"destinations creates {source_count * dest_count} operations")
        return (True, None)

    if semantics == Semantics.PRODUCT:
        total = source_count * dest_count
        if total > 1536:
            return (False, f"Product semantics would create {total} operations (max 1536)")
        if total > 384:
            return (True, f"Warning: Product semantics creates {total} operations")
        return (True, None)

    return (True, None)


# Convenience functions for common patterns

def zip_transfer(
    from_wells: List[str],
    to_wells: List[str],
    from_plate: str,
    to_plate: str
) -> List[WellPair]:
    """Create 1:1 transfer pairs."""
    return apply_zip_semantics(from_wells, to_wells, from_plate, to_plate)


def distribute_to_all(
    source_well: str,
    dest_wells: List[str],
    source_plate: str,
    dest_plate: str
) -> List[WellPair]:
    """Distribute from single source to all destinations."""
    return apply_broadcast_semantics([source_well], dest_wells, source_plate, dest_plate)


def pool_to_single(
    source_wells: List[str],
    dest_well: str,
    source_plate: str,
    dest_plate: str
) -> List[WellPair]:
    """Pool from multiple sources to single destination."""
    return [
        WellPair(source_plate, src, dest_plate, dest_well)
        for src in source_wells
    ]
