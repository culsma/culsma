"""
BPL Intent Lowerer - Converts high-level intents to primitive operations.

Intent Layer (user-facing):
    add(), transfer(), distribute(), mix(), inoculate(), dilute(), measure()

Lowered to Primitive Layer (executable):
    aspirate(), dispense(), pick_tips(), drop_tips(), pipette_mix(), etc.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum, auto

from bpl.location import normalize_well_id, well_to_coordinates

from .plan_ir import (
    ExecutionPlan, PlanStep, Aspirate, Dispense, Mix, PickTips, DropTips,
    Weigh, SetTemperature, Incubate, HumanStep, Pause, Resume, Checkpoint,
    PickColonies, AdjustPH, HeatShock, OnIce, RunPCR,
    PcrCycleStep as PcrCycleStepPrimitive,
    WellRef, ContainerRef, TipRackRef, Location,
    TipPolicy, MixMethod,
)
from .collection_semantics import (
    Semantics, WellPair, expand_collection_operation
)


class PhysicalForm(Enum):
    """Physical form of a reagent."""
    SOLID = auto()
    LIQUID = auto()
    GAS = auto()


@dataclass
class ReagentInfo:
    """Information about a reagent for lowering decisions."""
    reagent_id: str
    physical_form: PhysicalForm
    mw: Optional[float] = None  # Molecular weight in g/mol
    concentration: Optional[float] = None  # For stocks
    fold: Optional[int] = None  # For stock solutions (e.g., 1000X)


@dataclass
class LoweringContext:
    """Context for lowering intents to primitives."""
    target: str = "human"  # "human" | "robot" | "hybrid"
    tip_policy: TipPolicy = TipPolicy.SINGLE_USE
    default_flow_rate: float = 100.0  # uL/s
    default_mix_cycles: int = 3
    available_tip_racks: List[TipRackRef] = field(default_factory=list)
    exclusive_resource_keys: List[str] = field(default_factory=list)
    reagent_info: Dict[str, ReagentInfo] = field(default_factory=dict)

    # Step counter for generating unique IDs
    _step_counter: int = 0

    def next_step_id(self, prefix: str = "step") -> str:
        """Generate the next unique step ID."""
        self._step_counter += 1
        return f"{prefix}_{self._step_counter}"


def collection_conflict_keys(
    pair: WellPair,
    *,
    exclusive_resource_keys: Optional[List[str]] = None,
) -> tuple[str, ...]:
    """
    Build deterministic conflict keys for collection dependency emission.

    Safety keys always include source/destination well identity. Additional
    exclusive resources can be declared by context and are included as
    deterministic resource keys.
    """
    normalized_source = normalize_well_id(pair.source_well)
    normalized_dest = normalize_well_id(pair.dest_well)
    resource_keys = sorted(set(exclusive_resource_keys or []))
    keys = [
        f"source:{pair.source_plate}:{normalized_source}",
        f"destination:{pair.dest_plate}:{normalized_dest}",
    ]
    keys.extend(f"resource:{resource_key}" for resource_key in resource_keys)
    return tuple(keys)


def _collection_pair_sort_key(pair: WellPair) -> tuple[str, int, int, str, int, int]:
    """Deterministic pair ordering before dependency generation."""
    source_row, source_col = well_to_coordinates(normalize_well_id(pair.source_well))
    dest_row, dest_col = well_to_coordinates(normalize_well_id(pair.dest_well))
    return (
        pair.source_plate,
        source_row,
        source_col,
        pair.dest_plate,
        dest_row,
        dest_col,
    )


class IntentLowerer:
    """
    Lowers high-level intents to executable primitives.

    Each intent method returns a list of PlanStep objects that
    can be added to an ExecutionPlan.
    """

    def __init__(self, context: Optional[LoweringContext] = None):
        self.context = context or LoweringContext()
        self.plan = ExecutionPlan(
            plan_id="plan_" + str(id(self)),
            target=self.context.target
        )

    def lower_add(
        self,
        source: str,
        destination: Location,
        volume_ul: Optional[float] = None,
        mass_g: Optional[float] = None,
        to_concentration: Optional[float] = None,
        fold: Optional[int] = None,
        mix_after: bool = False
    ) -> List[PlanStep]:
        """
        Lower add() intent to primitives.

        Add can be lowered to:
        - Solid: weigh + dissolve (manual)
        - Liquid: aspirate + dispense (pipette)
        """
        steps = []
        reagent_info = self.context.reagent_info.get(source)

        # Determine physical form
        physical_form = PhysicalForm.LIQUID
        if reagent_info:
            physical_form = reagent_info.physical_form

        if physical_form == PhysicalForm.SOLID:
            # Solid requires weighing
            if mass_g is None:
                raise ValueError(f"Solid reagent {source} requires mass parameter")

            # For robot, this is a human step
            if self.context.target in ["robot", "hybrid"]:
                steps.append(PlanStep(
                    step_id=self.context.next_step_id("pause"),
                    primitive=Pause(reason=f"Weigh {mass_g}g of {source}"),
                    source_intent="add"
                ))

            steps.append(PlanStep(
                step_id=self.context.next_step_id("weigh"),
                primitive=Weigh(container_id=source, tare=True),
                source_intent="add"
            ))

            steps.append(PlanStep(
                step_id=self.context.next_step_id("human"),
                primitive=HumanStep(
                    instruction=f"Add weighed {source} to destination",
                    checklist=["Verify mass on balance", "Transfer to container"]
                ),
                dependencies=[steps[-1].step_id],
                source_intent="add"
            ))

        else:
            # Liquid handling
            if volume_ul is None:
                raise ValueError(f"Liquid reagent {source} requires volume parameter")

            # Pick tips
            if self.context.available_tip_racks:
                tip_rack = self.context.available_tip_racks[0]
                pick_step = PlanStep(
                    step_id=self.context.next_step_id("pick"),
                    primitive=PickTips(tip_rack=tip_rack, tip_positions=["A1"]),
                    source_intent="add"
                )
                steps.append(pick_step)

            # Aspirate
            source_loc = ContainerRef(container_id=source)
            aspirate_step = PlanStep(
                step_id=self.context.next_step_id("aspirate"),
                primitive=Aspirate(
                    source=source_loc,
                    volume_ul=volume_ul,
                    flow_rate_ul_s=self.context.default_flow_rate
                ),
                dependencies=[steps[-1].step_id] if steps else [],
                source_intent="add"
            )
            steps.append(aspirate_step)

            # Dispense
            dispense_step = PlanStep(
                step_id=self.context.next_step_id("dispense"),
                primitive=Dispense(
                    destination=destination,
                    volume_ul=volume_ul,
                    flow_rate_ul_s=self.context.default_flow_rate,
                    blow_out=True
                ),
                dependencies=[aspirate_step.step_id],
                source_intent="add"
            )
            steps.append(dispense_step)

            # Mix after if requested
            if mix_after:
                mix_step = PlanStep(
                    step_id=self.context.next_step_id("mix"),
                    primitive=Mix(
                        location=destination,
                        volume_ul=volume_ul * 0.8,
                        cycles=self.context.default_mix_cycles
                    ),
                    dependencies=[dispense_step.step_id],
                    source_intent="add"
                )
                steps.append(mix_step)

            # Drop tips
            if self.context.tip_policy == TipPolicy.SINGLE_USE:
                drop_step = PlanStep(
                    step_id=self.context.next_step_id("drop"),
                    primitive=DropTips(to_waste=True),
                    dependencies=[steps[-1].step_id],
                    source_intent="add"
                )
                steps.append(drop_step)

        return steps

    def lower_transfer(
        self,
        from_location: Location,
        to_location: Location,
        volume_ul: float,
        mix_before: bool = False,
        mix_after: bool = False
    ) -> List[PlanStep]:
        """
        Lower transfer() intent to primitives.

        transfer = pick_tips + aspirate + dispense + drop_tips
        """
        steps = []

        # Pick tips
        if self.context.available_tip_racks:
            tip_rack = self.context.available_tip_racks[0]
            pick_step = PlanStep(
                step_id=self.context.next_step_id("pick"),
                primitive=PickTips(tip_rack=tip_rack, tip_positions=["A1"]),
                source_intent="transfer"
            )
            steps.append(pick_step)

        # Mix before if requested
        if mix_before:
            mix_step = PlanStep(
                step_id=self.context.next_step_id("mix_before"),
                primitive=Mix(
                    location=from_location,
                    volume_ul=volume_ul * 0.8,
                    cycles=self.context.default_mix_cycles
                ),
                dependencies=[steps[-1].step_id] if steps else [],
                source_intent="transfer"
            )
            steps.append(mix_step)

        # Aspirate
        aspirate_step = PlanStep(
            step_id=self.context.next_step_id("aspirate"),
            primitive=Aspirate(
                source=from_location,
                volume_ul=volume_ul,
                flow_rate_ul_s=self.context.default_flow_rate
            ),
            dependencies=[steps[-1].step_id] if steps else [],
            source_intent="transfer"
        )
        steps.append(aspirate_step)

        # Dispense
        dispense_step = PlanStep(
            step_id=self.context.next_step_id("dispense"),
            primitive=Dispense(
                destination=to_location,
                volume_ul=volume_ul,
                flow_rate_ul_s=self.context.default_flow_rate,
                blow_out=True
            ),
            dependencies=[aspirate_step.step_id],
            source_intent="transfer"
        )
        steps.append(dispense_step)

        # Mix after if requested
        if mix_after:
            mix_step = PlanStep(
                step_id=self.context.next_step_id("mix_after"),
                primitive=Mix(
                    location=to_location,
                    volume_ul=volume_ul * 0.8,
                    cycles=self.context.default_mix_cycles
                ),
                dependencies=[dispense_step.step_id],
                source_intent="transfer"
            )
            steps.append(mix_step)

        # Drop tips
        if self.context.tip_policy == TipPolicy.SINGLE_USE:
            drop_step = PlanStep(
                step_id=self.context.next_step_id("drop"),
                primitive=DropTips(to_waste=True),
                dependencies=[steps[-1].step_id],
                source_intent="transfer"
            )
            steps.append(drop_step)

        return steps

    def lower_transfer_collection(
        self,
        from_plate: str,
        from_wells: str,
        to_plate: str,
        to_wells: str,
        volume_ul: float,
        semantics: Optional[Semantics] = None,
        mix_after: bool = False
    ) -> List[PlanStep]:
        """
        Lower collection transfer (multiple wells) to primitives.

        Uses ZIP semantics by default (source[i] → dest[i]).
        """
        # Expand well collections
        pairs = expand_collection_operation(
            intent_type='transfer',
            source_spec=from_wells,
            source_plate=from_plate,
            dest_spec=to_wells,
            dest_plate=to_plate,
            semantics=semantics
        )

        ordered_pairs = sorted(pairs, key=_collection_pair_sort_key)
        all_steps = []
        last_conflict_step: Dict[str, str] = {}

        for pair in ordered_pairs:
            source = WellRef(plate_id=pair.source_plate, well_id=pair.source_well)
            dest = WellRef(plate_id=pair.dest_plate, well_id=pair.dest_well)

            # Generate transfer steps for this pair
            transfer_steps = self.lower_transfer(
                from_location=source,
                to_location=dest,
                volume_ul=volume_ul,
                mix_after=mix_after
            )

            if not transfer_steps:
                continue

            conflict_keys = collection_conflict_keys(
                pair,
                exclusive_resource_keys=self.context.exclusive_resource_keys,
            )
            blockers = sorted({
                last_conflict_step[key]
                for key in conflict_keys
                if key in last_conflict_step
            })
            if blockers:
                transfer_steps[0].dependencies = sorted(set(transfer_steps[0].dependencies + blockers))

            all_steps.extend(transfer_steps)
            final_step_id = transfer_steps[-1].step_id
            for key in conflict_keys:
                last_conflict_step[key] = final_step_id

        return all_steps

    def lower_distribute(
        self,
        source: Location,
        destinations: List[Location],
        volume_ul: float
    ) -> List[PlanStep]:
        """
        Lower distribute() intent to optimized primitives.

        distribute = pick_tips + aspirate_all + dispense_each + drop_tips
        """
        steps = []

        # Calculate total volume needed
        total_volume = volume_ul * len(destinations)

        # Pick tips
        if self.context.available_tip_racks:
            tip_rack = self.context.available_tip_racks[0]
            pick_step = PlanStep(
                step_id=self.context.next_step_id("pick"),
                primitive=PickTips(tip_rack=tip_rack, tip_positions=["A1"]),
                source_intent="distribute"
            )
            steps.append(pick_step)

        # Single aspirate for total volume
        aspirate_step = PlanStep(
            step_id=self.context.next_step_id("aspirate"),
            primitive=Aspirate(
                source=source,
                volume_ul=total_volume,
                flow_rate_ul_s=self.context.default_flow_rate
            ),
            dependencies=[steps[-1].step_id] if steps else [],
            source_intent="distribute"
        )
        steps.append(aspirate_step)

        # Multiple dispenses
        prev_step_id = aspirate_step.step_id
        for i, dest in enumerate(destinations):
            dispense_step = PlanStep(
                step_id=self.context.next_step_id("dispense"),
                primitive=Dispense(
                    destination=dest,
                    volume_ul=volume_ul,
                    flow_rate_ul_s=self.context.default_flow_rate,
                    blow_out=(i == len(destinations) - 1)  # Only on last
                ),
                dependencies=[prev_step_id],
                source_intent="distribute"
            )
            steps.append(dispense_step)
            prev_step_id = dispense_step.step_id

        # Drop tips
        drop_step = PlanStep(
            step_id=self.context.next_step_id("drop"),
            primitive=DropTips(to_waste=True),
            dependencies=[prev_step_id],
            source_intent="distribute"
        )
        steps.append(drop_step)

        return steps

    def lower_consolidate(
        self,
        sources: List[Location],
        destination: Location,
        volume_ul: float
    ) -> List[PlanStep]:
        """
        Lower consolidate() intent (pooling) to primitives.

        consolidate = pick_tips + (aspirate_each) + dispense_all + drop_tips
        """
        steps = []

        # Pick tips
        if self.context.available_tip_racks:
            tip_rack = self.context.available_tip_racks[0]
            pick_step = PlanStep(
                step_id=self.context.next_step_id("pick"),
                primitive=PickTips(tip_rack=tip_rack, tip_positions=["A1"]),
                source_intent="consolidate"
            )
            steps.append(pick_step)

        # Aspirate from each source
        prev_step_id = steps[-1].step_id if steps else None
        total_aspirated = 0
        for source in sources:
            aspirate_step = PlanStep(
                step_id=self.context.next_step_id("aspirate"),
                primitive=Aspirate(
                    source=source,
                    volume_ul=volume_ul,
                    flow_rate_ul_s=self.context.default_flow_rate
                ),
                dependencies=[prev_step_id] if prev_step_id else [],
                source_intent="consolidate"
            )
            steps.append(aspirate_step)
            prev_step_id = aspirate_step.step_id
            total_aspirated += volume_ul

        # Single dispense of total volume
        dispense_step = PlanStep(
            step_id=self.context.next_step_id("dispense"),
            primitive=Dispense(
                destination=destination,
                volume_ul=total_aspirated,
                flow_rate_ul_s=self.context.default_flow_rate,
                blow_out=True
            ),
            dependencies=[prev_step_id] if prev_step_id else [],
            source_intent="consolidate"
        )
        steps.append(dispense_step)

        # Drop tips
        drop_step = PlanStep(
            step_id=self.context.next_step_id("drop"),
            primitive=DropTips(to_waste=True),
            dependencies=[dispense_step.step_id],
            source_intent="consolidate"
        )
        steps.append(drop_step)

        return steps

    def lower_mix(
        self,
        location: Location,
        volume_ul: float,
        cycles: int = 3,
        method: MixMethod = MixMethod.PIPETTE
    ) -> List[PlanStep]:
        """Lower mix() intent to primitives."""
        steps = []

        if method == MixMethod.PIPETTE:
            # Pick tips
            if self.context.available_tip_racks:
                tip_rack = self.context.available_tip_racks[0]
                pick_step = PlanStep(
                    step_id=self.context.next_step_id("pick"),
                    primitive=PickTips(tip_rack=tip_rack, tip_positions=["A1"]),
                    source_intent="mix"
                )
                steps.append(pick_step)

            # Mix
            mix_step = PlanStep(
                step_id=self.context.next_step_id("mix"),
                primitive=Mix(
                    location=location,
                    volume_ul=volume_ul,
                    cycles=cycles,
                    method=method
                ),
                dependencies=[steps[-1].step_id] if steps else [],
                source_intent="mix"
            )
            steps.append(mix_step)

            # Drop tips
            drop_step = PlanStep(
                step_id=self.context.next_step_id("drop"),
                primitive=DropTips(to_waste=True),
                dependencies=[mix_step.step_id],
                source_intent="mix"
            )
            steps.append(drop_step)

        else:
            # Non-pipette mixing is a human/instrument step
            steps.append(PlanStep(
                step_id=self.context.next_step_id("mix"),
                primitive=HumanStep(
                    instruction=f"Mix using {method.name} for {cycles} cycles",
                    expected_time_s=cycles * 5.0
                ),
                source_intent="mix"
            ))

        return steps

    def lower_incubate(
        self,
        device_id: str,
        temperature_c: float,
        duration_s: float,
        shake_rpm: Optional[float] = None
    ) -> List[PlanStep]:
        """Lower incubate() intent to primitives."""
        steps = []

        # Set temperature
        set_temp_step = PlanStep(
            step_id=self.context.next_step_id("set_temp"),
            primitive=SetTemperature(device_id=device_id, temperature_c=temperature_c),
            source_intent="incubate"
        )
        steps.append(set_temp_step)

        # Incubate
        incubate_step = PlanStep(
            step_id=self.context.next_step_id("incubate"),
            primitive=Incubate(
                device_id=device_id,
                temperature_c=temperature_c,
                duration_s=duration_s,
                shake_rpm=shake_rpm
            ),
            dependencies=[set_temp_step.step_id],
            source_intent="incubate"
        )
        steps.append(incubate_step)

        return steps

    def lower_manual(
        self,
        instruction: str,
        expected_time_s: Optional[float] = None,
        checklist: Optional[List[str]] = None,
        safety_tags: Optional[List[str]] = None,
        requires_confirmation: bool = True
    ) -> List[PlanStep]:
        """Lower manual() intent to human step primitives."""
        steps = []

        # For robot target, insert pause
        if self.context.target in ["robot", "hybrid"]:
            pause_step = PlanStep(
                step_id=self.context.next_step_id("pause"),
                primitive=Pause(reason=instruction, requires_deck_confirmation=True),
                source_intent="manual"
            )
            steps.append(pause_step)

        # Human step
        human_step = PlanStep(
            step_id=self.context.next_step_id("human"),
            primitive=HumanStep(
                instruction=instruction,
                expected_time_s=expected_time_s,
                checklist=checklist or [],
                safety_tags=safety_tags or [],
                requires_confirmation=requires_confirmation
            ),
            dependencies=[steps[-1].step_id] if steps else [],
            source_intent="manual"
        )
        steps.append(human_step)

        # For robot target, insert resume
        if self.context.target in ["robot", "hybrid"]:
            resume_step = PlanStep(
                step_id=self.context.next_step_id("resume"),
                primitive=Resume(deck_state_verified=False),
                dependencies=[human_step.step_id],
                source_intent="manual"
            )
            steps.append(resume_step)

        return steps

    def lower_checkpoint(self, checkpoint_id: str) -> List[PlanStep]:
        """Lower checkpoint to primitive."""
        return [PlanStep(
            step_id=self.context.next_step_id("checkpoint"),
            primitive=Checkpoint(checkpoint_id=checkpoint_id),
            source_intent="checkpoint"
        )]

    def lower_run_pcr(
        self,
        plate_id: str,
        device_id: str = "thermocycler",
        initial_temp_c: Optional[float] = None,
        initial_duration_s: Optional[float] = None,
        cycle_count: int = 30,
        cycle_steps: Optional[List[Dict[str, Any]]] = None,
        final_temp_c: Optional[float] = None,
        final_duration_s: Optional[float] = None,
        hold_temp_c: Optional[float] = 4.0,
        lid_temp_c: Optional[float] = 105.0
    ) -> List[PlanStep]:
        """
        Lower run_pcr() intent to primitives.

        For human target: HumanStep with detailed PCR program instructions
        For robot target: RunPCR primitive for thermocycler

        Args:
            plate_id: PCR plate identifier
            device_id: Thermocycler device ID
            initial_temp_c: Initial denaturation temperature
            initial_duration_s: Initial denaturation time
            cycle_count: Number of PCR cycles
            cycle_steps: List of cycle steps [{"name": "denature", "temp": 98, "duration": 10}, ...]
            final_temp_c: Final extension temperature
            final_duration_s: Final extension time
            hold_temp_c: Hold temperature after PCR
            lid_temp_c: Heated lid temperature
        """
        steps = []

        # Convert cycle_steps to PcrCycleStepPrimitive objects
        pcr_cycle_steps = []
        if cycle_steps:
            for step in cycle_steps:
                pcr_cycle_steps.append(PcrCycleStepPrimitive(
                    name=step.get("name", "step"),
                    temperature_c=step.get("temp", 0.0),
                    duration_s=step.get("duration", 0.0)
                ))

        if self.context.target == "human":
            # Generate human-readable PCR program instructions
            instructions = [f"Run PCR on plate {plate_id}:"]
            if initial_temp_c and initial_duration_s:
                instructions.append(f"  Initial: {initial_temp_c}°C for {initial_duration_s}s")
            instructions.append(f"  Cycles: {cycle_count}x")
            for step in pcr_cycle_steps:
                instructions.append(f"    - {step.name}: {step.temperature_c}°C for {step.duration_s}s")
            if final_temp_c and final_duration_s:
                instructions.append(f"  Final: {final_temp_c}°C for {final_duration_s}s")
            if hold_temp_c:
                instructions.append(f"  Hold: {hold_temp_c}°C")

            steps.append(PlanStep(
                step_id=self.context.next_step_id("pcr"),
                primitive=HumanStep(
                    instruction="\n".join(instructions),
                    checklist=[
                        "Load plate into thermocycler",
                        "Start PCR program",
                        "Wait for completion",
                        "Remove plate"
                    ],
                    requires_confirmation=True
                ),
                source_intent="run_pcr"
            ))
        else:
            # Robot/hybrid: Use RunPCR primitive
            steps.append(PlanStep(
                step_id=self.context.next_step_id("pcr"),
                primitive=RunPCR(
                    plate_id=plate_id,
                    device_id=device_id,
                    initial_temp_c=initial_temp_c,
                    initial_duration_s=initial_duration_s,
                    cycle_count=cycle_count,
                    cycle_steps=pcr_cycle_steps,
                    final_temp_c=final_temp_c,
                    final_duration_s=final_duration_s,
                    hold_temp_c=hold_temp_c,
                    lid_temp_c=lid_temp_c
                ),
                source_intent="run_pcr"
            ))

        return steps

    def lower_pick_colonies(
        self,
        source_plate: str,
        well_id: str,
        destination: Location,
        count: int = 1,
        selection_criteria: str = "largest"
    ) -> List[PlanStep]:
        """
        Lower pick_colonies() intent to primitives.

        For human target: HumanStep with picking instructions
        For robot target: PickColonies primitive (requires colony picker)

        Args:
            source_plate: Agar plate with colonies
            well_id: Well/region to pick from
            destination: Destination well for picked colony
            count: Number of colonies to pick
            selection_criteria: Selection method ("largest", "random", "morphology")
        """
        steps = []

        if self.context.target == "human":
            steps.append(PlanStep(
                step_id=self.context.next_step_id("pick"),
                primitive=HumanStep(
                    instruction=f"Pick {count} {selection_criteria} colony(ies) from {source_plate}:{well_id}",
                    checklist=[
                        f"Identify {selection_criteria} colony/colonies",
                        "Use sterile pick/loop",
                        "Transfer to destination",
                        "Dispose of pick properly"
                    ],
                    requires_confirmation=True
                ),
                source_intent="pick_colonies"
            ))
        else:
            # Robot/hybrid: May need pause for manual colony picker
            if self.context.target == "hybrid":
                steps.append(PlanStep(
                    step_id=self.context.next_step_id("pause"),
                    primitive=Pause(reason="Prepare colony picker"),
                    source_intent="pick_colonies"
                ))

            steps.append(PlanStep(
                step_id=self.context.next_step_id("pick"),
                primitive=PickColonies(
                    source_plate=source_plate,
                    well_id=well_id,
                    destination=destination,
                    count=count,
                    selection_criteria=selection_criteria
                ),
                dependencies=[steps[-1].step_id] if steps else [],
                source_intent="pick_colonies"
            ))

        return steps

    def lower_adjust_ph(
        self,
        container_id: str,
        target_ph: float,
        tolerance: float = 0.1,
        acid_reagent: Optional[str] = None,
        base_reagent: Optional[str] = None
    ) -> List[PlanStep]:
        """
        Lower adjust_ph() intent to primitives.

        pH adjustment is typically a manual operation requiring
        pH meter readings and titration.

        Args:
            container_id: Container to adjust pH
            target_ph: Target pH value
            tolerance: Acceptable pH tolerance
            acid_reagent: Acid for pH down adjustment
            base_reagent: Base for pH up adjustment
        """
        steps = []

        # pH adjustment is manual for all targets
        checklist = [
            "Calibrate pH meter",
            f"Measure initial pH of {container_id}",
        ]
        if acid_reagent:
            checklist.append(f"If pH > {target_ph + tolerance}, add {acid_reagent} dropwise")
        if base_reagent:
            checklist.append(f"If pH < {target_ph - tolerance}, add {base_reagent} dropwise")
        checklist.extend([
            "Mix gently after each addition",
            f"Continue until pH is {target_ph} ± {tolerance}",
            "Record final pH and titrant volume"
        ])

        if self.context.target in ["robot", "hybrid"]:
            steps.append(PlanStep(
                step_id=self.context.next_step_id("pause"),
                primitive=Pause(reason=f"pH adjustment required: target {target_ph}"),
                source_intent="adjust_ph"
            ))

        steps.append(PlanStep(
            step_id=self.context.next_step_id("adjust_ph"),
            primitive=AdjustPH(
                container_id=container_id,
                target_ph=target_ph,
                tolerance=tolerance,
                acid_reagent=acid_reagent,
                base_reagent=base_reagent
            ),
            dependencies=[steps[-1].step_id] if steps else [],
            source_intent="adjust_ph"
        ))

        # Add human instructions for manual operation
        steps.append(PlanStep(
            step_id=self.context.next_step_id("human"),
            primitive=HumanStep(
                instruction=f"Adjust pH of {container_id} to {target_ph} ± {tolerance}",
                checklist=checklist,
                requires_confirmation=True
            ),
            dependencies=[steps[-1].step_id],
            source_intent="adjust_ph"
        ))

        if self.context.target in ["robot", "hybrid"]:
            steps.append(PlanStep(
                step_id=self.context.next_step_id("resume"),
                primitive=Resume(deck_state_verified=False),
                dependencies=[steps[-1].step_id],
                source_intent="adjust_ph"
            ))

        return steps

    def lower_heat_shock(
        self,
        target: Location,
        temperature_c: float = 42.0,
        duration_s: float = 60.0,
        device_id: str = "water_bath"
    ) -> List[PlanStep]:
        """
        Lower heat_shock() intent to primitives.

        Heat shock is a rapid temperature pulse used in transformation.

        Args:
            target: Sample location to heat shock
            temperature_c: Heat shock temperature (typically 42°C)
            duration_s: Duration of heat shock
            device_id: Heat source device (water bath, heat block)
        """
        steps = []

        if self.context.target == "human":
            steps.append(PlanStep(
                step_id=self.context.next_step_id("heat_shock"),
                primitive=HumanStep(
                    instruction=f"Heat shock at {temperature_c}°C for {duration_s}s",
                    expected_time_s=duration_s,
                    checklist=[
                        f"Verify {device_id} is at {temperature_c}°C",
                        "Transfer sample to heat source",
                        f"Start timer for {duration_s} seconds",
                        "Remove immediately when timer ends"
                    ],
                    requires_confirmation=True
                ),
                source_intent="heat_shock"
            ))
        else:
            steps.append(PlanStep(
                step_id=self.context.next_step_id("heat_shock"),
                primitive=HeatShock(
                    target=target,
                    temperature_c=temperature_c,
                    duration_s=duration_s,
                    device_id=device_id
                ),
                source_intent="heat_shock"
            ))

        return steps

    def lower_on_ice(
        self,
        target: Location,
        duration_s: float = 120.0
    ) -> List[PlanStep]:
        """
        Lower on_ice() intent to primitives.

        Place sample on ice for cooling/recovery.

        Args:
            target: Sample location to place on ice
            duration_s: Duration on ice
        """
        steps = []

        if self.context.target == "human":
            steps.append(PlanStep(
                step_id=self.context.next_step_id("on_ice"),
                primitive=HumanStep(
                    instruction=f"Place on ice for {duration_s}s",
                    expected_time_s=duration_s,
                    checklist=[
                        "Transfer sample to ice bucket",
                        f"Incubate for {duration_s} seconds",
                        "Keep sample cold"
                    ],
                    requires_confirmation=True
                ),
                source_intent="on_ice"
            ))
        else:
            steps.append(PlanStep(
                step_id=self.context.next_step_id("on_ice"),
                primitive=OnIce(
                    target=target,
                    duration_s=duration_s
                ),
                source_intent="on_ice"
            ))

        return steps

    def add_steps_to_plan(self, steps: List[PlanStep]) -> None:
        """Add lowered steps to the execution plan."""
        for step in steps:
            self.plan.add_step(step)

    def get_plan(self) -> ExecutionPlan:
        """Get the execution plan with all lowered steps."""
        return self.plan
