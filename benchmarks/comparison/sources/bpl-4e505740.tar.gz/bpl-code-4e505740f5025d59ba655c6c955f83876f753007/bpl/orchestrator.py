"""Shared orchestration helpers for CLI command execution."""

from dataclasses import dataclass
from itertools import count
from pathlib import Path
from typing import Iterator, cast

from bpl.ast.base import SourceSpan
from bpl.ast.declarations import ProtocolDecl
from bpl.ast.expressions import Argument, IdentifierExpr, ListExpr, QuantityExpr
from bpl.ast.literals import NumberLit, StringLit
from bpl.ast.program import Program
from bpl.ast.statements import (
    CherrypickStmt,
    CallStmt,
    ParallelBlock,
    SequenceBlock,
    SerialDiluteStmt,
    StampStmt,
    Statement,
)
from bpl.capabilities import (
    StrictCapabilityError,
    enforce_strict_capabilities,
    get_unsupported_primitives_for_plan,
    normalize_target,
    primitive_identifier,
)
from bpl.graph import GraphIntegrityError, build_workflow_graph
from bpl.location import validate_well_in_plate_bounds
from bpl.lowering import (
    Aspirate,
    Checkpoint,
    Dispense,
    ExecutionPlan,
    HumanStep,
    Pause,
    PlanStep,
    Primitive,
    Wait,
    WellRef,
)
from bpl.parser import parse_file
from bpl.parser.errors import BPLSyntaxError
from bpl.validation import ExperimentSetup, SetupDiagnostic, load_experiment_setup, validate_plan_against_setup

EXIT_SUCCESS = 0
EXIT_USAGE_ERROR = 2
EXIT_PARSE_FAILURE = 10
EXIT_SEMANTIC_FAILURE = 11
EXIT_LOWERING_FAILURE = 20
EXIT_SIMULATION_FAILURE = 30
EXIT_STRICT_CAPABILITY_FAILURE = 40
EXIT_INTERNAL_ERROR = 99

_TRANSFER_LIKE_INTENTS = {"transfer", "stamp", "cherrypick", "serial_dilute"}


@dataclass(frozen=True)
class DiagnosticPoint:
    """Normalized diagnostic position."""

    line: int
    col: int
    offset: int

    def to_dict(self) -> dict[str, int]:
        return {"line": self.line, "col": self.col, "offset": self.offset}


@dataclass(frozen=True)
class DiagnosticLocation:
    """Normalized diagnostic location."""

    file: str
    start: DiagnosticPoint
    end: DiagnosticPoint

    def to_dict(self) -> dict[str, object]:
        return {
            "file": self.file,
            "start": self.start.to_dict(),
            "end": self.end.to_dict(),
        }


@dataclass(frozen=True)
class Diagnostic:
    """Machine-readable deterministic diagnostic."""

    code: str
    severity: str
    message: str
    location: DiagnosticLocation | None = None
    hint: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "severity": self.severity,
            "message": self.message,
            "location": self.location.to_dict() if self.location else None,
            "hint": self.hint,
        }


class OrchestrationError(RuntimeError):
    """Deterministic failure raised by orchestrator gates."""

    def __init__(self, exit_code: int, diagnostics: list[Diagnostic]):
        self.exit_code = exit_code
        self.diagnostics = diagnostics
        super().__init__("\n".join(d.message for d in diagnostics))


@dataclass(frozen=True)
class CapabilityPreflightResult:
    """Capability preflight result from orchestrator checks."""

    target: str
    unsupported_primitives: list[str]

    @property
    def allowed(self) -> bool:
        return not self.unsupported_primitives


@dataclass(frozen=True)
class ValidationPipelineResult:
    """Validated protocol artifacts after staged gate evaluation."""

    program: Program
    plan: ExecutionPlan
    warnings: list[Diagnostic]
    target: str
    setup: ExperimentSetup | None = None


def run_capability_preflight(
    plan: ExecutionPlan,
    target: str,
    strict: bool,
) -> CapabilityPreflightResult:
    """
    Validate capability support for a plan using shared registry.

    In strict mode this raises ``StrictCapabilityError`` when unsupported
    primitives are present.
    """

    normalized = normalize_target(target)
    if strict:
        try:
            enforce_strict_capabilities(plan=plan, target=normalized)
            unsupported: list[str] = []
        except StrictCapabilityError as exc:
            raise StrictCapabilityError(
                target=normalized,
                unsupported_primitives=exc.unsupported_primitives,
            ) from exc
    else:
        unsupported = get_unsupported_primitives_for_plan(plan=plan, target=normalized)

    return CapabilityPreflightResult(
        target=normalized,
        unsupported_primitives=unsupported,
    )


def run_parse_gate(input_path: Path) -> Program:
    """Run syntax gate and return parsed program."""

    try:
        return parse_file(input_path)
    except FileNotFoundError as exc:
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="SYNTAX_INPUT_NOT_FOUND",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Provide a valid .bpl input file path.",
                )
            ],
        ) from exc
    except BPLSyntaxError as exc:
        source_text = _safe_read_text(input_path)
        location = _location_from_span(exc.span, source_text)
        if location is None and source_text is not None:
            location = _eof_location(file_path=str(input_path), source_text=source_text)
        raise OrchestrationError(
            EXIT_PARSE_FAILURE,
            [
                Diagnostic(
                    code=exc.code,
                    severity="error",
                    message=exc.message,
                    location=location,
                    hint=(exc.suggestions[0] if exc.suggestions else None),
                )
            ],
        ) from exc


def run_semantic_gate(program: Program, input_path: Path) -> list[Diagnostic]:
    """Run baseline semantic validation gate."""

    diagnostics: list[Diagnostic] = []
    source_text = _safe_read_text(input_path)
    protocols = [decl for decl in program.declarations if isinstance(decl, ProtocolDecl)]
    if not protocols:
        diagnostics.append(
            Diagnostic(
                code="SEMANTIC_MISSING_PROTOCOL",
                severity="error",
                message="No protocol declaration found.",
                location=None,
                hint="Declare one `protocol Name { ... }` block.",
            )
        )
        return diagnostics

    protocol = protocols[0]
    for statement in _iter_statements(protocol.body):
        if isinstance(statement, StampStmt):
            volume_value = _numeric_value(statement.volume)
            if volume_value is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_MISSING_VOLUME",
                        severity="error",
                        message="`stamp` requires numeric `volume` argument.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Example: volume: 10 uL",
                    )
                )
            elif volume_value <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_VOLUME",
                        severity="error",
                        message=f"Volume must be positive for `stamp`, got {volume_value}.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a strictly positive transfer volume.",
                    )
                )
            continue

        if isinstance(statement, CherrypickStmt):
            all_wells = list(statement.source_wells) + list(statement.dest_wells)
            for well in all_wells:
                if validate_well_in_plate_bounds(well, plate_format="plate_96"):
                    continue
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_WELL_OUT_OF_BOUNDS",
                        severity="error",
                        message=(
                            f"Well '{well}' is out of bounds for default plate_96 "
                            f"semantic checks."
                        ),
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a well within A1..H12 or declare a wider plate context.",
                    )
                )

            volume_value = _numeric_value(statement.volume)
            if volume_value is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_MISSING_VOLUME",
                        severity="error",
                        message="`cherrypick` requires numeric `volume` argument.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Example: volume: 2 uL",
                    )
                )
            elif volume_value <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_VOLUME",
                        severity="error",
                        message=f"Volume must be positive for `cherrypick`, got {volume_value}.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a strictly positive transfer volume.",
                    )
                )

            if len(statement.source_wells) != len(statement.dest_wells):
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_COLLECTION_CARDINALITY",
                        severity="error",
                        message=(
                            f"Collection transfer requires equal counts; got "
                            f"{len(statement.source_wells)} source(s) and "
                            f"{len(statement.dest_wells)} destination(s)."
                        ),
                        location=_location_from_span(statement.span, source_text),
                        hint="Use same-length source and destination well lists.",
                    )
                )
            continue

        if isinstance(statement, SerialDiluteStmt):
            volume_value = _numeric_value(statement.volume)
            if volume_value is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_MISSING_VOLUME",
                        severity="error",
                        message="`serial_dilute` requires numeric `volume` argument.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Example: volume: 20 uL",
                    )
                )
            elif volume_value <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_VOLUME",
                        severity="error",
                        message=(
                            f"Volume must be positive for `serial_dilute`, got {volume_value}."
                        ),
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a strictly positive transfer volume.",
                    )
                )

            if statement.dilution_steps <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_STEPS",
                        severity="error",
                        message=(
                            f"`serial_dilute` requires positive `steps`, got "
                            f"{statement.dilution_steps}."
                        ),
                        location=_location_from_span(statement.span, source_text),
                        hint="Use steps >= 1.",
                    )
                )

            if len(statement.dest_plates) < statement.dilution_steps:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_SERIAL_DILUTE_DESTINATION_MISMATCH",
                        severity="error",
                        message=(
                            f"`serial_dilute` steps ({statement.dilution_steps}) exceed "
                            f"destination plate count ({len(statement.dest_plates)})."
                        ),
                        location=_location_from_span(statement.span, source_text),
                        hint="Provide at least one destination plate per dilution step.",
                    )
                )
            continue

        if not isinstance(statement, CallStmt):
            continue

        intent_name = statement.name.strip().lower()
        named_args = _named_arguments(statement.arguments)

        if intent_name in _TRANSFER_LIKE_INTENTS:
            from_arg = named_args.get("from")
            to_arg = named_args.get("to")
            volume_arg = named_args.get("volume")

            if from_arg is None or to_arg is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_MISSING_ENDPOINT",
                        severity="error",
                        message=f"`{statement.name}` requires `from` and `to` arguments.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Use named arguments: from: <source>, to: <destination>.",
                    )
                )
                continue

            volume_value = _numeric_value(volume_arg.value) if volume_arg else None
            if volume_value is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_MISSING_VOLUME",
                        severity="error",
                        message=f"`{statement.name}` requires numeric `volume` argument.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Example: volume: 10 uL",
                    )
                )
            elif volume_value <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_VOLUME",
                        severity="error",
                        message=f"Volume must be positive for `{statement.name}`, got {volume_value}.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a strictly positive transfer volume.",
                    )
                )

            from_count = _collection_size(from_arg.value)
            to_count = _collection_size(to_arg.value)
            if from_count > 1 or to_count > 1:
                if from_count != to_count:
                    diagnostics.append(
                        Diagnostic(
                            code="SEMANTIC_COLLECTION_CARDINALITY",
                            severity="error",
                            message=(
                                f"Collection transfer requires equal counts; got "
                                f"{from_count} source(s) and {to_count} destination(s)."
                            ),
                            location=_location_from_span(statement.span, source_text),
                            hint="Use ZIP-style same-length collections for transfer.",
                        )
                    )

        if intent_name == "wait":
            duration_arg = named_args.get("duration")
            duration_value = _duration_seconds(duration_arg.value) if duration_arg else None
            if duration_value is not None and duration_value <= 0:
                diagnostics.append(
                    Diagnostic(
                        code="SEMANTIC_NON_POSITIVE_DURATION",
                        severity="error",
                        message=f"Wait duration must be positive, got {duration_value}.",
                        location=_location_from_span(statement.span, source_text),
                        hint="Use a duration greater than zero seconds.",
                    )
                )

    return diagnostics


def run_setup_gate(
    setup_path: Path | None,
    *,
    plan: ExecutionPlan | None = None,
) -> ExperimentSetup | None:
    """Load setup payload and validate setup-aware plan constraints."""

    if setup_path is None:
        return None

    setup, setup_diagnostics = load_experiment_setup(setup_path)
    if setup_diagnostics:
        raise OrchestrationError(
            EXIT_SEMANTIC_FAILURE,
            [_diagnostic_from_setup_diagnostic(diag) for diag in setup_diagnostics],
        )
    assert setup is not None

    if plan is not None:
        plan_diagnostics = validate_plan_against_setup(plan=plan, setup=setup)
        if plan_diagnostics:
            raise OrchestrationError(
                EXIT_SEMANTIC_FAILURE,
                [_diagnostic_from_setup_diagnostic(diag) for diag in plan_diagnostics],
            )

    return setup


def run_pipeline_for_plan(
    input_path: Path,
    target: str,
    strict: bool,
    setup_path: Path | None = None,
) -> ValidationPipelineResult:
    """
    Build plan through staged validation gates.

    Gate order: syntax -> semantic -> plan/DAG -> experiment-parameter ->
    capability -> backend preflight.
    """

    program = run_parse_gate(input_path)

    semantic_diagnostics = run_semantic_gate(program=program, input_path=input_path)
    if semantic_diagnostics:
        raise OrchestrationError(EXIT_SEMANTIC_FAILURE, semantic_diagnostics)

    try:
        plan = lower_program_to_plan(program=program, source_path=input_path, target=target)
    except ValueError as exc:
        raise OrchestrationError(
            EXIT_LOWERING_FAILURE,
            [
                Diagnostic(
                    code="PLAN_LOWERING_ERROR",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Check intent arguments and lowering assumptions.",
                )
            ],
        ) from exc

    plan_diagnostics = run_plan_gate(plan)
    if plan_diagnostics:
        raise OrchestrationError(EXIT_LOWERING_FAILURE, plan_diagnostics)

    setup = run_setup_gate(setup_path, plan=plan)

    warnings: list[Diagnostic] = []
    if target.strip().lower() == "biomek" and not strict:
        rewritten_plan, rewritten_steps = _rewrite_unsupported_steps_for_biomek(plan)
        if rewritten_steps:
            plan = rewritten_plan
            warnings.append(
                Diagnostic(
                    code="CAPABILITY_BIOMEK_MANUAL_REWRITE",
                    severity="warning",
                    message=(
                        "Rewrote unsupported biomek step(s) into manual checkpoint/pause gates: "
                        f"{', '.join(rewritten_steps)}"
                    ),
                    location=None,
                    hint="Use --strict to fail instead of rewriting unsupported steps.",
                )
            )

    try:
        capability = run_capability_preflight(plan=plan, target=target, strict=strict)
    except StrictCapabilityError as exc:
        raise OrchestrationError(
            EXIT_STRICT_CAPABILITY_FAILURE,
            [
                Diagnostic(
                    code="CAPABILITY_UNSUPPORTED_SET",
                    severity="error",
                    message=(
                        f"Strict capability failure for target '{exc.target}': "
                        f"{', '.join(exc.unsupported_primitives)}"
                    ),
                    location=None,
                    hint="Use non-strict mode or switch backend target.",
                )
            ],
        ) from exc

    if capability.unsupported_primitives:
        warnings.append(
            Diagnostic(
                code="CAPABILITY_UNSUPPORTED_SET",
                severity="warning",
                message=(
                    f"Unsupported primitives (non-strict): "
                    f"{', '.join(capability.unsupported_primitives)}"
                ),
                location=None,
                hint="Use --strict to fail instead of degrade.",
            )
        )

    return ValidationPipelineResult(
        program=program,
        plan=plan,
        warnings=warnings,
        target=capability.target,
        setup=setup,
    )


def _rewrite_unsupported_steps_for_biomek(
    plan: ExecutionPlan,
) -> tuple[ExecutionPlan, list[str]]:
    """Rewrite unsupported biomek steps into explicit manual checkpoint/pause gates."""

    unsupported = set(get_unsupported_primitives_for_plan(plan=plan, target="biomek"))
    if not unsupported:
        return plan, []

    rewritten_plan = ExecutionPlan(
        plan_id=plan.plan_id,
        protocol_name=plan.protocol_name,
        created_at=plan.created_at,
        target=plan.target,
    )
    terminal_step_by_original_step: dict[str, str] = {}
    rewritten_steps: list[str] = []

    for step_id in plan.topological_order():
        step = plan.steps[step_id]
        rewritten_dependencies = sorted(
            {terminal_step_by_original_step.get(dep, dep) for dep in step.dependencies}
        )
        primitive_id = primitive_identifier(step.primitive.primitive_type)
        if primitive_id not in unsupported:
            rewritten_plan.add_step(_clone_plan_step(step, dependencies=rewritten_dependencies))
            terminal_step_by_original_step[step_id] = step.step_id
            continue

        manual_instruction = _manual_instruction_for_step(step)
        manual_metadata = {
            "instruction": manual_instruction,
            "original_primitive": step.primitive.primitive_type.name,
            "original_step_id": step.step_id,
            "source_intent": step.source_intent,
        }

        checkpoint_step_id = _unique_step_id(
            f"{step.step_id}__manual_checkpoint",
            existing_ids=rewritten_plan.steps,
        )
        checkpoint_annotations = dict(step.annotations)
        checkpoint_annotations["manual_intervention"] = {
            **manual_metadata,
            "gate": "checkpoint",
        }
        rewritten_plan.add_step(
            PlanStep(
                step_id=checkpoint_step_id,
                primitive=cast(
                    Primitive,
                    Checkpoint(checkpoint_id=f"manual_{step.step_id}"),
                ),
                dependencies=rewritten_dependencies,
                source_intent=step.source_intent,
                annotations=checkpoint_annotations,
            )
        )

        pause_step_id = _unique_step_id(
            f"{step.step_id}__manual_pause",
            existing_ids=rewritten_plan.steps,
        )
        pause_annotations = dict(step.annotations)
        pause_annotations["manual_intervention"] = {
            **manual_metadata,
            "checkpoint_step_id": checkpoint_step_id,
            "gate": "pause",
        }
        rewritten_plan.add_step(
            PlanStep(
                step_id=pause_step_id,
                primitive=cast(
                    Primitive,
                    Pause(
                        reason=(
                            "Manual intervention required for "
                            f"{step.step_id}: {manual_instruction}"
                        )
                    ),
                ),
                dependencies=[checkpoint_step_id],
                source_intent=step.source_intent,
                annotations=pause_annotations,
            )
        )

        terminal_step_by_original_step[step_id] = pause_step_id
        rewritten_steps.append(step.step_id)

    return rewritten_plan, rewritten_steps


def _clone_plan_step(step: PlanStep, *, dependencies: list[str]) -> PlanStep:
    """Clone one plan step with rewritten dependency edges."""

    return PlanStep(
        step_id=step.step_id,
        primitive=step.primitive,
        dependencies=dependencies,
        status=step.status,
        started_at=step.started_at,
        completed_at=step.completed_at,
        result=step.result,
        error=step.error,
        source_intent=step.source_intent,
        annotations=dict(step.annotations),
    )


def _manual_instruction_for_step(step: PlanStep) -> str:
    if isinstance(step.primitive, HumanStep):
        instruction = step.primitive.instruction.strip()
        if instruction:
            return instruction

    primitive_label = primitive_identifier(step.primitive.primitive_type).replace("_", " ")
    if step.source_intent:
        return f"{step.source_intent} ({primitive_label})"
    return f"Execute {primitive_label}"


def _unique_step_id(base: str, *, existing_ids: dict[str, PlanStep]) -> str:
    if base not in existing_ids:
        return base
    index = 2
    while f"{base}_{index}" in existing_ids:
        index += 1
    return f"{base}_{index}"


def _diagnostic_from_setup_diagnostic(diagnostic: SetupDiagnostic) -> Diagnostic:
    return Diagnostic(
        code=diagnostic.code,
        severity="error",
        message=diagnostic.message,
        location=None,
        hint=diagnostic.hint,
    )


def run_plan_gate(plan: ExecutionPlan) -> list[Diagnostic]:
    """Run plan/DAG validation gate diagnostics."""

    if not plan.steps:
        return [
            Diagnostic(
                code="PLAN_EMPTY",
                severity="error",
                message="Lowered plan contains no executable steps.",
                location=None,
                hint="Ensure protocol body has at least one executable statement.",
            )
        ]

    try:
        build_workflow_graph(plan)
    except GraphIntegrityError as exc:
        return [
            Diagnostic(
                code=f"PLAN_{exc.code}",
                severity="error",
                message=str(exc),
                location=None,
                hint=(
                    "Ensure every dependency references an existing step and "
                    "the dependency graph is acyclic."
                ),
            )
        ]

    return []


def lower_program_to_plan(program: Program, source_path: Path, target: str) -> ExecutionPlan:
    """Lower parsed protocol program to deterministic plan."""

    protocol = next(
        (decl for decl in program.declarations if isinstance(decl, ProtocolDecl)),
        None,
    )
    if protocol is None:
        raise ValueError("No protocol declaration found in source program.")

    protocol_name = protocol.name or source_path.stem
    safe_name = protocol_name.strip().replace(" ", "_") or "protocol"
    plan = ExecutionPlan(
        plan_id=f"{safe_name}_plan",
        protocol_name=protocol_name,
        target=normalize_target(target),
    )

    step_counter = count(start=1)
    location_cache: dict[str, WellRef] = {}
    source_text = _safe_read_text(source_path)
    source_lines = source_text.splitlines() if source_text is not None else None
    _emit_statements(
        statements=protocol.body,
        incoming_dependencies=[],
        plan=plan,
        step_counter=step_counter,
        location_cache=location_cache,
        source_lines=source_lines,
    )
    return plan


def _emit_statements(
    statements: list[Statement],
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    location_cache: dict[str, WellRef],
    source_lines: list[str] | None,
) -> list[str]:
    current_dependencies = sorted(set(incoming_dependencies))
    for statement in statements:
        current_dependencies = _emit_statement(
            statement=statement,
            incoming_dependencies=current_dependencies,
            plan=plan,
            step_counter=step_counter,
            location_cache=location_cache,
            source_lines=source_lines,
        )
    return current_dependencies


def _emit_statement(
    statement: Statement,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    location_cache: dict[str, WellRef],
    source_lines: list[str] | None,
) -> list[str]:
    if isinstance(statement, CallStmt):
        return _emit_call_statement(
            statement=statement,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            location_cache=location_cache,
            source_lines=source_lines,
        )

    if isinstance(statement, StampStmt):
        return _emit_stamp_statement(
            statement=statement,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            source_lines=source_lines,
        )

    if isinstance(statement, CherrypickStmt):
        return _emit_cherrypick_statement(
            statement=statement,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            source_lines=source_lines,
        )

    if isinstance(statement, SerialDiluteStmt):
        return _emit_serial_dilute_statement(
            statement=statement,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            source_lines=source_lines,
        )

    if isinstance(statement, SequenceBlock):
        return _emit_statements(
            statements=statement.statements,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            location_cache=location_cache,
            source_lines=source_lines,
        )

    if isinstance(statement, ParallelBlock):
        branch_dependencies: list[str] = []
        for nested in statement.statements:
            branch_dependencies.extend(
                _emit_statement(
                    statement=nested,
                    incoming_dependencies=incoming_dependencies,
                    plan=plan,
                    step_counter=step_counter,
                    location_cache=location_cache,
                    source_lines=source_lines,
                )
            )
        return sorted(set(branch_dependencies)) or incoming_dependencies

    return incoming_dependencies


def _emit_call_statement(
    statement: CallStmt,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    location_cache: dict[str, WellRef],
    source_lines: list[str] | None,
) -> list[str]:
    intent_name = statement.name.strip().lower()
    step_annotations = _statement_annotations(statement, source_lines=source_lines)

    if intent_name == "transfer":
        named_args = _named_arguments(statement.arguments)
        from_arg = named_args.get("from")
        to_arg = named_args.get("to")
        volume_arg = named_args.get("volume")
        if from_arg is None or to_arg is None or volume_arg is None:
            raise ValueError("transfer() requires from/to/volume arguments.")

        volume = _numeric_value(volume_arg.value)
        if volume is None:
            raise ValueError("transfer() volume must be numeric.")

        sources = _locations_from_expression(from_arg.value, location_cache)
        destinations = _locations_from_expression(to_arg.value, location_cache)
        if len(sources) != len(destinations):
            raise ValueError(
                f"transfer() source/destination count mismatch: "
                f"{len(sources)} vs {len(destinations)}."
            )

        return _emit_transfer_pairs(
            sources=sources,
            destinations=destinations,
            volume=volume,
            source_intent=statement.name,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
            step_annotations=step_annotations,
        )

    if intent_name == "wait":
        named_args = _named_arguments(statement.arguments)
        duration_expr = named_args.get("duration")
        duration_seconds = _duration_seconds(
            duration_expr.value if duration_expr else statement.arguments[0].value
            if statement.arguments
            else None
        )
        if duration_seconds is None:
            duration_seconds = 1.0
        step_id = f"step_{next(step_counter):04d}"
        plan.add_step(
            PlanStep(
                step_id=step_id,
                primitive=cast(Primitive, Wait(duration_s=duration_seconds)),
                dependencies=sorted(set(incoming_dependencies)),
                source_intent=statement.name,
                annotations=step_annotations,
            )
        )
        return [step_id]

    step_id = f"step_{next(step_counter):04d}"
    plan.add_step(
        PlanStep(
            step_id=step_id,
            primitive=cast(Primitive, HumanStep(instruction=_format_call_statement(statement))),
            dependencies=sorted(set(incoming_dependencies)),
            source_intent=statement.name,
            annotations=step_annotations,
        )
    )
    return [step_id]


def _emit_stamp_statement(
    statement: StampStmt,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    source_lines: list[str] | None,
) -> list[str]:
    volume = _numeric_value(statement.volume)
    if volume is None:
        raise ValueError("stamp() volume must be numeric.")

    return _emit_transfer_pairs(
        sources=_plate_wells(statement.source_plate),
        destinations=_plate_wells(statement.dest_plate),
        volume=volume,
        source_intent="stamp",
        incoming_dependencies=incoming_dependencies,
        plan=plan,
        step_counter=step_counter,
        step_annotations=_statement_annotations(statement, source_lines=source_lines),
    )


def _emit_cherrypick_statement(
    statement: CherrypickStmt,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    source_lines: list[str] | None,
) -> list[str]:
    volume = _numeric_value(statement.volume)
    if volume is None:
        raise ValueError("cherrypick() volume must be numeric.")

    sources = [
        WellRef(plate_id=statement.source_plate, well_id=well)
        for well in statement.source_wells
    ]
    destinations = [
        WellRef(plate_id=statement.dest_plate, well_id=well)
        for well in statement.dest_wells
    ]
    return _emit_transfer_pairs(
        sources=sources,
        destinations=destinations,
        volume=volume,
        source_intent="cherrypick",
        incoming_dependencies=incoming_dependencies,
        plan=plan,
        step_counter=step_counter,
        step_annotations=_statement_annotations(statement, source_lines=source_lines),
    )


def _emit_serial_dilute_statement(
    statement: SerialDiluteStmt,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    source_lines: list[str] | None,
) -> list[str]:
    volume = _numeric_value(statement.volume)
    if volume is None:
        raise ValueError("serial_dilute() volume must be numeric.")
    if statement.dilution_steps <= 0:
        raise ValueError("serial_dilute() steps must be positive.")
    if len(statement.dest_plates) < statement.dilution_steps:
        raise ValueError(
            "serial_dilute() requires at least one destination plate per requested step."
        )

    current_dependencies = sorted(set(incoming_dependencies))
    current_source_plate = statement.source_plate
    step_annotations = _statement_annotations(statement, source_lines=source_lines)
    for dest_plate in statement.dest_plates[: statement.dilution_steps]:
        current_dependencies = _emit_transfer_pairs(
            sources=_plate_wells(current_source_plate),
            destinations=_plate_wells(dest_plate),
            volume=volume,
            source_intent="serial_dilute",
            incoming_dependencies=current_dependencies,
            plan=plan,
            step_counter=step_counter,
            step_annotations=step_annotations,
        )
        current_source_plate = dest_plate

    return current_dependencies


def _emit_transfer_pairs(
    *,
    sources: list[WellRef],
    destinations: list[WellRef],
    volume: float,
    source_intent: str,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
    step_annotations: dict[str, object],
) -> list[str]:
    if len(sources) != len(destinations):
        raise ValueError(
            "Transfer source/destination count mismatch: "
            f"{len(sources)} vs {len(destinations)}."
        )

    current_dependencies = sorted(set(incoming_dependencies))
    for source, destination in zip(sources, destinations):
        aspirate_id = f"step_{next(step_counter):04d}"
        plan.add_step(
            PlanStep(
                step_id=aspirate_id,
                primitive=cast(Primitive, Aspirate(source=source, volume_ul=volume)),
                dependencies=current_dependencies,
                source_intent=source_intent,
                annotations=step_annotations,
            )
        )

        dispense_id = f"step_{next(step_counter):04d}"
        plan.add_step(
            PlanStep(
                step_id=dispense_id,
                primitive=cast(Primitive, Dispense(destination=destination, volume_ul=volume)),
                dependencies=[aspirate_id],
                source_intent=source_intent,
                annotations=step_annotations,
            )
        )
        current_dependencies = [dispense_id]

    return current_dependencies


def _plate_wells(plate_id: str) -> list[WellRef]:
    return [
        WellRef(plate_id=plate_id, well_id=f"{row}{col}")
        for row in "ABCDEFGH"
        for col in range(1, 13)
    ]


def _locations_from_expression(
    expression: object | None,
    location_cache: dict[str, WellRef],
) -> list[WellRef]:
    if isinstance(expression, ListExpr):
        locations: list[WellRef] = []
        for element in expression.elements:
            locations.extend(_locations_from_expression(element, location_cache))
        return locations

    return [_location_from_expression(expression, location_cache)]


def _location_from_expression(
    expression: object | None,
    location_cache: dict[str, WellRef],
) -> WellRef:
    if isinstance(expression, IdentifierExpr):
        return _cached_location(expression.name, location_cache)

    if isinstance(expression, StringLit):
        text = expression.value.strip()
        if ":" in text:
            labware_id, well = text.split(":", 1)
            return WellRef(plate_id=labware_id, well_id=well)
        return _cached_location(text, location_cache)

    key = _format_expression(expression)
    return _cached_location(key, location_cache)


def _cached_location(name: str, location_cache: dict[str, WellRef]) -> WellRef:
    cached = location_cache.get(name)
    if cached is not None:
        return cached

    index = len(location_cache)
    row_index = index // 12
    col = (index % 12) + 1
    row_char = chr(ord("A") + (row_index % 8))
    well_id = f"{row_char}{col}"
    location = WellRef(plate_id="plate_1", well_id=well_id)
    location_cache[name] = location
    return location


def _named_arguments(arguments: list[Argument]) -> dict[str, Argument]:
    return {argument.name: argument for argument in arguments if argument.name is not None}


def _numeric_value(expression: object | None) -> float | None:
    if isinstance(expression, NumberLit):
        return float(expression.value)
    if isinstance(expression, QuantityExpr) and isinstance(expression.value, NumberLit):
        return float(expression.value.value)
    return None


def _duration_seconds(expression: object | None) -> float | None:
    if expression is None:
        return None
    if isinstance(expression, NumberLit):
        return float(expression.value)
    if isinstance(expression, QuantityExpr) and isinstance(expression.value, NumberLit):
        value = float(expression.value.value)
        unit_text = expression.unit.text.strip().lower() if expression.unit else "s"
        if unit_text in {"s", "sec", "second", "seconds"}:
            return value
        if unit_text in {"m", "min", "minute", "minutes"}:
            return value * 60.0
        if unit_text in {"h", "hr", "hour", "hours"}:
            return value * 3600.0
        return value
    return None


def _iter_statements(statements: list[Statement]) -> Iterator[Statement]:
    for statement in statements:
        yield statement
        if isinstance(statement, SequenceBlock):
            yield from _iter_statements(statement.statements)
        if isinstance(statement, ParallelBlock):
            yield from _iter_statements(statement.statements)


def _span_annotation(statement: Statement) -> dict[str, dict[str, int | str]]:
    span = getattr(statement, "span", None)
    if span is None:
        return {}
    return {
        "source_span": {
            "file": span.file,
            "start_line": span.start_line,
            "start_col": span.start_col,
            "end_line": span.end_line,
            "end_col": span.end_col,
        }
    }


def _statement_annotations(
    statement: Statement,
    *,
    source_lines: list[str] | None,
) -> dict[str, object]:
    annotations: dict[str, object] = dict(_span_annotation(statement))

    if isinstance(statement, CallStmt):
        annotations["source_call"] = _format_call_statement(statement)

    span = getattr(statement, "span", None)
    if span is None or source_lines is None:
        return annotations

    line_index = span.start_line - 1
    if 0 <= line_index < len(source_lines):
        source_line = source_lines[line_index].strip()
        if source_line:
            annotations["source_line"] = source_line

    comment_block = _leading_comment_block(
        source_lines=source_lines,
        start_line=span.start_line,
    )
    if comment_block:
        annotations["source_comment"] = comment_block

    return annotations


def _leading_comment_block(*, source_lines: list[str], start_line: int) -> str | None:
    cursor = start_line - 2
    if cursor < 0:
        return None

    # Skip immediate blank lines right above the statement.
    while cursor >= 0 and not source_lines[cursor].strip():
        cursor -= 1

    if cursor < 0:
        return None

    comments: list[str] = []
    while cursor >= 0:
        stripped = source_lines[cursor].strip()
        if not stripped.startswith("//"):
            break
        comment_text = stripped.removeprefix("//").strip()
        comments.append(comment_text)
        cursor -= 1

    if not comments:
        return None
    comments.reverse()
    return "\n".join(comments)


def _location_from_span(
    span: SourceSpan | None,
    source_text: str | None,
) -> DiagnosticLocation | None:
    if span is None:
        return None

    start_offset = _offset_from_line_col(
        source_text=source_text,
        line=span.start_line,
        col=span.start_col,
    )
    end_offset = _offset_from_line_col(
        source_text=source_text,
        line=span.end_line,
        col=span.end_col,
    )
    return DiagnosticLocation(
        file=span.file,
        start=DiagnosticPoint(
            line=span.start_line,
            col=span.start_col,
            offset=start_offset,
        ),
        end=DiagnosticPoint(
            line=span.end_line,
            col=span.end_col,
            offset=max(end_offset, start_offset),
        ),
    )


def _offset_from_line_col(source_text: str | None, line: int, col: int) -> int:
    if source_text is None:
        return 0

    lines = source_text.splitlines(keepends=True)
    if line <= 0:
        return 0
    if line > len(lines):
        return len(source_text)

    prefix = sum(len(lines[idx]) for idx in range(line - 1))
    return min(prefix + max(col - 1, 0), len(source_text))


def _safe_read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return None


def _eof_location(file_path: str, source_text: str) -> DiagnosticLocation:
    lines = source_text.splitlines()
    if not lines:
        return DiagnosticLocation(
            file=file_path,
            start=DiagnosticPoint(line=1, col=1, offset=0),
            end=DiagnosticPoint(line=1, col=1, offset=0),
        )

    line_no = len(lines)
    end_col = len(lines[-1]) + 1
    offset = len(source_text)
    point = DiagnosticPoint(line=line_no, col=end_col, offset=offset)
    return DiagnosticLocation(file=file_path, start=point, end=point)


def _format_call_statement(statement: CallStmt) -> str:
    formatted_args = [_format_argument(argument) for argument in statement.arguments]
    return f"{statement.name}({', '.join(formatted_args)})"


def _format_argument(argument: Argument) -> str:
    value_text = _format_expression(argument.value)
    if argument.name is None:
        return value_text
    return f"{argument.name}: {value_text}"


def _format_expression(expression: object | None) -> str:
    if expression is None:
        return "null"
    if isinstance(expression, IdentifierExpr):
        return expression.name
    if isinstance(expression, NumberLit):
        return f"{expression.value:g}"
    if isinstance(expression, StringLit):
        return f'"{expression.value}"'
    if isinstance(expression, QuantityExpr):
        value_text = _format_expression(expression.value)
        unit_text = expression.unit.text if expression.unit is not None else ""
        return f"{value_text} {unit_text}".strip()
    if isinstance(expression, ListExpr):
        return "[" + ", ".join(_format_expression(item) for item in expression.elements) + "]"
    return expression.__class__.__name__


def _collection_size(expression: object | None) -> int:
    if isinstance(expression, ListExpr):
        return len(expression.elements)
    return 1
