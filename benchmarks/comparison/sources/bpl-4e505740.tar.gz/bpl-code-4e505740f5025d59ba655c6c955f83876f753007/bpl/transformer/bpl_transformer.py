"""
BPL Lark Transformer - Converts parse tree to AST nodes.
"""

from typing import List, Optional, Tuple
from lark import Transformer, Token

from bpl.ast.base import ASTNode, SourceSpan
from bpl.ast.program import Program
from bpl.ast.declarations import (
    Declaration, ProtocolDecl, ModuleDecl, ImportDecl,
    ReagentDecl, StockDecl, LabwareDecl, DeckModelDecl, DeckPosition,
    TargetDecl, ResourceDecl, TypeDecl, FunctionDecl, IntentDecl,
    PrimitiveDecl, RecoveryDecl, InvariantDecl, PcrProfileDecl, PcrCycleStep,
    Parameter, FieldDef, PhysicalForm, Footprint, LabwareCategory,
)
from bpl.ast.statements import (
    Statement, LetStmt, AssignStmt, CallStmt, IfStmt,
    ForStmt, WhileStmt, ReturnStmt, Block, ParallelBlock, SequenceBlock,
    StampStmt, CherrypickStmt, SerialDiluteStmt,
)
from bpl.ast.expressions import (
    Expression, BinaryExpr, UnaryExpr, ConditionalExpr, RangeExpr,
    FieldAccessExpr, MethodCallExpr, IndexExpr, CallExpr,
    QuantityExpr, IdentifierExpr, ListExpr, MapExpr, LambdaExpr,
    StateDeltaExpr, Argument,
)
from bpl.ast.types import (
    TypeExpr, SimpleTypeExpr, ParameterizedTypeExpr, SumTypeExpr,
    ProductTypeExpr, ConstrainedTypeExpr, TypeField, TypeVariant,
)
from bpl.ast.units import UnitExpr, UnitKind
from bpl.ast.annotations import Annotation, AnnotationArg, ProtocolSetting
from bpl.ast.literals import NumberLit, StringLit, BoolLit


# Reserved keywords that cannot be used as identifiers
# Note: 'from' and 'in' are allowed as identifiers since they're commonly
# used as parameter names in lab protocols (e.g., aspirate(from: well))
RESERVED_KEYWORDS = frozenset({
    "protocol", "module", "import", "reagent", "stock",
    "labware", "deck_model", "target", "resource", "type",
    "function", "intent", "primitive", "recovery", "invariant",
    "let", "if", "else", "for", "while", "return", "not",
    "mod", "as", "version", "parallel", "sequence", "StateDelta",
    "pcr_profile", "true", "false",
})


class KeywordAsIdentifierError(Exception):
    """Raised when a keyword is used as an identifier."""
    def __init__(self, keyword: str):
        self.keyword = keyword
        super().__init__(f"Cannot use keyword '{keyword}' as an identifier")


def _check_not_keyword(name: str) -> str:
    """Check that a name is not a reserved keyword."""
    if name in RESERVED_KEYWORDS:
        raise KeywordAsIdentifierError(name)
    return name


def _make_span(meta, filename: str = "<input>") -> Optional[SourceSpan]:
    """Create a SourceSpan from Lark meta information."""
    if meta is None or not hasattr(meta, 'line'):
        return None
    return SourceSpan(
        file=filename,
        start_line=getattr(meta, 'line', 0),
        start_col=getattr(meta, 'column', 0),
        end_line=getattr(meta, 'end_line', getattr(meta, 'line', 0)),
        end_col=getattr(meta, 'end_column', getattr(meta, 'column', 0)),
    )


def _token_span(token: Token) -> Optional[SourceSpan]:
    """Create a SourceSpan from a Lark Token."""
    if token is None:
        return None
    return SourceSpan(
        file="<input>",
        start_line=token.line or 0,
        start_col=token.column or 0,
        end_line=token.end_line or token.line or 0,
        end_col=token.end_column or token.column or 0,
    )


def _span_sort_key_start(span: SourceSpan) -> tuple[int, int]:
    return (span.start_line, span.start_col)


def _span_sort_key_end(span: SourceSpan) -> tuple[int, int]:
    return (span.end_line, span.end_col)


def _merge_spans(spans: list[SourceSpan]) -> Optional[SourceSpan]:
    if not spans:
        return None

    first_file = spans[0].file
    same_file = [span for span in spans if span.file == first_file]
    active = same_file or spans

    start = min(active, key=_span_sort_key_start)
    end = max(active, key=_span_sort_key_end)
    return SourceSpan(
        file=start.file,
        start_line=start.start_line,
        start_col=start.start_col,
        end_line=end.end_line,
        end_col=end.end_col,
    )


class BPLTransformer(Transformer):
    """Transforms Lark parse tree into BPL AST nodes."""

    def __init__(self, filename: str = "<input>"):
        super().__init__()
        self.filename = filename

    def _call_userfunc(self, tree, new_children=None):
        """Attach parse-tree spans to AST nodes produced by each rule."""
        result = super()._call_userfunc(tree, new_children)
        span = _make_span(getattr(tree, "meta", None), filename=self.filename)
        if isinstance(result, ASTNode) and result.span is None:
            result.span = span
        return result

    def _synthesize_spans(self, value) -> Optional[SourceSpan]:
        """Synthesize missing spans from child span bounds."""
        if isinstance(value, ASTNode):
            child_spans: list[SourceSpan] = []
            for field_name, field_value in vars(value).items():
                if field_name == "span":
                    continue
                nested_span = self._synthesize_spans(field_value)
                if nested_span is not None:
                    child_spans.append(nested_span)
            if value.span is None:
                value.span = _merge_spans(child_spans)
            return value.span

        if isinstance(value, list):
            spans = [
                child_span
                for child_span in (self._synthesize_spans(item) for item in value)
                if child_span is not None
            ]
            return _merge_spans(spans)

        if isinstance(value, tuple):
            spans = [
                child_span
                for child_span in (self._synthesize_spans(item) for item in value)
                if child_span is not None
            ]
            return _merge_spans(spans)

        if isinstance(value, dict):
            spans = [
                child_span
                for child_span in (self._synthesize_spans(item) for item in value.values())
                if child_span is not None
            ]
            return _merge_spans(spans)

        return None

    # =========================================================================
    # START / PROGRAM
    # =========================================================================

    def start(self, items) -> Program:
        """Root rule - creates Program node."""
        declarations = [item for item in items if isinstance(item, Declaration)]
        program = Program(declarations=declarations)
        self._synthesize_spans(program)
        return program

    # =========================================================================
    # TERMINALS
    # =========================================================================

    def IDENT(self, token: Token) -> str:
        return str(token)

    def TYPE_IDENT(self, token: Token) -> str:
        return str(token)

    def NUMBER(self, token: Token) -> float:
        return float(token)

    def INTEGER(self, token: Token) -> int:
        return int(token)

    def STRING(self, token: Token) -> str:
        # Remove quotes
        return str(token)[1:-1]

    def BOOL(self, token: Token) -> bool:
        return str(token) == "true"

    def UNIT(self, token: Token) -> str:
        return str(token)

    def COMPOUND_UNIT(self, token: Token) -> str:
        return str(token)

    def MOLAR_UNIT(self, token: Token) -> str:
        return str(token)

    def FOLD_UNIT(self, token: Token) -> str:
        return str(token)

    def PERCENT(self, token: Token) -> str:
        return str(token)

    def PERCENT_LITERAL(self, token: Token) -> str:
        return str(token)

    def PHYSICAL_FORM(self, token: Token) -> PhysicalForm:
        mapping = {
            "Solid": PhysicalForm.SOLID,
            "Liquid": PhysicalForm.LIQUID,
            "Gas": PhysicalForm.GAS,
        }
        return mapping[str(token)]

    def FOOTPRINT(self, token: Token) -> Footprint:
        mapping = {
            "SBS_Standard": Footprint.SBS_STANDARD,
            "SBS_Half": Footprint.SBS_HALF,
            "Custom": Footprint.CUSTOM,
        }
        return mapping[str(token)]

    def LABWARE_CATEGORY(self, token: Token) -> LabwareCategory:
        mapping = {
            "Plate_96": LabwareCategory.PLATE_96,
            "Plate_384": LabwareCategory.PLATE_384,
            "TipRack": LabwareCategory.TIP_RACK,
            "Reservoir": LabwareCategory.RESERVOIR,
            "Tube": LabwareCategory.TUBE,
        }
        return mapping[str(token)]

    def MINUS(self, token: Token) -> str:
        return "-"

    def BANG(self, token: Token) -> str:
        return "!"

    def UNARY_NOT(self, token: Token) -> str:
        return "not"

    # =========================================================================
    # LITERALS
    # =========================================================================

    def number_lit(self, items) -> NumberLit:
        return NumberLit(value=items[0])

    def string_lit(self, items) -> StringLit:
        return StringLit(value=items[0])

    def bool_lit(self, items) -> BoolLit:
        return BoolLit(value=items[0])

    def identifier(self, items) -> IdentifierExpr:
        return IdentifierExpr(name=items[0])

    def type_identifier(self, items) -> IdentifierExpr:
        return IdentifierExpr(name=items[0])

    # =========================================================================
    # QUANTITIES WITH UNITS
    # =========================================================================

    def quantity_simple(self, items) -> QuantityExpr:
        value, unit = items
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text=unit, kind=UnitKind.SIMPLE),
        )

    def quantity_compound(self, items) -> QuantityExpr:
        value, unit = items
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text=unit, kind=UnitKind.COMPOUND),
        )

    def quantity_molar(self, items) -> QuantityExpr:
        value, unit = items
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text=unit, kind=UnitKind.MOLAR),
        )

    def quantity_fold(self, items) -> QuantityExpr:
        value, unit = items
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text=unit, kind=UnitKind.FOLD),
        )

    def quantity_percent(self, items) -> QuantityExpr:
        value = items[0]
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text="%", kind=UnitKind.PERCENT),
        )

    def quantity_percent_lit(self, items) -> QuantityExpr:
        text = str(items[0])
        value = float(text.rstrip('%'))
        return QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text="%", kind=UnitKind.PERCENT),
        )

    # =========================================================================
    # EXPRESSIONS
    # =========================================================================

    def grouped(self, items) -> Expression:
        return items[0]

    def list_literal(self, items) -> ListExpr:
        return ListExpr(elements=list(items))

    def map_literal(self, items) -> MapExpr:
        entries = {}
        for entry in items:
            if isinstance(entry, tuple):
                entries[entry[0]] = entry[1]
        return MapExpr(entries=entries)

    def map_entry(self, items) -> Tuple[str, Expression]:
        return (items[0], items[1])

    def lambda_simple(self, items) -> LambdaExpr:
        if len(items) == 1:
            return LambdaExpr(parameters=[], body=items[0])
        return LambdaExpr(parameters=items[0], body=items[1])

    def lambda_block(self, items) -> LambdaExpr:
        if len(items) == 1:
            return LambdaExpr(parameters=[], body=items[0])
        return LambdaExpr(parameters=items[0], body=items[1])

    def state_delta_expr(self, items) -> StateDeltaExpr:
        fields = {}
        for item in items:
            if isinstance(item, tuple):
                fields[item[0]] = item[1]
        return StateDeltaExpr(fields=fields)

    def state_delta_field_def(self, items) -> Tuple[str, Expression]:
        return (items[0], items[1])

    # Binary operators
    def logical_or_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        for item in items[1:]:
            result = BinaryExpr(op="||", left=result, right=item)
        return result

    def logical_and_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        for item in items[1:]:
            result = BinaryExpr(op="&&", left=result, right=item)
        return result

    def equality_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        i = 1
        while i < len(items):
            op = items[i] if isinstance(items[i], str) else "=="
            right = items[i + 1] if i + 1 < len(items) else items[i]
            result = BinaryExpr(op=op, left=result, right=right)
            i += 2
        return result

    def relational_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        i = 1
        while i < len(items):
            if isinstance(items[i], str):
                op = items[i]
                right = items[i + 1]
                i += 2
            else:
                op = "<"
                right = items[i]
                i += 1
            result = BinaryExpr(op=op, left=result, right=right)
        return result

    def range_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        return RangeExpr(start=items[0], end=items[1])

    def additive_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        i = 1
        while i < len(items):
            if isinstance(items[i], str) and items[i] in ('+', '-'):
                op = items[i]
                right = items[i + 1]
                i += 2
            else:
                op = "+"
                right = items[i]
                i += 1
            result = BinaryExpr(op=op, left=result, right=right)
        return result

    def multiplicative_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        i = 1
        while i < len(items):
            if isinstance(items[i], str) and items[i] in ('*', '/', 'mod'):
                op = items[i]
                right = items[i + 1]
                i += 2
            else:
                op = "*"
                right = items[i]
                i += 1
            result = BinaryExpr(op=op, left=result, right=right)
        return result

    def unary_op(self, items) -> UnaryExpr:
        if len(items) < 2:
            # Handle case where items might be a tree or token
            raise ValueError(f"unary_op requires 2 items, got {len(items)}: {items}")
        op = items[0] if isinstance(items[0], str) else str(items[0])
        return UnaryExpr(op=op, operand=items[1])

    def conditional_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        return ConditionalExpr(
            condition=items[0],
            then_expr=items[1],
            else_expr=items[2],
        )

    # Postfix operations
    def field_access(self, items) -> FieldAccessExpr:
        return FieldAccessExpr(object=None, field=items[0])

    def method_call(self, items) -> MethodCallExpr:
        name = items[0]
        args = items[1] if len(items) > 1 else []
        return MethodCallExpr(object=None, method=name, arguments=args)

    def index_access(self, items) -> IndexExpr:
        return IndexExpr(object=None, index=items[0])

    def func_call(self, items) -> CallExpr:
        args = items[0] if items else []
        return CallExpr(function=None, arguments=args)

    def postfix_expr(self, items) -> Expression:
        if len(items) == 1:
            return items[0]
        result = items[0]
        for op in items[1:]:
            if isinstance(op, FieldAccessExpr):
                result = FieldAccessExpr(object=result, field=op.field)
            elif isinstance(op, MethodCallExpr):
                result = MethodCallExpr(object=result, method=op.method, arguments=op.arguments)
            elif isinstance(op, IndexExpr):
                result = IndexExpr(object=result, index=op.index)
            elif isinstance(op, CallExpr):
                # Check if this should be a method call (previous result was field access)
                if isinstance(result, FieldAccessExpr):
                    # Convert field_access + func_call to method_call: a.b() -> MethodCallExpr(object=a, method='b')
                    result = MethodCallExpr(object=result.object, method=result.field, arguments=op.arguments)
                elif isinstance(result, IdentifierExpr):
                    result = CallExpr(function=result, arguments=op.arguments)
                else:
                    result = CallExpr(function=result, arguments=op.arguments)
        return result

    # =========================================================================
    # ARGUMENTS
    # =========================================================================

    def argument_list(self, items) -> List[Argument]:
        return list(items)

    def named_arg(self, items) -> Argument:
        return Argument(name=items[0], value=items[1])

    def positional_arg(self, items) -> Argument:
        return Argument(name=None, value=items[0])

    # =========================================================================
    # STATEMENTS
    # =========================================================================

    def block(self, items) -> Block:
        statements = []
        for item in items:
            if isinstance(item, Statement):
                statements.append(item)
            elif isinstance(item, list):
                statements.extend(item)
        return Block(statements=statements)

    def parallel_block(self, items) -> ParallelBlock:
        statements = []
        for item in items:
            if isinstance(item, Statement):
                statements.append(item)
        return ParallelBlock(statements=statements)

    def sequence_block(self, items) -> SequenceBlock:
        statements = []
        for item in items:
            if isinstance(item, Statement):
                statements.append(item)
        return SequenceBlock(statements=statements)

    def annotated_statement(self, items) -> Optional[Statement]:
        annotations = []
        statement = None
        for item in items:
            if isinstance(item, Annotation):
                annotations.append(item)
            elif isinstance(item, Statement):
                statement = item
        if statement and annotations:
            statement.annotations = annotations
        return statement

    def call_stmt(self, items) -> CallStmt:
        name = items[0]
        args = items[1] if len(items) > 1 else []
        return CallStmt(name=name, arguments=args)

    def let_stmt(self, items) -> LetStmt:
        name = _check_not_keyword(items[0])
        type_annotation = None
        value = None
        for item in items[1:]:
            if isinstance(item, TypeExpr):
                type_annotation = item
            elif isinstance(item, str) and item and item[0].isupper():
                # TYPE_IDENT came through as string due to inlined type_expr rule
                type_annotation = SimpleTypeExpr(name=item)
            elif isinstance(item, Expression):
                value = item
        return LetStmt(name=name, type_annotation=type_annotation, value=value)

    def reassign_stmt(self, items) -> AssignStmt:
        return AssignStmt(target=items[0], value=items[1])

    def if_stmt(self, items) -> IfStmt:
        # Parse if/else if/else chain
        condition = items[0]
        then_block = items[1]
        else_ifs = []
        else_block = None

        i = 2
        while i < len(items):
            if isinstance(items[i], Expression) and i + 1 < len(items):
                # else if
                else_ifs.append((items[i], items[i + 1]))
                i += 2
            elif isinstance(items[i], Block):
                else_block = items[i]
                i += 1
            else:
                i += 1

        return IfStmt(
            condition=condition,
            then_block=then_block,
            else_ifs=else_ifs,
            else_block=else_block,
        )

    def for_stmt(self, items) -> ForStmt:
        return ForStmt(
            variable=_check_not_keyword(items[0]),
            iterable=items[1],
            body=items[2],
        )

    def while_stmt(self, items) -> WhileStmt:
        return WhileStmt(condition=items[0], body=items[1])

    def return_stmt(self, items) -> ReturnStmt:
        value = items[0] if items else None
        return ReturnStmt(value=value)

    # =========================================================================
    # WORKLIST INTENTS (v2.5)
    # =========================================================================

    def stamp_stmt(self, items) -> StampStmt:
        """Parse stamp(from: plate, to: plate, volume: quantity)"""
        # Skip the STAMP token (index 0), get the actual values
        source_plate = str(items[1])
        dest_plate = str(items[2])
        volume = items[3]
        return StampStmt(
            source_plate=source_plate,
            dest_plate=dest_plate,
            volume=volume,
        )

    def cherrypick_stmt(self, items) -> CherrypickStmt:
        """Parse cherrypick(from: plate[wells], to: plate[wells], volume: quantity)"""
        # Skip the CHERRYPICK token (index 0), get the actual values
        source_plate = str(items[1])
        source_wells = items[2]  # well_list
        dest_plate = str(items[3])
        dest_wells = items[4]  # well_list
        volume = items[5]
        return CherrypickStmt(
            source_plate=source_plate,
            source_wells=source_wells,
            dest_plate=dest_plate,
            dest_wells=dest_wells,
            volume=volume,
        )

    def serial_dilute_stmt(self, items) -> SerialDiluteStmt:
        """Parse serial_dilute(source: plate, destinations: [plates], volume: quantity, steps: int)"""
        # Skip the SERIAL_DILUTE token (index 0), get the actual values
        source_plate = str(items[1])
        dest_plates = items[2]  # name_list
        volume = items[3]
        steps = int(items[4])
        return SerialDiluteStmt(
            source_plate=source_plate,
            dest_plates=dest_plates,
            volume=volume,
            dilution_steps=steps,
        )

    def well_list(self, items) -> List[str]:
        """Parse list of well IDs."""
        return [str(item) for item in items]

    def name_list(self, items) -> List[str]:
        """Parse list of names."""
        return [str(item) for item in items]

    def WELL_ID(self, token) -> str:
        """Handle WELL_ID terminal."""
        raw = str(token).strip().upper()
        row = "".join(char for char in raw if char.isalpha())
        col = "".join(char for char in raw if char.isdigit())
        if not row or not col:
            return raw
        return f"{row}{int(col)}"

    # =========================================================================
    # ANNOTATIONS
    # =========================================================================

    def annotation(self, items) -> Annotation:
        name = items[0]
        args = items[1] if len(items) > 1 else []
        return Annotation(name=name, arguments=args)

    def annotation_args(self, items) -> List[AnnotationArg]:
        return list(items)

    def named_annotation_arg(self, items) -> AnnotationArg:
        return AnnotationArg(name=items[0], value=items[1])

    def positional_annotation_arg(self, items) -> AnnotationArg:
        return AnnotationArg(name=None, value=items[0])

    # =========================================================================
    # TYPE EXPRESSIONS
    # =========================================================================

    def type_expr(self, items) -> TypeExpr:
        return items[0]

    def sum_type(self, items) -> SumTypeExpr:
        return SumTypeExpr(variants=list(items))

    def type_variant(self, items) -> TypeVariant:
        name = items[0]
        fields = items[1] if len(items) > 1 else []
        return TypeVariant(name=name, fields=fields)

    def type_fields(self, items) -> List[TypeField]:
        return list(items)

    def type_field(self, items) -> TypeField:
        name = items[0]
        type_expr = items[1]
        optional = len(items) > 2 and items[2] == "?"
        return TypeField(name=name, type_expr=type_expr, optional=optional)

    def product_type(self, items) -> ProductTypeExpr:
        return ProductTypeExpr(fields=list(items))

    def constrained_type(self, items) -> ConstrainedTypeExpr:
        if len(items) == 3:
            # Number constrained [min, max] with validator
            return ConstrainedTypeExpr(
                base_type=SimpleTypeExpr(name="Number"),
                min_value=items[0],
                max_value=items[1],
                validator=items[2],
            )
        else:
            # Number with validator
            return ConstrainedTypeExpr(
                base_type=SimpleTypeExpr(name="Number"),
                validator=items[0],
            )

    def parameterized_type(self, items) -> ParameterizedTypeExpr:
        name = items[0]
        type_params = list(items[1:])
        return ParameterizedTypeExpr(name=name, type_params=type_params)

    # =========================================================================
    # PARAMETERS
    # =========================================================================

    def parameter_block(self, items) -> List[Parameter]:
        if not items:
            return []
        return items[0] if isinstance(items[0], list) else list(items)

    def parameter_list(self, items) -> List[Parameter]:
        return list(items)

    def parameter(self, items) -> Parameter:
        name = _check_not_keyword(items[0])
        type_annotation = None
        default_value = None
        for item in items[1:]:
            if isinstance(item, TypeExpr):
                type_annotation = item
            elif isinstance(item, Expression):
                default_value = item
            elif isinstance(item, str):
                # Simple type name
                type_annotation = SimpleTypeExpr(name=item)
        return Parameter(
            name=name,
            type_annotation=type_annotation,
            default_value=default_value,
        )

    # =========================================================================
    # IMPORT DECLARATIONS
    # =========================================================================

    def import_path(self, items) -> List[str]:
        return list(items)

    def version_constraint(self, items) -> str:
        return items[0]

    def import_names(self, items) -> List[Tuple[str, Optional[str]]]:
        return list(items)

    def import_item(self, items) -> Tuple[str, Optional[str]]:
        name = items[0]
        alias = items[1] if len(items) > 1 else None
        return (name, alias)

    def import_all(self, items) -> Tuple[str, None]:
        return ("*", None)

    def import_simple(self, items) -> ImportDecl:
        path = items[0]
        version = None
        alias = None
        for item in items[1:]:
            if isinstance(item, str):
                if alias is None:
                    # Could be version or alias
                    if item.startswith('"') or any(c.isdigit() for c in item):
                        version = item
                    else:
                        alias = item
                else:
                    alias = item
        return ImportDecl(
            name=".".join(path),
            path=path,
            version=version,
            alias=alias,
        )

    def import_from(self, items) -> ImportDecl:
        path = items[0]
        version = None
        names = []
        import_all = False

        for item in items[1:]:
            if isinstance(item, str):
                version = item
            elif isinstance(item, list):
                names = item
            elif isinstance(item, tuple):
                if item[0] == "*":
                    import_all = True
                else:
                    names.append(item)

        return ImportDecl(
            name=".".join(path),
            path=path,
            version=version,
            names=names,
            import_all=import_all,
        )

    # =========================================================================
    # MODULE DECLARATION
    # =========================================================================

    def qualified_name(self, items) -> List[str]:
        return list(items)

    def module_body(self, items) -> List[Declaration]:
        return [item for item in items if isinstance(item, Declaration)]

    def module_decl(self, items) -> ModuleDecl:
        name = items[0]
        members = items[1] if len(items) > 1 else []
        return ModuleDecl(
            name=".".join(name),
            qualified_name=name,
            members=members,
        )

    # =========================================================================
    # PROTOCOL DECLARATION
    # =========================================================================

    def protocol_body(self, items) -> Tuple[List[ProtocolSetting], List[Statement]]:
        settings = []
        statements = []
        for item in items:
            if isinstance(item, ProtocolSetting):
                settings.append(item)
            elif isinstance(item, Statement):
                statements.append(item)
        return (settings, statements)

    def protocol_meta(self, items) -> ProtocolSetting:
        return ProtocolSetting(name=items[0], value=items[1])

    def protocol_decl(self, items) -> ProtocolDecl:
        annotations = []
        name = None
        parameters = []
        settings = []
        body = []

        for item in items:
            if isinstance(item, Annotation):
                annotations.append(item)
            elif isinstance(item, str) and name is None:
                name = item
            elif isinstance(item, list) and all(isinstance(p, Parameter) for p in item):
                parameters = item
            elif isinstance(item, tuple):
                settings, body = item

        return ProtocolDecl(
            name=name or "",
            annotations=annotations,
            parameters=parameters,
            settings=settings,
            body=body,
        )

    # =========================================================================
    # REAGENT DECLARATION
    # =========================================================================

    def physical_form_field(self, items) -> Tuple[str, PhysicalForm]:
        return ("physical_form", items[0])

    def mw_field(self, items) -> Tuple[str, QuantityExpr]:
        return ("mw", items[0])

    def field_def(self, items) -> FieldDef:
        return FieldDef(name=items[0], value=items[1])

    def reagent_decl(self, items) -> ReagentDecl:
        name = items[0]
        physical_form = None
        mw = None
        fields = []

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "physical_form":
                    physical_form = item[1]
                elif item[0] == "mw":
                    mw = item[1]
            elif isinstance(item, FieldDef):
                fields.append(item)

        return ReagentDecl(
            name=name,
            physical_form=physical_form,
            mw=mw,
            fields=fields,
        )

    # =========================================================================
    # STOCK DECLARATION
    # =========================================================================

    def stock_reagent(self, items) -> Tuple[str, str]:
        return ("reagent", items[0])

    def stock_concentration(self, items) -> Tuple[str, QuantityExpr]:
        return ("concentration", items[0])

    def stock_solvent(self, items) -> Tuple[str, str]:
        return ("solvent", items[0])

    def stock_fold(self, items) -> Tuple[str, QuantityExpr]:
        value = items[0]
        unit = items[1]
        return ("fold", QuantityExpr(
            value=NumberLit(value=value),
            unit=UnitExpr(text=unit, kind=UnitKind.FOLD),
        ))

    def stock_decl(self, items) -> StockDecl:
        name = items[0]
        reagent = None
        concentration = None
        solvent = None
        fold = None
        fields = []

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "reagent":
                    reagent = item[1]
                elif item[0] == "concentration":
                    concentration = item[1]
                elif item[0] == "solvent":
                    solvent = item[1]
                elif item[0] == "fold":
                    fold = item[1]
            elif isinstance(item, FieldDef):
                fields.append(item)

        return StockDecl(
            name=name,
            reagent=reagent,
            concentration=concentration,
            solvent=solvent,
            fold=fold,
            fields=fields,
        )

    # =========================================================================
    # LABWARE DECLARATION
    # =========================================================================

    def footprint_field(self, items) -> Tuple[str, Footprint]:
        return ("footprint", items[0])

    def well_count_field(self, items) -> Tuple[str, int]:
        return ("well_count", items[0])

    def well_volume_field(self, items) -> Tuple[str, QuantityExpr]:
        return ("well_volume", items[0])

    def category_field(self, items) -> Tuple[str, LabwareCategory]:
        return ("category", items[0])

    def barcode_field(self, items) -> Tuple[str, str]:
        # Strip quotes from the string
        barcode = items[0][1:-1] if items[0].startswith('"') else items[0]
        return ("barcode", barcode)

    def set_id_field(self, items) -> Tuple[str, str]:
        # Strip quotes from the string
        set_id = items[0][1:-1] if items[0].startswith('"') else items[0]
        return ("set_identifier", set_id)

    def labware_decl(self, items) -> LabwareDecl:
        name = items[0]
        footprint = None
        well_count = None
        well_volume = None
        category = None
        barcode = None
        set_identifier = None
        fields = []

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "footprint":
                    footprint = item[1]
                elif item[0] == "well_count":
                    well_count = item[1]
                elif item[0] == "well_volume":
                    well_volume = item[1]
                elif item[0] == "category":
                    category = item[1]
                elif item[0] == "barcode":
                    barcode = item[1]
                elif item[0] == "set_identifier":
                    set_identifier = item[1]
            elif isinstance(item, FieldDef):
                fields.append(item)

        return LabwareDecl(
            name=name,
            footprint=footprint,
            well_count=well_count,
            well_volume=well_volume,
            category=category,
            barcode=barcode,
            set_identifier=set_identifier,
            fields=fields,
        )

    # =========================================================================
    # DECK MODEL DECLARATION
    # =========================================================================

    def positions_field(self, items) -> List[DeckPosition]:
        return list(items)

    def deck_position(self, items) -> DeckPosition:
        id = ""
        accepts = []
        coordinates = None
        is_waste = False

        for item in items:
            if isinstance(item, tuple):
                if item[0] == "id":
                    id = item[1]
                elif item[0] == "accepts":
                    accepts = item[1]
                elif item[0] == "coordinates":
                    coordinates = item[1]
                elif item[0] == "is_waste":
                    is_waste = item[1]

        return DeckPosition(
            id=id,
            accepts=accepts,
            coordinates=coordinates,
            is_waste=is_waste,
        )

    def position_id(self, items) -> Tuple[str, str]:
        return ("id", items[0])

    def position_accepts(self, items) -> Tuple[str, List[Footprint]]:
        return ("accepts", list(items))

    def position_coords(self, items) -> Tuple[str, Tuple[float, float, float]]:
        return ("coordinates", items[0])

    def coord_entries(self, items) -> Tuple[float, float, float]:
        return (float(items[0]), float(items[1]), float(items[2]))

    def position_waste(self, items) -> Tuple[str, bool]:
        return ("is_waste", items[0])

    def deck_model_decl(self, items) -> DeckModelDecl:
        name = items[0]
        positions = []
        fields = []

        for item in items[1:]:
            if isinstance(item, list):
                positions = item
            elif isinstance(item, FieldDef):
                fields.append(item)

        return DeckModelDecl(
            name=name,
            positions=positions,
            fields=fields,
        )

    # =========================================================================
    # TARGET DECLARATION
    # =========================================================================

    def capabilities_field(self, items) -> Tuple[str, List[str]]:
        return ("capabilities", list(items))

    def not_capabilities_field(self, items) -> Tuple[str, List[str]]:
        return ("not_capabilities", list(items))

    def target_decl(self, items) -> TargetDecl:
        name = items[0]
        capabilities = []
        not_capabilities = []
        fields = []

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "capabilities":
                    capabilities = item[1]
                elif item[0] == "not_capabilities":
                    not_capabilities = item[1]
            elif isinstance(item, FieldDef):
                fields.append(item)

        return TargetDecl(
            name=name,
            capabilities=capabilities,
            not_capabilities=not_capabilities,
            fields=fields,
        )

    # =========================================================================
    # RESOURCE DECLARATION (v2.4)
    # =========================================================================

    def capacity_field(self, items) -> Tuple[str, int]:
        return ("capacity", items[0])

    def booking_required_field(self, items) -> Tuple[str, bool]:
        return ("booking_required", items[0])

    def cooldown_field(self, items) -> Tuple[str, QuantityExpr]:
        return ("cooldown", items[0])

    def min_booking_field(self, items) -> Tuple[str, QuantityExpr]:
        return ("min_booking_duration", items[0])

    def resource_decl(self, items) -> ResourceDecl:
        name = items[0]
        capacity = None
        booking_required = None
        cooldown = None
        min_booking_duration = None
        fields = []

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "capacity":
                    capacity = item[1]
                elif item[0] == "booking_required":
                    booking_required = item[1]
                elif item[0] == "cooldown":
                    cooldown = item[1]
                elif item[0] == "min_booking_duration":
                    min_booking_duration = item[1]
            elif isinstance(item, FieldDef):
                fields.append(item)

        return ResourceDecl(
            name=name,
            capacity=capacity,
            booking_required=booking_required,
            cooldown=cooldown,
            min_booking_duration=min_booking_duration,
            fields=fields,
        )

    # =========================================================================
    # TYPE DECLARATION
    # =========================================================================

    def type_decl(self, items) -> TypeDecl:
        name = items[0]
        type_expr = items[1]
        return TypeDecl(name=name, type_expr=type_expr)

    # =========================================================================
    # FUNCTION DECLARATION
    # =========================================================================

    def function_decl(self, items) -> FunctionDecl:
        name = items[0]
        parameters = []
        return_type = None
        body = None

        for item in items[1:]:
            if isinstance(item, list) and all(isinstance(p, Parameter) for p in item):
                parameters = item
            elif isinstance(item, TypeExpr):
                return_type = item
            elif isinstance(item, str) and item and item[0].isupper():
                # TYPE_IDENT came through as string due to inlined type_expr rule
                return_type = SimpleTypeExpr(name=item)
            elif isinstance(item, Block):
                body = item

        return FunctionDecl(
            name=name,
            parameters=parameters,
            return_type=return_type,
            body=body,
        )

    # =========================================================================
    # INTENT / PRIMITIVE DECLARATIONS
    # =========================================================================

    def intent_decl(self, items) -> IntentDecl:
        name = items[0]
        parameters = []
        return_type = None

        for item in items[1:]:
            if isinstance(item, list):
                parameters = item
            elif isinstance(item, TypeExpr):
                return_type = item
            elif isinstance(item, str):
                return_type = SimpleTypeExpr(name=item)

        return IntentDecl(
            name=name,
            parameters=parameters,
            return_type=return_type,
        )

    def primitive_decl(self, items) -> PrimitiveDecl:
        name = items[0]
        parameters = []
        return_type = None

        for item in items[1:]:
            if isinstance(item, list):
                parameters = item
            elif isinstance(item, TypeExpr):
                return_type = item
            elif isinstance(item, str):
                return_type = SimpleTypeExpr(name=item)

        return PrimitiveDecl(
            name=name,
            parameters=parameters,
            return_type=return_type,
        )

    # =========================================================================
    # RECOVERY DECLARATION (v2.4)
    # =========================================================================

    def recovery_decl(self, items) -> RecoveryDecl:
        annotations = []
        name = None
        body = []

        for item in items:
            if isinstance(item, Annotation):
                annotations.append(item)
            elif isinstance(item, str) and name is None:
                name = item
            elif isinstance(item, Statement):
                body.append(item)

        return RecoveryDecl(
            name=name or "",
            annotations=annotations,
            body=body,
        )

    # =========================================================================
    # INVARIANT DECLARATION (v2.4)
    # =========================================================================

    def invariant_check(self, items) -> Tuple[str, Expression]:
        return ("check", items[0])

    def invariant_after(self, items) -> Tuple[str, List[str]]:
        return ("after", list(items))

    def invariant_violation(self, items) -> Tuple[str, Expression]:
        return ("on_violation", items[0])

    def invariant_decl(self, items) -> InvariantDecl:
        name = items[0]
        check = None
        after = []
        on_violation = None

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "check":
                    check = item[1]
                elif item[0] == "after":
                    after = item[1]
                elif item[0] == "on_violation":
                    on_violation = item[1]

        return InvariantDecl(
            name=name,
            check=check,
            after=after,
            on_violation=on_violation,
        )

    # =========================================================================
    # PCR PROFILE DECLARATION
    # =========================================================================

    def pcr_initial(self, items) -> Tuple[str, Tuple[QuantityExpr, QuantityExpr]]:
        return ("initial", (items[0], items[1]))

    def pcr_cycles(self, items) -> Tuple[str, Tuple[int, List[PcrCycleStep]]]:
        cycle_count = items[0]
        cycle_steps = [item for item in items[1:] if isinstance(item, PcrCycleStep)]
        return ("cycles", (cycle_count, cycle_steps))

    def pcr_cycle_step(self, items) -> PcrCycleStep:
        name = items[0]
        temperature = items[1]
        duration = items[2]
        return PcrCycleStep(name=name, temperature=temperature, duration=duration)

    def pcr_final(self, items) -> Tuple[str, Tuple[QuantityExpr, QuantityExpr]]:
        return ("final", (items[0], items[1]))

    def pcr_hold(self, items) -> Tuple[str, QuantityExpr]:
        return ("hold", items[0])

    def pcr_lid_temp(self, items) -> Tuple[str, QuantityExpr]:
        return ("lid_temp", items[0])

    def pcr_profile_decl(self, items) -> PcrProfileDecl:
        name = items[0]
        initial_temp = None
        initial_duration = None
        cycle_count = 30
        cycle_steps: List[PcrCycleStep] = []
        final_temp = None
        final_duration = None
        hold_temp = None
        lid_temp = None

        for item in items[1:]:
            if isinstance(item, tuple):
                if item[0] == "initial":
                    initial_temp, initial_duration = item[1]
                elif item[0] == "cycles":
                    cycle_count, cycle_steps = item[1]
                elif item[0] == "final":
                    final_temp, final_duration = item[1]
                elif item[0] == "hold":
                    hold_temp = item[1]
                elif item[0] == "lid_temp":
                    lid_temp = item[1]

        return PcrProfileDecl(
            name=name,
            initial_temp=initial_temp,
            initial_duration=initial_duration,
            cycle_count=cycle_count,
            cycle_steps=cycle_steps,
            final_temp=final_temp,
            final_duration=final_duration,
            hold_temp=hold_temp,
            lid_temp=lid_temp,
        )
