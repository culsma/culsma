"""
BPL Validation - Simulation validation checks.

Provides:
- NoOverflow, NoEmptyAspiration, NoNegativeVolume
- ResourceAvailable, TipsAvailable
- TemperatureInRange, ConcentrationValid
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum, auto
from abc import ABC, abstractmethod

from .virtual_deck import VirtualDeckState
from ..lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    Aspirate,
    Dispense,
    WellRef,
)


class ValidationSeverity(Enum):
    """Severity of validation issues."""
    INFO = auto()
    WARNING = auto()
    ERROR = auto()
    CRITICAL = auto()


@dataclass
class ValidationIssue:
    """A validation issue found during checking."""
    check_name: str
    severity: ValidationSeverity
    message: str
    step_id: Optional[str] = None
    location: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        loc = f" at {self.location}" if self.location else ""
        step = f" [step: {self.step_id}]" if self.step_id else ""
        return f"[{self.severity.name}] {self.check_name}{loc}{step}: {self.message}"


@dataclass
class ValidationResult:
    """Result of validation checks."""
    passed: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    checks_run: int = 0
    checks_passed: int = 0
    checks_failed: int = 0

    def add_issue(self, issue: ValidationIssue) -> None:
        """Add a validation issue."""
        self.issues.append(issue)
        if issue.severity in (ValidationSeverity.ERROR, ValidationSeverity.CRITICAL):
            self.passed = False

    def merge(self, other: 'ValidationResult') -> None:
        """Merge another result into this one."""
        self.issues.extend(other.issues)
        self.checks_run += other.checks_run
        self.checks_passed += other.checks_passed
        self.checks_failed += other.checks_failed
        if not other.passed:
            self.passed = False

    def get_errors(self) -> List[ValidationIssue]:
        """Get only error-level issues."""
        return [i for i in self.issues if i.severity == ValidationSeverity.ERROR]

    def get_warnings(self) -> List[ValidationIssue]:
        """Get only warning-level issues."""
        return [i for i in self.issues if i.severity == ValidationSeverity.WARNING]


class ValidationCheck(ABC):
    """Base class for validation checks."""

    def __init__(self, name: str, severity: ValidationSeverity = ValidationSeverity.ERROR):
        self.name = name
        self.severity = severity

    @abstractmethod
    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        """
        Validate a step against deck state.

        Returns None if valid, ValidationIssue if invalid.
        """
        pass


class NoOverflowCheck(ValidationCheck):
    """Check that dispensing won't overflow wells."""

    def __init__(self):
        super().__init__("NoOverflow", ValidationSeverity.ERROR)

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        if not isinstance(step.primitive, Dispense):
            return None

        primitive = step.primitive
        dest = primitive.destination
        volume = primitive.volume_ul

        if not isinstance(dest, WellRef):
            # ContainerRef does not have plate_id/well_id, skip validation
            return None

        contents = deck_state.get_well_contents(dest.plate_id, dest.well_id)
        if contents is None:
            return ValidationIssue(
                check_name=self.name,
                severity=ValidationSeverity.ERROR,
                message="Destination well not found",
                step_id=step.step_id,
                location=f"{dest.plate_id}/{dest.well_id}"
            )

        if contents.would_overflow(volume):
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message=(
                    f"Adding {volume}uL would overflow "
                    f"(current: {contents.volume_ul}uL, max: {contents.max_volume_ul}uL)"
                ),
                step_id=step.step_id,
                location=f"{dest.plate_id}/{dest.well_id}",
                details={
                    "current_volume": contents.volume_ul,
                    "add_volume": volume,
                    "max_volume": contents.max_volume_ul
                }
            )

        return None


class NoEmptyAspirationCheck(ValidationCheck):
    """Check that aspirating from non-empty wells."""

    def __init__(self):
        super().__init__("NoEmptyAspiration", ValidationSeverity.ERROR)

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        if not isinstance(step.primitive, Aspirate):
            return None

        primitive = step.primitive
        source = primitive.source
        volume = primitive.volume_ul

        if not isinstance(source, WellRef):
            # ContainerRef does not have plate_id/well_id, skip validation
            return None

        contents = deck_state.get_well_contents(source.plate_id, source.well_id)
        if contents is None:
            return ValidationIssue(
                check_name=self.name,
                severity=ValidationSeverity.ERROR,
                message="Source well not found",
                step_id=step.step_id,
                location=f"{source.plate_id}/{source.well_id}"
            )

        if contents.is_empty():
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message="Aspirating from empty well",
                step_id=step.step_id,
                location=f"{source.plate_id}/{source.well_id}"
            )

        if contents.volume_ul < volume:
            return ValidationIssue(
                check_name=self.name,
                severity=ValidationSeverity.WARNING,
                message=(
                    f"Aspirating {volume}uL but only {contents.volume_ul}uL available"
                ),
                step_id=step.step_id,
                location=f"{source.plate_id}/{source.well_id}",
                details={
                    "requested_volume": volume,
                    "available_volume": contents.volume_ul
                }
            )

        return None


class NoNegativeVolumeCheck(ValidationCheck):
    """Check that transfer and mix volumes are positive."""

    def __init__(self):
        super().__init__("NoNegativeVolume", ValidationSeverity.ERROR)

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        from ..lowering.plan_ir import Mix

        primitive = step.primitive
        volume: Optional[float] = None

        # Check for primitives that have volume_ul attribute
        if isinstance(primitive, (Aspirate, Dispense, Mix)):
            volume = primitive.volume_ul

        if volume is not None and volume <= 0:
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message=f"Non-positive volume: {volume}uL",
                step_id=step.step_id,
                details={"volume": volume}
            )

        return None


class TipsAvailableCheck(ValidationCheck):
    """Check that tips are available when needed."""

    def __init__(self):
        super().__init__("TipsAvailable", ValidationSeverity.ERROR)

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        from ..lowering.plan_ir import PickTips

        if not isinstance(step.primitive, PickTips):
            return None

        primitive = step.primitive
        rack_id = primitive.tip_rack.rack_id
        positions = primitive.tip_positions

        tip_state = deck_state.tip_states.get(rack_id)
        if tip_state is None:
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message=f"Tip rack not found: {rack_id}",
                step_id=step.step_id
            )

        missing = [p for p in positions if not tip_state.has_tip(p)]
        if missing:
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message=f"Tips not available at positions: {missing}",
                step_id=step.step_id,
                location=rack_id,
                details={"missing_positions": missing}
            )

        return None


class ResourceAvailableCheck(ValidationCheck):
    """Check that required resources are available."""

    def __init__(self, required_resources: Optional[Dict[str, str]] = None):
        super().__init__("ResourceAvailable", ValidationSeverity.ERROR)
        self.required_resources = required_resources or {}

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        # Check labware exists
        primitive = step.primitive

        # Check source for Aspirate primitives
        if isinstance(primitive, Aspirate):
            source = primitive.source
            if isinstance(source, WellRef):
                plate_id = source.plate_id
                if deck_state.get_labware(plate_id) is None:
                    return ValidationIssue(
                        check_name=self.name,
                        severity=self.severity,
                        message=f"Source labware not found: {plate_id}",
                        step_id=step.step_id
                    )

        # Check destination for Dispense primitives
        if isinstance(primitive, Dispense):
            destination = primitive.destination
            if isinstance(destination, WellRef):
                plate_id = destination.plate_id
                if deck_state.get_labware(plate_id) is None:
                    return ValidationIssue(
                        check_name=self.name,
                        severity=self.severity,
                        message=f"Destination labware not found: {plate_id}",
                        step_id=step.step_id
                    )

        return None


class TemperatureInRangeCheck(ValidationCheck):
    """Check that temperatures are within valid ranges."""

    def __init__(self, min_temp: float = -20.0, max_temp: float = 100.0):
        super().__init__("TemperatureInRange", ValidationSeverity.WARNING)
        self.min_temp = min_temp
        self.max_temp = max_temp

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        from ..lowering.plan_ir import SetTemperature

        if not isinstance(step.primitive, SetTemperature):
            return None

        primitive = step.primitive
        temp = primitive.temperature_c

        if temp < self.min_temp or temp > self.max_temp:
            return ValidationIssue(
                check_name=self.name,
                severity=self.severity,
                message=f"Temperature {temp}°C outside range [{self.min_temp}, {self.max_temp}]",
                step_id=step.step_id,
                location=primitive.device_id,
                details={
                    "temperature": temp,
                    "min": self.min_temp,
                    "max": self.max_temp
                }
            )

        return None


class VolumeRangeCheck(ValidationCheck):
    """Check that volumes are within pipette range."""

    def __init__(self, min_volume: float = 1.0, max_volume: float = 1000.0):
        super().__init__("VolumeInRange", ValidationSeverity.WARNING)
        self.min_volume = min_volume
        self.max_volume = max_volume

    def validate(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> Optional[ValidationIssue]:
        from ..lowering.plan_ir import Mix

        primitive = step.primitive
        volume: Optional[float] = None

        # Check for primitives that have volume_ul attribute
        if isinstance(primitive, (Aspirate, Dispense, Mix)):
            volume = primitive.volume_ul

        if volume is not None:
            if volume < self.min_volume:
                return ValidationIssue(
                    check_name=self.name,
                    severity=self.severity,
                    message=f"Volume {volume}uL below minimum {self.min_volume}uL",
                    step_id=step.step_id,
                    details={"volume": volume, "min": self.min_volume}
                )
            if volume > self.max_volume:
                return ValidationIssue(
                    check_name=self.name,
                    severity=self.severity,
                    message=f"Volume {volume}uL above maximum {self.max_volume}uL",
                    step_id=step.step_id,
                    details={"volume": volume, "max": self.max_volume}
                )

        return None


class Validator:
    """
    Validator that runs multiple checks on execution plans.
    """

    def __init__(self):
        self.checks: List[ValidationCheck] = []

    def add_check(self, check: ValidationCheck) -> None:
        """Add a validation check."""
        self.checks.append(check)

    def add_default_checks(self) -> None:
        """Add default validation checks."""
        self.checks.extend([
            NoOverflowCheck(),
            NoEmptyAspirationCheck(),
            NoNegativeVolumeCheck(),
            TipsAvailableCheck(),
            ResourceAvailableCheck(),
            TemperatureInRangeCheck(),
            VolumeRangeCheck(),
        ])

    def validate_step(
        self,
        step: PlanStep,
        deck_state: VirtualDeckState
    ) -> ValidationResult:
        """Validate a single step."""
        result = ValidationResult(passed=True)

        for check in self.checks:
            result.checks_run += 1
            issue = check.validate(step, deck_state)
            if issue:
                result.add_issue(issue)
                result.checks_failed += 1
            else:
                result.checks_passed += 1

        return result

    def validate_plan(
        self,
        plan: ExecutionPlan,
        deck_state: VirtualDeckState
    ) -> ValidationResult:
        """Validate an entire execution plan."""
        result = ValidationResult(passed=True)

        for step_id in plan.topological_order():
            step = plan.steps[step_id]
            step_result = self.validate_step(step, deck_state)
            result.merge(step_result)

        return result


def create_validator() -> Validator:
    """Create a validator with default checks."""
    validator = Validator()
    validator.add_default_checks()
    return validator


def validate_plan(
    plan: ExecutionPlan,
    deck_state: VirtualDeckState
) -> ValidationResult:
    """Convenience function to validate a plan."""
    validator = create_validator()
    return validator.validate_plan(plan, deck_state)
