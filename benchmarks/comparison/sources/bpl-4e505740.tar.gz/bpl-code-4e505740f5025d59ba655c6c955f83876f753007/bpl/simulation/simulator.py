"""
BPL Simulator - Dry-run simulation engine.

Provides:
- simulate() function with state trace
- Step-by-step execution
- SimulationResult with final state
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime

from ..capabilities import (
    StrictCapabilityError,
    is_primitive_supported,
    primitive_identifier,
)
from ..orchestrator import run_capability_preflight
from .virtual_deck import (
    VirtualDeckState,
    create_standard_deck,
)
from ..lowering.plan_ir import (
    ExecutionPlan,
    PlanStep,
    PrimitiveType,
    Primitive,
    Aspirate,
    Dispense,
    Mix,
    PickTips,
    DropTips,
    Checkpoint,
    Pause,
    Wait,
    MoveLabware,
    SetTemperature,
    WellRef,
)


class SimulationStatus(Enum):
    """Status of simulation."""
    NOT_STARTED = auto()
    RUNNING = auto()
    PAUSED = auto()
    COMPLETED = auto()
    FAILED = auto()
    ABORTED = auto()


@dataclass
class StepTrace:
    """Trace of a single step execution."""
    step_id: str
    primitive_type: PrimitiveType
    state_before_hash: str
    state_after_hash: str
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0.0
    success: bool = True
    error_message: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SimulationResult:
    """Result of a simulation run."""
    plan_id: str
    status: SimulationStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    initial_state_hash: str = ""
    final_state_hash: str = ""
    steps_executed: int = 0
    steps_failed: int = 0
    step_traces: List[StepTrace] = field(default_factory=list)
    validation_errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    unsupported_step_count: int = 0
    unsupported_primitives: List[str] = field(default_factory=list)
    final_deck_state: Optional[VirtualDeckState] = None

    @property
    def success(self) -> bool:
        return self.status == SimulationStatus.COMPLETED and self.steps_failed == 0

    @property
    def duration_s(self) -> Optional[float]:
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    def add_trace(self, trace: StepTrace) -> None:
        """Add a step trace."""
        self.step_traces.append(trace)
        self.steps_executed += 1
        if not trace.success:
            self.steps_failed += 1

    def add_error(self, error: str) -> None:
        """Add a validation error."""
        self.validation_errors.append(error)

    def add_warning(self, warning: str) -> None:
        """Add a warning."""
        self.warnings.append(warning)


class Simulator:
    """
    Simulation engine for BPL execution plans.

    Executes plans against a virtual deck state,
    tracking all state transitions.
    """

    def __init__(
        self,
        deck_state: Optional[VirtualDeckState] = None,
        validate: bool = True,
        trace_enabled: bool = True,
        strict_capabilities: bool = False,
        capability_target: str = "simulation",
    ):
        self.deck_state = deck_state or create_standard_deck()
        self.validate = validate
        self.trace_enabled = trace_enabled
        self.strict_capabilities = strict_capabilities
        self.capability_target = capability_target
        self._status = SimulationStatus.NOT_STARTED
        self._current_step: Optional[str] = None
        self._breakpoints: set[str] = set()
        self._step_callbacks: List[Callable[[PlanStep, VirtualDeckState], None]] = []

    def simulate(
        self,
        plan: ExecutionPlan,
        stop_on_error: bool = True
    ) -> SimulationResult:
        """
        Simulate execution of a plan.

        Args:
            plan: The execution plan to simulate
            stop_on_error: Whether to stop on first error

        Returns:
            SimulationResult with traces and final state
        """
        result = SimulationResult(
            plan_id=plan.plan_id,
            status=SimulationStatus.RUNNING,
            started_at=datetime.now(),
            initial_state_hash=self.deck_state.get_state_hash()
        )

        self._status = SimulationStatus.RUNNING

        try:
            preflight = run_capability_preflight(
                plan=plan,
                target=self.capability_target,
                strict=self.strict_capabilities,
            )
            if preflight.unsupported_primitives:
                result.warnings.append(
                    "Unsupported primitives will run as no-op in non-strict mode: "
                    + ", ".join(preflight.unsupported_primitives)
                )

            # Get execution order
            step_order = plan.topological_order()

            for step_id in step_order:
                if self._status == SimulationStatus.ABORTED:
                    break

                step = plan.steps[step_id]
                self._current_step = step_id

                # Execute step
                trace = self._execute_step(step)
                result.add_trace(trace)
                if trace.details.get("unsupported"):
                    result.unsupported_step_count += 1
                    primitive_id = str(trace.details.get("primitive_id", ""))
                    if primitive_id and primitive_id not in result.unsupported_primitives:
                        result.unsupported_primitives.append(primitive_id)
                    result.add_warning(
                        f"Unsupported primitive executed as no-op: "
                        f"{step.primitive.primitive_type.name} [step: {step_id}]"
                    )

                # Check for errors
                if not trace.success:
                    result.add_error(f"Step {step_id} failed: {trace.error_message}")
                    if stop_on_error:
                        self._status = SimulationStatus.FAILED
                        break

                # Invoke callbacks
                for callback in self._step_callbacks:
                    callback(step, self.deck_state)

            # Complete simulation
            if self._status == SimulationStatus.RUNNING:
                self._status = SimulationStatus.COMPLETED

        except StrictCapabilityError as exc:
            self._status = SimulationStatus.FAILED
            result.unsupported_primitives = list(exc.unsupported_primitives)
            result.add_error(
                f"Strict capability failure ({exc.target}): "
                f"{', '.join(exc.unsupported_primitives)}"
            )
        except Exception as e:
            self._status = SimulationStatus.FAILED
            result.add_error(f"Simulation error: {str(e)}")

        result.status = self._status
        result.completed_at = datetime.now()
        result.final_state_hash = self.deck_state.get_state_hash()
        result.final_deck_state = self.deck_state

        return result

    def _execute_step(self, step: PlanStep) -> StepTrace:
        """Execute a single step and return trace."""
        start_time = datetime.now()
        state_before = self.deck_state.get_state_hash()

        trace = StepTrace(
            step_id=step.step_id,
            primitive_type=step.primitive.primitive_type,
            state_before_hash=state_before,
            state_after_hash=""  # Will be set after
        )

        try:
            # Execute based on primitive type
            self._execute_primitive(step.primitive, trace)
            trace.success = True
        except Exception as e:
            trace.success = False
            trace.error_message = str(e)

        trace.state_after_hash = self.deck_state.get_state_hash()
        trace.duration_ms = (datetime.now() - start_time).total_seconds() * 1000

        return trace

    def _execute_primitive(self, primitive: Primitive, trace: StepTrace) -> None:
        """Execute a primitive operation."""
        if not is_primitive_supported(primitive.primitive_type, self.capability_target):
            trace.details["action"] = "unsupported_no_op"
            trace.details["unsupported"] = True
            trace.details["primitive_id"] = primitive_identifier(primitive.primitive_type)
            return

        if isinstance(primitive, Aspirate):
            self._exec_aspirate(primitive, trace)
        elif isinstance(primitive, Dispense):
            self._exec_dispense(primitive, trace)
        elif isinstance(primitive, Mix):
            self._exec_mix(primitive, trace)
        elif isinstance(primitive, PickTips):
            self._exec_pick_tips(primitive, trace)
        elif isinstance(primitive, DropTips):
            self._exec_drop_tips(primitive, trace)
        elif isinstance(primitive, Checkpoint):
            self._exec_checkpoint(primitive, trace)
        elif isinstance(primitive, Pause):
            self._exec_pause(primitive, trace)
        elif isinstance(primitive, Wait):
            self._exec_wait(primitive, trace)
        elif isinstance(primitive, MoveLabware):
            self._exec_move_labware(primitive, trace)
        elif isinstance(primitive, SetTemperature):
            self._exec_set_temperature(primitive, trace)
        else:
            # Default: no-op for simulation
            trace.details["action"] = "unsupported_no_op"
            trace.details["unsupported"] = True
            trace.details["primitive_id"] = primitive_identifier(primitive.primitive_type)

    def _exec_aspirate(self, primitive: Aspirate, trace: StepTrace) -> None:
        """Execute aspirate operation."""
        source = primitive.source
        volume = primitive.volume_ul

        if self.validate and volume <= 0:
            raise ValueError(f"Aspirate volume must be positive, got {volume}uL")

        # Only WellRef has plate_id and well_id
        if not isinstance(source, WellRef):
            raise ValueError(f"Aspirate source must be a WellRef, got {type(source).__name__}")

        # Get well contents
        contents = self.deck_state.get_well_contents(source.plate_id, source.well_id)
        if contents is None:
            raise ValueError(f"Well not found: {source.plate_id}/{source.well_id}")

        # Validate
        if self.validate and contents.volume_ul < volume:
            raise ValueError(
                f"Source insufficiency: requested {volume}uL from {source.well_id} "
                f"but only {contents.volume_ul}uL available"
            )

        # Execute
        actual = contents.remove_volume(volume)
        trace.details["volume_aspirated"] = actual
        trace.details["source"] = f"{source.plate_id}/{source.well_id}"

        # Update pipette if available
        pipette = self.deck_state.get_pipette("default_pipette")
        if pipette:
            pipette.aspirate(actual)

    def _exec_dispense(self, primitive: Dispense, trace: StepTrace) -> None:
        """Execute dispense operation."""
        dest = primitive.destination
        volume = primitive.volume_ul

        if self.validate and volume <= 0:
            raise ValueError(f"Dispense volume must be positive, got {volume}uL")

        # Only WellRef has plate_id and well_id
        if not isinstance(dest, WellRef):
            raise ValueError(f"Dispense destination must be a WellRef, got {type(dest).__name__}")

        # Get well contents
        contents = self.deck_state.get_well_contents(dest.plate_id, dest.well_id)
        if contents is None:
            raise ValueError(f"Well not found: {dest.plate_id}/{dest.well_id}")

        # Validate
        if self.validate and contents.would_overflow(volume):
            raise ValueError(
                f"Overflow: adding {volume}uL to {dest.well_id} "
                f"(current: {contents.volume_ul}uL, max: {contents.max_volume_ul}uL)"
            )

        # Execute
        contents.add_volume(volume)
        trace.details["volume_dispensed"] = volume
        trace.details["destination"] = f"{dest.plate_id}/{dest.well_id}"

        # Update pipette if available
        pipette = self.deck_state.get_pipette("default_pipette")
        if pipette:
            pipette.dispense(volume)

    def _exec_mix(self, primitive: Mix, trace: StepTrace) -> None:
        """Execute mix operation."""
        location = primitive.location
        cycles = primitive.cycles

        if self.validate and primitive.volume_ul <= 0:
            raise ValueError(f"Mix volume must be positive, got {primitive.volume_ul}uL")

        # Only WellRef has plate_id and well_id
        if not isinstance(location, WellRef):
            raise ValueError(f"Mix location must be a WellRef, got {type(location).__name__}")

        # Get well contents
        contents = self.deck_state.get_well_contents(location.plate_id, location.well_id)
        if contents is None:
            raise ValueError(f"Well not found: {location.plate_id}/{location.well_id}")

        # Execute
        contents.mix()
        trace.details["location"] = f"{location.plate_id}/{location.well_id}"
        trace.details["cycles"] = cycles

    def _exec_pick_tips(self, primitive: PickTips, trace: StepTrace) -> None:
        """Execute pick tips operation."""
        rack_id = primitive.tip_rack.rack_id
        positions = primitive.tip_positions

        # Get tip state
        tip_state = self.deck_state.tip_states.get(rack_id)
        if tip_state is None:
            raise ValueError(f"Tip rack not found: {rack_id}")

        # Pick tips
        picked = []
        for pos in positions:
            if tip_state.pick_tip(pos):
                picked.append(pos)
            elif self.validate:
                raise ValueError(f"No tip at position {pos} in {rack_id}")

        trace.details["rack_id"] = rack_id
        trace.details["positions_picked"] = picked

        # Update pipette
        pipette = self.deck_state.get_pipette("default_pipette")
        if pipette:
            pipette.pick_tip()

    def _exec_drop_tips(self, primitive: DropTips, trace: StepTrace) -> None:
        """Execute drop tips operation."""
        trace.details["action"] = "drop_tips"

        # Update pipette
        pipette = self.deck_state.get_pipette("default_pipette")
        if pipette:
            pipette.drop_tip()

    def _exec_wait(self, primitive: Wait, trace: StepTrace) -> None:
        """Execute wait operation (no-op in simulation)."""
        trace.details["duration_s"] = primitive.duration_s

    def _exec_checkpoint(self, primitive: Checkpoint, trace: StepTrace) -> None:
        """Record checkpoint marker without mutating deck state."""
        trace.details["action"] = "checkpoint"
        trace.details["checkpoint_id"] = primitive.checkpoint_id

    def _exec_pause(self, primitive: Pause, trace: StepTrace) -> None:
        """Record manual pause marker without mutating deck state."""
        trace.details["action"] = "pause"
        trace.details["reason"] = primitive.reason

    def _exec_move_labware(self, primitive: MoveLabware, trace: StepTrace) -> None:
        """Execute move labware operation."""
        labware_id = primitive.labware_id
        to_position = primitive.to_position

        labware = self.deck_state.get_labware(labware_id)
        if labware is None:
            raise ValueError(f"Labware not found: {labware_id}")

        old_pos = labware.position
        labware.position = to_position

        trace.details["labware_id"] = labware_id
        trace.details["from"] = old_pos
        trace.details["to"] = to_position

    def _exec_set_temperature(self, primitive: SetTemperature, trace: StepTrace) -> None:
        """Execute set temperature operation."""
        device_id = primitive.device_id
        temp_c = primitive.temperature_c

        self.deck_state.set_temperature(device_id, temp_c)

        trace.details["device_id"] = device_id
        trace.details["temperature_c"] = temp_c

    def add_breakpoint(self, step_id: str) -> None:
        """Add a breakpoint at a step."""
        self._breakpoints.add(step_id)

    def remove_breakpoint(self, step_id: str) -> None:
        """Remove a breakpoint."""
        self._breakpoints.discard(step_id)

    def abort(self) -> None:
        """Abort the simulation."""
        self._status = SimulationStatus.ABORTED

    def add_step_callback(
        self,
        callback: Callable[[PlanStep, VirtualDeckState], None]
    ) -> None:
        """Add a callback to be called after each step."""
        self._step_callbacks.append(callback)


def simulate(
    plan: ExecutionPlan,
    deck_state: Optional[VirtualDeckState] = None,
    validate: bool = True,
    strict_capabilities: bool = False,
    capability_target: str = "simulation",
) -> SimulationResult:
    """
    Convenience function to simulate a plan.

    Args:
        plan: Execution plan to simulate
        deck_state: Initial deck state (creates default if None)
        validate: Whether to validate operations

    Returns:
        SimulationResult with traces and final state
    """
    simulator = Simulator(
        deck_state=deck_state,
        validate=validate,
        strict_capabilities=strict_capabilities,
        capability_target=capability_target,
    )
    return simulator.simulate(plan)
