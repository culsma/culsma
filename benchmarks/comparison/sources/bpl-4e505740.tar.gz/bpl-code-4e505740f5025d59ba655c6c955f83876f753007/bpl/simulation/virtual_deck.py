"""
BPL Virtual Deck - Simulated deck state for dry-run execution.

Provides:
- VirtualDeckState with labware and contents
- VirtualContents with volume, components, temperature
- VirtualLabware for plate simulation
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any, Tuple
from enum import Enum, auto
from datetime import datetime
import hashlib
import json


class LabwareType(Enum):
    """Types of labware."""
    PLATE_96 = auto()
    PLATE_384 = auto()
    RESERVOIR = auto()
    TIP_RACK = auto()
    TUBE_RACK = auto()
    TROUGH = auto()


@dataclass
class Component:
    """A component in a well/container."""
    name: str
    concentration: Optional[float] = None  # In appropriate units
    volume_ul: float = 0.0
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class VirtualContents:
    """Contents of a virtual well or container."""
    volume_ul: float = 0.0
    max_volume_ul: float = 200.0
    components: List[Component] = field(default_factory=list)
    temperature_c: Optional[float] = None
    ph: Optional[float] = None
    mixed: bool = True
    last_modified: datetime = field(default_factory=datetime.now)

    def add_volume(self, volume_ul: float, component: Optional[Component] = None) -> None:
        """Add volume to contents."""
        self.volume_ul += volume_ul
        if component:
            # Check if component already exists
            existing = next(
                (c for c in self.components if c.name == component.name),
                None
            )
            if existing:
                # Merge volumes
                existing.volume_ul += component.volume_ul
            else:
                self.components.append(component)
        self.mixed = False
        self.last_modified = datetime.now()

    def remove_volume(self, volume_ul: float) -> float:
        """Remove volume from contents. Returns actual removed amount."""
        actual = min(volume_ul, self.volume_ul)
        self.volume_ul -= actual
        # Proportionally reduce component volumes
        if self.volume_ul > 0:
            ratio = actual / (self.volume_ul + actual)
            for comp in self.components:
                comp.volume_ul *= (1 - ratio)
        self.last_modified = datetime.now()
        return actual

    def mix(self) -> None:
        """Mark contents as mixed."""
        self.mixed = True
        self.last_modified = datetime.now()

    def is_empty(self) -> bool:
        """Check if contents are empty."""
        return self.volume_ul <= 0.0

    def available_volume(self) -> float:
        """Get available volume capacity."""
        return self.max_volume_ul - self.volume_ul

    def would_overflow(self, add_volume_ul: float) -> bool:
        """Check if adding volume would overflow."""
        return (self.volume_ul + add_volume_ul) > self.max_volume_ul

    def get_hash(self) -> str:
        """Get hash of current contents state."""
        data = {
            "volume": self.volume_ul,
            "components": [(c.name, c.volume_ul) for c in self.components],
            "temp": self.temperature_c
        }
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()[:16]


@dataclass
class VirtualWell:
    """A virtual well in a plate."""
    well_id: str
    row: str
    col: int
    contents: VirtualContents = field(default_factory=VirtualContents)

    @staticmethod
    def parse_well_id(well_id: str) -> Tuple[str, int]:
        """Parse well ID into row and column."""
        row = well_id[0].upper()
        col = int(well_id[1:])
        return row, col


@dataclass
class VirtualLabware:
    """A virtual labware item on the deck."""
    labware_id: str
    labware_type: LabwareType
    rows: int = 8
    cols: int = 12
    wells: Dict[str, VirtualWell] = field(default_factory=dict)
    position: Optional[str] = None
    barcode: Optional[str] = None

    def __post_init__(self):
        if not self.wells:
            self._initialize_wells()

    def _initialize_wells(self) -> None:
        """Initialize wells based on labware type."""
        if self.labware_type == LabwareType.PLATE_96:
            self.rows, self.cols = 8, 12
            max_vol = 200.0
        elif self.labware_type == LabwareType.PLATE_384:
            self.rows, self.cols = 16, 24
            max_vol = 50.0
        elif self.labware_type == LabwareType.RESERVOIR:
            self.rows, self.cols = 1, 12
            max_vol = 20000.0
        elif self.labware_type == LabwareType.TIP_RACK:
            self.rows, self.cols = 8, 12
            max_vol = 0.0  # Tips don't hold liquid
        else:
            max_vol = 200.0

        row_letters = "ABCDEFGHIJKLMNOP"[:self.rows]
        for row in row_letters:
            for col in range(1, self.cols + 1):
                well_id = f"{row}{col}"
                self.wells[well_id] = VirtualWell(
                    well_id=well_id,
                    row=row,
                    col=col,
                    contents=VirtualContents(max_volume_ul=max_vol)
                )

    def get_well(self, well_id: str) -> Optional[VirtualWell]:
        """Get a well by ID."""
        return self.wells.get(well_id.upper())

    def get_contents(self, well_id: str) -> Optional[VirtualContents]:
        """Get contents of a well."""
        well = self.get_well(well_id)
        return well.contents if well else None

    def set_contents(self, well_id: str, contents: VirtualContents) -> None:
        """Set contents of a well."""
        well = self.get_well(well_id)
        if well:
            well.contents = contents

    def get_all_wells(self) -> List[str]:
        """Get all well IDs."""
        return list(self.wells.keys())

    def get_wells_in_row(self, row: str) -> List[str]:
        """Get all wells in a row."""
        return [wid for wid, w in self.wells.items() if w.row == row.upper()]

    def get_wells_in_column(self, col: int) -> List[str]:
        """Get all wells in a column."""
        return [wid for wid, w in self.wells.items() if w.col == col]


@dataclass
class TipState:
    """State of tips on the deck."""
    rack_id: str
    available_tips: Set[str] = field(default_factory=set)
    used_tips: Set[str] = field(default_factory=set)
    tip_volume_ul: float = 200.0

    def pick_tip(self, position: str) -> bool:
        """Pick a tip from position."""
        if position in self.available_tips:
            self.available_tips.remove(position)
            self.used_tips.add(position)
            return True
        return False

    def has_tip(self, position: str) -> bool:
        """Check if tip is available at position."""
        return position in self.available_tips

    def available_count(self) -> int:
        """Get number of available tips."""
        return len(self.available_tips)

    def reset(self) -> None:
        """Reset all tips to available."""
        self.available_tips = self.available_tips.union(self.used_tips)
        self.used_tips.clear()


@dataclass
class VirtualPipette:
    """State of a virtual pipette."""
    pipette_id: str
    channels: int = 1
    min_volume_ul: float = 1.0
    max_volume_ul: float = 200.0
    current_volume_ul: float = 0.0
    has_tip: bool = False
    tip_volume_ul: float = 0.0
    current_contents: Optional[VirtualContents] = None

    def pick_tip(self, volume_ul: float = 200.0) -> None:
        """Pick up a tip."""
        self.has_tip = True
        self.tip_volume_ul = volume_ul
        self.current_contents = VirtualContents(max_volume_ul=volume_ul)

    def drop_tip(self) -> None:
        """Drop the current tip."""
        self.has_tip = False
        self.tip_volume_ul = 0.0
        self.current_volume_ul = 0.0
        self.current_contents = None

    def aspirate(self, volume_ul: float) -> bool:
        """Aspirate volume into tip."""
        if not self.has_tip:
            return False
        if self.current_volume_ul + volume_ul > self.tip_volume_ul:
            return False
        self.current_volume_ul += volume_ul
        return True

    def dispense(self, volume_ul: float) -> float:
        """Dispense volume from tip. Returns actual dispensed."""
        if not self.has_tip:
            return 0.0
        actual = min(volume_ul, self.current_volume_ul)
        self.current_volume_ul -= actual
        return actual


class VirtualDeckState:
    """
    Complete virtual deck state for simulation.

    Tracks:
    - Labware positions and contents
    - Tip states
    - Pipette states
    - Temperature modules
    """

    def __init__(self, num_positions: int = 12):
        self.positions: Dict[str, Optional[str]] = {
            f"slot_{i}": None for i in range(1, num_positions + 1)
        }
        self.labware: Dict[str, VirtualLabware] = {}
        self.tip_states: Dict[str, TipState] = {}
        self.pipettes: Dict[str, VirtualPipette] = {}
        self.temperature_modules: Dict[str, float] = {}
        self._state_history: List[str] = []

    def add_labware(
        self,
        labware_id: str,
        labware_type: LabwareType,
        position: str
    ) -> VirtualLabware:
        """Add labware to the deck."""
        if position in self.positions and self.positions[position] is not None:
            raise ValueError(f"Position {position} is already occupied")

        labware = VirtualLabware(
            labware_id=labware_id,
            labware_type=labware_type,
            position=position
        )
        self.labware[labware_id] = labware
        self.positions[position] = labware_id

        # Initialize tip state if it's a tip rack
        if labware_type == LabwareType.TIP_RACK:
            self.tip_states[labware_id] = TipState(
                rack_id=labware_id,
                available_tips=set(labware.get_all_wells())
            )

        return labware

    def remove_labware(self, labware_id: str) -> None:
        """Remove labware from deck."""
        if labware_id in self.labware:
            labware = self.labware[labware_id]
            if labware.position:
                self.positions[labware.position] = None
            del self.labware[labware_id]
            if labware_id in self.tip_states:
                del self.tip_states[labware_id]

    def get_labware(self, labware_id: str) -> Optional[VirtualLabware]:
        """Get labware by ID."""
        return self.labware.get(labware_id)

    def get_well_contents(
        self,
        labware_id: str,
        well_id: str
    ) -> Optional[VirtualContents]:
        """Get contents of a specific well."""
        labware = self.get_labware(labware_id)
        if labware:
            return labware.get_contents(well_id)
        return None

    def add_pipette(
        self,
        pipette_id: str,
        channels: int = 1,
        max_volume_ul: float = 200.0
    ) -> VirtualPipette:
        """Add a pipette to the deck."""
        pipette = VirtualPipette(
            pipette_id=pipette_id,
            channels=channels,
            max_volume_ul=max_volume_ul
        )
        self.pipettes[pipette_id] = pipette
        return pipette

    def get_pipette(self, pipette_id: str) -> Optional[VirtualPipette]:
        """Get pipette by ID."""
        return self.pipettes.get(pipette_id)

    def set_temperature(self, module_id: str, temp_c: float) -> None:
        """Set temperature of a temperature module."""
        self.temperature_modules[module_id] = temp_c

    def get_temperature(self, module_id: str) -> Optional[float]:
        """Get temperature of a module."""
        return self.temperature_modules.get(module_id)

    def get_state_hash(self) -> str:
        """Get hash representing current state."""
        state_data = {
            "labware": {
                lid: {
                    wid: w.contents.get_hash()
                    for wid, w in lw.wells.items()
                }
                for lid, lw in self.labware.items()
            },
            "tips": {
                tid: ts.available_count()
                for tid, ts in self.tip_states.items()
            },
            "temps": self.temperature_modules
        }
        return hashlib.sha256(
            json.dumps(state_data, sort_keys=True).encode()
        ).hexdigest()[:32]

    def save_state(self) -> None:
        """Save current state to history."""
        self._state_history.append(self.get_state_hash())

    def get_state_history(self) -> List[str]:
        """Get state hash history."""
        return self._state_history.copy()

    def get_deck_summary(self) -> Dict[str, Any]:
        """Get summary of deck state."""
        return {
            "positions": {
                pos: lid for pos, lid in self.positions.items() if lid
            },
            "labware_count": len(self.labware),
            "tip_racks": len(self.tip_states),
            "pipettes": list(self.pipettes.keys()),
            "temp_modules": list(self.temperature_modules.keys())
        }


def create_standard_deck() -> VirtualDeckState:
    """Create a standard 12-position deck."""
    return VirtualDeckState(num_positions=12)


def create_deck_with_labware(
    labware_specs: List[Tuple[str, LabwareType, str]]
) -> VirtualDeckState:
    """Create deck with specified labware."""
    deck = create_standard_deck()
    for labware_id, labware_type, position in labware_specs:
        deck.add_labware(labware_id, labware_type, position)
    return deck
