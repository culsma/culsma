"""
BPL Assertions - Runtime and compile-time assertions.

Provides:
- @assert runtime checking
- @static_assert compile-time checking
- Assertion modes: Enforce, Warn, Skip
- Invariant blocks
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable, Union
from enum import Enum, auto
from datetime import datetime
import ast
import operator


_BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
}

_COMPARISON_OPERATORS = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
}

_UNARY_OPERATORS = {
    ast.Not: operator.not_,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _safe_eval_assertion(expression: str, context: Dict[str, Any]) -> Any:
    """Evaluate a small assertion expression language without Python eval."""

    def eval_node(node: ast.AST) -> Any:
        if isinstance(node, ast.Expression):
            return eval_node(node.body)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id in context:
                return context[node.id]
            raise NameError(f"Unknown assertion name: {node.id}")
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPERATORS:
            return _UNARY_OPERATORS[type(node.op)](eval_node(node.operand))
        if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPERATORS:
            return _BINARY_OPERATORS[type(node.op)](
                eval_node(node.left), eval_node(node.right)
            )
        if isinstance(node, ast.BoolOp):
            values = [bool(eval_node(value)) for value in node.values]
            if isinstance(node.op, ast.And):
                return all(values)
            if isinstance(node.op, ast.Or):
                return any(values)
        if isinstance(node, ast.Compare):
            left = eval_node(node.left)
            for op, comparator in zip(node.ops, node.comparators):
                op_func = _COMPARISON_OPERATORS.get(type(op))
                if op_func is None:
                    raise ValueError(f"Unsupported comparison operator: {type(op).__name__}")
                right = eval_node(comparator)
                if not op_func(left, right):
                    return False
                left = right
            return True
        raise ValueError(f"Unsupported assertion expression: {type(node).__name__}")

    tree = ast.parse(expression, mode="eval")
    return eval_node(tree)


class AssertionMode(Enum):
    """How assertions should be handled."""
    ENFORCE = auto()   # Fail on assertion failure
    WARN = auto()      # Log warning but continue
    SKIP = auto()      # Skip assertion entirely


class AssertionType(Enum):
    """Type of assertion."""
    RUNTIME = auto()       # Checked during execution
    STATIC = auto()        # Checked at compile time
    INVARIANT = auto()     # Checked throughout scope


@dataclass
class AssertionResult:
    """Result of an assertion check."""
    assertion_id: str
    assertion_type: AssertionType
    passed: bool
    expression: str
    message: str = ""
    actual_value: Any = None
    expected_value: Any = None
    location: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)

    def __str__(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return f"[{status}] {self.expression}: {self.message}"


@dataclass
class Assertion:
    """An assertion definition."""
    assertion_id: str
    expression: str
    message: str = ""
    assertion_type: AssertionType = AssertionType.RUNTIME
    mode: AssertionMode = AssertionMode.ENFORCE
    condition: Optional[Callable[..., bool]] = None
    step_id: Optional[str] = None

    def check(self, context: Optional[Dict[str, Any]] = None) -> AssertionResult:
        """Check the assertion."""
        context = context or {}

        if self.condition is None:
            # If no condition provided, evaluate a restricted expression grammar.
            try:
                passed = _safe_eval_assertion(self.expression, context)
            except Exception as e:
                return AssertionResult(
                    assertion_id=self.assertion_id,
                    assertion_type=self.assertion_type,
                    passed=False,
                    expression=self.expression,
                    message=f"Evaluation error: {e}"
                )
        else:
            try:
                passed = self.condition(context)
            except Exception as e:
                return AssertionResult(
                    assertion_id=self.assertion_id,
                    assertion_type=self.assertion_type,
                    passed=False,
                    expression=self.expression,
                    message=f"Condition error: {e}"
                )

        return AssertionResult(
            assertion_id=self.assertion_id,
            assertion_type=self.assertion_type,
            passed=bool(passed),
            expression=self.expression,
            message=self.message if not passed else "Assertion passed"
        )


@dataclass
class InvariantBlock:
    """A block of invariants that must hold throughout a scope."""
    invariant_id: str
    assertions: List[Assertion] = field(default_factory=list)
    scope_start_step: Optional[str] = None
    scope_end_step: Optional[str] = None
    mode: AssertionMode = AssertionMode.ENFORCE

    def add_assertion(self, assertion: Assertion) -> None:
        """Add an assertion to the invariant block."""
        assertion.assertion_type = AssertionType.INVARIANT
        self.assertions.append(assertion)

    def check_all(self, context: Optional[Dict[str, Any]] = None) -> List[AssertionResult]:
        """Check all assertions in the invariant block."""
        return [a.check(context) for a in self.assertions]

    def all_passed(self, context: Optional[Dict[str, Any]] = None) -> bool:
        """Check if all assertions pass."""
        return all(r.passed for r in self.check_all(context))


class AssertionManager:
    """
    Manages assertions during execution.

    Handles:
    - Assertion registration
    - Runtime checking
    - Result tracking
    """

    def __init__(self, default_mode: AssertionMode = AssertionMode.ENFORCE):
        self.default_mode = default_mode
        self.assertions: Dict[str, Assertion] = {}
        self.invariant_blocks: Dict[str, InvariantBlock] = {}
        self.results: List[AssertionResult] = []
        self._assertion_counter = 0

    def create_assertion(
        self,
        expression: str,
        message: str = "",
        assertion_type: AssertionType = AssertionType.RUNTIME,
        mode: Optional[AssertionMode] = None,
        condition: Optional[Callable[..., bool]] = None,
        step_id: Optional[str] = None
    ) -> Assertion:
        """Create and register an assertion."""
        self._assertion_counter += 1
        assertion_id = f"assert_{self._assertion_counter}"

        assertion = Assertion(
            assertion_id=assertion_id,
            expression=expression,
            message=message,
            assertion_type=assertion_type,
            mode=mode or self.default_mode,
            condition=condition,
            step_id=step_id
        )

        self.assertions[assertion_id] = assertion
        return assertion

    def create_static_assertion(
        self,
        expression: str,
        message: str = ""
    ) -> Assertion:
        """Create a static (compile-time) assertion."""
        return self.create_assertion(
            expression=expression,
            message=message,
            assertion_type=AssertionType.STATIC
        )

    def create_invariant_block(
        self,
        scope_start: Optional[str] = None,
        scope_end: Optional[str] = None,
        mode: Optional[AssertionMode] = None
    ) -> InvariantBlock:
        """Create an invariant block."""
        self._assertion_counter += 1
        invariant_id = f"invariant_{self._assertion_counter}"

        block = InvariantBlock(
            invariant_id=invariant_id,
            scope_start_step=scope_start,
            scope_end_step=scope_end,
            mode=mode or self.default_mode
        )

        self.invariant_blocks[invariant_id] = block
        return block

    def check_assertion(
        self,
        assertion_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AssertionResult:
        """Check a specific assertion."""
        assertion = self.assertions.get(assertion_id)
        if assertion is None:
            return AssertionResult(
                assertion_id=assertion_id,
                assertion_type=AssertionType.RUNTIME,
                passed=False,
                expression="<unknown>",
                message="Assertion not found"
            )

        # Skip if mode is SKIP
        if assertion.mode == AssertionMode.SKIP:
            return AssertionResult(
                assertion_id=assertion_id,
                assertion_type=assertion.assertion_type,
                passed=True,
                expression=assertion.expression,
                message="Assertion skipped"
            )

        result = assertion.check(context)
        self.results.append(result)

        return result

    def check_invariants(
        self,
        step_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> List[AssertionResult]:
        """Check all invariants applicable to a step."""
        results = []

        for block in self.invariant_blocks.values():
            # Check if step is within invariant scope
            if block.scope_start_step and step_id < block.scope_start_step:
                continue
            if block.scope_end_step and step_id > block.scope_end_step:
                continue

            # Skip if mode is SKIP
            if block.mode == AssertionMode.SKIP:
                continue

            block_results = block.check_all(context)
            results.extend(block_results)
            self.results.extend(block_results)

        return results

    def check_static_assertions(
        self,
        context: Optional[Dict[str, Any]] = None
    ) -> List[AssertionResult]:
        """Check all static assertions (at compile time)."""
        results = []

        for assertion in self.assertions.values():
            if assertion.assertion_type == AssertionType.STATIC:
                result = assertion.check(context)
                results.append(result)
                self.results.append(result)

        return results

    def get_failed_assertions(self) -> List[AssertionResult]:
        """Get all failed assertion results."""
        return [r for r in self.results if not r.passed]

    def get_passed_assertions(self) -> List[AssertionResult]:
        """Get all passed assertion results."""
        return [r for r in self.results if r.passed]

    def clear_results(self) -> None:
        """Clear all assertion results."""
        self.results.clear()

    def get_summary(self) -> Dict[str, Any]:
        """Get summary of assertion checks."""
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        failed = total - passed

        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": (passed / total * 100) if total > 0 else 100.0,
            "failed_assertions": [
                {"id": r.assertion_id, "expression": r.expression, "message": r.message}
                for r in self.get_failed_assertions()
            ]
        }


# Convenience functions

def assert_volume_positive(volume: float, context: str = "") -> AssertionResult:
    """Assert that a volume is positive."""
    assertion = Assertion(
        assertion_id="volume_positive",
        expression=f"volume > 0",
        message=f"Volume must be positive{': ' + context if context else ''}",
        condition=lambda _: volume > 0
    )
    return assertion.check({})


def assert_well_exists(
    plate_id: str,
    well_id: str,
    deck_state: Any
) -> AssertionResult:
    """Assert that a well exists on the deck."""
    def check(_):
        contents = deck_state.get_well_contents(plate_id, well_id)
        return contents is not None

    assertion = Assertion(
        assertion_id="well_exists",
        expression=f"{plate_id}/{well_id} exists",
        message=f"Well {well_id} not found in {plate_id}",
        condition=check
    )
    return assertion.check({})


def assert_no_overflow(
    plate_id: str,
    well_id: str,
    add_volume: float,
    deck_state: Any
) -> AssertionResult:
    """Assert that adding volume won't cause overflow."""
    def check(_):
        contents = deck_state.get_well_contents(plate_id, well_id)
        if contents is None:
            return False
        return not contents.would_overflow(add_volume)

    assertion = Assertion(
        assertion_id="no_overflow",
        expression=f"no_overflow({plate_id}/{well_id}, +{add_volume}uL)",
        message=f"Adding {add_volume}uL would overflow well {well_id}",
        condition=check
    )
    return assertion.check({})


def create_assertion_manager(
    mode: AssertionMode = AssertionMode.ENFORCE
) -> AssertionManager:
    """Create an assertion manager."""
    return AssertionManager(default_mode=mode)
