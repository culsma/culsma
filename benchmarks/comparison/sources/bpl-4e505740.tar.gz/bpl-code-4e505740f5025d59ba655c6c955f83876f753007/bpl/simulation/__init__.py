"""BPL Simulation - Virtual deck simulation and debugging."""

from .virtual_deck import (
    LabwareType,
    Component,
    VirtualContents,
    VirtualWell,
    VirtualLabware,
    TipState,
    VirtualPipette,
    VirtualDeckState,
    create_standard_deck,
    create_deck_with_labware,
)

from .simulator import (
    SimulationStatus,
    StepTrace,
    SimulationResult,
    Simulator,
    simulate,
)

from .validation import (
    ValidationSeverity,
    ValidationIssue,
    ValidationResult,
    ValidationCheck,
    NoOverflowCheck,
    NoEmptyAspirationCheck,
    NoNegativeVolumeCheck,
    TipsAvailableCheck,
    ResourceAvailableCheck,
    TemperatureInRangeCheck,
    VolumeRangeCheck,
    Validator,
    create_validator,
    validate_plan,
)

from .checkpoint import (
    CheckpointType,
    CheckpointData,
    Checkpoint,
    RecoveryPlan,
    CheckpointManager,
    create_checkpoint_manager,
)

from .assertions import (
    AssertionMode,
    AssertionType,
    AssertionResult,
    Assertion,
    InvariantBlock,
    AssertionManager,
    assert_volume_positive,
    assert_well_exists,
    assert_no_overflow,
    create_assertion_manager,
)

from .breakpoints import (
    BreakpointType,
    BreakpointAction,
    Breakpoint,
    BreakpointHit,
    DebugMode,
    BreakpointManager,
    create_breakpoint_manager,
)

from .sim_logging import (
    LogLevel,
    LogOutput,
    LogEntry,
    LogFilter,
    SimulationLogger,
    create_logger,
    create_silent_logger,
    create_verbose_logger,
)

__all__ = [
    # Virtual deck
    "LabwareType",
    "Component",
    "VirtualContents",
    "VirtualWell",
    "VirtualLabware",
    "TipState",
    "VirtualPipette",
    "VirtualDeckState",
    "create_standard_deck",
    "create_deck_with_labware",
    # Simulator
    "SimulationStatus",
    "StepTrace",
    "SimulationResult",
    "Simulator",
    "simulate",
    # Validation
    "ValidationSeverity",
    "ValidationIssue",
    "ValidationResult",
    "ValidationCheck",
    "NoOverflowCheck",
    "NoEmptyAspirationCheck",
    "NoNegativeVolumeCheck",
    "TipsAvailableCheck",
    "ResourceAvailableCheck",
    "TemperatureInRangeCheck",
    "VolumeRangeCheck",
    "Validator",
    "create_validator",
    "validate_plan",
    # Checkpoints
    "CheckpointType",
    "CheckpointData",
    "Checkpoint",
    "RecoveryPlan",
    "CheckpointManager",
    "create_checkpoint_manager",
    # Assertions
    "AssertionMode",
    "AssertionType",
    "AssertionResult",
    "Assertion",
    "InvariantBlock",
    "AssertionManager",
    "assert_volume_positive",
    "assert_well_exists",
    "assert_no_overflow",
    "create_assertion_manager",
    # Breakpoints
    "BreakpointType",
    "BreakpointAction",
    "Breakpoint",
    "BreakpointHit",
    "DebugMode",
    "BreakpointManager",
    "create_breakpoint_manager",
    # Logging
    "LogLevel",
    "LogOutput",
    "LogEntry",
    "LogFilter",
    "SimulationLogger",
    "create_logger",
    "create_silent_logger",
    "create_verbose_logger",
]
