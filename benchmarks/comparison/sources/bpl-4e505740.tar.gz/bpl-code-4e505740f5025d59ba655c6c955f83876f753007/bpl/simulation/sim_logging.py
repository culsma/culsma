"""
BPL Simulation Logging - Multi-level execution logging.

Provides:
- LogLevel: Trace, Debug, Info, Warn, Error
- LogOutput: Console, File, Structured, Streaming
- Per-step log level override
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable, TextIO
from enum import Enum, auto
from datetime import datetime
import json
import sys


class LogLevel(Enum):
    """Logging levels."""
    TRACE = 0    # Most verbose
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERROR = 4
    NONE = 5     # No logging


class LogOutput(Enum):
    """Output destinations."""
    CONSOLE = auto()
    FILE = auto()
    STRUCTURED = auto()   # JSON structured logging
    STREAMING = auto()    # Real-time streaming
    CALLBACK = auto()     # Custom callback


@dataclass
class LogEntry:
    """A log entry."""
    level: LogLevel
    message: str
    timestamp: datetime = field(default_factory=datetime.now)
    step_id: Optional[str] = None
    category: str = "general"
    details: Dict[str, Any] = field(default_factory=dict)
    source: str = "simulator"

    def format_console(self) -> str:
        """Format for console output."""
        ts = self.timestamp.strftime("%H:%M:%S.%f")[:-3]
        step = f"[{self.step_id}]" if self.step_id else ""
        return f"{ts} {self.level.name:5s} {step} {self.message}"

    def format_structured(self) -> str:
        """Format as JSON."""
        data = {
            "timestamp": self.timestamp.isoformat(),
            "level": self.level.name,
            "message": self.message,
            "step_id": self.step_id,
            "category": self.category,
            "source": self.source,
            "details": self.details
        }
        return json.dumps(data)

    def format_detailed(self) -> str:
        """Format with all details."""
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")
        lines = [
            f"[{ts}] [{self.level.name}] [{self.category}]",
            f"  Step: {self.step_id or 'N/A'}",
            f"  Message: {self.message}"
        ]
        if self.details:
            lines.append(f"  Details: {json.dumps(self.details)}")
        return "\n".join(lines)


class LogFilter:
    """Filter for log entries."""

    def __init__(
        self,
        min_level: LogLevel = LogLevel.INFO,
        categories: Optional[List[str]] = None,
        step_ids: Optional[List[str]] = None
    ):
        self.min_level = min_level
        self.categories = set(categories) if categories else None
        self.step_ids = set(step_ids) if step_ids else None

    def should_log(self, entry: LogEntry) -> bool:
        """Check if entry should be logged."""
        # Check level
        if entry.level.value < self.min_level.value:
            return False

        # Check category filter
        if self.categories and entry.category not in self.categories:
            return False

        # Check step filter
        if self.step_ids and entry.step_id not in self.step_ids:
            return False

        return True


class SimulationLogger:
    """
    Logger for simulation execution.

    Supports:
    - Multiple log levels
    - Multiple output destinations
    - Per-step overrides
    - Filtering
    """

    def __init__(
        self,
        default_level: LogLevel = LogLevel.INFO,
        output: LogOutput = LogOutput.CONSOLE
    ):
        self.default_level = default_level
        self.output = output
        self.entries: List[LogEntry] = []
        self.filter = LogFilter(min_level=default_level)

        # Step-specific overrides
        self.step_overrides: Dict[str, LogLevel] = {}

        # Output destinations
        self._file_handle: Optional[TextIO] = None
        self._callback: Optional[Callable[[LogEntry], None]] = None
        self._streaming_handlers: List[Callable[[LogEntry], None]] = []

    def set_level(self, level: LogLevel) -> None:
        """Set default log level."""
        self.default_level = level
        self.filter.min_level = level

    def set_step_level(self, step_id: str, level: LogLevel) -> None:
        """Set log level for a specific step."""
        self.step_overrides[step_id] = level

    def set_filter(self, log_filter: LogFilter) -> None:
        """Set log filter."""
        self.filter = log_filter

    def set_file_output(self, filepath: str) -> None:
        """Set file output destination."""
        self._file_handle = open(filepath, 'a')
        self.output = LogOutput.FILE

    def set_callback(self, callback: Callable[[LogEntry], None]) -> None:
        """Set callback for log entries."""
        self._callback = callback
        self.output = LogOutput.CALLBACK

    def add_streaming_handler(
        self,
        handler: Callable[[LogEntry], None]
    ) -> None:
        """Add a streaming handler."""
        self._streaming_handlers.append(handler)

    def _get_effective_level(self, step_id: Optional[str]) -> LogLevel:
        """Get effective log level for a step."""
        if step_id and step_id in self.step_overrides:
            return self.step_overrides[step_id]
        return self.default_level

    def _should_log(self, entry: LogEntry) -> bool:
        """Check if entry should be logged."""
        effective_level = self._get_effective_level(entry.step_id)
        if entry.level.value < effective_level.value:
            return False
        return self.filter.should_log(entry)

    def _output_entry(self, entry: LogEntry) -> None:
        """Output a log entry."""
        if self.output == LogOutput.CONSOLE:
            print(entry.format_console(), file=sys.stderr)

        elif self.output == LogOutput.FILE and self._file_handle:
            self._file_handle.write(entry.format_detailed() + "\n")
            self._file_handle.flush()

        elif self.output == LogOutput.STRUCTURED:
            print(entry.format_structured())

        elif self.output == LogOutput.CALLBACK and self._callback:
            self._callback(entry)

        # Always call streaming handlers
        for handler in self._streaming_handlers:
            handler(entry)

    def log(
        self,
        level: LogLevel,
        message: str,
        step_id: Optional[str] = None,
        category: str = "general",
        **details
    ) -> None:
        """Log a message."""
        entry = LogEntry(
            level=level,
            message=message,
            step_id=step_id,
            category=category,
            details=details
        )

        self.entries.append(entry)

        if self._should_log(entry):
            self._output_entry(entry)

    def trace(self, message: str, **kwargs) -> None:
        """Log at TRACE level."""
        self.log(LogLevel.TRACE, message, **kwargs)

    def debug(self, message: str, **kwargs) -> None:
        """Log at DEBUG level."""
        self.log(LogLevel.DEBUG, message, **kwargs)

    def info(self, message: str, **kwargs) -> None:
        """Log at INFO level."""
        self.log(LogLevel.INFO, message, **kwargs)

    def warn(self, message: str, **kwargs) -> None:
        """Log at WARN level."""
        self.log(LogLevel.WARN, message, **kwargs)

    def error(self, message: str, **kwargs) -> None:
        """Log at ERROR level."""
        self.log(LogLevel.ERROR, message, **kwargs)

    def log_step_start(self, step_id: str, primitive_type: str) -> None:
        """Log step start."""
        self.debug(
            f"Starting step: {primitive_type}",
            step_id=step_id,
            category="step"
        )

    def log_step_complete(
        self,
        step_id: str,
        duration_ms: float,
        success: bool
    ) -> None:
        """Log step completion."""
        level = LogLevel.DEBUG if success else LogLevel.WARN
        status = "completed" if success else "failed"
        self.log(
            level,
            f"Step {status} in {duration_ms:.2f}ms",
            step_id=step_id,
            category="step",
            duration_ms=duration_ms,
            success=success
        )

    def log_state_change(
        self,
        step_id: str,
        before_hash: str,
        after_hash: str
    ) -> None:
        """Log state change."""
        self.trace(
            f"State: {before_hash[:8]}... -> {after_hash[:8]}...",
            step_id=step_id,
            category="state",
            before_hash=before_hash,
            after_hash=after_hash
        )

    def log_validation_error(
        self,
        step_id: str,
        check_name: str,
        message: str
    ) -> None:
        """Log validation error."""
        self.error(
            f"Validation failed [{check_name}]: {message}",
            step_id=step_id,
            category="validation",
            check_name=check_name
        )

    def get_entries(
        self,
        level: Optional[LogLevel] = None,
        category: Optional[str] = None
    ) -> List[LogEntry]:
        """Get log entries with optional filtering."""
        entries = self.entries

        if level:
            entries = [e for e in entries if e.level == level]

        if category:
            entries = [e for e in entries if e.category == category]

        return entries

    def get_errors(self) -> List[LogEntry]:
        """Get error entries."""
        return self.get_entries(level=LogLevel.ERROR)

    def get_warnings(self) -> List[LogEntry]:
        """Get warning entries."""
        return self.get_entries(level=LogLevel.WARN)

    def clear(self) -> None:
        """Clear log entries."""
        self.entries.clear()

    def close(self) -> None:
        """Close file handle if open."""
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None

    def get_summary(self) -> Dict[str, Any]:
        """Get logging summary."""
        level_counts = {level.name: 0 for level in LogLevel if level != LogLevel.NONE}
        for entry in self.entries:
            level_counts[entry.level.name] += 1

        return {
            "total_entries": len(self.entries),
            "by_level": level_counts,
            "errors": level_counts.get("ERROR", 0),
            "warnings": level_counts.get("WARN", 0)
        }


def create_logger(
    level: LogLevel = LogLevel.INFO,
    output: LogOutput = LogOutput.CONSOLE
) -> SimulationLogger:
    """Create a simulation logger."""
    return SimulationLogger(default_level=level, output=output)


def create_silent_logger() -> SimulationLogger:
    """Create a logger that produces no output."""
    return SimulationLogger(default_level=LogLevel.NONE)


def create_verbose_logger() -> SimulationLogger:
    """Create a verbose logger for debugging."""
    return SimulationLogger(default_level=LogLevel.TRACE)
