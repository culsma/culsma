"""
BPL Breakpoints - Debugging support for simulation.

Provides:
- @breakpoint annotation support
- Conditional breakpoints
- Single-step mode
- @step_into for lowering debug
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime


class BreakpointType(Enum):
    """Types of breakpoints."""
    STEP = auto()          # Break at specific step
    CONDITION = auto()     # Break when condition is true
    EXCEPTION = auto()     # Break on exception
    WELL = auto()          # Break on well access
    VOLUME = auto()        # Break on volume threshold


class BreakpointAction(Enum):
    """Action when breakpoint is hit."""
    PAUSE = auto()         # Pause execution
    LOG = auto()           # Log and continue
    INSPECT = auto()       # Dump state and continue
    CALLBACK = auto()      # Call registered callback


@dataclass
class Breakpoint:
    """A breakpoint definition."""
    breakpoint_id: str
    breakpoint_type: BreakpointType
    enabled: bool = True
    hit_count: int = 0
    hit_limit: Optional[int] = None  # Stop after N hits
    action: BreakpointAction = BreakpointAction.PAUSE

    # For STEP type
    step_id: Optional[str] = None

    # For CONDITION type
    condition: Optional[Callable[..., bool]] = None
    condition_expr: str = ""

    # For WELL type
    plate_id: Optional[str] = None
    well_id: Optional[str] = None

    # For VOLUME type
    volume_threshold: Optional[float] = None

    # Callback for CALLBACK action
    callback: Optional[Callable[..., None]] = None

    def should_trigger(self, context: Dict[str, Any]) -> bool:
        """Check if breakpoint should trigger."""
        if not self.enabled:
            return False

        if self.hit_limit and self.hit_count >= self.hit_limit:
            return False

        if self.breakpoint_type == BreakpointType.STEP:
            return context.get("step_id") == self.step_id

        elif self.breakpoint_type == BreakpointType.CONDITION:
            if self.condition:
                try:
                    return self.condition(context)
                except Exception:
                    return False
            return False

        elif self.breakpoint_type == BreakpointType.WELL:
            ctx_plate = context.get("plate_id")
            ctx_well = context.get("well_id")
            if self.plate_id and ctx_plate != self.plate_id:
                return False
            if self.well_id and ctx_well != self.well_id:
                return False
            return True

        elif self.breakpoint_type == BreakpointType.VOLUME:
            volume = context.get("volume_ul", 0)
            if self.volume_threshold:
                return volume >= self.volume_threshold
            return False

        elif self.breakpoint_type == BreakpointType.EXCEPTION:
            return "exception" in context

        return False

    def record_hit(self) -> None:
        """Record a breakpoint hit."""
        self.hit_count += 1


@dataclass
class BreakpointHit:
    """Record of a breakpoint hit."""
    breakpoint_id: str
    step_id: str
    timestamp: datetime = field(default_factory=datetime.now)
    context: Dict[str, Any] = field(default_factory=dict)
    action_taken: BreakpointAction = BreakpointAction.PAUSE


class DebugMode(Enum):
    """Debugging modes."""
    RUN = auto()           # Normal execution
    STEP = auto()          # Single step
    STEP_OVER = auto()     # Step over (don't enter sub-plans)
    STEP_INTO = auto()     # Step into (enter sub-plans)
    CONTINUE = auto()      # Continue to next breakpoint


class BreakpointManager:
    """
    Manages breakpoints during execution.

    Supports:
    - Multiple breakpoint types
    - Conditional breakpoints
    - Single-step debugging
    """

    def __init__(self):
        self.breakpoints: Dict[str, Breakpoint] = {}
        self.hit_history: List[BreakpointHit] = []
        self.debug_mode: DebugMode = DebugMode.RUN
        self._breakpoint_counter = 0
        self._pause_requested = False
        self._step_callbacks: List[Callable[[str, Dict], None]] = []

    def add_breakpoint(
        self,
        breakpoint_type: BreakpointType,
        **kwargs
    ) -> Breakpoint:
        """Add a breakpoint."""
        self._breakpoint_counter += 1
        bp_id = kwargs.get("breakpoint_id", f"bp_{self._breakpoint_counter}")

        bp = Breakpoint(
            breakpoint_id=bp_id,
            breakpoint_type=breakpoint_type,
            **{k: v for k, v in kwargs.items() if k != "breakpoint_id"}
        )

        self.breakpoints[bp_id] = bp
        return bp

    def add_step_breakpoint(self, step_id: str) -> Breakpoint:
        """Add a breakpoint at a specific step."""
        return self.add_breakpoint(
            BreakpointType.STEP,
            step_id=step_id
        )

    def add_conditional_breakpoint(
        self,
        condition: Callable[..., bool],
        expression: str = ""
    ) -> Breakpoint:
        """Add a conditional breakpoint."""
        return self.add_breakpoint(
            BreakpointType.CONDITION,
            condition=condition,
            condition_expr=expression
        )

    def add_well_breakpoint(
        self,
        plate_id: Optional[str] = None,
        well_id: Optional[str] = None
    ) -> Breakpoint:
        """Add a breakpoint on well access."""
        return self.add_breakpoint(
            BreakpointType.WELL,
            plate_id=plate_id,
            well_id=well_id
        )

    def add_volume_breakpoint(self, threshold: float) -> Breakpoint:
        """Add a breakpoint on volume threshold."""
        return self.add_breakpoint(
            BreakpointType.VOLUME,
            volume_threshold=threshold
        )

    def remove_breakpoint(self, breakpoint_id: str) -> bool:
        """Remove a breakpoint."""
        if breakpoint_id in self.breakpoints:
            del self.breakpoints[breakpoint_id]
            return True
        return False

    def enable_breakpoint(self, breakpoint_id: str) -> None:
        """Enable a breakpoint."""
        if breakpoint_id in self.breakpoints:
            self.breakpoints[breakpoint_id].enabled = True

    def disable_breakpoint(self, breakpoint_id: str) -> None:
        """Disable a breakpoint."""
        if breakpoint_id in self.breakpoints:
            self.breakpoints[breakpoint_id].enabled = False

    def disable_all(self) -> None:
        """Disable all breakpoints."""
        for bp in self.breakpoints.values():
            bp.enabled = False

    def enable_all(self) -> None:
        """Enable all breakpoints."""
        for bp in self.breakpoints.values():
            bp.enabled = True

    def check_breakpoints(
        self,
        step_id: str,
        context: Dict[str, Any]
    ) -> Optional[BreakpointHit]:
        """Check if any breakpoint triggers."""
        context["step_id"] = step_id

        # Check single-step mode
        if self.debug_mode in (DebugMode.STEP, DebugMode.STEP_INTO):
            hit = BreakpointHit(
                breakpoint_id="single_step",
                step_id=step_id,
                context=context.copy(),
                action_taken=BreakpointAction.PAUSE
            )
            self.hit_history.append(hit)
            return hit

        # Check all breakpoints
        for bp in self.breakpoints.values():
            if bp.should_trigger(context):
                bp.record_hit()

                hit = BreakpointHit(
                    breakpoint_id=bp.breakpoint_id,
                    step_id=step_id,
                    context=context.copy(),
                    action_taken=bp.action
                )
                self.hit_history.append(hit)

                # Execute action
                if bp.action == BreakpointAction.CALLBACK and bp.callback:
                    bp.callback(step_id, context)
                    return None  # Don't pause

                if bp.action == BreakpointAction.LOG:
                    # Would log in real implementation
                    return None  # Don't pause

                return hit  # PAUSE or INSPECT

        return None

    def set_debug_mode(self, mode: DebugMode) -> None:
        """Set debugging mode."""
        self.debug_mode = mode

    def step(self) -> None:
        """Enter single-step mode."""
        self.debug_mode = DebugMode.STEP

    def step_into(self) -> None:
        """Enter step-into mode."""
        self.debug_mode = DebugMode.STEP_INTO

    def continue_execution(self) -> None:
        """Continue to next breakpoint."""
        self.debug_mode = DebugMode.RUN

    def run(self) -> None:
        """Resume normal execution."""
        self.debug_mode = DebugMode.RUN

    def add_step_callback(
        self,
        callback: Callable[[str, Dict], None]
    ) -> None:
        """Add callback for each step (for step_into)."""
        self._step_callbacks.append(callback)

    def get_hit_history(self) -> List[BreakpointHit]:
        """Get breakpoint hit history."""
        return self.hit_history.copy()

    def clear_history(self) -> None:
        """Clear hit history."""
        self.hit_history.clear()

    def get_breakpoints_for_step(self, step_id: str) -> List[Breakpoint]:
        """Get all breakpoints that would trigger for a step."""
        return [
            bp for bp in self.breakpoints.values()
            if bp.enabled and bp.breakpoint_type == BreakpointType.STEP
            and bp.step_id == step_id
        ]

    def get_active_breakpoints(self) -> List[Breakpoint]:
        """Get all enabled breakpoints."""
        return [bp for bp in self.breakpoints.values() if bp.enabled]

    def get_summary(self) -> Dict[str, Any]:
        """Get summary of breakpoints."""
        return {
            "total_breakpoints": len(self.breakpoints),
            "enabled": sum(1 for bp in self.breakpoints.values() if bp.enabled),
            "total_hits": sum(bp.hit_count for bp in self.breakpoints.values()),
            "debug_mode": self.debug_mode.name,
            "history_length": len(self.hit_history)
        }


def create_breakpoint_manager() -> BreakpointManager:
    """Create a breakpoint manager."""
    return BreakpointManager()
