"""
BPL Checkpoints - State serialization and recovery.

Provides:
- Checkpoint creation and serialization
- Integrity verification
- Recovery plan generation
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum, auto
from datetime import datetime
import hashlib
import json


class CheckpointType(Enum):
    """Types of checkpoints."""
    AUTO = auto()        # Automatic checkpoint
    MANUAL = auto()      # User-triggered checkpoint
    ERROR = auto()       # Checkpoint on error
    MILESTONE = auto()   # Protocol milestone


@dataclass
class CheckpointData:
    """Data stored in a checkpoint."""
    # State hashes
    deck_state_hash: str
    execution_state_hash: str

    # Serialized states
    deck_state_json: str = ""
    step_states: Dict[str, str] = field(default_factory=dict)

    # Metadata
    variables: Dict[str, Any] = field(default_factory=dict)
    counters: Dict[str, int] = field(default_factory=dict)


@dataclass
class Checkpoint:
    """A checkpoint in protocol execution."""
    checkpoint_id: str
    checkpoint_type: CheckpointType
    step_id: str
    created_at: datetime = field(default_factory=datetime.now)
    data: CheckpointData = field(default_factory=lambda: CheckpointData("", ""))
    integrity_hash: str = ""
    parent_checkpoint_id: Optional[str] = None
    description: str = ""

    def __post_init__(self):
        if not self.integrity_hash:
            self.integrity_hash = self._compute_integrity_hash()

    def _compute_integrity_hash(self) -> str:
        """Compute integrity hash for checkpoint."""
        data = {
            "id": self.checkpoint_id,
            "type": self.checkpoint_type.name,
            "step": self.step_id,
            "deck_hash": self.data.deck_state_hash,
            "exec_hash": self.data.execution_state_hash,
            "parent": self.parent_checkpoint_id
        }
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()

    def verify_integrity(self) -> bool:
        """Verify checkpoint integrity."""
        return self.integrity_hash == self._compute_integrity_hash()


@dataclass
class RecoveryPlan:
    """Plan for recovering from a checkpoint."""
    checkpoint_id: str
    steps_to_skip: List[str] = field(default_factory=list)
    steps_to_rerun: List[str] = field(default_factory=list)
    state_to_restore: Optional[CheckpointData] = None
    warnings: List[str] = field(default_factory=list)

    @property
    def can_recover(self) -> bool:
        return self.state_to_restore is not None


class CheckpointManager:
    """
    Manages checkpoints during execution.

    Handles:
    - Checkpoint creation
    - Serialization/deserialization
    - Integrity verification
    - Recovery planning
    """

    def __init__(self, auto_checkpoint_interval: int = 10):
        self.checkpoints: Dict[str, Checkpoint] = {}
        self.checkpoint_chain: List[str] = []
        self.auto_checkpoint_interval = auto_checkpoint_interval
        self._step_counter = 0
        self._last_checkpoint_id: Optional[str] = None

    def create_checkpoint(
        self,
        step_id: str,
        checkpoint_type: CheckpointType,
        deck_state_hash: str,
        execution_state_hash: str,
        description: str = ""
    ) -> Checkpoint:
        """Create a new checkpoint."""
        checkpoint_id = f"cp_{step_id}_{datetime.now().strftime('%H%M%S%f')}"

        data = CheckpointData(
            deck_state_hash=deck_state_hash,
            execution_state_hash=execution_state_hash
        )

        checkpoint = Checkpoint(
            checkpoint_id=checkpoint_id,
            checkpoint_type=checkpoint_type,
            step_id=step_id,
            data=data,
            parent_checkpoint_id=self._last_checkpoint_id,
            description=description
        )

        self.checkpoints[checkpoint_id] = checkpoint
        self.checkpoint_chain.append(checkpoint_id)
        self._last_checkpoint_id = checkpoint_id

        return checkpoint

    def create_auto_checkpoint(
        self,
        step_id: str,
        deck_state_hash: str,
        execution_state_hash: str
    ) -> Optional[Checkpoint]:
        """Create automatic checkpoint if interval reached."""
        self._step_counter += 1

        if self._step_counter >= self.auto_checkpoint_interval:
            self._step_counter = 0
            return self.create_checkpoint(
                step_id=step_id,
                checkpoint_type=CheckpointType.AUTO,
                deck_state_hash=deck_state_hash,
                execution_state_hash=execution_state_hash,
                description=f"Auto checkpoint at step {step_id}"
            )

        return None

    def get_checkpoint(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Get a checkpoint by ID."""
        return self.checkpoints.get(checkpoint_id)

    def get_latest_checkpoint(self) -> Optional[Checkpoint]:
        """Get the most recent checkpoint."""
        if self.checkpoint_chain:
            return self.checkpoints.get(self.checkpoint_chain[-1])
        return None

    def get_checkpoint_chain(self) -> List[Checkpoint]:
        """Get all checkpoints in order."""
        return [self.checkpoints[cid] for cid in self.checkpoint_chain]

    def verify_chain_integrity(self) -> tuple[bool, List[str]]:
        """Verify integrity of entire checkpoint chain."""
        issues = []

        for i, checkpoint_id in enumerate(self.checkpoint_chain):
            checkpoint = self.checkpoints[checkpoint_id]

            # Verify individual integrity
            if not checkpoint.verify_integrity():
                issues.append(f"Checkpoint {checkpoint_id} integrity check failed")

            # Verify chain linkage
            if i > 0:
                expected_parent = self.checkpoint_chain[i - 1]
                if checkpoint.parent_checkpoint_id != expected_parent:
                    issues.append(
                        f"Checkpoint {checkpoint_id} parent mismatch: "
                        f"expected {expected_parent}, got {checkpoint.parent_checkpoint_id}"
                    )

        return len(issues) == 0, issues

    def create_recovery_plan(
        self,
        from_checkpoint_id: str,
        completed_steps: List[str]
    ) -> RecoveryPlan:
        """Create a recovery plan from a checkpoint."""
        checkpoint = self.get_checkpoint(from_checkpoint_id)

        if checkpoint is None:
            return RecoveryPlan(
                checkpoint_id=from_checkpoint_id,
                warnings=["Checkpoint not found"]
            )

        # Verify integrity
        if not checkpoint.verify_integrity():
            return RecoveryPlan(
                checkpoint_id=from_checkpoint_id,
                warnings=["Checkpoint integrity verification failed"]
            )

        # Find steps to skip (already completed before checkpoint)
        checkpoint_step = checkpoint.step_id
        steps_to_skip = []
        steps_to_rerun = []

        found_checkpoint = False
        for step_id in completed_steps:
            if step_id == checkpoint_step:
                found_checkpoint = True
            elif not found_checkpoint:
                steps_to_skip.append(step_id)
            else:
                steps_to_rerun.append(step_id)

        return RecoveryPlan(
            checkpoint_id=from_checkpoint_id,
            steps_to_skip=steps_to_skip,
            steps_to_rerun=steps_to_rerun,
            state_to_restore=checkpoint.data
        )

    def serialize_checkpoint(self, checkpoint_id: str) -> Optional[str]:
        """Serialize a checkpoint to JSON string."""
        checkpoint = self.get_checkpoint(checkpoint_id)
        if checkpoint is None:
            return None

        data = {
            "checkpoint_id": checkpoint.checkpoint_id,
            "checkpoint_type": checkpoint.checkpoint_type.name,
            "step_id": checkpoint.step_id,
            "created_at": checkpoint.created_at.isoformat(),
            "integrity_hash": checkpoint.integrity_hash,
            "parent_checkpoint_id": checkpoint.parent_checkpoint_id,
            "description": checkpoint.description,
            "data": {
                "deck_state_hash": checkpoint.data.deck_state_hash,
                "execution_state_hash": checkpoint.data.execution_state_hash,
                "deck_state_json": checkpoint.data.deck_state_json,
                "step_states": checkpoint.data.step_states,
                "variables": checkpoint.data.variables,
                "counters": checkpoint.data.counters
            }
        }

        return json.dumps(data, indent=2)

    def deserialize_checkpoint(self, json_str: str) -> Optional[Checkpoint]:
        """Deserialize a checkpoint from JSON string."""
        try:
            data = json.loads(json_str)

            checkpoint_data = CheckpointData(
                deck_state_hash=data["data"]["deck_state_hash"],
                execution_state_hash=data["data"]["execution_state_hash"],
                deck_state_json=data["data"].get("deck_state_json", ""),
                step_states=data["data"].get("step_states", {}),
                variables=data["data"].get("variables", {}),
                counters=data["data"].get("counters", {})
            )

            checkpoint = Checkpoint(
                checkpoint_id=data["checkpoint_id"],
                checkpoint_type=CheckpointType[data["checkpoint_type"]],
                step_id=data["step_id"],
                created_at=datetime.fromisoformat(data["created_at"]),
                data=checkpoint_data,
                integrity_hash=data["integrity_hash"],
                parent_checkpoint_id=data.get("parent_checkpoint_id"),
                description=data.get("description", "")
            )

            return checkpoint

        except (json.JSONDecodeError, KeyError, ValueError):
            return None

    def export_all(self) -> str:
        """Export all checkpoints to JSON."""
        export_data = {
            "checkpoint_chain": self.checkpoint_chain,
            "checkpoints": {
                cid: json.loads(self.serialize_checkpoint(cid) or "{}")
                for cid in self.checkpoint_chain
            }
        }
        return json.dumps(export_data, indent=2)

    def import_all(self, json_str: str) -> bool:
        """Import checkpoints from JSON."""
        try:
            data = json.loads(json_str)
            self.checkpoint_chain = data.get("checkpoint_chain", [])
            self.checkpoints = {}

            for cid, cp_data in data.get("checkpoints", {}).items():
                checkpoint = self.deserialize_checkpoint(json.dumps(cp_data))
                if checkpoint:
                    self.checkpoints[cid] = checkpoint

            return True
        except Exception:
            return False


def create_checkpoint_manager(
    auto_interval: int = 10
) -> CheckpointManager:
    """Create a checkpoint manager."""
    return CheckpointManager(auto_checkpoint_interval=auto_interval)
