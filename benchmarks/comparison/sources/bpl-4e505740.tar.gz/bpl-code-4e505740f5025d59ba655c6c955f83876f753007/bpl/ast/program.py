"""
Program node - the root of a BPL AST.
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List

from bpl.ast.base import ASTNode

if TYPE_CHECKING:
    from bpl.ast.declarations import Declaration


@dataclass
class Program(ASTNode):
    """
    Root node representing a complete BPL program.

    A program consists of a sequence of top-level declarations.
    """
    declarations: List['Declaration'] = field(default_factory=list)
