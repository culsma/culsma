"""
Unit expression nodes for BPL AST.
"""

from dataclasses import dataclass
from enum import Enum, auto

from bpl.ast.base import ASTNode


class UnitKind(Enum):
    """The kind of unit."""
    SIMPLE = auto()      # e.g., mL, g, degC
    COMPOUND = auto()    # e.g., mg/mL, g/L
    MOLAR = auto()       # e.g., M, mM, uM
    PERCENT = auto()     # e.g., %, percent
    FOLD = auto()        # e.g., 1000X


@dataclass
class UnitExpr(ASTNode):
    """
    A unit expression.

    Examples: mL, mg/mL, M, %, 1000X
    """
    text: str = ""
    kind: UnitKind = UnitKind.SIMPLE

    @classmethod
    def simple(cls, text: str) -> 'UnitExpr':
        """Create a simple unit (e.g., mL, g)."""
        return cls(kind=UnitKind.SIMPLE, text=text)

    @classmethod
    def compound(cls, text: str) -> 'UnitExpr':
        """Create a compound unit (e.g., mg/mL)."""
        return cls(kind=UnitKind.COMPOUND, text=text)

    @classmethod
    def molar(cls, text: str) -> 'UnitExpr':
        """Create a molar unit (e.g., M, mM)."""
        return cls(kind=UnitKind.MOLAR, text=text)

    @classmethod
    def percent(cls, text: str = "%") -> 'UnitExpr':
        """Create a percent unit."""
        return cls(kind=UnitKind.PERCENT, text=text)

    @classmethod
    def fold(cls, text: str = "X") -> 'UnitExpr':
        """Create a fold factor unit (e.g., 1000X)."""
        return cls(kind=UnitKind.FOLD, text=text)
