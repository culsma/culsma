"""
Annotation nodes for BPL AST.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any

from bpl.ast.base import ASTNode


@dataclass
class AnnotationArg(ASTNode):
    """
    An argument to an annotation.

    Can be either named (name: value) or positional (just value).
    """
    name: Optional[str] = None
    value: Any = None  # Expression

    @property
    def is_named(self) -> bool:
        """Check if this is a named argument."""
        return self.name is not None


@dataclass
class Annotation(ASTNode):
    """
    An annotation like @step(critical) or @compliance(GxP).

    Examples:
        @step(critical)
        @compliance(GxP)
        @on_error(match: TipClog, action: Retry { max: 3 })
        @checkpoint("before_heat_shock")
    """
    name: str = ""
    arguments: List['AnnotationArg'] = field(default_factory=list)

    def get_arg(self, name: str) -> Optional[Any]:
        """Get a named argument by name."""
        for arg in self.arguments:
            if arg.name == name:
                return arg.value
        return None

    def get_positional(self, index: int) -> Optional[Any]:
        """Get a positional argument by index."""
        positional = [a for a in self.arguments if not a.is_named]
        if 0 <= index < len(positional):
            return positional[index].value
        return None


@dataclass
class ProtocolSetting(ASTNode):
    """
    A protocol-level setting like @default_compliance: GxP.

    These appear at the top of a protocol body.
    """
    name: str = ""
    value: Any = None  # Expression
