"""
Statement nodes for BPL AST.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Any

from bpl.ast.base import ASTNode


@dataclass
class Statement(ASTNode):
    """Base class for all statements."""
    annotations: List[Any] = field(default_factory=list)  # List[Annotation]


@dataclass
class Block(ASTNode):
    """
    A block of statements enclosed in braces.
    """
    statements: List['Statement'] = field(default_factory=list)


@dataclass
class LetStmt(Statement):
    """
    A let binding statement like:
        let x = 10 mL
        let y: Volume = 100 uL
    """
    name: str = ""
    type_annotation: Any = None  # TypeExpr
    value: Any = None  # Expression


@dataclass
class AssignStmt(Statement):
    """
    A reassignment statement like:
        x = 20 mL
    """
    target: str = ""
    value: Any = None  # Expression


@dataclass
class CallStmt(Statement):
    """
    A function/intent call statement like:
        transfer(from: source, to: dest, volume: 100 uL)
    """
    name: str = ""
    arguments: List[Any] = field(default_factory=list)  # List[Argument]


@dataclass
class IfBranch(ASTNode):
    """
    An if or else-if branch with condition and body.
    """
    condition: Any = None  # Expression
    body: Optional['Block'] = None


@dataclass
class IfStmt(Statement):
    """
    An if statement with optional else-if and else branches.

    Example:
        if x > 0 {
            ...
        } else if x < 0 {
            ...
        } else {
            ...
        }
    """
    condition: Any = None  # Expression
    then_block: Optional['Block'] = None
    else_ifs: List[Tuple[Any, 'Block']] = field(default_factory=list)
    else_block: Optional['Block'] = None


@dataclass
class ForStmt(Statement):
    """
    A for loop statement like:
        for well in plate.wells(All) {
            ...
        }
    """
    variable: str = ""
    iterable: Any = None  # Expression
    body: Optional['Block'] = None


@dataclass
class WhileStmt(Statement):
    """
    A while loop statement like:
        while od < 0.6 {
            ...
        }
    """
    condition: Any = None  # Expression
    body: Optional['Block'] = None


@dataclass
class ReturnStmt(Statement):
    """
    A return statement like:
        return result
        return
    """
    value: Any = None  # Expression


@dataclass
class ParallelBlock(Statement):
    """
    A parallel block for concurrent execution (v2.4).

    Example:
        parallel {
            incubate(plate_a, 37 degC, 30 min)
            incubate(plate_b, 37 degC, 30 min)
        }
    """
    statements: List['Statement'] = field(default_factory=list)


@dataclass
class SequenceBlock(Statement):
    """
    An explicit sequence block (v2.4).

    Example:
        sequence {
            wait(30 min)
            measure(plate, Absorbance)
        }
    """
    statements: List['Statement'] = field(default_factory=list)


# ============================================================================
# WORKLIST INTENTS (v2.5)
# ============================================================================

@dataclass
class StampStmt(Statement):
    """
    Stamp transfer: all wells from source plate to destination plate 1:1.

    Example:
        stamp(from: pcr_reaction_plate, to: cleanup_plate, volume: 10 uL)
    """
    source_plate: str = ""
    dest_plate: str = ""
    volume: Any = None  # QuantityExpr


@dataclass
class CherrypickStmt(Statement):
    """
    Selective well-to-well transfers.

    Example:
        cherrypick(
            from: template_inventory[A1, B3, C5, D7],
            to: pcr_setup_plate[A1, A2, A3, A4],
            volume: 2 uL
        )
    """
    source_plate: str = ""
    source_wells: List[str] = field(default_factory=list)  # ["A1", "B3", "C5"]
    dest_plate: str = ""
    dest_wells: List[str] = field(default_factory=list)
    volume: Any = None  # QuantityExpr


@dataclass
class SerialDiluteStmt(Statement):
    """
    Multi-step serial dilution.

    Example:
        serial_dilute(
            source: growth_plate,
            destinations: [dilution_1, dilution_2, dilution_3, dilution_4],
            volume: 20 uL,
            steps: 4
        )
    """
    source_plate: str = ""
    dest_plates: List[str] = field(default_factory=list)  # [plate1, plate2, plate3, plate4]
    volume: Any = None  # QuantityExpr
    dilution_steps: int = 4
