"""
Declaration nodes for BPL AST.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any
from enum import Enum, auto

from bpl.ast.base import ASTNode


class PhysicalForm(Enum):
    """Physical form of a reagent."""
    SOLID = auto()
    LIQUID = auto()
    GAS = auto()


class Footprint(Enum):
    """Labware footprint."""
    SBS_STANDARD = auto()
    SBS_HALF = auto()
    CUSTOM = auto()


class LabwareCategory(Enum):
    """Labware category."""
    PLATE_96 = auto()
    PLATE_384 = auto()
    TIP_RACK = auto()
    RESERVOIR = auto()
    TUBE = auto()


@dataclass
class Parameter(ASTNode):
    """
    A function/protocol parameter.

    Example:
        x: Volume
        y: Number = 10
    """
    name: str = ""
    type_annotation: Any = None  # TypeExpr
    default_value: Any = None  # Expression


@dataclass
class FieldDef(ASTNode):
    """
    A field definition in a declaration.

    Example:
        name: "My Reagent"
        concentration: 50 mg/mL
    """
    name: str = ""
    value: Any = None  # Expression


@dataclass
class Declaration(ASTNode):
    """Base class for all declarations."""
    name: str = ""
    annotations: List[Any] = field(default_factory=list)  # List[Annotation]


@dataclass
class ProtocolDecl(Declaration):
    """
    A protocol declaration.

    Example:
        protocol HeatShockTransform(dna: DNA) {
            @default_compliance: Research
            @error_policy: { default: Stop }

            transfer(from: cells, to: tube, volume: 50 uL)
            ...
        }
    """
    parameters: List['Parameter'] = field(default_factory=list)
    settings: List[Any] = field(default_factory=list)  # List[ProtocolSetting]
    body: List[Any] = field(default_factory=list)  # List[Statement]


@dataclass
class ModuleDecl(Declaration):
    """
    A module declaration.

    Example:
        module stdlib.reagents {
            reagent Water { ... }
            reagent NaCl { ... }
        }
    """
    qualified_name: List[str] = field(default_factory=list)
    members: List['Declaration'] = field(default_factory=list)


@dataclass
class ImportDecl(Declaration):
    """
    An import declaration.

    Examples:
        import stdlib.reagents version "1.0"
        import stdlib.reagents as reagents
        from stdlib.media version "2.1" import LB, YPD
    """
    path: List[str] = field(default_factory=list)
    version: Optional[str] = None
    alias: Optional[str] = None
    names: Optional[List[tuple]] = None  # List of (name, alias) tuples
    import_all: bool = False


@dataclass
class ReagentDecl(Declaration):
    """
    A reagent declaration.

    Example:
        reagent NaCl {
            physical_form: Solid
            MW: 58.44 g/mol
        }
    """
    physical_form: Optional[PhysicalForm] = None
    mw: Any = None  # QuantityExpr
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class StockDecl(Declaration):
    """
    A stock solution declaration.

    Example:
        stock Kanamycin_1000X {
            reagent: Kanamycin
            concentration: 50 mg/mL
            solvent: Water
            fold: 1000X
        }
    """
    reagent: Optional[str] = None
    concentration: Any = None  # QuantityExpr
    solvent: Optional[str] = None
    fold: Any = None  # QuantityExpr
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class DeckPosition(ASTNode):
    """
    A position in a deck model.

    Example:
        { id: "P1", accepts: [SBS_Standard], is_waste: false }
    """
    id: str = ""
    accepts: List[Footprint] = field(default_factory=list)
    coordinates: Optional[tuple] = None  # (x, y, z)
    is_waste: bool = False


@dataclass
class LabwareDecl(Declaration):
    """
    A labware declaration.

    Example:
        labware DeepWellPlate_96 {
            footprint: SBS_Standard
            well_count: 96
            well_volume: 2.2 mL
            category: Plate_96
            barcode: "PCRP001"
            set_identifier: "Set1"
        }
    """
    footprint: Optional[Footprint] = None
    well_count: Optional[int] = None
    well_volume: Any = None  # QuantityExpr
    category: Optional[LabwareCategory] = None
    barcode: Optional[str] = None  # External identifier for worklist generation
    set_identifier: Optional[str] = None  # Group identifier for batch operations
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class DeckModelDecl(Declaration):
    """
    A deck model declaration.

    Example:
        deck_model Biomek_i7 {
            positions: [
                { id: "P1", accepts: [SBS_Standard] },
                { id: "Waste", is_waste: true }
            ]
        }
    """
    positions: List['DeckPosition'] = field(default_factory=list)
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class TargetDecl(Declaration):
    """
    A target (execution environment) declaration.

    Example:
        target Biomek_i7 {
            capabilities: [aspirate, dispense, pick_tips, drop_tips]
            NOT: [vortex, weigh]
        }
    """
    capabilities: List[str] = field(default_factory=list)
    not_capabilities: List[str] = field(default_factory=list)
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class ResourceDecl(Declaration):
    """
    A shared resource declaration (v2.4).

    Example:
        resource Centrifuge_1 {
            capacity: 1
            booking_required: true
            cooldown: 30 s
        }
    """
    capacity: Optional[int] = None
    booking_required: Optional[bool] = None
    cooldown: Any = None  # QuantityExpr
    min_booking_duration: Any = None  # QuantityExpr
    fields: List['FieldDef'] = field(default_factory=list)


@dataclass
class TypeDecl(Declaration):
    """
    A type declaration.

    Example:
        type Concentration = MassConcentration | MolarConcentration
    """
    type_expr: Any = None  # TypeExpr


@dataclass
class FunctionDecl(Declaration):
    """
    A function declaration.

    Example:
        function calculate_volume(conc: Concentration, mass: Mass) -> Volume {
            return mass / conc
        }
    """
    parameters: List['Parameter'] = field(default_factory=list)
    return_type: Any = None  # TypeExpr
    body: Any = None  # Block


@dataclass
class IntentDecl(Declaration):
    """
    An intent declaration (high-level action signature).

    Example:
        intent add(source: Source, to: Destination, volume: Volume?) -> StateTransition
    """
    parameters: List['Parameter'] = field(default_factory=list)
    return_type: Any = None  # TypeExpr


@dataclass
class PrimitiveDecl(Declaration):
    """
    A primitive declaration (low-level action signature).

    Example:
        primitive aspirate(from: WellRef, volume: Volume, speed: VolumeRate)
    """
    parameters: List['Parameter'] = field(default_factory=list)
    return_type: Any = None  # TypeExpr


@dataclass
class RecoveryDecl(Declaration):
    """
    A recovery procedure declaration (v2.4).

    Example:
        recovery TipClogRecovery {
            @for_error: TipClog
            drop_tips(to: Waste)
            pick_tips(type: same_as_before, count: same_as_before)
        }
    """
    body: List[Any] = field(default_factory=list)  # List[Statement]


@dataclass
class InvariantClause(ASTNode):
    """A clause in an invariant declaration."""
    pass


@dataclass
class InvariantCheck(InvariantClause):
    """The check clause of an invariant."""
    expression: Any = None  # Expression


@dataclass
class InvariantAfter(InvariantClause):
    """The after clause listing steps to check after."""
    steps: List[str] = field(default_factory=list)


@dataclass
class InvariantViolation(InvariantClause):
    """The on_violation clause specifying what to do."""
    action: Any = None  # Expression


@dataclass
class InvariantDecl(Declaration):
    """
    An invariant declaration (v2.4).

    Example:
        invariant "cell_viability" {
            check: cells.viability > 0.9
            after: [centrifuge, resuspend]
            on_violation: AlertAndContinue { timeout: 5 min }
        }
    """
    check: Any = None  # Expression
    after: List[str] = field(default_factory=list)
    on_violation: Any = None  # Expression


@dataclass
class PcrCycleStep(ASTNode):
    """
    A single step within PCR cycling.

    Example:
        denature: 98 degC for 10 s
    """
    name: str = ""
    temperature: Any = None  # QuantityExpr
    duration: Any = None  # QuantityExpr


@dataclass
class PcrProfileDecl(Declaration):
    """
    A PCR profile declaration.

    Example:
        pcr_profile Q5_Standard {
            initial: 98 degC for 30 s
            cycles: 34 {
                denature: 98 degC for 10 s
                anneal: 60 degC for 30 s
                extend: 72 degC for 20 s
            }
            final: 72 degC for 2 min
            hold: 4 degC
            lid_temp: 105 degC
        }
    """
    initial_temp: Any = None  # QuantityExpr
    initial_duration: Any = None  # QuantityExpr
    cycle_count: int = 30
    cycle_steps: List['PcrCycleStep'] = field(default_factory=list)
    final_temp: Any = None  # QuantityExpr
    final_duration: Any = None  # QuantityExpr
    hold_temp: Any = None  # QuantityExpr
    lid_temp: Any = None  # QuantityExpr
