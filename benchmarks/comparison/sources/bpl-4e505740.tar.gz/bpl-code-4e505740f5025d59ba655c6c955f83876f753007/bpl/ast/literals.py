"""
Literal value nodes for BPL AST.
"""

from dataclasses import dataclass

from bpl.ast.base import ASTNode


@dataclass
class NumberLit(ASTNode):
    """A numeric literal (integer or float)."""
    value: float = 0.0


@dataclass
class StringLit(ASTNode):
    """A string literal."""
    value: str = ""


@dataclass
class BoolLit(ASTNode):
    """A boolean literal (true/false)."""
    value: bool = False
