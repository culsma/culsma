"""
Type expression nodes for BPL AST.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any

from bpl.ast.base import ASTNode


@dataclass
class TypeExpr(ASTNode):
    """Base class for type expressions."""
    pass


@dataclass
class SimpleTypeExpr(TypeExpr):
    """
    A simple type reference like Mass, Volume, Concentration.
    """
    name: str = ""


@dataclass
class ParameterizedTypeExpr(TypeExpr):
    """
    A parameterized type like List<Mass> or Map<String, Number>.
    """
    name: str = ""
    type_params: List['TypeExpr'] = field(default_factory=list)


@dataclass
class TypeField(ASTNode):
    """
    A field in a product or sum type.

    Examples:
        name: String
        value: Number?  (optional)
    """
    name: str = ""
    type_expr: Optional['TypeExpr'] = None
    optional: bool = False


@dataclass
class SumTypeExpr(TypeExpr):
    """
    A sum type (union) like A | B | C.

    Example:
        type Concentration = MassConcentration | MolarConcentration
    """
    variants: List['TypeVariant'] = field(default_factory=list)


@dataclass
class TypeVariant(ASTNode):
    """
    A variant in a sum type.

    Example:
        TipClog { pressure: Pressure, channel: Integer }
    """
    name: str = ""
    fields: List['TypeField'] = field(default_factory=list)


@dataclass
class ProductTypeExpr(TypeExpr):
    """
    A product type (record/struct) like { field1: Type1, field2: Type2 }.

    Example:
        { name: String, age: Number }
    """
    fields: List['TypeField'] = field(default_factory=list)


@dataclass
class ConstrainedTypeExpr(TypeExpr):
    """
    A constrained type like Number constrained [0, 100] with PercentUnit.

    Example:
        type Percentage = Number constrained [0, 100] with PercentUnit
    """
    base_type: Any = None  # TypeExpr or str
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    validator: Optional[str] = None
