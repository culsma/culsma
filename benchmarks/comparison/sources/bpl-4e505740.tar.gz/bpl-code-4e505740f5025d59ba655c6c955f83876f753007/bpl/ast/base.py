"""
Base classes for BPL Abstract Syntax Tree nodes.
"""

from dataclasses import dataclass, field
from typing import Optional, Any, TypeVar
from abc import ABC


@dataclass(frozen=True)
class SourceSpan:
    """
    Represents a location span in source code.
    """
    file: str
    start_line: int
    start_col: int
    end_line: int
    end_col: int

    def __str__(self) -> str:
        return f"{self.file}:{self.start_line}:{self.start_col}"


T = TypeVar('T')


class ASTVisitor(ABC):
    """
    Base visitor class for traversing AST nodes.

    Subclasses should implement visit_* methods for each node type.
    """

    def visit(self, node: 'ASTNode') -> Any:
        """Visit a node by dispatching to the appropriate visit method."""
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: 'ASTNode') -> Any:
        """
        Called when no specific visitor method exists.

        Override this to provide default behavior.
        """
        raise NotImplementedError(
            f"No visitor method for {type(node).__name__}"
        )


@dataclass
class ASTNode(ABC):
    """
    Base class for all AST nodes.

    Every node has an optional source span for error reporting.
    """
    span: Optional[SourceSpan] = field(
        default=None,
        repr=False,
        compare=False
    )

    def accept(self, visitor: ASTVisitor) -> Any:
        """Accept a visitor for double-dispatch pattern."""
        return visitor.visit(self)
