"""
Expression nodes for BPL AST.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from bpl.ast.base import ASTNode
from bpl.ast.units import UnitExpr


@dataclass
class Expression(ASTNode):
    """Base class for all expressions."""
    pass


@dataclass
class BinaryExpr(Expression):
    """
    A binary expression like a + b, x && y, etc.

    Operators include: +, -, *, /, mod, &&, ||, ==, !=, <, <=, >, >=, in
    """
    op: str = ""
    left: Optional['Expression'] = None
    right: Optional['Expression'] = None


@dataclass
class UnaryExpr(Expression):
    """
    A unary expression like -x, !flag, not condition.

    Operators: -, !, not
    """
    op: str = ""
    operand: Optional['Expression'] = None


@dataclass
class ConditionalExpr(Expression):
    """
    A ternary conditional expression: condition ? then_expr : else_expr.
    """
    condition: Optional['Expression'] = None
    then_expr: Optional['Expression'] = None
    else_expr: Optional['Expression'] = None


@dataclass
class RangeExpr(Expression):
    """
    A range expression like 1..10.
    """
    start: Optional['Expression'] = None
    end: Optional['Expression'] = None


@dataclass
class FieldAccessExpr(Expression):
    """
    A field access expression like obj.field.
    """
    object: Optional['Expression'] = None
    field: str = ""


@dataclass
class MethodCallExpr(Expression):
    """
    A method call expression like obj.method(args).
    """
    object: Optional['Expression'] = None
    method: str = ""
    arguments: List['Argument'] = field(default_factory=list)


@dataclass
class IndexExpr(Expression):
    """
    An index access expression like arr[i] or map["key"].
    """
    object: Optional['Expression'] = None
    index: Optional['Expression'] = None


@dataclass
class CallExpr(Expression):
    """
    A function/intent call expression like transfer(from: a, to: b, volume: 100 uL).
    """
    function: Optional['Expression'] = None
    arguments: List['Argument'] = field(default_factory=list)


@dataclass
class QuantityExpr(Expression):
    """
    A quantity with a unit like 100 mL, 37 degC, 50 mg/mL.
    """
    value: Any = None  # NumberLit or Expression
    unit: Optional[UnitExpr] = None


@dataclass
class IdentifierExpr(Expression):
    """
    An identifier reference like variable_name.
    """
    name: str = ""


@dataclass
class TypeIdentifierExpr(Expression):
    """
    A type identifier reference like TypeName (starts with uppercase).
    """
    name: str = ""


@dataclass
class ListExpr(Expression):
    """
    A list literal like [a, b, c].
    """
    elements: List['Expression'] = field(default_factory=list)


@dataclass
class MapEntry(ASTNode):
    """
    A map entry like key: value.
    """
    key: str = ""
    value: Optional['Expression'] = None


@dataclass
class MapExpr(Expression):
    """
    A map literal like {key: value, ...}.
    """
    entries: Dict[str, 'Expression'] = field(default_factory=dict)


@dataclass
class LambdaExpr(Expression):
    """
    A lambda expression like |x, y| x + y or |x| { return x * 2 }.
    """
    parameters: List[Any] = field(default_factory=list)  # List[Parameter]
    body: Any = None  # Expression or Block


@dataclass
class StateDeltaExpr(Expression):
    """
    A StateDelta expression for manual() state_effects.

    Example:
        StateDelta {
            containers_modified: [{ container: tube, volume_change: -100 uL }]
        }
    """
    fields: Dict[str, 'Expression'] = field(default_factory=dict)


@dataclass
class Argument(ASTNode):
    """
    An argument to a function or method call.

    Can be positional or named.
    """
    name: Optional[str] = None
    value: Optional['Expression'] = None

    @property
    def is_named(self) -> bool:
        """Check if this is a named argument."""
        return self.name is not None
