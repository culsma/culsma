"""Canonical location DTOs and conversion helpers."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Literal

_WELL_PATTERN = re.compile(r"^([A-Za-z]+)(\d+)$")
_PLATE_DIMENSIONS: dict[str, tuple[int, int]] = {
    "plate_6": (2, 3),
    "plate_12": (3, 4),
    "plate_24": (4, 6),
    "plate_48": (6, 8),
    "plate_96": (8, 12),
    "plate_384": (16, 24),
    "plate_1536": (32, 48),
}


@dataclass(frozen=True)
class WellAddress:
    """Canonical well location DTO."""

    labware_id: str
    well: str
    row: int
    col: int
    plate_format: str | None = None
    index: int | None = None


@dataclass(frozen=True)
class ContainerAddress:
    """Canonical container location DTO."""

    labware_id: str


LocationAddress = WellAddress | ContainerAddress


def normalize_well_id(well_id: str) -> str:
    """Normalize well identifiers into canonical uppercase, non-padded form."""

    raw = well_id.strip()
    match = _WELL_PATTERN.match(raw)
    if match is None:
        raise ValueError(f"Invalid well identifier: {well_id!r}")

    row_label = match.group(1).upper()
    col = int(match.group(2))
    if col <= 0:
        raise ValueError(f"Well column must be >= 1, got {col} for {well_id!r}")
    return f"{row_label}{col}"


def row_label_to_index(row_label: str) -> int:
    """Convert alphabetic row label (A, Z, AA) into 0-based row index."""

    cleaned = row_label.strip().upper()
    if not cleaned or not cleaned.isalpha():
        raise ValueError(f"Invalid row label: {row_label!r}")

    value = 0
    for char in cleaned:
        value = value * 26 + (ord(char) - ord("A") + 1)
    return value - 1


def row_index_to_label(row_index: int) -> str:
    """Convert 0-based row index into alphabetic row label."""

    if row_index < 0:
        raise ValueError(f"Row index must be >= 0, got {row_index}")

    value = row_index + 1
    chars: list[str] = []
    while value > 0:
        value -= 1
        value, remainder = divmod(value, 26)
        chars.append(chr(ord("A") + remainder))
    return "".join(reversed(chars))


def well_to_coordinates(well_id: str) -> tuple[int, int]:
    """Convert well identifier to 0-based (row, col) coordinates."""

    normalized = normalize_well_id(well_id)
    match = _WELL_PATTERN.match(normalized)
    if match is None:  # pragma: no cover - guaranteed by normalize_well_id
        raise ValueError(f"Invalid normalized well identifier: {well_id!r}")
    row = row_label_to_index(match.group(1))
    col = int(match.group(2)) - 1
    return row, col


def well_from_coordinates(row: int, col: int) -> str:
    """Convert 0-based coordinates into canonical well identifier."""

    if row < 0 or col < 0:
        raise ValueError(f"Row and col must be >= 0, got row={row}, col={col}")
    return f"{row_index_to_label(row)}{col + 1}"


def validate_well_in_plate_bounds(
    well_id: str,
    *,
    plate_format: str,
) -> bool:
    """Validate whether a well is within declared plate format bounds."""

    dims = _plate_dimensions(plate_format)
    row, col = well_to_coordinates(well_id)
    return row < dims[0] and col < dims[1]


def plan_well_ref_to_canonical(
    well_ref,
    *,
    plate_format: str | None = None,
) -> WellAddress:
    """
    Convert lowering `WellRef` to canonical location DTO.

    Import is duck-typed to avoid a hard dependency cycle.
    """

    return make_well_address(
        labware_id=str(well_ref.plate_id),
        well=str(well_ref.well_id),
        plate_format=plate_format,
    )


def canonical_to_plan_well_ref(address: WellAddress):
    """Convert canonical well address to lowering `WellRef`."""

    from bpl.lowering import WellRef

    return WellRef(plate_id=address.labware_id, well_id=address.well)


def export_well_ref_to_canonical(
    well_ref,
    *,
    plate_format: str | None = None,
) -> WellAddress:
    """Convert export `WellRef` to canonical location DTO."""

    return make_well_address(
        labware_id=str(well_ref.plate),
        well=str(well_ref.well),
        plate_format=plate_format,
    )


def canonical_to_export_well_ref(address: WellAddress):
    """Convert canonical well address to export `WellRef`."""

    from bpl.export.worklist_exporter import WellRef

    return WellRef(plate=address.labware_id, well=address.well)


def make_well_address(
    *,
    labware_id: str,
    well: str,
    plate_format: str | None = None,
) -> WellAddress:
    """Construct a canonical well address from raw fields."""

    normalized_well = normalize_well_id(well)
    row, col = well_to_coordinates(normalized_well)
    index: int | None = None
    if plate_format is not None:
        rows, cols = _plate_dimensions(plate_format)
        if row >= rows or col >= cols:
            raise ValueError(
                f"Well {normalized_well} out of bounds for {plate_format} "
                f"(rows={rows}, cols={cols})"
            )
        index = row * cols + col
    return WellAddress(
        labware_id=labware_id,
        well=normalized_well,
        row=row,
        col=col,
        plate_format=plate_format,
        index=index,
    )


def _plate_dimensions(plate_format: str) -> tuple[int, int]:
    normalized = _normalize_plate_format_key(plate_format)
    dims = _PLATE_DIMENSIONS.get(normalized)
    if dims is None:
        raise ValueError(f"Unsupported plate format: {plate_format!r}")
    return dims


def _normalize_plate_format_key(raw: str) -> str:
    key = raw.strip().lower().replace("-", "_")
    alias_map: dict[str, str] = {
        "6": "plate_6",
        "12": "plate_12",
        "24": "plate_24",
        "48": "plate_48",
        "96": "plate_96",
        "384": "plate_384",
        "1536": "plate_1536",
    }
    return alias_map.get(key, key)


PlateFormatLiteral = Literal[
    "plate_6",
    "plate_12",
    "plate_24",
    "plate_48",
    "plate_96",
    "plate_384",
    "plate_1536",
]
