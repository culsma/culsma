"""
BPL Audit System - Audit trail, compliance, and export.

Provides:
- AuditTrail for complete protocol execution tracking
- ChainHash for cryptographic integrity verification
- AmendmentManager for protocol change tracking
- ComplianceChecker for regulatory compliance
- AuditExporter for report generation
"""

from .audit_trail import (
    # Enums
    AuditEventType,
    # Data classes
    AuditEntry,
    AuditTrail,
    # Functions
    create_audit_trail,
)

from .chain_hash import (
    # Enums
    HashAlgorithm,
    # Data classes
    ChainBlock,
    ChainIntegrityResult,
    # Classes
    ChainHash,
    # Functions
    compute_hash,
    compute_merkle_root,
    verify_chain_integrity,
)

from .amendments import (
    # Enums
    AmendmentType,
    AmendmentStatus,
    # Data classes
    AmendmentSignature,
    Amendment,
    # Classes
    AmendmentManager,
    # Functions
    create_amendment,
)

from .compliance import (
    # Enums
    ComplianceLevel,
    RequirementStatus,
    RequirementCategory,
    # Data classes
    ComplianceRequirement,
    RequirementResult,
    ComplianceReport,
    # Classes
    ComplianceChecker,
    # Functions
    check_compliance,
    get_requirements_for_level,
)

from .export import (
    # Enums
    ExportFormat,
    # Data classes
    ExportOptions,
    ExportResult,
    # Classes
    AuditExporter,
    # Functions
    export_audit_trail,
    export_to_file,
    export_compliance_report,
)

__all__ = [
    # Audit Trail
    "AuditEventType",
    "AuditEntry",
    "AuditTrail",
    "create_audit_trail",
    # Chain Hash
    "HashAlgorithm",
    "ChainBlock",
    "ChainIntegrityResult",
    "ChainHash",
    "compute_hash",
    "compute_merkle_root",
    "verify_chain_integrity",
    # Amendments
    "AmendmentType",
    "AmendmentStatus",
    "AmendmentSignature",
    "Amendment",
    "AmendmentManager",
    "create_amendment",
    # Compliance
    "ComplianceLevel",
    "RequirementStatus",
    "RequirementCategory",
    "ComplianceRequirement",
    "RequirementResult",
    "ComplianceReport",
    "ComplianceChecker",
    "check_compliance",
    "get_requirements_for_level",
    # Export
    "ExportFormat",
    "ExportOptions",
    "ExportResult",
    "AuditExporter",
    "export_audit_trail",
    "export_to_file",
    "export_compliance_report",
]
