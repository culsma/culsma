"""
BPL Chain Hash - Cryptographic integrity verification.

Provides:
- ChainHash for hash chain management
- Integrity verification functions
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import hashlib
import json


class HashAlgorithm(Enum):
    """Supported hash algorithms."""
    SHA256 = "sha256"
    SHA384 = "sha384"
    SHA512 = "sha512"
    SHA3_256 = "sha3_256"
    SHA3_512 = "sha3_512"


@dataclass
class ChainBlock:
    """A single block in the hash chain."""
    block_id: str
    timestamp: datetime
    data_hash: str
    previous_hash: str
    block_hash: str
    nonce: int = 0  # For optional proof-of-work

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "block_id": self.block_id,
            "timestamp": self.timestamp.isoformat(),
            "data_hash": self.data_hash,
            "previous_hash": self.previous_hash,
            "block_hash": self.block_hash,
            "nonce": self.nonce,
        }


@dataclass
class ChainIntegrityResult:
    """Result of chain integrity verification."""
    valid: bool
    checked_blocks: int = 0
    invalid_blocks: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    verified_at: datetime = field(default_factory=datetime.now)

    def add_error(self, block_id: str, error: str) -> None:
        """Add an integrity error."""
        self.invalid_blocks.append(block_id)
        self.errors.append(error)
        self.valid = False


class ChainHash:
    """Manages a cryptographic hash chain."""

    def __init__(
        self,
        algorithm: HashAlgorithm = HashAlgorithm.SHA256,
        genesis_hash: Optional[str] = None
    ):
        self.algorithm = algorithm
        self.blocks: List[ChainBlock] = []
        self._block_counter = 0

        # Genesis block
        if genesis_hash:
            self.genesis_hash = genesis_hash
        else:
            self.genesis_hash = self._create_genesis_hash()

    def _get_hasher(self):
        """Get the appropriate hash function."""
        if self.algorithm == HashAlgorithm.SHA256:
            return hashlib.sha256()
        elif self.algorithm == HashAlgorithm.SHA384:
            return hashlib.sha384()
        elif self.algorithm == HashAlgorithm.SHA512:
            return hashlib.sha512()
        elif self.algorithm == HashAlgorithm.SHA3_256:
            return hashlib.sha3_256()
        elif self.algorithm == HashAlgorithm.SHA3_512:
            return hashlib.sha3_512()
        return hashlib.sha256()

    def _create_genesis_hash(self) -> str:
        """Create genesis block hash."""
        hasher = self._get_hasher()
        hasher.update(b"GENESIS_BLOCK_BPL_AUDIT_TRAIL")
        return hasher.hexdigest()

    def compute_hash(self, data: str) -> str:
        """Compute hash of data."""
        hasher = self._get_hasher()
        hasher.update(data.encode())
        return hasher.hexdigest()

    def compute_data_hash(self, data: Any) -> str:
        """Compute hash of arbitrary data."""
        if isinstance(data, dict):
            data_str = json.dumps(data, sort_keys=True, default=str)
        elif isinstance(data, (list, tuple)):
            data_str = json.dumps(list(data), sort_keys=True, default=str)
        else:
            data_str = str(data)
        return self.compute_hash(data_str)

    def add_block(self, data: Any, block_id: Optional[str] = None) -> ChainBlock:
        """Add a new block to the chain."""
        self._block_counter += 1

        if block_id is None:
            block_id = f"block_{self._block_counter}"

        # Get previous hash
        if self.blocks:
            previous_hash = self.blocks[-1].block_hash
        else:
            previous_hash = self.genesis_hash

        # Compute data hash
        data_hash = self.compute_data_hash(data)

        # Create block
        timestamp = datetime.now()

        # Compute block hash from an unambiguous canonical representation.
        block_hash = self.compute_hash(
            self._block_hash_content(block_id, timestamp, data_hash, previous_hash)
        )

        block = ChainBlock(
            block_id=block_id,
            timestamp=timestamp,
            data_hash=data_hash,
            previous_hash=previous_hash,
            block_hash=block_hash,
        )

        self.blocks.append(block)
        return block

    def verify(self) -> ChainIntegrityResult:
        """Verify the integrity of the chain."""
        result = ChainIntegrityResult(valid=True)

        if not self.blocks:
            return result

        # Check first block links to genesis
        if self.blocks[0].previous_hash != self.genesis_hash:
            result.add_error(
                self.blocks[0].block_id,
                "First block does not link to genesis hash"
            )

        # Check each block
        for i, block in enumerate(self.blocks):
            result.checked_blocks += 1

            # Verify block hash
            expected_hash = self.compute_hash(
                self._block_hash_content(
                    block.block_id,
                    block.timestamp,
                    block.data_hash,
                    block.previous_hash,
                )
            )

            if block.block_hash != expected_hash:
                result.add_error(
                    block.block_id,
                    f"Block hash mismatch: expected {expected_hash[:16]}..., got {block.block_hash[:16]}..."
                )

            # Verify chain linkage
            if i > 0:
                if block.previous_hash != self.blocks[i - 1].block_hash:
                    result.add_error(
                        block.block_id,
                        "Chain linkage broken: previous_hash does not match"
                    )

        return result

    @staticmethod
    def _block_hash_content(
        block_id: str,
        timestamp: datetime,
        data_hash: str,
        previous_hash: str,
    ) -> str:
        return json.dumps(
            {
                "block_id": block_id,
                "timestamp": timestamp.isoformat(),
                "data_hash": data_hash,
                "previous_hash": previous_hash,
            },
            sort_keys=True,
            separators=(",", ":"),
        )

    def get_latest_hash(self) -> str:
        """Get the hash of the latest block."""
        if self.blocks:
            return self.blocks[-1].block_hash
        return self.genesis_hash

    def get_block(self, block_id: str) -> Optional[ChainBlock]:
        """Get a block by ID."""
        for block in self.blocks:
            if block.block_id == block_id:
                return block
        return None

    def get_block_at_index(self, index: int) -> Optional[ChainBlock]:
        """Get a block by index."""
        if 0 <= index < len(self.blocks):
            return self.blocks[index]
        return None

    @property
    def length(self) -> int:
        """Get chain length."""
        return len(self.blocks)

    def to_dict(self) -> Dict[str, Any]:
        """Convert chain to dictionary."""
        return {
            "algorithm": self.algorithm.value,
            "genesis_hash": self.genesis_hash,
            "blocks": [b.to_dict() for b in self.blocks],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChainHash':
        """Create chain from dictionary."""
        algorithm = HashAlgorithm(data.get("algorithm", "sha256"))
        chain = cls(algorithm=algorithm, genesis_hash=data.get("genesis_hash"))

        for block_data in data.get("blocks", []):
            block = ChainBlock(
                block_id=block_data["block_id"],
                timestamp=datetime.fromisoformat(block_data["timestamp"]),
                data_hash=block_data["data_hash"],
                previous_hash=block_data["previous_hash"],
                block_hash=block_data["block_hash"],
                nonce=block_data.get("nonce", 0),
            )
            chain.blocks.append(block)
            chain._block_counter = max(chain._block_counter, len(chain.blocks))

        return chain


def verify_chain(chain: ChainHash) -> ChainIntegrityResult:
    """Convenience function to verify a chain."""
    return chain.verify()


def create_chain_hash(
    algorithm: HashAlgorithm = HashAlgorithm.SHA256
) -> ChainHash:
    """Create a new chain hash."""
    return ChainHash(algorithm=algorithm)


def compute_hash(data: Any, algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> str:
    """Compute hash of arbitrary data."""
    if algorithm == HashAlgorithm.SHA256:
        hasher = hashlib.sha256()
    elif algorithm == HashAlgorithm.SHA384:
        hasher = hashlib.sha384()
    elif algorithm == HashAlgorithm.SHA512:
        hasher = hashlib.sha512()
    elif algorithm == HashAlgorithm.SHA3_256:
        hasher = hashlib.sha3_256()
    elif algorithm == HashAlgorithm.SHA3_512:
        hasher = hashlib.sha3_512()
    else:
        hasher = hashlib.sha256()

    if isinstance(data, dict):
        data_str = json.dumps(data, sort_keys=True, default=str)
    elif isinstance(data, (list, tuple)):
        data_str = json.dumps(list(data), sort_keys=True, default=str)
    elif isinstance(data, bytes):
        hasher.update(data)
        return hasher.hexdigest()
    else:
        data_str = str(data)

    hasher.update(data_str.encode())
    return hasher.hexdigest()


def compute_merkle_root(hashes: List[str], algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> str:
    """Compute Merkle root of a list of hashes."""
    if not hashes:
        return ""

    if len(hashes) == 1:
        return hashes[0]

    # Create hasher function
    def hash_pair(h1: str, h2: str) -> str:
        hasher = hashlib.new(algorithm.value)
        hasher.update((h1 + h2).encode())
        return hasher.hexdigest()

    # Build tree
    current_level = hashes[:]
    while len(current_level) > 1:
        next_level = []
        for i in range(0, len(current_level), 2):
            if i + 1 < len(current_level):
                combined = hash_pair(current_level[i], current_level[i + 1])
            else:
                # Odd number: duplicate last hash
                combined = hash_pair(current_level[i], current_level[i])
            next_level.append(combined)
        current_level = next_level

    return current_level[0]


def verify_chain_integrity(chain: ChainHash) -> ChainIntegrityResult:
    """Verify the integrity of a chain hash."""
    return chain.verify()
