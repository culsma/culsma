"""
BPL Audit Trail - Core audit trail functionality.

Provides:
- AuditEntry for individual audit records
- AuditTrail for complete protocol audit trails
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import hashlib
import json
import uuid


class AuditEventType(Enum):
    """Types of audit events."""
    # Protocol lifecycle
    PROTOCOL_CREATED = auto()
    PROTOCOL_STARTED = auto()
    PROTOCOL_COMPLETED = auto()
    PROTOCOL_ABORTED = auto()
    PROTOCOL_PAUSED = auto()
    PROTOCOL_RESUMED = auto()

    # Step execution
    STEP_STARTED = auto()
    STEP_COMPLETED = auto()
    STEP_FAILED = auto()
    STEP_SKIPPED = auto()
    STEP_RETRIED = auto()

    # Data events
    DATA_RECORDED = auto()
    DATA_MODIFIED = auto()
    DATA_DELETED = auto()

    # Signature events
    SIGNATURE_REQUESTED = auto()
    SIGNATURE_APPLIED = auto()
    SIGNATURE_REJECTED = auto()
    SIGNATURE_REVOKED = auto()

    # Error events
    ERROR_OCCURRED = auto()
    ERROR_RECOVERED = auto()
    ERROR_ESCALATED = auto()

    # User actions
    USER_LOGIN = auto()
    USER_LOGOUT = auto()
    USER_ACTION = auto()

    # System events
    SYSTEM_CHECKPOINT = auto()
    SYSTEM_BACKUP = auto()
    SYSTEM_RESTORE = auto()

    # Amendment events
    AMENDMENT_REQUESTED = auto()
    AMENDMENT_APPROVED = auto()
    AMENDMENT_REJECTED = auto()
    AMENDMENT_APPLIED = auto()

    # Compliance events
    COMPLIANCE_CHECK = auto()
    COMPLIANCE_VIOLATION = auto()

    # Custom events
    CUSTOM = auto()


@dataclass
class AuditEntry:
    """A single audit trail entry."""
    entry_id: str
    event_type: AuditEventType
    timestamp: datetime
    description: str

    # Context
    protocol_id: Optional[str] = None
    step_id: Optional[str] = None
    user_id: Optional[str] = None
    user_name: Optional[str] = None

    # Event data
    data: Dict[str, Any] = field(default_factory=dict)

    # Integrity
    previous_hash: str = ""
    entry_hash: str = ""

    # Status
    severity: str = "INFO"  # INFO, WARNING, ERROR, CRITICAL
    category: str = "general"

    def compute_hash(self, algorithm: str = "sha256") -> str:
        """Compute hash for this entry."""
        content = json.dumps(
            {
                "entry_id": self.entry_id,
                "event_type": self.event_type.name,
                "timestamp": self.timestamp.isoformat(),
                "description": self.description,
                "protocol_id": self.protocol_id,
                "step_id": self.step_id,
                "user_id": self.user_id,
                "data": self.data,
                "previous_hash": self.previous_hash,
            },
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )

        if algorithm == "sha256":
            return hashlib.sha256(content.encode()).hexdigest()
        elif algorithm == "sha512":
            return hashlib.sha512(content.encode()).hexdigest()
        else:
            return hashlib.sha256(content.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "entry_id": self.entry_id,
            "event_type": self.event_type.name,
            "timestamp": self.timestamp.isoformat(),
            "description": self.description,
            "protocol_id": self.protocol_id,
            "step_id": self.step_id,
            "user_id": self.user_id,
            "user_name": self.user_name,
            "data": self.data,
            "previous_hash": self.previous_hash,
            "entry_hash": self.entry_hash,
            "severity": self.severity,
            "category": self.category,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AuditEntry':
        """Create from dictionary."""
        return cls(
            entry_id=data["entry_id"],
            event_type=AuditEventType[data["event_type"]],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            description=data["description"],
            protocol_id=data.get("protocol_id"),
            step_id=data.get("step_id"),
            user_id=data.get("user_id"),
            user_name=data.get("user_name"),
            data=data.get("data", {}),
            previous_hash=data.get("previous_hash", ""),
            entry_hash=data.get("entry_hash", ""),
            severity=data.get("severity", "INFO"),
            category=data.get("category", "general"),
        )


@dataclass
class AuditTrail:
    """Complete audit trail for a protocol execution."""
    trail_id: str
    protocol_id: str
    protocol_name: str

    # Entries
    entries: List[AuditEntry] = field(default_factory=list)

    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    created_by: Optional[str] = None
    closed_at: Optional[datetime] = None

    # Hash chain settings
    hash_algorithm: str = "sha256"
    genesis_hash: str = "0" * 64

    # Hooks
    _entry_hooks: List[Callable[[AuditEntry], None]] = field(default_factory=list)

    def add_entry(
        self,
        event_type: AuditEventType,
        description: str,
        step_id: Optional[str] = None,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        data: Optional[Dict] = None,
        severity: str = "INFO",
        category: str = "general",
    ) -> AuditEntry:
        """Add a new audit entry."""
        # Get previous hash
        if self.entries:
            previous_hash = self.entries[-1].entry_hash
        else:
            previous_hash = self.genesis_hash

        # Create entry
        entry = AuditEntry(
            entry_id=str(uuid.uuid4())[:8],
            event_type=event_type,
            timestamp=datetime.now(),
            description=description,
            protocol_id=self.protocol_id,
            step_id=step_id,
            user_id=user_id,
            user_name=user_name,
            data=data or {},
            previous_hash=previous_hash,
            severity=severity,
            category=category,
        )

        # Compute hash
        entry.entry_hash = entry.compute_hash(self.hash_algorithm)

        # Add to trail
        self.entries.append(entry)

        # Invoke hooks
        for hook in self._entry_hooks:
            hook(entry)

        return entry

    def log_protocol_start(
        self,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        data: Optional[Dict] = None
    ) -> AuditEntry:
        """Log protocol start event."""
        return self.add_entry(
            AuditEventType.PROTOCOL_STARTED,
            f"Protocol '{self.protocol_name}' started",
            user_id=user_id,
            user_name=user_name,
            data=data,
            category="lifecycle"
        )

    def log_protocol_completed(
        self,
        user_id: Optional[str] = None,
        user_name: Optional[str] = None,
        data: Optional[Dict] = None
    ) -> AuditEntry:
        """Log protocol completion event."""
        return self.add_entry(
            AuditEventType.PROTOCOL_COMPLETED,
            f"Protocol '{self.protocol_name}' completed",
            user_id=user_id,
            user_name=user_name,
            data=data,
            category="lifecycle"
        )

    def log_step_started(
        self,
        step_id: str,
        step_name: str,
        user_id: Optional[str] = None
    ) -> AuditEntry:
        """Log step start event."""
        return self.add_entry(
            AuditEventType.STEP_STARTED,
            f"Step started: {step_name}",
            step_id=step_id,
            user_id=user_id,
            category="execution"
        )

    def log_step_completed(
        self,
        step_id: str,
        step_name: str,
        user_id: Optional[str] = None,
        data: Optional[Dict] = None
    ) -> AuditEntry:
        """Log step completion event."""
        return self.add_entry(
            AuditEventType.STEP_COMPLETED,
            f"Step completed: {step_name}",
            step_id=step_id,
            user_id=user_id,
            data=data,
            category="execution"
        )

    def log_step_failed(
        self,
        step_id: str,
        step_name: str,
        error: str,
        user_id: Optional[str] = None
    ) -> AuditEntry:
        """Log step failure event."""
        return self.add_entry(
            AuditEventType.STEP_FAILED,
            f"Step failed: {step_name} - {error}",
            step_id=step_id,
            user_id=user_id,
            data={"error": error},
            severity="ERROR",
            category="execution"
        )

    def log_data_recorded(
        self,
        field_name: str,
        value: Any,
        step_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> AuditEntry:
        """Log data recording event."""
        return self.add_entry(
            AuditEventType.DATA_RECORDED,
            f"Data recorded: {field_name} = {value}",
            step_id=step_id,
            user_id=user_id,
            data={"field": field_name, "value": value},
            category="data"
        )

    def log_signature_applied(
        self,
        signature_type: str,
        signer_id: str,
        signer_name: str,
        step_id: Optional[str] = None
    ) -> AuditEntry:
        """Log signature event."""
        return self.add_entry(
            AuditEventType.SIGNATURE_APPLIED,
            f"Signature applied by {signer_name} ({signature_type})",
            step_id=step_id,
            user_id=signer_id,
            user_name=signer_name,
            data={"signature_type": signature_type},
            category="signature"
        )

    def log_error(
        self,
        error_type: str,
        error_message: str,
        step_id: Optional[str] = None,
        user_id: Optional[str] = None,
        data: Optional[Dict] = None
    ) -> AuditEntry:
        """Log error event."""
        return self.add_entry(
            AuditEventType.ERROR_OCCURRED,
            f"Error: {error_type} - {error_message}",
            step_id=step_id,
            user_id=user_id,
            data={"error_type": error_type, "message": error_message, **(data or {})},
            severity="ERROR",
            category="error"
        )

    def verify_chain(self) -> bool:
        """Verify the integrity of the hash chain."""
        if not self.entries:
            return True

        # Check first entry
        if self.entries[0].previous_hash != self.genesis_hash:
            return False

        # Check chain
        for i, entry in enumerate(self.entries):
            # Verify entry's own hash
            computed = entry.compute_hash(self.hash_algorithm)
            if computed != entry.entry_hash:
                return False

            # Verify chain linkage
            if i > 0:
                if entry.previous_hash != self.entries[i - 1].entry_hash:
                    return False

        return True

    def add_entry_hook(self, hook: Callable[[AuditEntry], None]) -> None:
        """Add a hook to be called for each new entry."""
        self._entry_hooks.append(hook)

    def close(self) -> None:
        """Close the audit trail."""
        self.closed_at = datetime.now()
        self.add_entry(
            AuditEventType.PROTOCOL_COMPLETED,
            f"Audit trail closed for protocol '{self.protocol_name}'",
            category="lifecycle"
        )

    def get_entries_by_type(self, event_type: AuditEventType) -> List[AuditEntry]:
        """Get all entries of a specific type."""
        return [e for e in self.entries if e.event_type == event_type]

    def get_entries_by_step(self, step_id: str) -> List[AuditEntry]:
        """Get all entries for a specific step."""
        return [e for e in self.entries if e.step_id == step_id]

    def get_entries_by_user(self, user_id: str) -> List[AuditEntry]:
        """Get all entries by a specific user."""
        return [e for e in self.entries if e.user_id == user_id]

    def get_errors(self) -> List[AuditEntry]:
        """Get all error entries."""
        return [e for e in self.entries if e.severity in ("ERROR", "CRITICAL")]

    def summary(self) -> Dict[str, Any]:
        """Get audit trail summary."""
        type_counts = {}
        for entry in self.entries:
            type_name = entry.event_type.name
            type_counts[type_name] = type_counts.get(type_name, 0) + 1

        return {
            "trail_id": self.trail_id,
            "protocol_id": self.protocol_id,
            "protocol_name": self.protocol_name,
            "total_entries": len(self.entries),
            "event_types": type_counts,
            "error_count": len(self.get_errors()),
            "chain_valid": self.verify_chain(),
            "created_at": self.created_at.isoformat(),
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert entire trail to dictionary."""
        return {
            "trail_id": self.trail_id,
            "protocol_id": self.protocol_id,
            "protocol_name": self.protocol_name,
            "hash_algorithm": self.hash_algorithm,
            "genesis_hash": self.genesis_hash,
            "created_at": self.created_at.isoformat(),
            "created_by": self.created_by,
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
            "entries": [e.to_dict() for e in self.entries],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AuditTrail':
        """Create from dictionary."""
        trail = cls(
            trail_id=data["trail_id"],
            protocol_id=data["protocol_id"],
            protocol_name=data["protocol_name"],
            hash_algorithm=data.get("hash_algorithm", "sha256"),
            genesis_hash=data.get("genesis_hash", "0" * 64),
            created_at=datetime.fromisoformat(data["created_at"]),
            created_by=data.get("created_by"),
        )

        if data.get("closed_at"):
            trail.closed_at = datetime.fromisoformat(data["closed_at"])

        for entry_data in data.get("entries", []):
            entry = AuditEntry.from_dict(entry_data)
            trail.entries.append(entry)

        return trail


def create_audit_trail(
    protocol_id: str,
    protocol_name: str,
    created_by: Optional[str] = None
) -> AuditTrail:
    """Create a new audit trail."""
    trail = AuditTrail(
        trail_id=str(uuid.uuid4())[:8],
        protocol_id=protocol_id,
        protocol_name=protocol_name,
        created_by=created_by,
    )

    # Add creation entry
    trail.add_entry(
        AuditEventType.PROTOCOL_CREATED,
        f"Audit trail created for protocol '{protocol_name}'",
        user_id=created_by,
        category="lifecycle"
    )

    return trail
