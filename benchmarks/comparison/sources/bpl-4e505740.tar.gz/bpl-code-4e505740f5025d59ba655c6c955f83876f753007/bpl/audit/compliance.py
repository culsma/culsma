"""
BPL Compliance - Regulatory compliance checking.

Provides:
- ComplianceRequirement definitions
- ComplianceChecker for validating protocols
- ComplianceReport generation
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime

from .audit_trail import AuditTrail, AuditEventType


class ComplianceLevel(Enum):
    """Compliance level/strictness."""
    BASIC = auto()           # Basic research use
    GLP = auto()             # Good Laboratory Practice
    GMP = auto()             # Good Manufacturing Practice
    GCP = auto()             # Good Clinical Practice
    FDA_21_CFR_11 = auto()   # FDA 21 CFR Part 11
    ISO_17025 = auto()       # ISO 17025 Testing labs
    CAP = auto()             # College of American Pathologists


class RequirementCategory(Enum):
    """Categories of compliance requirements."""
    DOCUMENTATION = auto()
    SIGNATURE = auto()
    AUDIT_TRAIL = auto()
    DATA_INTEGRITY = auto()
    ACCESS_CONTROL = auto()
    VALIDATION = auto()
    TRAINING = auto()
    CHANGE_CONTROL = auto()


class RequirementStatus(Enum):
    """Status of a compliance requirement check."""
    PASSED = auto()
    FAILED = auto()
    WARNING = auto()
    NOT_APPLICABLE = auto()
    NOT_CHECKED = auto()


@dataclass
class ComplianceRequirement:
    """A single compliance requirement."""
    requirement_id: str
    name: str
    description: str
    category: RequirementCategory
    levels: List[ComplianceLevel]  # Which levels require this

    # Checking
    check_function: Optional[Callable[[AuditTrail], tuple[RequirementStatus, str]]] = None
    is_critical: bool = False

    # Reference
    reference: Optional[str] = None  # e.g., "21 CFR 11.10(a)"

    def check(self, trail: AuditTrail) -> tuple[RequirementStatus, str]:
        """Check this requirement against an audit trail."""
        if self.check_function:
            return self.check_function(trail)
        return RequirementStatus.NOT_CHECKED, "No check function defined"


@dataclass
class RequirementResult:
    """Result of checking a single requirement."""
    requirement_id: str
    requirement_name: str
    status: RequirementStatus
    message: str
    category: RequirementCategory
    is_critical: bool = False
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceReport:
    """Complete compliance check report."""
    report_id: str
    protocol_id: str
    compliance_level: ComplianceLevel

    # Results
    results: List[RequirementResult] = field(default_factory=list)

    # Summary
    total_requirements: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    not_applicable: int = 0

    # Timestamps
    checked_at: datetime = field(default_factory=datetime.now)
    checked_by: Optional[str] = None

    # Overall status
    overall_compliant: bool = False

    def add_result(self, result: RequirementResult) -> None:
        """Add a check result."""
        self.results.append(result)
        self.total_requirements += 1

        if result.status == RequirementStatus.PASSED:
            self.passed += 1
        elif result.status == RequirementStatus.FAILED:
            self.failed += 1
            if result.is_critical:
                self.overall_compliant = False
        elif result.status == RequirementStatus.WARNING:
            self.warnings += 1
        elif result.status == RequirementStatus.NOT_APPLICABLE:
            self.not_applicable += 1

    def finalize(self) -> None:
        """Finalize the report and determine overall compliance."""
        # Check if any critical failures
        critical_failures = [
            r for r in self.results
            if r.is_critical and r.status == RequirementStatus.FAILED
        ]

        # Overall compliant if no critical failures
        self.overall_compliant = len(critical_failures) == 0

    @property
    def compliance_percentage(self) -> float:
        """Calculate compliance percentage."""
        applicable = self.total_requirements - self.not_applicable
        if applicable == 0:
            return 100.0
        return (self.passed / applicable) * 100

    def get_failures(self) -> List[RequirementResult]:
        """Get all failed requirements."""
        return [r for r in self.results if r.status == RequirementStatus.FAILED]

    def get_warnings(self) -> List[RequirementResult]:
        """Get all warning requirements."""
        return [r for r in self.results if r.status == RequirementStatus.WARNING]

    def summary(self) -> Dict[str, Any]:
        """Get report summary."""
        return {
            "report_id": self.report_id,
            "protocol_id": self.protocol_id,
            "compliance_level": self.compliance_level.name,
            "overall_compliant": self.overall_compliant,
            "compliance_percentage": f"{self.compliance_percentage:.1f}%",
            "total_requirements": self.total_requirements,
            "passed": self.passed,
            "failed": self.failed,
            "warnings": self.warnings,
            "not_applicable": self.not_applicable,
            "checked_at": self.checked_at.isoformat(),
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            **self.summary(),
            "results": [
                {
                    "requirement_id": r.requirement_id,
                    "requirement_name": r.requirement_name,
                    "status": r.status.name,
                    "message": r.message,
                    "category": r.category.name,
                    "is_critical": r.is_critical,
                }
                for r in self.results
            ]
        }


class ComplianceChecker:
    """Checks protocols against compliance requirements."""

    def __init__(self, level: ComplianceLevel = ComplianceLevel.BASIC):
        self.level = level
        self.requirements: List[ComplianceRequirement] = []
        self._setup_default_requirements()

    def _setup_default_requirements(self) -> None:
        """Set up default compliance requirements."""
        # Audit trail requirements
        self.add_requirement(ComplianceRequirement(
            requirement_id="AT-001",
            name="Audit Trail Present",
            description="Protocol has an audit trail with entries",
            category=RequirementCategory.AUDIT_TRAIL,
            levels=[ComplianceLevel.BASIC, ComplianceLevel.GLP, ComplianceLevel.GMP,
                   ComplianceLevel.FDA_21_CFR_11],
            check_function=self._check_audit_trail_present,
            is_critical=True,
        ))

        self.add_requirement(ComplianceRequirement(
            requirement_id="AT-002",
            name="Chain Integrity",
            description="Audit trail hash chain is valid",
            category=RequirementCategory.DATA_INTEGRITY,
            levels=[ComplianceLevel.GLP, ComplianceLevel.GMP, ComplianceLevel.FDA_21_CFR_11],
            check_function=self._check_chain_integrity,
            is_critical=True,
        ))

        self.add_requirement(ComplianceRequirement(
            requirement_id="AT-003",
            name="Timestamp Ordering",
            description="All entries have valid, sequential timestamps",
            category=RequirementCategory.AUDIT_TRAIL,
            levels=[ComplianceLevel.GLP, ComplianceLevel.GMP, ComplianceLevel.FDA_21_CFR_11],
            check_function=self._check_timestamp_ordering,
            is_critical=False,
        ))

        # Signature requirements
        self.add_requirement(ComplianceRequirement(
            requirement_id="SIG-001",
            name="Protocol Signatures",
            description="Protocol has required signatures",
            category=RequirementCategory.SIGNATURE,
            levels=[ComplianceLevel.GMP, ComplianceLevel.FDA_21_CFR_11],
            check_function=self._check_signatures_present,
            is_critical=True,
        ))

        # Documentation requirements
        self.add_requirement(ComplianceRequirement(
            requirement_id="DOC-001",
            name="Protocol Start/End Documented",
            description="Protocol start and completion are documented",
            category=RequirementCategory.DOCUMENTATION,
            levels=[ComplianceLevel.BASIC, ComplianceLevel.GLP, ComplianceLevel.GMP],
            check_function=self._check_protocol_lifecycle,
            is_critical=False,
        ))

        self.add_requirement(ComplianceRequirement(
            requirement_id="DOC-002",
            name="User Attribution",
            description="Actions are attributed to users",
            category=RequirementCategory.DOCUMENTATION,
            levels=[ComplianceLevel.GLP, ComplianceLevel.GMP, ComplianceLevel.FDA_21_CFR_11],
            check_function=self._check_user_attribution,
            is_critical=False,
        ))

        # Data integrity requirements
        self.add_requirement(ComplianceRequirement(
            requirement_id="DI-001",
            name="Data Recording",
            description="Data entries are recorded in audit trail",
            category=RequirementCategory.DATA_INTEGRITY,
            levels=[ComplianceLevel.GLP, ComplianceLevel.GMP],
            check_function=self._check_data_recording,
            is_critical=False,
        ))

    def add_requirement(self, requirement: ComplianceRequirement) -> None:
        """Add a compliance requirement."""
        self.requirements.append(requirement)

    def check(
        self,
        trail: AuditTrail,
        checked_by: Optional[str] = None
    ) -> ComplianceReport:
        """Check an audit trail against requirements."""
        import uuid as uuid_module

        report = ComplianceReport(
            report_id=str(uuid_module.uuid4())[:8],
            protocol_id=trail.protocol_id,
            compliance_level=self.level,
            checked_by=checked_by,
        )

        # Check each requirement applicable to this level
        for requirement in self.requirements:
            if self.level in requirement.levels:
                status, message = requirement.check(trail)

                result = RequirementResult(
                    requirement_id=requirement.requirement_id,
                    requirement_name=requirement.name,
                    status=status,
                    message=message,
                    category=requirement.category,
                    is_critical=requirement.is_critical,
                )
                report.add_result(result)

        report.finalize()
        return report

    # Check functions
    def _check_audit_trail_present(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check that audit trail has entries."""
        if len(trail.entries) > 0:
            return RequirementStatus.PASSED, f"Audit trail has {len(trail.entries)} entries"
        return RequirementStatus.FAILED, "Audit trail is empty"

    def _check_chain_integrity(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check hash chain integrity."""
        if trail.verify_chain():
            return RequirementStatus.PASSED, "Hash chain integrity verified"
        return RequirementStatus.FAILED, "Hash chain integrity verification failed"

    def _check_timestamp_ordering(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check timestamp ordering."""
        if len(trail.entries) <= 1:
            return RequirementStatus.PASSED, "Timestamp ordering verified (single entry)"

        for i in range(1, len(trail.entries)):
            if trail.entries[i].timestamp < trail.entries[i - 1].timestamp:
                return RequirementStatus.FAILED, f"Timestamp out of order at entry {i}"

        return RequirementStatus.PASSED, "All timestamps in chronological order"

    def _check_signatures_present(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check for signature events."""
        sig_events = trail.get_entries_by_type(AuditEventType.SIGNATURE_APPLIED)
        if len(sig_events) > 0:
            return RequirementStatus.PASSED, f"Found {len(sig_events)} signature(s)"
        return RequirementStatus.WARNING, "No signatures found in audit trail"

    def _check_protocol_lifecycle(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check protocol start/end documentation."""
        start_events = trail.get_entries_by_type(AuditEventType.PROTOCOL_STARTED)
        complete_events = trail.get_entries_by_type(AuditEventType.PROTOCOL_COMPLETED)

        if len(start_events) == 0:
            return RequirementStatus.WARNING, "Protocol start not documented"

        if trail.closed_at and len(complete_events) == 0:
            return RequirementStatus.WARNING, "Protocol completion not documented"

        return RequirementStatus.PASSED, "Protocol lifecycle documented"

    def _check_user_attribution(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check user attribution."""
        attributed = sum(1 for e in trail.entries if e.user_id is not None)
        total = len(trail.entries)

        if total == 0:
            return RequirementStatus.NOT_APPLICABLE, "No entries to check"

        ratio = attributed / total
        if ratio >= 0.9:
            return RequirementStatus.PASSED, f"{attributed}/{total} entries have user attribution"
        elif ratio >= 0.5:
            return RequirementStatus.WARNING, f"Only {attributed}/{total} entries have user attribution"
        return RequirementStatus.FAILED, f"Only {attributed}/{total} entries have user attribution"

    def _check_data_recording(
        self,
        trail: AuditTrail
    ) -> tuple[RequirementStatus, str]:
        """Check data recording."""
        data_events = trail.get_entries_by_type(AuditEventType.DATA_RECORDED)
        return RequirementStatus.PASSED, f"Found {len(data_events)} data recording event(s)"


def check_compliance(
    trail: AuditTrail,
    level: ComplianceLevel = ComplianceLevel.BASIC,
    checked_by: Optional[str] = None
) -> ComplianceReport:
    """Convenience function to check compliance."""
    checker = ComplianceChecker(level)
    return checker.check(trail, checked_by)


def get_requirements_for_level(level: ComplianceLevel) -> List[str]:
    """Get list of requirement IDs for a compliance level."""
    checker = ComplianceChecker(level)
    return [
        req.requirement_id
        for req in checker.requirements
        if level in req.levels
    ]
