"""
BPL Audit Export - Export audit trails to various formats.

Provides:
- AuditExporter for generating audit reports
- Multiple export formats (JSON, PDF, CSV)
"""

from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum, auto
from datetime import datetime
import json
import csv
import io

from .audit_trail import AuditTrail
from .compliance import ComplianceReport


class ExportFormat(Enum):
    """Export format options."""
    JSON = auto()
    CSV = auto()
    HTML = auto()
    MARKDOWN = auto()
    TEXT = auto()


@dataclass
class ExportOptions:
    """Options for export."""
    format: ExportFormat = ExportFormat.JSON
    include_metadata: bool = True
    include_summary: bool = True
    include_chain_hashes: bool = True
    pretty_print: bool = True
    timestamp_format: str = "%Y-%m-%d %H:%M:%S"


@dataclass
class ExportResult:
    """Result of an export operation."""
    success: bool
    content: str = ""
    format: ExportFormat = ExportFormat.JSON
    exported_entries: int = 0
    errors: List[str] = field(default_factory=list)
    exported_at: datetime = field(default_factory=datetime.now)


class AuditExporter:
    """Exports audit trails to various formats."""

    def __init__(self, options: Optional[ExportOptions] = None):
        self.options = options or ExportOptions()

    def export(self, trail: AuditTrail) -> ExportResult:
        """Export an audit trail."""
        exporters = {
            ExportFormat.JSON: self._export_json,
            ExportFormat.CSV: self._export_csv,
            ExportFormat.HTML: self._export_html,
            ExportFormat.MARKDOWN: self._export_markdown,
            ExportFormat.TEXT: self._export_text,
        }

        exporter = exporters.get(self.options.format, self._export_json)
        return exporter(trail)

    def _export_json(self, trail: AuditTrail) -> ExportResult:
        """Export to JSON format."""
        result = ExportResult(success=True, format=ExportFormat.JSON)

        try:
            data = trail.to_dict()

            if not self.options.include_chain_hashes:
                for entry in data.get("entries", []):
                    entry.pop("previous_hash", None)
                    entry.pop("entry_hash", None)

            if self.options.include_summary:
                data["summary"] = trail.summary()

            if self.options.pretty_print:
                result.content = json.dumps(data, indent=2, default=str)
            else:
                result.content = json.dumps(data, default=str)

            result.exported_entries = len(trail.entries)

        except Exception as e:
            result.success = False
            result.errors.append(str(e))

        return result

    def _export_csv(self, trail: AuditTrail) -> ExportResult:
        """Export to CSV format."""
        result = ExportResult(success=True, format=ExportFormat.CSV)

        try:
            output = io.StringIO()
            writer = csv.writer(output)

            # Header
            headers = [
                "entry_id", "event_type", "timestamp", "description",
                "step_id", "user_id", "user_name", "severity", "category"
            ]
            if self.options.include_chain_hashes:
                headers.extend(["previous_hash", "entry_hash"])

            writer.writerow(headers)

            # Data rows
            for entry in trail.entries:
                row = [
                    entry.entry_id,
                    entry.event_type.name,
                    entry.timestamp.strftime(self.options.timestamp_format),
                    entry.description,
                    entry.step_id or "",
                    entry.user_id or "",
                    entry.user_name or "",
                    entry.severity,
                    entry.category,
                ]
                if self.options.include_chain_hashes:
                    row.extend([entry.previous_hash, entry.entry_hash])

                writer.writerow(row)

            result.content = output.getvalue()
            result.exported_entries = len(trail.entries)

        except Exception as e:
            result.success = False
            result.errors.append(str(e))

        return result

    def _export_html(self, trail: AuditTrail) -> ExportResult:
        """Export to HTML format."""
        result = ExportResult(success=True, format=ExportFormat.HTML)

        try:
            lines = [
                "<!DOCTYPE html>",
                "<html>",
                "<head>",
                f"<title>Audit Trail - {trail.protocol_name}</title>",
                "<style>",
                "body { font-family: Arial, sans-serif; margin: 20px; }",
                "table { border-collapse: collapse; width: 100%; }",
                "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }",
                "th { background-color: #4CAF50; color: white; }",
                "tr:nth-child(even) { background-color: #f2f2f2; }",
                ".error { color: red; }",
                ".warning { color: orange; }",
                ".summary { background-color: #f9f9f9; padding: 15px; margin-bottom: 20px; }",
                "</style>",
                "</head>",
                "<body>",
            ]

            # Header
            lines.append(f"<h1>Audit Trail: {trail.protocol_name}</h1>")

            # Summary
            if self.options.include_summary:
                summary = trail.summary()
                lines.append("<div class='summary'>")
                lines.append("<h2>Summary</h2>")
                lines.append(f"<p><strong>Protocol ID:</strong> {trail.protocol_id}</p>")
                lines.append(f"<p><strong>Total Entries:</strong> {summary['total_entries']}</p>")
                lines.append(f"<p><strong>Errors:</strong> {summary['error_count']}</p>")
                lines.append(f"<p><strong>Chain Valid:</strong> {'Yes' if summary['chain_valid'] else 'No'}</p>")
                lines.append("</div>")

            # Table
            lines.append("<table>")
            lines.append("<tr>")
            lines.append("<th>Timestamp</th>")
            lines.append("<th>Event Type</th>")
            lines.append("<th>Description</th>")
            lines.append("<th>User</th>")
            lines.append("<th>Step</th>")
            lines.append("</tr>")

            for entry in trail.entries:
                severity_class = ""
                if entry.severity == "ERROR":
                    severity_class = " class='error'"
                elif entry.severity == "WARNING":
                    severity_class = " class='warning'"

                lines.append(f"<tr{severity_class}>")
                lines.append(f"<td>{entry.timestamp.strftime(self.options.timestamp_format)}</td>")
                lines.append(f"<td>{entry.event_type.name}</td>")
                lines.append(f"<td>{entry.description}</td>")
                lines.append(f"<td>{entry.user_name or entry.user_id or '-'}</td>")
                lines.append(f"<td>{entry.step_id or '-'}</td>")
                lines.append("</tr>")

            lines.append("</table>")

            # Footer
            lines.append(f"<p><em>Exported at: {datetime.now().isoformat()}</em></p>")
            lines.append("</body>")
            lines.append("</html>")

            result.content = "\n".join(lines)
            result.exported_entries = len(trail.entries)

        except Exception as e:
            result.success = False
            result.errors.append(str(e))

        return result

    def _export_markdown(self, trail: AuditTrail) -> ExportResult:
        """Export to Markdown format."""
        result = ExportResult(success=True, format=ExportFormat.MARKDOWN)

        try:
            lines = [f"# Audit Trail: {trail.protocol_name}", ""]

            # Summary
            if self.options.include_summary:
                summary = trail.summary()
                lines.append("## Summary")
                lines.append(f"- **Protocol ID:** {trail.protocol_id}")
                lines.append(f"- **Total Entries:** {summary['total_entries']}")
                lines.append(f"- **Errors:** {summary['error_count']}")
                lines.append(f"- **Chain Valid:** {'Yes' if summary['chain_valid'] else 'No'}")
                lines.append("")

            # Entries table
            lines.append("## Entries")
            lines.append("")
            lines.append("| Timestamp | Event Type | Description | User | Step |")
            lines.append("|-----------|------------|-------------|------|------|")

            for entry in trail.entries:
                timestamp = entry.timestamp.strftime(self.options.timestamp_format)
                user = entry.user_name or entry.user_id or "-"
                step = entry.step_id or "-"
                # Truncate long descriptions
                desc = entry.description[:50] + "..." if len(entry.description) > 50 else entry.description
                lines.append(f"| {timestamp} | {entry.event_type.name} | {desc} | {user} | {step} |")

            lines.append("")
            lines.append(f"*Exported at: {datetime.now().isoformat()}*")

            result.content = "\n".join(lines)
            result.exported_entries = len(trail.entries)

        except Exception as e:
            result.success = False
            result.errors.append(str(e))

        return result

    def _export_text(self, trail: AuditTrail) -> ExportResult:
        """Export to plain text format."""
        result = ExportResult(success=True, format=ExportFormat.TEXT)

        try:
            lines = [
                "=" * 60,
                f"AUDIT TRAIL: {trail.protocol_name}",
                "=" * 60,
                f"Protocol ID: {trail.protocol_id}",
                f"Created: {trail.created_at.isoformat()}",
                f"Entries: {len(trail.entries)}",
                f"Chain Valid: {trail.verify_chain()}",
                "=" * 60,
                "",
            ]

            for entry in trail.entries:
                lines.append("-" * 40)
                lines.append(f"[{entry.timestamp.strftime(self.options.timestamp_format)}]")
                lines.append(f"Event: {entry.event_type.name}")
                lines.append(f"Description: {entry.description}")
                if entry.user_name or entry.user_id:
                    lines.append(f"User: {entry.user_name or entry.user_id}")
                if entry.step_id:
                    lines.append(f"Step: {entry.step_id}")
                if entry.severity != "INFO":
                    lines.append(f"Severity: {entry.severity}")
                lines.append("")

            lines.append("=" * 60)
            lines.append(f"Exported at: {datetime.now().isoformat()}")

            result.content = "\n".join(lines)
            result.exported_entries = len(trail.entries)

        except Exception as e:
            result.success = False
            result.errors.append(str(e))

        return result


def export_audit_trail(
    trail: AuditTrail,
    format: ExportFormat = ExportFormat.JSON,
    options: Optional[ExportOptions] = None
) -> ExportResult:
    """Convenience function to export an audit trail."""
    if options is None:
        options = ExportOptions(format=format)
    else:
        options.format = format

    exporter = AuditExporter(options)
    return exporter.export(trail)


def export_to_file(
    trail: AuditTrail,
    file_path: str,
    format: ExportFormat = ExportFormat.JSON
) -> ExportResult:
    """Export audit trail to a file."""
    result = export_audit_trail(trail, format)

    if result.success:
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(result.content)
        except Exception as e:
            result.success = False
            result.errors.append(f"File write error: {e}")

    return result


def export_compliance_report(
    report: ComplianceReport,
    format: ExportFormat = ExportFormat.JSON
) -> str:
    """Export a compliance report."""
    if format == ExportFormat.JSON:
        return json.dumps(report.to_dict(), indent=2)

    elif format == ExportFormat.MARKDOWN:
        lines = [
            f"# Compliance Report: {report.protocol_id}",
            "",
            "## Summary",
            f"- **Compliance Level:** {report.compliance_level.name}",
            f"- **Overall Compliant:** {'Yes' if report.overall_compliant else 'No'}",
            f"- **Compliance Score:** {report.compliance_percentage:.1f}%",
            f"- **Passed:** {report.passed}",
            f"- **Failed:** {report.failed}",
            f"- **Warnings:** {report.warnings}",
            "",
            "## Results",
            "",
            "| Requirement | Status | Message |",
            "|-------------|--------|---------|",
        ]

        for r in report.results:
            status_icon = "✓" if r.status.name == "PASSED" else ("✗" if r.status.name == "FAILED" else "⚠")
            lines.append(f"| {r.requirement_name} | {status_icon} {r.status.name} | {r.message} |")

        return "\n".join(lines)

    elif format == ExportFormat.TEXT:
        lines = [
            "=" * 50,
            f"COMPLIANCE REPORT: {report.protocol_id}",
            "=" * 50,
            f"Level: {report.compliance_level.name}",
            f"Compliant: {report.overall_compliant}",
            f"Score: {report.compliance_percentage:.1f}%",
            "-" * 50,
        ]

        for r in report.results:
            lines.append(f"[{r.status.name}] {r.requirement_name}: {r.message}")

        return "\n".join(lines)

    return json.dumps(report.to_dict())
