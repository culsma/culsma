"""
BPL Amendments - Protocol amendment tracking.

Provides:
- Amendment types and records
- AmendmentManager for handling protocol changes
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from datetime import datetime
import uuid


class AmendmentType(Enum):
    """Types of amendments."""
    # Data amendments
    DATA_CORRECTION = auto()    # Correcting recorded data
    DATA_ADDITION = auto()      # Adding missing data
    DATA_DELETION = auto()      # Removing erroneous data

    # Step amendments
    STEP_MODIFICATION = auto()  # Modifying step parameters
    STEP_INSERTION = auto()     # Adding a step
    STEP_DELETION = auto()      # Removing a step
    STEP_REORDER = auto()       # Changing step order

    # Protocol amendments
    PROTOCOL_VERSION = auto()   # Version update
    PROTOCOL_PARAMETER = auto() # Parameter change
    PROTOCOL_DEVIATION = auto() # Planned deviation

    # Signature amendments
    SIGNATURE_ADDITION = auto()   # Adding signature
    SIGNATURE_REVOCATION = auto() # Revoking signature

    # General
    COMMENT = auto()            # Adding comment/note
    ATTACHMENT = auto()         # Adding attachment


class AmendmentStatus(Enum):
    """Status of an amendment."""
    DRAFT = auto()
    PENDING_REVIEW = auto()
    APPROVED = auto()
    REJECTED = auto()
    APPLIED = auto()
    SUPERSEDED = auto()


@dataclass
class AmendmentSignature:
    """Signature on an amendment."""
    signer_id: str
    signer_name: str
    signer_role: str
    signed_at: datetime
    signature_hash: str
    comment: Optional[str] = None


@dataclass
class Amendment:
    """A protocol amendment record."""
    amendment_id: str
    amendment_type: AmendmentType
    description: str

    # Context
    protocol_id: str
    step_id: Optional[str] = None
    field_id: Optional[str] = None

    # Change details
    original_value: Optional[Any] = None
    new_value: Optional[Any] = None
    reason: str = ""

    # Status
    status: AmendmentStatus = AmendmentStatus.DRAFT

    # Tracking
    created_at: datetime = field(default_factory=datetime.now)
    created_by: Optional[str] = None
    created_by_name: Optional[str] = None

    applied_at: Optional[datetime] = None
    applied_by: Optional[str] = None

    # Approvals
    required_approvers: int = 1
    signatures: List[AmendmentSignature] = field(default_factory=list)

    # Audit
    supersedes_id: Optional[str] = None  # ID of amendment this supersedes
    superseded_by_id: Optional[str] = None  # ID of amendment that superseded this

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def request_approval(self) -> None:
        """Request approval for the amendment."""
        if self.status == AmendmentStatus.DRAFT:
            self.status = AmendmentStatus.PENDING_REVIEW

    def approve(
        self,
        signer_id: str,
        signer_name: str,
        signer_role: str,
        comment: Optional[str] = None
    ) -> bool:
        """Add an approval signature."""
        if self.status not in (AmendmentStatus.PENDING_REVIEW, AmendmentStatus.DRAFT):
            return False

        # Check if already signed by this person
        for sig in self.signatures:
            if sig.signer_id == signer_id:
                return False

        signature = AmendmentSignature(
            signer_id=signer_id,
            signer_name=signer_name,
            signer_role=signer_role,
            signed_at=datetime.now(),
            signature_hash=self._compute_signature_hash(signer_id),
            comment=comment,
        )
        self.signatures.append(signature)

        # Check if fully approved
        if len(self.signatures) >= self.required_approvers:
            self.status = AmendmentStatus.APPROVED

        return True

    def reject(self, reason: str, rejector_id: str) -> None:
        """Reject the amendment."""
        self.status = AmendmentStatus.REJECTED
        self.metadata["rejection_reason"] = reason
        self.metadata["rejected_by"] = rejector_id
        self.metadata["rejected_at"] = datetime.now().isoformat()

    def apply(self, applied_by: str) -> None:
        """Mark the amendment as applied."""
        if self.status == AmendmentStatus.APPROVED:
            self.status = AmendmentStatus.APPLIED
            self.applied_at = datetime.now()
            self.applied_by = applied_by

    def supersede(self, new_amendment_id: str) -> None:
        """Mark this amendment as superseded."""
        self.status = AmendmentStatus.SUPERSEDED
        self.superseded_by_id = new_amendment_id

    def _compute_signature_hash(self, signer_id: str) -> str:
        """Compute hash for signature."""
        import hashlib
        content = f"{self.amendment_id}:{signer_id}:{datetime.now().isoformat()}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    @property
    def is_approved(self) -> bool:
        """Check if amendment is approved."""
        return self.status in (AmendmentStatus.APPROVED, AmendmentStatus.APPLIED)

    @property
    def is_pending(self) -> bool:
        """Check if amendment is pending approval."""
        return self.status in (AmendmentStatus.DRAFT, AmendmentStatus.PENDING_REVIEW)

    @property
    def approval_count(self) -> int:
        """Get number of approvals."""
        return len(self.signatures)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "amendment_id": self.amendment_id,
            "amendment_type": self.amendment_type.name,
            "description": self.description,
            "protocol_id": self.protocol_id,
            "step_id": self.step_id,
            "field_id": self.field_id,
            "original_value": self.original_value,
            "new_value": self.new_value,
            "reason": self.reason,
            "status": self.status.name,
            "created_at": self.created_at.isoformat(),
            "created_by": self.created_by,
            "applied_at": self.applied_at.isoformat() if self.applied_at else None,
            "signatures": [
                {
                    "signer_id": s.signer_id,
                    "signer_name": s.signer_name,
                    "signer_role": s.signer_role,
                    "signed_at": s.signed_at.isoformat(),
                }
                for s in self.signatures
            ],
        }


class AmendmentManager:
    """Manages amendments for a protocol."""

    def __init__(self, protocol_id: str):
        self.protocol_id = protocol_id
        self.amendments: Dict[str, Amendment] = {}
        self._amendment_hooks: List[Callable[[Amendment], None]] = []

    def create_amendment(
        self,
        amendment_type: AmendmentType,
        description: str,
        reason: str,
        created_by: Optional[str] = None,
        created_by_name: Optional[str] = None,
        step_id: Optional[str] = None,
        field_id: Optional[str] = None,
        original_value: Optional[Any] = None,
        new_value: Optional[Any] = None,
        required_approvers: int = 1,
    ) -> Amendment:
        """Create a new amendment."""
        amendment_id = str(uuid.uuid4())[:8]

        amendment = Amendment(
            amendment_id=amendment_id,
            amendment_type=amendment_type,
            description=description,
            protocol_id=self.protocol_id,
            step_id=step_id,
            field_id=field_id,
            original_value=original_value,
            new_value=new_value,
            reason=reason,
            created_by=created_by,
            created_by_name=created_by_name,
            required_approvers=required_approvers,
        )

        self.amendments[amendment_id] = amendment

        # Invoke hooks
        for hook in self._amendment_hooks:
            hook(amendment)

        return amendment

    def create_data_correction(
        self,
        field_id: str,
        original_value: Any,
        new_value: Any,
        reason: str,
        step_id: Optional[str] = None,
        created_by: Optional[str] = None
    ) -> Amendment:
        """Create a data correction amendment."""
        return self.create_amendment(
            AmendmentType.DATA_CORRECTION,
            f"Correct value for field '{field_id}'",
            reason=reason,
            step_id=step_id,
            field_id=field_id,
            original_value=original_value,
            new_value=new_value,
            created_by=created_by,
        )

    def create_deviation(
        self,
        description: str,
        reason: str,
        step_id: Optional[str] = None,
        created_by: Optional[str] = None
    ) -> Amendment:
        """Create a protocol deviation amendment."""
        return self.create_amendment(
            AmendmentType.PROTOCOL_DEVIATION,
            description,
            reason=reason,
            step_id=step_id,
            created_by=created_by,
        )

    def get_amendment(self, amendment_id: str) -> Optional[Amendment]:
        """Get an amendment by ID."""
        return self.amendments.get(amendment_id)

    def get_pending_amendments(self) -> List[Amendment]:
        """Get all pending amendments."""
        return [a for a in self.amendments.values() if a.is_pending]

    def get_approved_amendments(self) -> List[Amendment]:
        """Get all approved amendments."""
        return [a for a in self.amendments.values() if a.is_approved]

    def get_step_amendments(self, step_id: str) -> List[Amendment]:
        """Get all amendments for a step."""
        return [a for a in self.amendments.values() if a.step_id == step_id]

    def approve_amendment(
        self,
        amendment_id: str,
        signer_id: str,
        signer_name: str,
        signer_role: str,
        comment: Optional[str] = None
    ) -> bool:
        """Approve an amendment."""
        amendment = self.amendments.get(amendment_id)
        if amendment:
            return amendment.approve(signer_id, signer_name, signer_role, comment)
        return False

    def reject_amendment(
        self,
        amendment_id: str,
        reason: str,
        rejector_id: str
    ) -> bool:
        """Reject an amendment."""
        amendment = self.amendments.get(amendment_id)
        if amendment:
            amendment.reject(reason, rejector_id)
            return True
        return False

    def apply_amendment(
        self,
        amendment_id: str,
        applied_by: str
    ) -> bool:
        """Apply an approved amendment."""
        amendment = self.amendments.get(amendment_id)
        if amendment and amendment.is_approved:
            amendment.apply(applied_by)
            return True
        return False

    def add_hook(self, hook: Callable[[Amendment], None]) -> None:
        """Add amendment creation hook."""
        self._amendment_hooks.append(hook)

    def summary(self) -> Dict[str, Any]:
        """Get amendment summary."""
        status_counts = {}
        for amendment in self.amendments.values():
            status_name = amendment.status.name
            status_counts[status_name] = status_counts.get(status_name, 0) + 1

        return {
            "protocol_id": self.protocol_id,
            "total_amendments": len(self.amendments),
            "pending": len(self.get_pending_amendments()),
            "approved": len(self.get_approved_amendments()),
            "status_breakdown": status_counts,
        }


def create_amendment(
    protocol_id: str,
    amendment_type: AmendmentType,
    description: str,
    reason: str,
    **kwargs
) -> Amendment:
    """Convenience function to create an amendment."""
    manager = AmendmentManager(protocol_id)
    return manager.create_amendment(
        amendment_type,
        description,
        reason,
        **kwargs
    )
