"""
BPL - Biology Programming Language

A domain-specific language for biology experiments.
Version 2.4 - Implementation-ready with full robustness features.
"""

__version__ = "2.4.0"

from bpl.parser.bpl_parser import BPLParser
from bpl.parser.errors import BPLSyntaxError

__all__ = ["BPLParser", "BPLSyntaxError", "__version__"]
