"""Command-line entrypoint for BPL."""

from __future__ import annotations

import argparse
from dataclasses import fields, is_dataclass
from datetime import datetime
from enum import Enum
import json
from itertools import count
from pathlib import Path
import sys
from typing import Any, Iterator, Sequence, cast

from bpl.agentic import (
    SOPConfigurationError,
    SOPGenerationError,
    generate_bpl_from_sop,
)
from bpl.capabilities import (
    StrictCapabilityError,
    get_capability_report,
)
from bpl.export import (
    CSVFormatter,
    ExcelFormatter,
    WorklistRow,
    compose_dual_target_markdown,
    compose_plan_payload_markdown,
)
from bpl.graph import (
    GraphIntegrityError,
    build_workflow_graph,
    load_execution_plan,
    render_workflow_graph,
    render_workflow_graph_reactflow_html_from_dict,
)
from bpl.lowering import (
    Aspirate,
    Dispense,
    ExecutionPlan,
    HumanStep,
    Mix,
    PlanStep,
    Primitive,
    WellRef,
)
from bpl.orchestrator import (
    Diagnostic,
    EXIT_INTERNAL_ERROR,
    EXIT_LOWERING_FAILURE,
    EXIT_PARSE_FAILURE,
    EXIT_SEMANTIC_FAILURE,
    EXIT_SIMULATION_FAILURE,
    EXIT_STRICT_CAPABILITY_FAILURE,
    EXIT_SUCCESS,
    EXIT_USAGE_ERROR,
    OrchestrationError,
    run_capability_preflight,
    run_parse_gate,
    run_pipeline_for_plan,
    run_semantic_gate,
)
from bpl.parser import parse_file
from bpl.parser.errors import BPLSyntaxError
from bpl.simulation import SimulationStatus, simulate
from bpl.simulation.virtual_deck import LabwareType, VirtualContents, create_standard_deck
from bpl.ast.declarations import ProtocolDecl
from bpl.ast.expressions import (
    Argument,
    CallExpr,
    FieldAccessExpr,
    IdentifierExpr,
    IndexExpr,
    ListExpr,
    MapExpr,
    QuantityExpr,
)
from bpl.ast.literals import BoolLit, NumberLit, StringLit
from bpl.ast.statements import (
    CallStmt,
    ForStmt,
    IfStmt,
    ParallelBlock,
    SequenceBlock,
    Statement,
    WhileStmt,
)


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint."""

    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help()
        return EXIT_USAGE_ERROR
    return _run_handler(handler, args)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="bplc", description="Biology Programming Language CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--json-errors",
        action="store_true",
        help="Emit structured diagnostics JSON to stderr.",
    )
    common.add_argument("--quiet", action="store_true", help="Reduce CLI logging noise.")
    common.add_argument("--verbose", action="store_true", help="Enable verbose diagnostics.")

    check_parser = subparsers.add_parser(
        "check",
        parents=[common],
        help="Run syntax and baseline semantic checks for a BPL file.",
    )
    check_parser.add_argument("input_bpl", help="Path to input .bpl file.")
    check_parser.set_defaults(handler=_handle_check)

    parse_parser = subparsers.add_parser(
        "parse",
        parents=[common],
        help="Parse BPL source and emit deterministic AST artifact.",
    )
    parse_parser.add_argument("input_bpl", help="Path to input .bpl file.")
    parse_parser.add_argument("--format", choices=("json", "pretty"), default="json")
    parse_parser.add_argument("--with-spans", action="store_true")
    parse_parser.add_argument("--out", help="Optional output artifact path.")
    parse_parser.set_defaults(handler=_handle_parse)

    lower_parser = subparsers.add_parser(
        "lower",
        parents=[common],
        help="Lower BPL source into plan JSON with staged validation gates.",
    )
    lower_parser.add_argument("input_bpl", help="Path to input .bpl file.")
    lower_parser.add_argument(
        "--target",
        default="human",
        help="Backend target for capability checks (human|biomek|simulation|export).",
    )
    lower_parser.add_argument("--strict", action="store_true", help="Enable strict capability mode.")
    lower_parser.add_argument("--setup", help="Optional setup JSON for setup gate.")
    lower_parser.add_argument("--out", help="Optional output plan path.")
    lower_parser.set_defaults(handler=_handle_lower)

    validate_parser = subparsers.add_parser(
        "validate",
        parents=[common],
        help="Run staged validation gates and emit deterministic diagnostics artifact.",
    )
    validate_parser.add_argument("input_bpl", help="Path to input .bpl file.")
    validate_parser.add_argument(
        "--target",
        default="human",
        help="Backend target for capability checks (human|biomek|simulation|export).",
    )
    validate_parser.add_argument("--strict", action="store_true", help="Enable strict capability mode.")
    validate_parser.add_argument("--setup", help="Optional setup JSON for setup gate.")
    validate_parser.set_defaults(handler=_handle_validate)

    simulate_parser = subparsers.add_parser(
        "simulate",
        parents=[common],
        help="Simulate execution from BPL source or plan JSON input.",
    )
    simulate_parser.add_argument(
        "input_positional",
        nargs="?",
        help="Input path (.bpl or plan .json).",
    )
    simulate_parser.add_argument("--input-bpl", help="Path to input .bpl file.")
    simulate_parser.add_argument("--input-plan", "--plan", dest="input_plan", help="Path to plan JSON.")
    simulate_parser.add_argument(
        "--target",
        default="simulation",
        help="Capability target used during simulation preflight.",
    )
    simulate_parser.add_argument("--strict", action="store_true", help="Enable strict capability mode.")
    simulate_parser.add_argument("--setup", help="Optional setup JSON when lowering from BPL.")
    simulate_parser.add_argument("--trace", help="Optional trace output path.")
    simulate_parser.set_defaults(handler=_handle_simulate)

    export_parser = subparsers.add_parser(
        "export",
        parents=[common],
        help="Export plan-derived worklist artifacts as CSV/XLSX.",
    )
    export_parser.add_argument(
        "input_positional",
        nargs="?",
        help="Input path (.bpl or plan .json).",
    )
    export_parser.add_argument("--input-bpl", help="Path to input .bpl file.")
    export_parser.add_argument("--input-plan", "--plan", dest="input_plan", help="Path to plan JSON.")
    export_parser.add_argument("--format", choices=("csv", "xlsx"), default="csv")
    export_parser.add_argument(
        "--target",
        default="export",
        help="Capability target used during export preflight.",
    )
    export_parser.add_argument("--strict", action="store_true", help="Enable strict capability mode.")
    export_parser.add_argument("--setup", help="Optional setup JSON when lowering from BPL.")
    export_parser.add_argument("--out", help="Optional output path.")
    export_parser.set_defaults(handler=_handle_export)

    compose_parser = subparsers.add_parser(
        "compose",
        parents=[common],
        help="Compose human-readable markdown from compiled BPL plan artifacts.",
    )
    compose_parser.add_argument(
        "input_positional",
        nargs="?",
        help="Input path (.bpl or plan .json).",
    )
    compose_parser.add_argument("--input-bpl", help="Path to input .bpl file.")
    compose_parser.add_argument("--input-plan", "--plan", dest="input_plan", help="Path to plan JSON.")
    compose_parser.add_argument(
        "--target",
        default="human",
        help="Capability target used during composition preflight.",
    )
    compose_parser.add_argument("--strict", action="store_true", help="Enable strict capability mode.")
    compose_parser.add_argument("--setup", help="Optional setup JSON when lowering from BPL.")
    compose_parser.add_argument("--out", help="Optional markdown output path.")
    compose_parser.add_argument(
        "--both-targets",
        action="store_true",
        help="Compose one markdown artifact with both human and biomek target variants.",
    )
    compose_parser.set_defaults(handler=_handle_compose)

    capabilities_parser = subparsers.add_parser(
        "capabilities",
        parents=[common],
        help="Report backend primitive support from shared capability registry.",
    )
    capabilities_parser.add_argument(
        "--target",
        required=True,
        help="Backend target, e.g. human|biomek|simulation|export.",
    )
    capabilities_parser.set_defaults(handler=_handle_capabilities)

    graph_parser = subparsers.add_parser(
        "graph",
        parents=[common],
        help="Render workflow graph artifacts.",
    )
    graph_parser.add_argument(
        "input_bpl_positional",
        nargs="?",
        help="Path to input .bpl file (same as --input-bpl).",
    )
    graph_parser.add_argument("--input-bpl", help="Path to input .bpl file.")
    graph_parser.add_argument(
        "--input-plan",
        "--plan",
        dest="input_plan",
        help="Path to input execution plan JSON.",
    )
    graph_parser.add_argument(
        "--format",
        choices=("json", "mermaid", "reactflow-html"),
        default="json",
    )
    graph_parser.add_argument("--out", help="Optional output file path.")
    graph_parser.set_defaults(handler=_handle_graph)

    sop_parser = subparsers.add_parser(
        "sop-generate",
        parents=[common],
        help="Generate validated BPL from SOP markdown using bounded agentic workflow.",
    )
    sop_parser.add_argument("--sop", required=True, help="Path to SOP markdown input.")
    sop_parser.add_argument("--setup", help="Optional setup JSON for validation.")
    sop_parser.add_argument(
        "--lab-catalog",
        help=(
            "Optional xlsx path for reagent/consumable/equipment inventory. "
            "When omitted, auto-detects lab_inventory.xlsx near SOP."
        ),
    )
    sop_parser.add_argument("--out", required=True, help="Output BPL path.")
    sop_parser.add_argument("--graph-out", help="Optional workflow graph output path.")
    sop_parser.set_defaults(handler=_handle_sop_generate)

    return parser


def _run_handler(handler: Any, args: argparse.Namespace) -> int:
    try:
        return int(handler(args))
    except OrchestrationError as exc:
        _emit_diagnostics(exc.diagnostics, json_errors=args.json_errors)
        return exc.exit_code
    except Exception as exc:  # pragma: no cover - top-level guard
        diagnostic = Diagnostic(
            code="INTERNAL_UNHANDLED_ERROR",
            severity="error",
            message=f"Unhandled error: {exc}",
            location=None,
            hint="Inspect stack trace and inputs for unexpected state.",
        )
        _emit_diagnostics([diagnostic], json_errors=args.json_errors)
        return EXIT_INTERNAL_ERROR


def _handle_check(args: argparse.Namespace) -> int:
    input_path = Path(args.input_bpl)
    program = run_parse_gate(input_path)
    diagnostics = run_semantic_gate(program=program, input_path=input_path)
    if diagnostics:
        raise OrchestrationError(EXIT_SEMANTIC_FAILURE, diagnostics)

    diagnostics_path = _default_artifact_path("check", input_path, "diagnostics.json")
    _write_json_file(diagnostics_path, {"diagnostics": []})
    _emit_manifest(
        {
            "artifacts": {"diagnostics": str(diagnostics_path)},
            "command": "check",
            "input": str(input_path),
            "ok": True,
        }
    )
    return EXIT_SUCCESS


def _handle_parse(args: argparse.Namespace) -> int:
    input_path = Path(args.input_bpl)
    program = run_parse_gate(input_path)
    payload = _ast_to_data(program, with_spans=args.with_spans)

    if args.format == "json":
        artifact_path = (
            Path(args.out)
            if args.out
            else _default_artifact_path("parse", input_path, "ast.json")
        )
        _write_json_file(artifact_path, payload)
    else:
        artifact_path = (
            Path(args.out)
            if args.out
            else _default_artifact_path("parse", input_path, "ast.txt")
        )
        _write_text_file(
            artifact_path,
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
        )

    _emit_manifest(
        {
            "artifacts": {"ast": str(artifact_path)},
            "command": "parse",
            "format": args.format,
            "input": str(input_path),
            "ok": True,
        }
    )
    return EXIT_SUCCESS


def _handle_lower(args: argparse.Namespace) -> int:
    input_path = Path(args.input_bpl)
    pipeline = run_pipeline_for_plan(
        input_path=input_path,
        target=args.target,
        strict=args.strict,
        setup_path=Path(args.setup) if args.setup else None,
    )
    _emit_diagnostics(pipeline.warnings, json_errors=args.json_errors)

    artifact_path = Path(args.out) if args.out else _default_artifact_path("lower", input_path, "plan.json")
    _write_json_file(artifact_path, _execution_plan_payload(pipeline.plan))
    _emit_manifest(
        {
            "artifacts": {"plan": str(artifact_path)},
            "command": "lower",
            "input": str(input_path),
            "ok": True,
            "target": pipeline.target,
        }
    )
    return EXIT_SUCCESS


def _handle_validate(args: argparse.Namespace) -> int:
    input_path = Path(args.input_bpl)
    pipeline = run_pipeline_for_plan(
        input_path=input_path,
        target=args.target,
        strict=args.strict,
        setup_path=Path(args.setup) if args.setup else None,
    )
    _emit_diagnostics(pipeline.warnings, json_errors=args.json_errors)

    diagnostics_path = _default_artifact_path("validate", input_path, "diagnostics.json")
    _write_json_file(diagnostics_path, {"diagnostics": [d.to_dict() for d in pipeline.warnings]})
    _emit_manifest(
        {
            "artifacts": {"diagnostics": str(diagnostics_path)},
            "command": "validate",
            "input": str(input_path),
            "ok": True,
            "target": pipeline.target,
        }
    )
    return EXIT_SUCCESS


def _handle_simulate(args: argparse.Namespace) -> int:
    input_plan = args.input_plan
    input_bpl = args.input_bpl
    positional = args.input_positional

    if positional:
        suffix = Path(positional).suffix.lower()
        if suffix == ".bpl" and not input_plan and not input_bpl:
            input_bpl = positional
        elif suffix == ".json" and not input_plan and not input_bpl:
            input_plan = positional

    if bool(input_plan) == bool(input_bpl):
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_SIMULATE_INPUT",
                    severity="error",
                    message="Exactly one input is required: --input-plan or --input-bpl/<file.bpl>.",
                    location=None,
                    hint="Provide a single source input for simulation.",
                )
            ],
        )

    warnings: list[Diagnostic] = []
    if input_bpl:
        bpl_path = Path(str(input_bpl))
        pipeline = run_pipeline_for_plan(
            input_path=bpl_path,
            target=args.target,
            strict=args.strict,
            setup_path=Path(args.setup) if args.setup else None,
        )
        warnings.extend(pipeline.warnings)
        plan = pipeline.plan
        input_ref = bpl_path
    else:
        plan_path = Path(str(input_plan))
        plan = load_execution_plan(plan_path)
        input_ref = plan_path
        try:
            preflight = run_capability_preflight(plan=plan, target=args.target, strict=args.strict)
        except StrictCapabilityError as exc:
            raise OrchestrationError(
                EXIT_STRICT_CAPABILITY_FAILURE,
                [
                    Diagnostic(
                        code="CAPABILITY_UNSUPPORTED_SET",
                        severity="error",
                        message=(
                            f"Strict capability failure for target '{exc.target}': "
                            f"{', '.join(exc.unsupported_primitives)}"
                        ),
                        location=None,
                        hint="Use non-strict mode or switch backend target.",
                    )
                ],
            ) from exc
        if preflight.unsupported_primitives:
            warnings.append(
                Diagnostic(
                    code="CAPABILITY_UNSUPPORTED_SET",
                    severity="warning",
                    message=(
                        f"Unsupported primitives (non-strict): "
                        f"{', '.join(preflight.unsupported_primitives)}"
                    ),
                    location=None,
                    hint="Use --strict to fail instead of degrade.",
                )
            )

    _emit_diagnostics(warnings, json_errors=args.json_errors)

    deck_state = _seed_deck_for_plan(plan)
    result = simulate(
        plan=plan,
        deck_state=deck_state,
        strict_capabilities=False,
        capability_target=args.target,
    )
    if result.status != SimulationStatus.COMPLETED:
        message = result.validation_errors[0] if result.validation_errors else "Simulation failed."
        raise OrchestrationError(
            EXIT_SIMULATION_FAILURE,
            [
                Diagnostic(
                    code="SIMULATION_RUNTIME_FAILURE",
                    severity="error",
                    message=message,
                    location=None,
                    hint="Inspect trace output and plan dependencies.",
                )
            ],
        )

    trace_path = (
        Path(args.trace) if args.trace else _default_artifact_path("simulate", input_ref, "trace.json")
    )
    _write_json_file(trace_path, _simulation_trace_payload(result))
    _emit_manifest(
        {
            "artifacts": {"trace": str(trace_path)},
            "command": "simulate",
            "input": str(input_ref),
            "ok": True,
            "target": args.target,
        }
    )
    return EXIT_SUCCESS


def _handle_export(args: argparse.Namespace) -> int:
    input_plan = args.input_plan
    input_bpl = args.input_bpl
    positional = args.input_positional

    if positional:
        suffix = Path(positional).suffix.lower()
        if suffix == ".bpl" and not input_plan and not input_bpl:
            input_bpl = positional
        elif suffix == ".json" and not input_plan and not input_bpl:
            input_plan = positional

    if bool(input_plan) == bool(input_bpl):
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_EXPORT_INPUT",
                    severity="error",
                    message="Exactly one input is required: --input-plan or --input-bpl/<file.bpl>.",
                    location=None,
                    hint="Provide a single source input for export.",
                )
            ],
        )

    warnings: list[Diagnostic] = []
    if input_bpl:
        bpl_path = Path(str(input_bpl))
        pipeline = run_pipeline_for_plan(
            input_path=bpl_path,
            target=args.target,
            strict=args.strict,
            setup_path=Path(args.setup) if args.setup else None,
        )
        warnings.extend(pipeline.warnings)
        plan = pipeline.plan
        input_ref = bpl_path
    else:
        plan_path = Path(str(input_plan))
        plan = load_execution_plan(plan_path)
        input_ref = plan_path
        try:
            preflight = run_capability_preflight(plan=plan, target=args.target, strict=args.strict)
        except StrictCapabilityError as exc:
            raise OrchestrationError(
                EXIT_STRICT_CAPABILITY_FAILURE,
                [
                    Diagnostic(
                        code="CAPABILITY_UNSUPPORTED_SET",
                        severity="error",
                        message=(
                            f"Strict capability failure for target '{exc.target}': "
                            f"{', '.join(exc.unsupported_primitives)}"
                        ),
                        location=None,
                        hint="Use non-strict mode or switch backend target.",
                    )
                ],
            ) from exc
        if preflight.unsupported_primitives:
            warnings.append(
                Diagnostic(
                    code="CAPABILITY_UNSUPPORTED_SET",
                    severity="warning",
                    message=(
                        f"Unsupported primitives (non-strict): "
                        f"{', '.join(preflight.unsupported_primitives)}"
                    ),
                    location=None,
                    hint="Use --strict to fail instead of degrade.",
                )
            )

    _emit_diagnostics(warnings, json_errors=args.json_errors)

    rows = _plan_to_worklist_rows(plan)
    if args.format == "csv":
        formatter = CSVFormatter()
    else:
        formatter = ExcelFormatter()

    output_bytes = formatter.format(rows)
    output_path = (
        Path(args.out)
        if args.out
        else _default_artifact_path("export", input_ref, f"worklist.{args.format}")
    )
    _write_bytes_file(output_path, output_bytes)
    _emit_manifest(
        {
            "artifacts": {"worklist": str(output_path)},
            "command": "export",
            "format": args.format,
            "input": str(input_ref),
            "ok": True,
            "row_count": len(rows),
            "target": args.target,
        }
    )
    return EXIT_SUCCESS


def _handle_compose(args: argparse.Namespace) -> int:
    input_plan = args.input_plan
    input_bpl = args.input_bpl
    positional = args.input_positional

    if positional:
        suffix = Path(positional).suffix.lower()
        if suffix == ".bpl" and not input_plan and not input_bpl:
            input_bpl = positional
        elif suffix == ".json" and not input_plan and not input_bpl:
            input_plan = positional

    if bool(input_plan) == bool(input_bpl):
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_COMPOSE_INPUT",
                    severity="error",
                    message="Exactly one input is required: --input-plan or --input-bpl/<file.bpl>.",
                    location=None,
                    hint="Provide a single source input for composition.",
                )
            ],
        )

    if args.both_targets and input_plan:
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_COMPOSE_DUAL_TARGET",
                    severity="error",
                    message="--both-targets requires BPL input, not plan JSON input.",
                    location=None,
                    hint="Use --input-bpl/<file.bpl> when composing both targets.",
                )
            ],
        )

    warnings: list[Diagnostic] = []
    step_count = 0
    step_count_by_target: dict[str, int] | None = None

    if args.both_targets:
        bpl_path = Path(str(input_bpl))
        human_pipeline = run_pipeline_for_plan(
            input_path=bpl_path,
            target="human",
            strict=args.strict,
            setup_path=Path(args.setup) if args.setup else None,
        )
        biomek_pipeline = run_pipeline_for_plan(
            input_path=bpl_path,
            target="biomek",
            strict=args.strict,
            setup_path=Path(args.setup) if args.setup else None,
        )
        warnings.extend(human_pipeline.warnings)
        warnings.extend(biomek_pipeline.warnings)
        human_payload = _execution_plan_payload(human_pipeline.plan)
        biomek_payload = _execution_plan_payload(biomek_pipeline.plan)
        input_ref = bpl_path
        manifest_target = "dual"

        human_steps = human_payload.get("steps")
        biomek_steps = biomek_payload.get("steps")
        human_count = len(human_steps) if isinstance(human_steps, list) else 0
        biomek_count = len(biomek_steps) if isinstance(biomek_steps, list) else 0
        step_count = human_count + biomek_count
        step_count_by_target = {"human": human_count, "biomek": biomek_count}

        _emit_diagnostics(warnings, json_errors=args.json_errors)
        try:
            markdown = compose_dual_target_markdown(
                human_payload=human_payload,
                biomek_payload=biomek_payload,
            )
        except ValueError as exc:
            raise OrchestrationError(
                EXIT_LOWERING_FAILURE,
                [
                    Diagnostic(
                        code="PLAN_COMPOSE_ERROR",
                        severity="error",
                        message=str(exc),
                        location=None,
                        hint="Inspect compiled plan JSON structure before composition.",
                    )
                ],
            ) from exc
    else:
        if input_bpl:
            bpl_path = Path(str(input_bpl))
            pipeline = run_pipeline_for_plan(
                input_path=bpl_path,
                target=args.target,
                strict=args.strict,
                setup_path=Path(args.setup) if args.setup else None,
            )
            warnings.extend(pipeline.warnings)
            plan_payload = _execution_plan_payload(pipeline.plan)
            input_ref = bpl_path
            manifest_target = pipeline.target
        else:
            plan_path = Path(str(input_plan))
            try:
                plan_payload = _load_plan_payload(plan_path)
                plan = load_execution_plan(plan_path)
            except FileNotFoundError as exc:
                raise OrchestrationError(
                    EXIT_USAGE_ERROR,
                    [
                        Diagnostic(
                            code="USAGE_COMPOSE_INPUT_NOT_FOUND",
                            severity="error",
                            message=str(exc),
                            location=None,
                            hint="Provide a valid input path.",
                        )
                    ],
                ) from exc
            except ValueError as exc:
                raise OrchestrationError(
                    EXIT_LOWERING_FAILURE,
                    [
                        Diagnostic(
                            code="PLAN_COMPOSE_ERROR",
                            severity="error",
                            message=str(exc),
                            location=None,
                            hint="Inspect compiled plan JSON structure before composition.",
                        )
                    ],
                ) from exc
            input_ref = plan_path
            manifest_target = str(plan_payload.get("target", args.target))
            try:
                preflight = run_capability_preflight(plan=plan, target=args.target, strict=args.strict)
            except StrictCapabilityError as exc:
                raise OrchestrationError(
                    EXIT_STRICT_CAPABILITY_FAILURE,
                    [
                        Diagnostic(
                            code="CAPABILITY_UNSUPPORTED_SET",
                            severity="error",
                            message=(
                                f"Strict capability failure for target '{exc.target}': "
                                f"{', '.join(exc.unsupported_primitives)}"
                            ),
                            location=None,
                            hint="Use non-strict mode or switch backend target.",
                        )
                    ],
                ) from exc
            if preflight.unsupported_primitives:
                warnings.append(
                    Diagnostic(
                        code="CAPABILITY_UNSUPPORTED_SET",
                        severity="warning",
                        message=(
                            f"Unsupported primitives (non-strict): "
                            f"{', '.join(preflight.unsupported_primitives)}"
                        ),
                        location=None,
                        hint="Use --strict to fail instead of degrade.",
                    )
                )

        _emit_diagnostics(warnings, json_errors=args.json_errors)

        try:
            markdown = compose_plan_payload_markdown(plan_payload)
        except ValueError as exc:
            raise OrchestrationError(
                EXIT_LOWERING_FAILURE,
                [
                    Diagnostic(
                        code="PLAN_COMPOSE_ERROR",
                        severity="error",
                        message=str(exc),
                        location=None,
                        hint="Inspect compiled plan JSON structure before composition.",
                    )
                ],
            ) from exc

        raw_steps = plan_payload.get("steps")
        if isinstance(raw_steps, list):
            step_count = len(raw_steps)
        elif isinstance(raw_steps, dict):
            step_count = len(raw_steps)
        else:
            step_count = 0

    output_path = (
        Path(args.out)
        if args.out
        else _default_artifact_path(
            "compose",
            input_ref,
            "protocol.dual.md" if args.both_targets else "protocol.md",
        )
    )
    _write_text_file(output_path, markdown)

    manifest: dict[str, object] = {
        "artifacts": {"markdown": str(output_path)},
        "command": "compose",
        "input": str(input_ref),
        "ok": True,
        "step_count": step_count,
        "target": manifest_target,
    }
    if step_count_by_target is not None:
        manifest["step_count_by_target"] = step_count_by_target
    _emit_manifest(manifest)
    return EXIT_SUCCESS


def _handle_capabilities(args: argparse.Namespace) -> int:
    try:
        report = get_capability_report(args.target)
    except ValueError as exc:
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_UNSUPPORTED_TARGET",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Choose one supported target.",
                )
            ],
        ) from exc

    sys.stdout.write(json.dumps(report.to_dict(), sort_keys=True) + "\n")
    return EXIT_SUCCESS


def _handle_graph(args: argparse.Namespace) -> int:
    input_plan = args.input_plan
    input_bpl = args.input_bpl or args.input_bpl_positional

    if bool(input_plan) == bool(input_bpl):
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_GRAPH_INPUT",
                    severity="error",
                    message="Exactly one input is required: use --input-plan or --input-bpl/<file.bpl>.",
                    location=None,
                    hint="Provide a single source input for graph rendering.",
                )
            ],
        )

    try:
        if input_plan:
            plan = load_execution_plan(Path(input_plan))
        else:
            plan = _lower_bpl_for_graph(Path(str(input_bpl)))

        graph = build_workflow_graph(plan)
        rendered = render_workflow_graph(graph, args.format)

        if args.out:
            out_path = Path(args.out)
            _write_text_file(out_path, rendered)
            manifest = {"format": args.format, "graph": str(out_path)}
            sys.stdout.write(json.dumps(manifest, sort_keys=True) + "\n")
        else:
            sys.stdout.write(rendered)
        return EXIT_SUCCESS
    except FileNotFoundError as exc:
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="USAGE_GRAPH_INPUT_NOT_FOUND",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Provide a valid input path.",
                )
            ],
        ) from exc
    except BPLSyntaxError as exc:
        raise OrchestrationError(
            EXIT_PARSE_FAILURE,
            [
                Diagnostic(
                    code="SYNTAX_PARSE_ERROR",
                    severity="error",
                    message=exc.message,
                    location=None,
                    hint=(exc.suggestions[0] if exc.suggestions else None),
                )
            ],
        ) from exc
    except GraphIntegrityError as exc:
        raise OrchestrationError(
            EXIT_LOWERING_FAILURE,
            [
                Diagnostic(
                    code=exc.code,
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Ensure dependencies are valid and acyclic.",
                )
            ],
        ) from exc
    except ValueError as exc:
        raise OrchestrationError(
            EXIT_LOWERING_FAILURE,
            [
                Diagnostic(
                    code="PLAN_GRAPH_ERROR",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Inspect lowered plan shape for graph rendering.",
                )
            ],
        ) from exc


def _handle_sop_generate(args: argparse.Namespace) -> int:
    sop_path = Path(args.sop)
    if not sop_path.exists():
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="SOP_INPUT_NOT_FOUND",
                    severity="error",
                    message=f"SOP file not found: {sop_path}",
                    location=None,
                    hint="Provide an existing SOP markdown file.",
                )
            ],
        )

    setup_path = Path(args.setup) if args.setup else None
    lab_catalog_path = Path(args.lab_catalog) if args.lab_catalog else None
    if lab_catalog_path is not None and not lab_catalog_path.exists():
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="SOP_LAB_CATALOG_NOT_FOUND",
                    severity="error",
                    message=f"Lab catalog file not found: {lab_catalog_path}",
                    location=None,
                    hint="Provide an existing .xlsx inventory file.",
                )
            ],
        )
    try:
        result = generate_bpl_from_sop(
            sop_path=sop_path,
            setup_path=setup_path,
            lab_catalog_path=lab_catalog_path,
            include_graph=bool(args.graph_out),
        )
    except SOPConfigurationError as exc:
        raise OrchestrationError(
            EXIT_USAGE_ERROR,
            [
                Diagnostic(
                    code="SOP_GENERATION_CONFIG_ERROR",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Set required SOP generation model/runtime environment variables.",
                )
            ],
        ) from exc
    except SOPGenerationError as exc:
        raise OrchestrationError(
            EXIT_INTERNAL_ERROR,
            [
                Diagnostic(
                    code="SOP_GENERATION_RUNTIME_ERROR",
                    severity="error",
                    message=str(exc),
                    location=None,
                    hint="Inspect model settings and prompt inputs.",
                )
            ],
        ) from exc

    out_path = Path(args.out)
    metadata_path = out_path.with_suffix(".metadata.json")
    _write_json_file(metadata_path, result.metadata_payload())

    if not result.success or result.final_bpl is None:
        failure_diagnostics = result.failure_diagnostics or [
            Diagnostic(
                code="SOP_GENERATION_RETRY_EXHAUSTED",
                severity="error",
                message="SOP generation exhausted retries without producing valid BPL.",
                location=None,
                hint="Review diagnostics history in metadata and refine SOP constraints.",
            )
        ]
        raise OrchestrationError(EXIT_SEMANTIC_FAILURE, failure_diagnostics)

    _write_text_file(out_path, result.final_bpl)
    _emit_diagnostics(result.validation_warnings, json_errors=args.json_errors)

    artifacts: dict[str, str] = {
        "bpl": str(out_path),
        "metadata": str(metadata_path),
    }
    if args.graph_out and result.graph_artifact is not None:
        graph_path = Path(args.graph_out)
        _write_text_file(graph_path, result.graph_artifact)
        artifacts["graph"] = str(graph_path)

        graph_payload = cast(dict[str, object], json.loads(result.graph_artifact))
        reactflow_html = render_workflow_graph_reactflow_html_from_dict(graph_payload)
        reactflow_path = (
            graph_path.with_suffix(".reactflow.html")
            if graph_path.suffix
            else graph_path.parent / f"{graph_path.name}.reactflow.html"
        )
        _write_text_file(reactflow_path, reactflow_html)
        artifacts["graph_reactflow"] = str(reactflow_path)

    _emit_manifest(
        {
            "artifacts": artifacts,
            "command": "sop-generate",
            "input": str(sop_path),
            "attempts_used": result.generation_metadata.get("attempts_used"),
            "ok": True,
        }
    )
    return EXIT_SUCCESS


def _emit_diagnostics(diagnostics: list[Diagnostic], json_errors: bool) -> None:
    if not diagnostics:
        return

    if json_errors:
        payload = {"diagnostics": [diag.to_dict() for diag in diagnostics]}
        sys.stderr.write(json.dumps(payload, sort_keys=True) + "\n")
        return

    for diagnostic in diagnostics:
        header = f"{diagnostic.severity}: {diagnostic.code}: {diagnostic.message}"
        sys.stderr.write(header + "\n")
        if diagnostic.location is not None:
            start = diagnostic.location.start
            sys.stderr.write(
                f"  at {diagnostic.location.file}:{start.line}:{start.col}"
                f" (offset {start.offset})\n"
            )
        if diagnostic.hint:
            sys.stderr.write(f"  hint: {diagnostic.hint}\n")


def _emit_manifest(payload: dict[str, object]) -> None:
    sys.stdout.write(json.dumps(payload, sort_keys=True) + "\n")


def _default_artifact_path(command: str, input_path: Path, filename: str) -> Path:
    return Path("artifacts") / command / f"{input_path.stem}.{filename}"


def _write_json_file(path: Path, payload: object) -> None:
    _ensure_parent(path)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_text_file(path: Path, content: str) -> None:
    _ensure_parent(path)
    path.write_text(content, encoding="utf-8")


def _write_bytes_file(path: Path, content: bytes) -> None:
    _ensure_parent(path)
    path.write_bytes(content)


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _load_plan_payload(path: Path) -> dict[str, object]:
    if not path.exists():
        raise FileNotFoundError(f"Plan file not found: {path}")

    raw_text = path.read_text(encoding="utf-8")
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in plan file '{path}': {exc}") from exc

    if not isinstance(payload, dict):
        raise ValueError("Plan JSON must be an object at top-level.")
    return cast(dict[str, object], payload)


def _safe_protocol_name(raw: str) -> str:
    candidate = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in raw)
    candidate = candidate.strip("_")
    if not candidate:
        return "SOPGeneratedProtocol"
    if candidate[0].isdigit():
        return f"Protocol_{candidate}"
    return candidate


def _ast_to_data(value: object, with_spans: bool) -> object:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, list):
        return [_ast_to_data(item, with_spans=with_spans) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _ast_to_data(item, with_spans=with_spans)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        }
    if is_dataclass(value):
        node_payload: dict[str, object] = {"node_type": type(value).__name__}
        for field in fields(value):
            if field.name == "span" and not with_spans:
                continue
            field_value = getattr(value, field.name)
            node_payload[field.name] = _ast_to_data(field_value, with_spans=with_spans)
        return node_payload
    return str(value)


def _execution_plan_payload(plan: ExecutionPlan) -> dict[str, object]:
    step_entries: list[dict[str, object]] = []
    for step_id in plan.topological_order():
        step = plan.steps[step_id]
        step_entries.append(
            {
                "annotations": _jsonable(step.annotations),
                "dependencies": list(step.dependencies),
                "primitive": _jsonable(step.primitive),
                "primitive_type": step.primitive.primitive_type.name,
                "source_intent": step.source_intent,
                "status": step.status.name,
                "step_id": step.step_id,
            }
        )

    return {
        "plan_id": plan.plan_id,
        "protocol_name": plan.protocol_name,
        "steps": step_entries,
        "target": plan.target,
    }


def _simulation_trace_payload(result: object) -> dict[str, object]:
    simulation_result = cast("Any", result)
    traces = []
    for trace in simulation_result.step_traces:
        traces.append(
            {
                "details": _jsonable(trace.details),
                "duration_ms": trace.duration_ms,
                "error_message": trace.error_message,
                "primitive_type": trace.primitive_type.name,
                "state_after_hash": trace.state_after_hash,
                "state_before_hash": trace.state_before_hash,
                "step_id": trace.step_id,
                "success": trace.success,
                "timestamp": trace.timestamp.isoformat(),
            }
        )

    return {
        "completed_at": simulation_result.completed_at.isoformat()
        if simulation_result.completed_at
        else None,
        "final_state_hash": simulation_result.final_state_hash,
        "plan_id": simulation_result.plan_id,
        "started_at": simulation_result.started_at.isoformat(),
        "status": simulation_result.status.name,
        "step_traces": traces,
        "steps_executed": simulation_result.steps_executed,
        "steps_failed": simulation_result.steps_failed,
        "unsupported_primitives": sorted(simulation_result.unsupported_primitives),
        "unsupported_step_count": simulation_result.unsupported_step_count,
        "validation_errors": list(simulation_result.validation_errors),
        "warnings": list(simulation_result.warnings),
    }


def _jsonable(value: object) -> object:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))}
    if is_dataclass(value):
        payload: dict[str, object] = {"__type__": type(value).__name__}
        for field in fields(value):
            payload[field.name] = _jsonable(getattr(value, field.name))
        return payload
    return str(value)


def _plan_to_worklist_rows(plan: ExecutionPlan) -> list[WorklistRow]:
    rows: list[WorklistRow] = []
    for step_id in plan.topological_order():
        step = plan.steps[step_id]
        if not isinstance(step.primitive, Dispense):
            continue

        dispense = step.primitive
        source = _find_source_for_dispense(plan, step)
        source_plate = source.plate_id if isinstance(source, WellRef) else "unknown_source"
        source_well = source.well_id if isinstance(source, WellRef) else None
        destination = dispense.destination
        destination_plate = destination.plate_id if isinstance(destination, WellRef) else "unknown_dest"
        destination_well = destination.well_id if isinstance(destination, WellRef) else None
        rows.append(
            WorklistRow(
                source_plate=source_plate,
                source_well=source_well,
                destination_plate=destination_plate,
                destination_well=destination_well,
                transfer_volume_ul=dispense.volume_ul,
                metadata={"step_id": step_id},
            )
        )
    return rows


def _find_source_for_dispense(plan: ExecutionPlan, step: PlanStep) -> object | None:
    for dependency in step.dependencies:
        dep_step = plan.steps.get(dependency)
        if dep_step is None:
            continue
        if isinstance(dep_step.primitive, Aspirate):
            return dep_step.primitive.source
    return None


def _seed_deck_for_plan(plan: ExecutionPlan):
    deck = create_standard_deck()
    deck.add_pipette("default_pipette")

    slot_counter = count(start=1)
    for step in plan.steps.values():
        primitive = step.primitive
        if isinstance(primitive, Aspirate) and isinstance(primitive.source, WellRef):
            _ensure_well_on_deck(deck, primitive.source, slot_counter)
            contents = deck.get_well_contents(primitive.source.plate_id, primitive.source.well_id)
            if contents is not None:
                contents.volume_ul = max(contents.volume_ul, primitive.volume_ul * 2.0)
        elif isinstance(primitive, Dispense) and isinstance(primitive.destination, WellRef):
            _ensure_well_on_deck(deck, primitive.destination, slot_counter)
        elif isinstance(primitive, Mix) and isinstance(primitive.location, WellRef):
            _ensure_well_on_deck(deck, primitive.location, slot_counter)

    return deck


def _ensure_well_on_deck(deck, well: WellRef, slot_counter: Iterator[int]) -> None:
    if deck.get_labware(well.plate_id) is None:
        slot = f"slot_{next(slot_counter)}"
        deck.add_labware(well.plate_id, LabwareType.PLATE_96, slot)
    contents = deck.get_well_contents(well.plate_id, well.well_id)
    if contents is None:
        labware = deck.get_labware(well.plate_id)
        if labware is not None:
            labware.set_contents(well.well_id, VirtualContents())


def _lower_bpl_for_graph(path: Path) -> ExecutionPlan:
    if not path.exists():
        raise FileNotFoundError(f"BPL file not found: {path}")

    program = parse_file(path)
    protocol = next(
        (decl for decl in program.declarations if isinstance(decl, ProtocolDecl)),
        None,
    )
    if protocol is None:
        raise ValueError("No protocol declaration found in BPL input.")

    protocol_name = protocol.name or "protocol"
    plan = ExecutionPlan(
        plan_id=f"{protocol_name}_plan",
        protocol_name=protocol_name,
        target="human",
    )

    step_counter = count(start=1)
    _emit_statements(protocol.body, incoming_dependencies=[], plan=plan, step_counter=step_counter)
    return plan


def _emit_statements(
    statements: list[Statement],
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
) -> list[str]:
    current_dependencies = sorted(set(incoming_dependencies))
    for statement in statements:
        current_dependencies = _emit_statement(
            statement=statement,
            incoming_dependencies=current_dependencies,
            plan=plan,
            step_counter=step_counter,
        )
    return current_dependencies


def _emit_statement(
    statement: Statement,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
) -> list[str]:
    if isinstance(statement, CallStmt):
        step_id = _add_call_step(statement, incoming_dependencies, plan, step_counter)
        return [step_id]

    if isinstance(statement, SequenceBlock):
        return _emit_statements(
            statements=statement.statements,
            incoming_dependencies=incoming_dependencies,
            plan=plan,
            step_counter=step_counter,
        )

    if isinstance(statement, ParallelBlock):
        branch_dependencies: list[str] = []
        for nested in statement.statements:
            branch_dependencies.extend(
                _emit_statement(
                    statement=nested,
                    incoming_dependencies=incoming_dependencies,
                    plan=plan,
                    step_counter=step_counter,
                )
            )
        return sorted(set(branch_dependencies)) or incoming_dependencies

    if isinstance(statement, IfStmt):
        control_step_id = _add_control_step("if", incoming_dependencies, plan, step_counter)
        branch_dependencies: list[str] = []

        if statement.then_block is not None:
            branch_dependencies.extend(
                _emit_statements(
                    statements=statement.then_block.statements,
                    incoming_dependencies=[control_step_id],
                    plan=plan,
                    step_counter=step_counter,
                )
            )

        for _, block in statement.else_ifs:
            branch_dependencies.extend(
                _emit_statements(
                    statements=block.statements,
                    incoming_dependencies=[control_step_id],
                    plan=plan,
                    step_counter=step_counter,
                )
            )

        if statement.else_block is not None:
            branch_dependencies.extend(
                _emit_statements(
                    statements=statement.else_block.statements,
                    incoming_dependencies=[control_step_id],
                    plan=plan,
                    step_counter=step_counter,
                )
            )

        return sorted(set(branch_dependencies)) or [control_step_id]

    if isinstance(statement, ForStmt):
        control_step_id = _add_control_step("for", incoming_dependencies, plan, step_counter)
        if statement.body is None:
            return [control_step_id]
        branch = _emit_statements(
            statements=statement.body.statements,
            incoming_dependencies=[control_step_id],
            plan=plan,
            step_counter=step_counter,
        )
        return sorted(set(branch)) or [control_step_id]

    if isinstance(statement, WhileStmt):
        control_step_id = _add_control_step("while", incoming_dependencies, plan, step_counter)
        if statement.body is None:
            return [control_step_id]
        branch = _emit_statements(
            statements=statement.body.statements,
            incoming_dependencies=[control_step_id],
            plan=plan,
            step_counter=step_counter,
        )
        return sorted(set(branch)) or [control_step_id]

    return incoming_dependencies


def _add_call_step(
    statement: CallStmt,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
) -> str:
    step_id = f"call_{next(step_counter):04d}"
    primitive = cast(Primitive, HumanStep(instruction=_format_call_statement(statement)))
    step = PlanStep(
        step_id=step_id,
        primitive=primitive,
        dependencies=sorted(set(incoming_dependencies)),
        source_intent=statement.name,
        annotations=_span_annotation(statement),
    )
    plan.add_step(step)
    return step_id


def _add_control_step(
    control_name: str,
    incoming_dependencies: list[str],
    plan: ExecutionPlan,
    step_counter: Iterator[int],
) -> str:
    step_id = f"control_{next(step_counter):04d}"
    primitive = cast(Primitive, HumanStep(instruction=f"{control_name} control"))
    step = PlanStep(
        step_id=step_id,
        primitive=primitive,
        dependencies=sorted(set(incoming_dependencies)),
        source_intent=control_name,
    )
    plan.add_step(step)
    return step_id


def _span_annotation(statement: Statement) -> dict[str, dict[str, int | str]]:
    span = getattr(statement, "span", None)
    if span is None:
        return {}
    return {
        "source_span": {
            "file": span.file,
            "start_line": span.start_line,
            "start_col": span.start_col,
            "end_line": span.end_line,
            "end_col": span.end_col,
        }
    }


def _format_call_statement(statement: CallStmt) -> str:
    formatted_args = [_format_argument(argument) for argument in statement.arguments]
    return f"{statement.name}({', '.join(formatted_args)})"


def _format_argument(argument: Argument) -> str:
    value_text = _format_expression(argument.value)
    if argument.name is None:
        return value_text
    return f"{argument.name}: {value_text}"


def _format_expression(expression: object | None) -> str:
    if expression is None:
        return "null"
    if isinstance(expression, IdentifierExpr):
        return expression.name
    if isinstance(expression, NumberLit):
        return f"{expression.value:g}"
    if isinstance(expression, StringLit):
        return f'"{expression.value}"'
    if isinstance(expression, BoolLit):
        return "true" if expression.value else "false"
    if isinstance(expression, QuantityExpr):
        value_text = _format_expression(expression.value)
        unit_text = expression.unit.text if expression.unit is not None else ""
        return f"{value_text} {unit_text}".strip()
    if isinstance(expression, FieldAccessExpr):
        return f"{_format_expression(expression.object)}.{expression.field}"
    if isinstance(expression, IndexExpr):
        return f"{_format_expression(expression.object)}[{_format_expression(expression.index)}]"
    if isinstance(expression, ListExpr):
        return "[" + ", ".join(_format_expression(item) for item in expression.elements) + "]"
    if isinstance(expression, MapExpr):
        parts = []
        for key in sorted(expression.entries):
            parts.append(f"{key}: {_format_expression(expression.entries[key])}")
        return "{" + ", ".join(parts) + "}"
    if isinstance(expression, CallExpr):
        function_text = _format_expression(expression.function)
        args_text = ", ".join(_format_argument(argument) for argument in expression.arguments)
        return f"{function_text}({args_text})"
    return expression.__class__.__name__


if __name__ == "__main__":
    raise SystemExit(main())
