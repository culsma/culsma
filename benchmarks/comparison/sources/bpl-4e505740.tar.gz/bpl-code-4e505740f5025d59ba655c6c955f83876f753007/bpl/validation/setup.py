"""Experiment setup loading and setup-aware plan validation."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Mapping

from bpl.location import normalize_well_id
from bpl.lowering import (
    AdjustPH,
    Aspirate,
    Centrifuge,
    ContainerRef,
    Dispense,
    ExecutionPlan,
    HeatShock,
    Incubate,
    Location,
    Mix,
    OnIce,
    PickColonies,
    ReadAbsorbance,
    ReadFluorescence,
    RunPCR,
    SetTemperature,
    Weigh,
    WellRef,
)


@dataclass(frozen=True)
class SetupDiagnostic:
    """Deterministic setup validation diagnostic."""

    code: str
    message: str
    hint: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LabwareSetup:
    """Labware setup constraints."""

    capacity_ul: float


@dataclass(frozen=True)
class PipetteSetup:
    """Pipette setup constraints."""

    min_volume_ul: float
    max_volume_ul: float


@dataclass(frozen=True)
class ExperimentSetup:
    """Canonical experiment setup contract."""

    backend: str
    labware: dict[str, LabwareSetup]
    initial_volumes: dict[str, float]
    pipettes: dict[str, PipetteSetup]
    devices: dict[str, bool]


def load_experiment_setup(path: Path) -> tuple[ExperimentSetup | None, list[SetupDiagnostic]]:
    """Load and validate setup.json from disk."""
    if not path.exists():
        return (
            None,
            [
                SetupDiagnostic(
                    code="SETUP_FILE_NOT_FOUND",
                    message=f"Setup file not found: {path}",
                    hint="Provide an existing setup.json path.",
                )
            ],
        )

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return (
            None,
            [
                SetupDiagnostic(
                    code="SETUP_INVALID_JSON",
                    message=f"Invalid setup JSON: {exc}",
                    hint="Fix JSON syntax in setup file.",
                )
            ],
        )

    return parse_experiment_setup(payload)


def parse_experiment_setup(payload: object) -> tuple[ExperimentSetup | None, list[SetupDiagnostic]]:
    """Validate and parse setup payload into canonical setup model."""
    diagnostics: list[SetupDiagnostic] = []
    if not isinstance(payload, Mapping):
        return (
            None,
            [
                SetupDiagnostic(
                    code="SETUP_SCHEMA_INVALID",
                    message="Setup file must contain a top-level JSON object.",
                    hint="Use an object with backend/labware/initial_volumes/pipettes/devices fields.",
                )
            ],
        )

    required_keys = ("backend", "labware", "initial_volumes", "pipettes", "devices")
    missing_keys = [key for key in required_keys if key not in payload]
    if missing_keys:
        return (
            None,
            [
                SetupDiagnostic(
                    code="SETUP_MISSING_KEYS",
                    message=f"Setup missing required key(s): {', '.join(missing_keys)}",
                    hint="Add required setup top-level keys.",
                )
            ],
        )

    backend_value = payload.get("backend")
    if not isinstance(backend_value, str) or not backend_value.strip():
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message="Setup `backend` must be a non-empty string.",
                hint="Example: \"backend\": \"opentrons\".",
            )
        )
    backend = backend_value.strip() if isinstance(backend_value, str) else ""

    labware = _parse_labware(payload.get("labware"), diagnostics)
    pipettes = _parse_pipettes(payload.get("pipettes"), diagnostics)
    devices = _parse_devices(payload.get("devices"), diagnostics)
    initial_volumes = _parse_initial_volumes(
        payload.get("initial_volumes"),
        labware=labware,
        diagnostics=diagnostics,
    )

    if diagnostics:
        return None, diagnostics

    return (
        ExperimentSetup(
            backend=backend,
            labware=labware,
            initial_volumes=initial_volumes,
            pipettes=pipettes,
            devices=devices,
        ),
        [],
    )


def validate_plan_against_setup(
    plan: ExecutionPlan,
    setup: ExperimentSetup,
) -> list[SetupDiagnostic]:
    """Validate plan operations against setup constraints."""
    diagnostics: list[SetupDiagnostic] = []
    volume_state = dict(setup.initial_volumes)

    for step_id in plan.topological_order():
        step = plan.steps[step_id]
        primitive = step.primitive

        diagnostics.extend(_validate_labware_references(step_id, primitive, setup))
        diagnostics.extend(_validate_device_requirements(step_id, primitive, setup))

        if isinstance(primitive, (Aspirate, Dispense, Mix)):
            diagnostics.extend(
                _validate_pipette_range(
                    step_id=step_id,
                    volume_ul=primitive.volume_ul,
                    pipettes=setup.pipettes,
                )
            )

        if isinstance(primitive, Aspirate):
            diagnostics.extend(
                _validate_aspirate(
                    step_id=step_id,
                    primitive=primitive,
                    setup=setup,
                    volume_state=volume_state,
                )
            )
        elif isinstance(primitive, Dispense):
            diagnostics.extend(
                _validate_dispense(
                    step_id=step_id,
                    primitive=primitive,
                    setup=setup,
                    volume_state=volume_state,
                )
            )

    return diagnostics


def _parse_labware(
    payload: object,
    diagnostics: list[SetupDiagnostic],
) -> dict[str, LabwareSetup]:
    if not isinstance(payload, Mapping):
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message="Setup field `labware` must be an object map.",
                hint="Use JSON object shape for labware map.",
            )
        )
        return {}

    labware: dict[str, LabwareSetup] = {}
    for labware_id in sorted(payload.keys()):
        config = payload[labware_id]
        if not isinstance(labware_id, str) or not labware_id:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_LABWARE_CONFIG_INVALID",
                    message="Labware IDs must be non-empty strings.",
                    hint="Use stable labware identifiers like `plate_1`.",
                )
            )
            continue
        if not isinstance(config, Mapping):
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_LABWARE_CONFIG_INVALID",
                    message=f"Labware `{labware_id}` must be an object.",
                    hint="Define at least `capacity_ul` for each labware entry.",
                )
            )
            continue

        capacity_value = config.get("capacity_ul")
        capacity_ul = _coerce_positive_float(capacity_value)
        if capacity_ul is None:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_LABWARE_CONFIG_INVALID",
                    message=(
                        f"Labware `{labware_id}` must define positive numeric `capacity_ul`; "
                        f"got {capacity_value!r}."
                    ),
                    hint="Use a value greater than zero for `capacity_ul`.",
                )
            )
            continue
        labware[labware_id] = LabwareSetup(capacity_ul=capacity_ul)
    return labware


def _parse_pipettes(
    payload: object,
    diagnostics: list[SetupDiagnostic],
) -> dict[str, PipetteSetup]:
    if not isinstance(payload, Mapping):
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message="Setup field `pipettes` must be an object map.",
                hint="Use JSON object shape for pipette map.",
            )
        )
        return {}

    pipettes: dict[str, PipetteSetup] = {}
    for pipette_id in sorted(payload.keys()):
        config = payload[pipette_id]
        if not isinstance(config, Mapping):
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_PIPETTE_CONFIG_INVALID",
                    message=f"Pipette `{pipette_id}` must be an object.",
                    hint="Define `min_volume_ul` and `max_volume_ul` per pipette.",
                )
            )
            continue

        min_value = _coerce_positive_float(config.get("min_volume_ul"))
        max_value = _coerce_positive_float(config.get("max_volume_ul"))
        if min_value is None or max_value is None or max_value < min_value:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_PIPETTE_CONFIG_INVALID",
                    message=(
                        f"Pipette `{pipette_id}` has invalid range: "
                        f"{config.get('min_volume_ul')!r}..{config.get('max_volume_ul')!r}."
                    ),
                    hint="Require positive `min_volume_ul` and `max_volume_ul >= min_volume_ul`.",
                )
            )
            continue

        pipettes[pipette_id] = PipetteSetup(
            min_volume_ul=min_value,
            max_volume_ul=max_value,
        )
    return pipettes


def _parse_devices(
    payload: object,
    diagnostics: list[SetupDiagnostic],
) -> dict[str, bool]:
    if not isinstance(payload, Mapping):
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message="Setup field `devices` must be an object map.",
                hint="Use JSON object shape for devices map.",
            )
        )
        return {}

    devices: dict[str, bool] = {}
    for device_id in sorted(payload.keys()):
        value = payload[device_id]
        if isinstance(value, bool):
            devices[device_id] = value
            continue
        if isinstance(value, Mapping) and isinstance(value.get("available"), bool):
            devices[device_id] = bool(value["available"])
            continue
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message=(
                    f"Device `{device_id}` must be boolean or object with boolean "
                    "`available` field."
                ),
                hint="Example: \"thermocycler\": true.",
            )
        )
    return devices


def _parse_initial_volumes(
    payload: object,
    *,
    labware: dict[str, LabwareSetup],
    diagnostics: list[SetupDiagnostic],
) -> dict[str, float]:
    if not isinstance(payload, Mapping):
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SCHEMA_INVALID",
                message="Setup field `initial_volumes` must be an object map.",
                hint="Use location keys like `plate_1:A1` with numeric values.",
            )
        )
        return {}

    initial_volumes: dict[str, float] = {}
    for location_key in sorted(payload.keys()):
        raw_value = payload[location_key]
        if not isinstance(location_key, str):
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_INITIAL_VOLUME_INVALID",
                    message="Initial volume keys must be strings.",
                    hint="Use `<labware_id>:<well_or_slot>` keys.",
                )
            )
            continue
        location = _normalize_location_key(location_key)
        if location is None:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_INITIAL_VOLUME_INVALID",
                    message=f"Invalid initial volume key `{location_key}`.",
                    hint="Use `<labware_id>:<well_or_slot>` format.",
                )
            )
            continue

        volume_ul = _coerce_non_negative_float(raw_value)
        if volume_ul is None:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_INITIAL_VOLUME_INVALID",
                    message=(
                        f"Initial volume `{location_key}` must be non-negative numeric, "
                        f"got {raw_value!r}."
                    ),
                    hint="Use values >= 0 for initial volumes.",
                )
            )
            continue

        labware_id = location.split(":", 1)[0]
        labware_setup = labware.get(labware_id)
        if labware_setup is None:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_LABWARE_REFERENCE",
                    message=(
                        f"Initial volume references undefined labware `{labware_id}` "
                        f"via `{location_key}`."
                    ),
                    hint="Declare all referenced labware in setup.labware.",
                )
            )
            continue
        if volume_ul > labware_setup.capacity_ul:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_INITIAL_VOLUME_OVER_CAPACITY",
                    message=(
                        f"Initial volume {volume_ul} uL exceeds capacity "
                        f"{labware_setup.capacity_ul} uL for `{location_key}`."
                    ),
                    hint="Lower initial volume or increase labware capacity.",
                )
            )
            continue
        initial_volumes[location] = volume_ul
    return initial_volumes


def _validate_labware_references(
    step_id: str,
    primitive: object,
    setup: ExperimentSetup,
) -> list[SetupDiagnostic]:
    diagnostics: list[SetupDiagnostic] = []
    for labware_id in _referenced_labware_ids(primitive):
        if labware_id not in setup.labware:
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_LABWARE_REFERENCE",
                    message=(
                        f"Step `{step_id}` references labware `{labware_id}` "
                        f"not declared in setup."
                    ),
                    hint="Declare referenced labware in setup.labware.",
                    details={"step_id": step_id, "labware_id": labware_id},
                )
            )
    return diagnostics


def _validate_device_requirements(
    step_id: str,
    primitive: object,
    setup: ExperimentSetup,
) -> list[SetupDiagnostic]:
    diagnostics: list[SetupDiagnostic] = []
    for device_id in _required_device_ids(primitive):
        if not setup.devices.get(device_id, False):
            diagnostics.append(
                SetupDiagnostic(
                    code="SETUP_DEVICE_AVAILABILITY",
                    message=(
                        f"Step `{step_id}` requires unavailable device `{device_id}`."
                    ),
                    hint="Declare the device as available in setup.devices.",
                    details={"step_id": step_id, "device_id": device_id},
                )
            )
    return diagnostics


def _validate_pipette_range(
    *,
    step_id: str,
    volume_ul: float,
    pipettes: dict[str, PipetteSetup],
) -> list[SetupDiagnostic]:
    if volume_ul <= 0:
        return [
            SetupDiagnostic(
                code="SETUP_VOLUME_RANGE_INVALID",
                message=f"Step `{step_id}` has non-positive volume {volume_ul} uL.",
                hint="Use a volume greater than zero.",
                details={"step_id": step_id, "requested_volume_ul": volume_ul},
            )
        ]

    if not pipettes:
        return [
            SetupDiagnostic(
                code="SETUP_PIPETTE_RANGE",
                message=(
                    f"Step `{step_id}` volume {volume_ul} uL cannot be validated: no pipettes configured."
                ),
                hint="Define at least one pipette range in setup.pipettes.",
                details={"step_id": step_id, "requested_volume_ul": volume_ul},
            )
        ]

    min_supported = min(pipette.min_volume_ul for pipette in pipettes.values())
    max_supported = max(pipette.max_volume_ul for pipette in pipettes.values())
    if any(
        pipette.min_volume_ul <= volume_ul <= pipette.max_volume_ul
        for pipette in pipettes.values()
    ):
        return []

    return [
        SetupDiagnostic(
            code="SETUP_PIPETTE_RANGE",
            message=(
                f"Step `{step_id}` volume {volume_ul} uL is outside pipette range "
                f"[{min_supported}, {max_supported}] uL."
            ),
            hint="Adjust transfer volume or configure compatible pipette ranges.",
            details={
                "step_id": step_id,
                "requested_volume_ul": volume_ul,
                "min_supported_ul": min_supported,
                "max_supported_ul": max_supported,
            },
        )
    ]


def _validate_aspirate(
    *,
    step_id: str,
    primitive: Aspirate,
    setup: ExperimentSetup,
    volume_state: dict[str, float],
) -> list[SetupDiagnostic]:
    diagnostics: list[SetupDiagnostic] = []
    location_key = _location_key_from_location(primitive.source)
    if location_key is None:
        return diagnostics

    labware_id = location_key.split(":", 1)[0]
    if labware_id not in setup.labware:
        return diagnostics

    available = volume_state.get(location_key, 0.0)
    requested = primitive.volume_ul
    if requested > available:
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_SOURCE_INSUFFICIENCY",
                message=(
                    f"Step `{step_id}` requests {requested} uL from `{location_key}` "
                    f"but only {available} uL is available."
                ),
                hint="Reduce requested volume or increase source initial volume.",
                details={
                    "step_id": step_id,
                    "location": location_key,
                    "requested_ul": requested,
                    "available_ul": available,
                },
            )
        )
        return diagnostics

    volume_state[location_key] = available - requested
    return diagnostics


def _validate_dispense(
    *,
    step_id: str,
    primitive: Dispense,
    setup: ExperimentSetup,
    volume_state: dict[str, float],
) -> list[SetupDiagnostic]:
    diagnostics: list[SetupDiagnostic] = []
    location_key = _location_key_from_location(primitive.destination)
    if location_key is None:
        return diagnostics

    labware_id = location_key.split(":", 1)[0]
    labware_setup = setup.labware.get(labware_id)
    if labware_setup is None:
        return diagnostics

    current = volume_state.get(location_key, 0.0)
    requested = primitive.volume_ul
    capacity = labware_setup.capacity_ul
    if current + requested > capacity:
        diagnostics.append(
            SetupDiagnostic(
                code="SETUP_DESTINATION_OVERFLOW",
                message=(
                    f"Step `{step_id}` would overflow `{location_key}`: current {current} uL, "
                    f"add {requested} uL, max {capacity} uL."
                ),
                hint="Reduce transfer volume or increase destination capacity.",
                details={
                    "step_id": step_id,
                    "location": location_key,
                    "current_ul": current,
                    "requested_ul": requested,
                    "max_ul": capacity,
                },
            )
        )
        return diagnostics

    volume_state[location_key] = current + requested
    return diagnostics


def _referenced_labware_ids(primitive: object) -> list[str]:
    ids: list[str] = []
    if isinstance(primitive, Aspirate):
        ids.extend(_labware_ids_from_location(primitive.source))
    elif isinstance(primitive, Dispense):
        ids.extend(_labware_ids_from_location(primitive.destination))
    elif isinstance(primitive, Mix):
        ids.extend(_labware_ids_from_location(primitive.location))
    elif isinstance(primitive, Weigh):
        ids.append(primitive.container_id)
    elif isinstance(primitive, (ReadAbsorbance, ReadFluorescence)):
        ids.append(primitive.plate_id)
    elif isinstance(primitive, PickColonies):
        ids.append(primitive.source_plate)
        ids.extend(_labware_ids_from_location(primitive.destination))
    elif isinstance(primitive, AdjustPH):
        ids.append(primitive.container_id)
    elif isinstance(primitive, HeatShock):
        ids.extend(_labware_ids_from_location(primitive.target))
    elif isinstance(primitive, OnIce):
        ids.extend(_labware_ids_from_location(primitive.target))
    elif isinstance(primitive, RunPCR):
        ids.append(primitive.plate_id)
    return sorted(set(ids))


def _required_device_ids(primitive: object) -> list[str]:
    if isinstance(primitive, SetTemperature):
        return [primitive.device_id]
    if isinstance(primitive, Incubate):
        return [primitive.device_id]
    if isinstance(primitive, Centrifuge):
        return [primitive.device_id]
    if isinstance(primitive, HeatShock):
        return [primitive.device_id]
    if isinstance(primitive, RunPCR):
        return [primitive.device_id]
    if isinstance(primitive, (ReadAbsorbance, ReadFluorescence)):
        return ["plate_reader"]
    return []


def _labware_ids_from_location(location: Location) -> list[str]:
    if isinstance(location, WellRef):
        return [location.plate_id]
    if isinstance(location, ContainerRef):
        return [location.container_id]
    return []


def _location_key_from_location(location: Location) -> str | None:
    if isinstance(location, WellRef):
        normalized_well = normalize_well_id(location.well_id)
        return f"{location.plate_id}:{normalized_well}"
    if isinstance(location, ContainerRef):
        return f"{location.container_id}:_container"
    return None


def _normalize_location_key(location_key: str) -> str | None:
    if ":" not in location_key:
        return None
    labware_id, slot = location_key.split(":", 1)
    labware_id = labware_id.strip()
    slot = slot.strip()
    if not labware_id or not slot:
        return None
    if slot != "_container":
        try:
            slot = normalize_well_id(slot)
        except ValueError:
            return None
    return f"{labware_id}:{slot}"


def _coerce_positive_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        numeric = float(value)
        return numeric if numeric > 0 else None
    return None


def _coerce_non_negative_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        numeric = float(value)
        return numeric if numeric >= 0 else None
    return None
