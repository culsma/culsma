"""Compose compiled BPL plan payloads into human-readable markdown."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import json
import re
from typing import Any, cast

from bpl.capabilities import is_primitive_supported


def compose_plan_payload_markdown(payload: Mapping[str, Any]) -> str:
    """Compose a deterministic markdown protocol from a compiled plan payload."""

    plan_id = _as_non_empty_str(payload.get("plan_id")) or "plan"
    protocol_name = _as_non_empty_str(payload.get("protocol_name")) or "Protocol"
    target = _as_non_empty_str(payload.get("target")) or "human"
    steps = _normalize_steps(payload.get("steps"))
    records = [_step_record(index=i, step=step) for i, step in enumerate(steps, start=1)]
    manual_entries = _build_manual_intervention_entries(
        steps=steps,
        records=records,
        target=target,
    )
    if target.strip().lower() == "biomek":
        display_records = [
            record
            for step, record in zip(steps, records)
            if not _is_manual_intervention_step(step, record)
        ]
    else:
        display_records = list(records)

    lines: list[str] = [
        f"# {protocol_name} - Execution Protocol",
        "",
        "## Overview",
        "",
        "| Field | Value |",
        "|---|---|",
        f"| Protocol | {_escape_table(protocol_name)} |",
        f"| Plan ID | `{_escape_table(plan_id)}` |",
        f"| Target | `{_escape_table(target)}` |",
        f"| Total Steps | {len(records)} |",
    ]

    if not records:
        lines.extend(
            [
                "",
                "## Step Index",
                "",
                "No executable steps were found in this compiled plan payload.",
            ]
        )
        return "\n".join(lines) + "\n"

    primitive_counts: dict[str, int] = {}
    for record in records:
        primitive = record["primitive"]
        primitive_counts[primitive] = primitive_counts.get(primitive, 0) + 1

    lines.extend(
        [
            "",
            "## Primitive Distribution",
            "",
            "| Primitive | Count | Percent |",
            "|---|---:|---:|",
        ]
    )
    total_steps = len(records)
    for primitive in sorted(primitive_counts.keys()):
        count = primitive_counts[primitive]
        percent = (count / total_steps) * 100.0
        lines.append(f"| `{_escape_table(primitive)}` | {count} | {percent:.1f}% |")

    if target.strip().lower() == "biomek" and manual_entries:
        execution_blocks = _build_interleaved_execution_blocks(
            steps=steps,
            records=records,
            manual_entries=manual_entries,
        )
        lines.extend(
            _render_interleaved_execution_blocks(
                heading="Interleaved Manual + Biomek Execution",
                blocks=execution_blocks,
            )
        )
    else:
        lines.extend(
            [
                "",
                "## Step Index",
                "",
                "| # | Step ID | Primitive | Intent | Action | Source | Destination | Volume | Depends On |",
                "|---:|---|---|---|---|---|---|---|---|",
            ]
        )

        if not display_records:
            lines.extend(
                [
                    "| 1 | `-` | `-` | `-` | No biomek-automatable steps remain. | - | - | - | - |",
                ]
            )

        for record in display_records:
            dependencies = record["dependencies"]
            dependency_text = ", ".join(dependencies) if dependencies else "-"
            lines.append(
                "| "
                + " | ".join(
                    [
                        str(record["index"]),
                        f"`{_escape_table(record['step_id'])}`",
                        f"`{_escape_table(record['primitive'])}`",
                        f"`{_escape_table(record['intent'])}`",
                        _escape_table(_truncate(record["action"], 96)),
                        _escape_table(record["source"]),
                        _escape_table(record["destination"]),
                        _escape_table(record["volume"]),
                        _escape_table(_truncate(dependency_text, 80)),
                    ]
                )
                + " |"
            )

    transfer_events = _collect_transfer_events(steps)
    if transfer_events:
        lines.extend(_render_plate_map_view(transfer_events))

    spans = [
        record
        for record in display_records
        if isinstance(record["source_span"], str) and record["source_span"] != "-"
    ]
    if spans and len(display_records) <= 80:
        lines.extend(
            [
                "",
                "## Source Mapping",
                "",
                "| Step ID | Source Location |",
                "|---|---|",
            ]
        )
        for record in spans:
            lines.append(
                f"| `{_escape_table(record['step_id'])}` | `{_escape_table(record['source_span'])}` |"
            )
    elif spans:
        span_counts: dict[str, int] = {}
        for record in spans:
            span = str(record["source_span"])
            span_counts[span] = span_counts.get(span, 0) + 1

        lines.extend(
            [
                "",
                "## Source Mapping Summary",
                "",
                "_Detailed per-step source mapping omitted for readability on large plans._",
                "",
                "| Source Location | Step Count |",
                "|---|---:|",
            ]
        )
        ordered = sorted(span_counts.items(), key=lambda item: (-item[1], item[0]))
        for source_span, count in ordered:
            lines.append(f"| `{_escape_table(source_span)}` | {count} |")

    return "\n".join(lines) + "\n"


def compose_dual_target_markdown(
    *,
    human_payload: Mapping[str, Any],
    biomek_payload: Mapping[str, Any],
) -> str:
    """Compose a single markdown protocol containing both human and biomek targets."""

    human_protocol_name = _as_non_empty_str(human_payload.get("protocol_name"))
    biomek_protocol_name = _as_non_empty_str(biomek_payload.get("protocol_name"))
    protocol_name = human_protocol_name or biomek_protocol_name or "Protocol"

    human_plan_id = _as_non_empty_str(human_payload.get("plan_id")) or "human_plan"
    biomek_plan_id = _as_non_empty_str(biomek_payload.get("plan_id")) or "biomek_plan"

    human_steps = _normalize_steps(human_payload.get("steps"))
    biomek_steps = _normalize_steps(biomek_payload.get("steps"))
    human_records = [_step_record(index=i, step=step) for i, step in enumerate(human_steps, start=1)]
    biomek_records = [_step_record(index=i, step=step) for i, step in enumerate(biomek_steps, start=1)]
    manual_entries = _build_manual_intervention_entries(
        steps=biomek_steps,
        records=biomek_records,
        target="biomek",
    )
    biomek_automated_records = [
        record
        for step, record in zip(biomek_steps, biomek_records)
        if not _is_manual_intervention_step(step, record)
    ]

    lines: list[str] = [
        f"# {protocol_name} - Dual Target Execution Protocol",
        "",
        "## Overview",
        "",
        "| Field | Value |",
        "|---|---|",
        f"| Protocol | {_escape_table(protocol_name)} |",
        f"| Human Plan ID | `{_escape_table(human_plan_id)}` |",
        f"| Biomek Plan ID | `{_escape_table(biomek_plan_id)}` |",
        f"| Human Steps | {len(human_records)} |",
        f"| Biomek Steps | {len(biomek_records)} |",
        f"| Biomek Automated Steps | {len(biomek_automated_records)} |",
        f"| Manual Interventions | {len(manual_entries)} |",
    ]

    if manual_entries:
        execution_blocks = _build_interleaved_execution_blocks(
            steps=biomek_steps,
            records=biomek_records,
            manual_entries=manual_entries,
        )
        lines.extend(
            _render_interleaved_execution_blocks(
                heading="Interleaved Manual + Biomek Execution",
                blocks=execution_blocks,
            )
        )
    else:
        lines.extend(
            _render_collapsible_step_section(
                heading="Biomek Automated Steps",
                summary=f"Biomek Automated Steps ({len(biomek_automated_records)})",
                records=biomek_automated_records,
                empty_message="No biomek-automatable steps remain.",
            )
        )

    lines.extend(
        _render_collapsible_step_section(
            heading="Human Steps",
            summary=f"Human Steps ({len(human_records)})",
            records=human_records,
            empty_message="No executable steps were found.",
        )
    )

    transfer_events = _collect_transfer_events(biomek_steps if biomek_steps else human_steps)
    if transfer_events:
        lines.extend(_render_plate_map_view(transfer_events))

    return "\n".join(lines) + "\n"


def _normalize_steps(raw_steps: object) -> list[Mapping[str, Any]]:
    if isinstance(raw_steps, Mapping):
        entries: list[Mapping[str, Any]] = []
        for step_id in sorted(str(key) for key in raw_steps.keys()):
            step_payload = raw_steps.get(step_id)
            if not isinstance(step_payload, Mapping):
                raise ValueError(f"Step '{step_id}' must be an object.")
            merged = dict(step_payload)
            merged.setdefault("step_id", step_id)
            entries.append(merged)
        return entries

    if isinstance(raw_steps, Sequence) and not isinstance(raw_steps, (str, bytes, bytearray)):
        entries = []
        for index, step_payload in enumerate(raw_steps):
            if not isinstance(step_payload, Mapping):
                raise ValueError(f"Step at index {index} must be an object.")
            entries.append(step_payload)
        return entries

    raise ValueError("Plan payload 'steps' must be a list or object map.")


def _step_record(index: int, step: Mapping[str, Any]) -> dict[str, object]:
    step_id = _as_non_empty_str(step.get("step_id")) or f"step_{index:04d}"
    primitive_type = _primitive_type_name(step)
    intent = _as_non_empty_str(step.get("source_intent")) or "n/a"
    instruction = _instruction_from_step(step, primitive_type)
    dependencies = _dependencies(step.get("dependencies"))
    source_span = _format_source_span(step.get("annotations")) or "-"
    source, destination, volume = _step_io(step, primitive_type)
    return {
        "index": index,
        "step_id": step_id,
        "primitive": primitive_type,
        "intent": intent,
        "action": instruction,
        "source": source,
        "destination": destination,
        "volume": volume,
        "dependencies": dependencies,
        "source_span": source_span,
    }


def _build_manual_intervention_entries(
    *,
    steps: list[Mapping[str, Any]],
    records: list[dict[str, object]],
    target: str,
) -> list[dict[str, str]]:
    if target.strip().lower() != "biomek":
        return []

    raw_entries: list[dict[str, str]] = []
    for index, (step, record) in enumerate(zip(steps, records), start=1):
        if not _is_manual_intervention_step(step, record):
            continue

        manual_payload = _manual_intervention_payload(step)
        raw_action = (
            _as_non_empty_str(manual_payload.get("instruction"))
            if manual_payload is not None
            else None
        ) or str(record["action"])
        original_step_id = (
            _as_non_empty_str(manual_payload.get("original_step_id"))
            if manual_payload is not None
            else None
        ) or str(record["step_id"])
        original_primitive = (
            _as_non_empty_str(manual_payload.get("original_primitive"))
            if manual_payload is not None
            else None
        ) or str(record["primitive"])
        raw_entries.append(
            {
                "action": raw_action,
                "gate_primitive": str(record["primitive"]),
                "gate_step_id": str(record["step_id"]),
                "index": str(index),
                "original_primitive": original_primitive,
                "original_step_id": original_step_id,
            }
        )

    grouped: dict[tuple[str, str, str], dict[str, object]] = {}
    for entry in raw_entries:
        original_step_id = entry["original_step_id"]
        original_primitive = entry["original_primitive"]
        action = _humanize_action_text(entry["action"])
        key = (original_step_id, original_primitive, action)
        bucket = grouped.get(key)
        if bucket is None:
            grouped[key] = {
                "action": action,
                "first_index": int(entry["index"]),
                "gate_primitives": [entry["gate_primitive"]],
                "gate_steps": [entry["gate_step_id"]],
                "original_primitive": original_primitive,
                "original_step_id": original_step_id,
            }
            continue

        gate_primitives = cast(list[str], bucket["gate_primitives"])
        gate_steps = cast(list[str], bucket["gate_steps"])
        gate_primitives.append(entry["gate_primitive"])
        gate_steps.append(entry["gate_step_id"])

    merged: list[dict[str, str]] = []
    for bucket in sorted(grouped.values(), key=lambda item: cast(int, item["first_index"])):
        gate_primitives = cast(list[str], bucket["gate_primitives"])
        gate_steps = cast(list[str], bucket["gate_steps"])
        merged.append(
            {
                "action": cast(str, bucket["action"]),
                "gate_primitive": " + ".join(sorted(set(gate_primitives))),
                "gate_step_id": ", ".join(gate_steps),
                "original_primitive": cast(str, bucket["original_primitive"]),
                "original_step_id": cast(str, bucket["original_step_id"]),
            }
        )
    return merged


def _render_manual_interventions_table(entries: list[dict[str, str]]) -> list[str]:
    lines = [
        "",
        "## Manual Interventions",
        "",
        "| # | Manual Intervention | Original Step | Gate Structure |",
        "|---:|---|---|---|",
    ]
    for index, entry in enumerate(entries, start=1):
        gate_structure = (
            f"`{_escape_table(entry['gate_primitive'])}` via `{_escape_table(entry['gate_step_id'])}`"
        )
        lines.append(
            "| "
            + " | ".join(
                [
                    str(index),
                    _escape_table(_truncate(entry["action"], 160)),
                    f"`{_escape_table(entry['original_step_id'])}` (`{_escape_table(entry['original_primitive'])}`)",
                    gate_structure,
                ]
            )
            + " |"
        )
    return lines


def _build_interleaved_execution_blocks(
    *,
    steps: list[Mapping[str, Any]],
    records: list[dict[str, object]],
    manual_entries: list[dict[str, str]],
) -> list[dict[str, object]]:
    gate_step_to_entry: dict[str, dict[str, str]] = {}
    for entry in manual_entries:
        for gate_step_id in _split_gate_step_ids(entry.get("gate_step_id", "")):
            gate_step_to_entry[gate_step_id] = entry

    blocks: list[dict[str, object]] = []
    for step, record in zip(steps, records):
        step_id = str(record["step_id"])
        manual_entry = gate_step_to_entry.get(step_id)
        is_manual_step = manual_entry is not None or _is_manual_intervention_step(step, record)

        if is_manual_step:
            normalized_manual_entry = manual_entry or _fallback_manual_entry(record)
            manual_key = _manual_entry_key(normalized_manual_entry)
            if not blocks or str(blocks[-1].get("kind")) != "manual":
                blocks.append(
                    {
                        "kind": "manual",
                        "entries": [normalized_manual_entry],
                        "keys": {manual_key},
                    }
                )
                continue

            existing_keys = cast(set[tuple[str, str, str]], blocks[-1].setdefault("keys", set()))
            if manual_key not in existing_keys:
                cast(list[dict[str, str]], blocks[-1].setdefault("entries", [])).append(
                    normalized_manual_entry
                )
                existing_keys.add(manual_key)
            continue

        if not blocks or str(blocks[-1].get("kind")) != "biomek":
            blocks.append(
                {
                    "kind": "biomek",
                    "records": [record],
                }
            )
            continue

        cast(list[dict[str, object]], blocks[-1].setdefault("records", [])).append(record)

    for block in blocks:
        block.pop("keys", None)
    return blocks


def _split_gate_step_ids(text: str) -> list[str]:
    return [item.strip() for item in text.split(",") if item.strip()]


def _manual_entry_key(entry: Mapping[str, str]) -> tuple[str, str, str]:
    return (
        entry.get("original_step_id", "-"),
        entry.get("original_primitive", "-"),
        entry.get("action", ""),
    )


def _fallback_manual_entry(record: Mapping[str, object]) -> dict[str, str]:
    action = _humanize_action_text(str(record["action"]))
    primitive = str(record["primitive"])
    step_id = str(record["step_id"])
    return {
        "action": action,
        "gate_primitive": primitive,
        "gate_step_id": step_id,
        "original_primitive": primitive,
        "original_step_id": step_id,
    }


def _render_interleaved_execution_blocks(
    *,
    heading: str,
    blocks: list[dict[str, object]],
) -> list[str]:
    lines: list[str] = [
        "",
        f"## {heading}",
    ]
    if not blocks:
        lines.extend(
            [
                "",
                "No biomek execution blocks were generated.",
            ]
        )
        return lines

    for block_index, block in enumerate(blocks, start=1):
        block_kind = str(block.get("kind", ""))
        if block_kind == "manual":
            manual_entries = cast(list[dict[str, str]], block.get("entries", []))
            summary = f"Block {block_index}: Manual Interventions ({len(manual_entries)} item(s))"
            lines.extend(
                [
                    "",
                    "<details>",
                    f"<summary>{_escape_table(summary)}</summary>",
                    "",
                    "| # | Manual Intervention | Original Step | Gate Structure |",
                    "|---:|---|---|---|",
                ]
            )
            if not manual_entries:
                lines.append("| 1 | - | `-` (`-`) | `-` via `-` |")
            else:
                for entry_index, entry in enumerate(manual_entries, start=1):
                    gate_structure = (
                        f"`{_escape_table(entry['gate_primitive'])}`"
                        f" via `{_escape_table(entry['gate_step_id'])}`"
                    )
                    lines.append(
                        "| "
                        + " | ".join(
                            [
                                str(entry_index),
                                _escape_table(_truncate(entry["action"], 160)),
                                (
                                    f"`{_escape_table(entry['original_step_id'])}` "
                                    f"(`{_escape_table(entry['original_primitive'])}`)"
                                ),
                                gate_structure,
                            ]
                        )
                        + " |"
                    )
            lines.extend(
                [
                    "",
                    "</details>",
                ]
            )
            continue

        automated_records = cast(list[dict[str, object]], block.get("records", []))
        summary = f"Block {block_index}: Biomek Automated Steps ({len(automated_records)} step(s))"
        lines.extend(
            [
                "",
                "<details>",
                f"<summary>{_escape_table(summary)}</summary>",
                "",
                "| # | Step ID | Primitive | Action | Depends On |",
                "|---:|---|---|---|---|",
            ]
        )
        if not automated_records:
            lines.append("| 1 | `-` | `-` | No biomek automated step in this block. | - |")
        else:
            for step_index, record in enumerate(automated_records, start=1):
                dependencies = record.get("dependencies")
                if isinstance(dependencies, list):
                    dependency_text = ", ".join(str(dep) for dep in dependencies)
                else:
                    dependency_text = "-"
                if not dependency_text:
                    dependency_text = "-"
                lines.append(
                    "| "
                    + " | ".join(
                        [
                            str(step_index),
                            f"`{_escape_table(str(record['step_id']))}`",
                            f"`{_escape_table(str(record['primitive']))}`",
                            _escape_table(_truncate(str(record["action"]), 120)),
                            _escape_table(_truncate(dependency_text, 80)),
                        ]
                    )
                    + " |"
                )
        lines.extend(
            [
                "",
                "</details>",
            ]
        )
    return lines


def _render_collapsible_step_section(
    *,
    heading: str,
    summary: str,
    records: list[dict[str, object]],
    empty_message: str,
) -> list[str]:
    lines = [
        "",
        f"## {heading}",
        "",
        "<details>",
        f"<summary>{_escape_table(summary)}</summary>",
        "",
        "| # | Step ID | Primitive | Action | Depends On |",
        "|---:|---|---|---|---|",
    ]

    if not records:
        lines.append(f"| 1 | `-` | `-` | {_escape_table(empty_message)} | - |")
    else:
        for row_index, record in enumerate(records, start=1):
            dependencies = record["dependencies"]
            dependency_text = ", ".join(dependencies) if isinstance(dependencies, list) else "-"
            lines.append(
                "| "
                + " | ".join(
                    [
                        str(row_index),
                        f"`{_escape_table(str(record['step_id']))}`",
                        f"`{_escape_table(str(record['primitive']))}`",
                        _escape_table(_truncate(str(record["action"]), 120)),
                        _escape_table(_truncate(dependency_text, 80)),
                    ]
                )
                + " |"
            )

    lines.extend(
        [
            "",
            "</details>",
        ]
    )
    return lines


def _humanize_action_text(action: str) -> str:
    text = action.strip()
    if not text:
        return "Perform the required manual action."

    parsed = _parse_call_style_action(text)
    if parsed is None:
        if text.endswith("."):
            return text
        return f"{text}."

    name, args = parsed
    verb = name.lower()
    if verb == "centrifuge":
        target = args.get("target") or args.get("plate")
        speed = args.get("speed")
        duration = args.get("duration")
        detail_parts: list[str] = []
        if speed:
            detail_parts.append(f"at {speed}")
        if duration:
            detail_parts.append(f"for {duration}")
        return _build_sentence(
            action="Centrifuge",
            target=target,
            details=[" ".join(detail_parts) if detail_parts else None],
        )
    if verb == "vortex":
        target = args.get("target") or args.get("sample")
        duration = args.get("duration")
        return _build_sentence(
            action="Vortex",
            target=target,
            details=[f"for {duration}" if duration else None],
        )
    if verb == "thermocycle":
        target = args.get("plate") or args.get("target")
        return _build_sentence(
            action="Run thermocycler program on",
            target=target,
            details=[],
        )
    if verb == "incubate":
        target = args.get("plate") or args.get("target")
        temperature = args.get("temperature")
        duration = args.get("duration")
        shaking = args.get("shaking")
        return _build_sentence(
            action="Incubate",
            target=target,
            details=[
                f"at {temperature}" if temperature else None,
                f"for {duration}" if duration else None,
                f"with shaking at {shaking}" if shaking else None,
            ],
        )
    if verb == "spread_plate":
        source = args.get("from")
        dest = args.get("to")
        volume = args.get("volume")
        details: list[str | None] = []
        if source and dest:
            details.append(f"from {source} to {dest}")
        elif dest:
            details.append(f"to {dest}")
        if volume:
            details.append(f"using {volume}")
        return _build_sentence(action="Spread plate", target=None, details=details)
    if verb == "purify":
        target = args.get("plate") or args.get("target")
        return _build_sentence(action="Purify sample from", target=target, details=[])

    generic_action = name.replace("_", " ")
    details = [f"{key}={value}" for key, value in args.items()]
    return _build_sentence(action=f"Perform {generic_action}", target=None, details=details)


def _parse_call_style_action(text: str) -> tuple[str, dict[str, str]] | None:
    match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)\((.*)\)", text)
    if match is None:
        return None
    name = match.group(1)
    body = match.group(2).strip()
    if not body:
        return name, {}
    args: dict[str, str] = {}
    for chunk in _split_outside_nested(body):
        if ":" not in chunk:
            continue
        key, value = chunk.split(":", 1)
        key_norm = key.strip().lower()
        value_norm = value.strip()
        if key_norm and value_norm:
            args[key_norm] = value_norm
    return name, args


def _split_outside_nested(text: str) -> list[str]:
    parts: list[str] = []
    start = 0
    depth = 0
    for index, char in enumerate(text):
        if char in "([{":
            depth += 1
        elif char in ")]}":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            parts.append(text[start:index].strip())
            start = index + 1
    parts.append(text[start:].strip())
    return [part for part in parts if part]


def _build_sentence(
    *,
    action: str,
    target: str | None,
    details: list[str | None],
) -> str:
    fragments: list[str] = []
    if target:
        fragments.append(f"{action} {target}")
    else:
        fragments.append(action)

    detail_text = ", ".join(detail for detail in details if detail)
    if detail_text:
        fragments.append(detail_text)

    sentence = " ".join(fragments).strip()
    sentence = sentence[0].upper() + sentence[1:] if sentence else "Perform manual operation"
    if not sentence.endswith("."):
        sentence += "."
    return sentence


def _is_manual_intervention_step(
    step: Mapping[str, Any],
    record: Mapping[str, object],
) -> bool:
    if _manual_intervention_payload(step) is not None:
        return True

    primitive = str(record["primitive"]).strip().upper()
    if primitive in {"HUMAN_STEP", "PAUSE", "CHECKPOINT", "RESUME"}:
        return True

    try:
        return not is_primitive_supported(primitive, "biomek")
    except Exception:
        return True


def _manual_intervention_payload(step: Mapping[str, Any]) -> Mapping[str, Any] | None:
    annotations = step.get("annotations")
    if not isinstance(annotations, Mapping):
        return None
    manual = annotations.get("manual_intervention")
    if isinstance(manual, Mapping):
        return manual
    return None


def _collect_transfer_events(steps: list[Mapping[str, Any]]) -> list[dict[str, object]]:
    by_step_id: dict[str, Mapping[str, Any]] = {}
    for step in steps:
        step_id = _as_non_empty_str(step.get("step_id"))
        if step_id is not None:
            by_step_id[step_id] = step

    events: list[dict[str, object]] = []
    for step in steps:
        if _primitive_type_name(step) != "DISPENSE":
            continue

        primitive = step.get("primitive")
        if not isinstance(primitive, Mapping):
            continue
        destination = _extract_well_ref(primitive.get("destination"))
        if destination is None:
            continue

        volume_ul = _as_float(primitive.get("volume_ul"))
        if volume_ul is None:
            continue

        source: tuple[str, str] | None = None
        for dep_id in _dependencies(step.get("dependencies")):
            dep_step = by_step_id.get(dep_id)
            if dep_step is None or _primitive_type_name(dep_step) != "ASPIRATE":
                continue
            dep_primitive = dep_step.get("primitive")
            if not isinstance(dep_primitive, Mapping):
                continue
            source = _extract_well_ref(dep_primitive.get("source"))
            if source is not None:
                break

        if source is None:
            continue

        source_plate, source_well = source
        dest_plate, dest_well = destination
        events.append(
            {
                "source_plate": source_plate,
                "source_well": source_well,
                "destination_plate": dest_plate,
                "destination_well": dest_well,
                "volume_ul": volume_ul,
            }
        )

    return events


def _render_plate_map_view(transfer_events: list[dict[str, object]]) -> list[str]:
    lines: list[str] = [
        "",
        "## Plate Map View",
        "",
        "_Cell legend: `Nx/VuL` where `N` is transfer count and `V` is total volume in uL._",
        "",
        "### Plate-to-Plate Summary",
        "",
        "| Source Plate | Destination Plate | Transfer Count | Total Volume (uL) |",
        "|---|---|---:|---:|",
    ]

    pair_stats: dict[tuple[str, str], dict[str, float]] = {}
    for event in transfer_events:
        source_plate = str(event["source_plate"])
        destination_plate = str(event["destination_plate"])
        key = (source_plate, destination_plate)
        bucket = pair_stats.setdefault(key, {"count": 0.0, "volume_ul": 0.0})
        bucket["count"] += 1.0
        bucket["volume_ul"] += float(event["volume_ul"])

    ordered_pairs = sorted(pair_stats.items(), key=lambda item: (item[0][0], item[0][1]))
    for (source_plate, destination_plate), stats in ordered_pairs:
        lines.append(
            "| "
            + " | ".join(
                [
                    f"`{_escape_table(source_plate)}`",
                    f"`{_escape_table(destination_plate)}`",
                    str(int(stats["count"])),
                    f"{stats['volume_ul']:.3g}",
                ]
            )
            + " |"
        )

    source_maps = _aggregate_plate_well_stats(transfer_events, role="source")
    destination_maps = _aggregate_plate_well_stats(transfer_events, role="destination")

    if source_maps:
        lines.extend(["", "### Source Wells (Outgoing)"])
        for plate_id in sorted(source_maps.keys()):
            lines.extend(_render_single_plate_map(plate_id, source_maps[plate_id]))

    if destination_maps:
        lines.extend(["", "### Destination Wells (Incoming)"])
        for plate_id in sorted(destination_maps.keys()):
            lines.extend(_render_single_plate_map(plate_id, destination_maps[plate_id]))

    return lines


def _aggregate_plate_well_stats(
    transfer_events: list[dict[str, object]],
    *,
    role: str,
) -> dict[str, dict[tuple[str, int], dict[str, float]]]:
    plate_maps: dict[str, dict[tuple[str, int], dict[str, float]]] = {}
    for event in transfer_events:
        if role == "source":
            plate = str(event["source_plate"])
            well = str(event["source_well"])
        else:
            plate = str(event["destination_plate"])
            well = str(event["destination_well"])

        row_col = _well_row_col(well)
        if row_col is None:
            continue

        well_stats = plate_maps.setdefault(plate, {})
        slot = well_stats.setdefault(row_col, {"count": 0.0, "volume_ul": 0.0})
        slot["count"] += 1.0
        slot["volume_ul"] += float(event["volume_ul"])

    return plate_maps


def _render_single_plate_map(
    plate_id: str,
    well_stats: dict[tuple[str, int], dict[str, float]],
) -> list[str]:
    rows = "ABCDEFGH"
    cols = list(range(1, 13))

    lines = [
        "",
        f"#### `{_escape_table(plate_id)}`",
        "",
        "| Row/Col | " + " | ".join(str(col) for col in cols) + " |",
        "|" + "---|" * (len(cols) + 1),
    ]

    for row in rows:
        cells: list[str] = []
        for col in cols:
            entry = well_stats.get((row, col))
            if entry is None:
                cells.append(".")
                continue
            count = int(entry["count"])
            volume = f"{entry['volume_ul']:.3g}"
            cells.append(f"{count}x/{volume}uL")
        lines.append(f"| {row} | " + " | ".join(cells) + " |")

    return lines


def _step_io(step: Mapping[str, Any], primitive_type: str) -> tuple[str, str, str]:
    primitive = step.get("primitive")
    if not isinstance(primitive, Mapping):
        return "-", "-", "-"

    normalized = primitive_type.upper()
    if normalized == "ASPIRATE":
        return (
            _format_location(primitive.get("source")) or "-",
            "-",
            _format_volume(primitive.get("volume_ul")) or "-",
        )
    if normalized == "DISPENSE":
        return (
            "-",
            _format_location(primitive.get("destination")) or "-",
            _format_volume(primitive.get("volume_ul")) or "-",
        )
    if normalized == "MIX":
        location = _format_location(primitive.get("location")) or "-"
        return (location, location, _format_volume(primitive.get("volume_ul")) or "-")
    if normalized == "WAIT":
        duration = _format_number(primitive.get("duration_s"))
        return ("-", "-", f"{duration} s" if duration is not None else "-")

    source = (
        _format_location(primitive.get("source"))
        or _format_location(primitive.get("from"))
        or "-"
    )
    destination = (
        _format_location(primitive.get("destination"))
        or _format_location(primitive.get("to"))
        or "-"
    )
    volume = _format_volume(primitive.get("volume_ul")) or "-"
    return source, destination, volume


def _primitive_type_name(step: Mapping[str, Any]) -> str:
    primitive_type = step.get("primitive_type")
    if isinstance(primitive_type, str) and primitive_type:
        return primitive_type.strip().upper()

    primitive = step.get("primitive")
    if isinstance(primitive, Mapping):
        nested_type = primitive.get("primitive_type")
        if isinstance(nested_type, str) and nested_type:
            return nested_type.strip().upper()

    return "HUMAN_STEP"


def _instruction_from_step(step: Mapping[str, Any], primitive_type: str) -> str:
    primitive = step.get("primitive")
    if isinstance(primitive, Mapping):
        rendered = _instruction_from_primitive(primitive_type=primitive_type, primitive=primitive)
        if rendered is not None:
            return rendered

    intent = _as_non_empty_str(step.get("source_intent"))
    if intent is not None:
        return f"Execute '{intent}'"
    return f"Execute {primitive_type.lower().replace('_', ' ')}"


def _instruction_from_primitive(
    *,
    primitive_type: str,
    primitive: Mapping[str, Any],
) -> str | None:
    normalized = primitive_type.strip().upper()

    if normalized == "ASPIRATE":
        source = _format_location(primitive.get("source"))
        volume = _format_volume(primitive.get("volume_ul"))
        if source is None or volume is None:
            return None
        return f"Aspirate {volume} from {source}"

    if normalized == "DISPENSE":
        destination = _format_location(primitive.get("destination"))
        volume = _format_volume(primitive.get("volume_ul"))
        if destination is None or volume is None:
            return None
        return f"Dispense {volume} into {destination}"

    if normalized == "MIX":
        location = _format_location(primitive.get("location"))
        cycles = _format_number(primitive.get("cycles"))
        volume = _format_volume(primitive.get("volume_ul"))
        if location is None:
            return None
        if cycles is not None and volume is not None:
            return f"Mix {cycles}x at {location} using {volume}"
        if cycles is not None:
            return f"Mix {cycles}x at {location}"
        return f"Mix at {location}"

    if normalized == "WAIT":
        duration = _format_number(primitive.get("duration_s"))
        if duration is None:
            return None
        return f"Wait for {duration} s"

    if normalized == "PICK_TIPS":
        rack = _format_tip_rack(primitive.get("tip_rack"))
        positions = _format_string_list(primitive.get("tip_positions"))
        if rack is None:
            return None
        if positions:
            return f"Pick tips from {rack} at {positions}"
        return f"Pick tips from {rack}"

    if normalized == "DROP_TIPS":
        to_waste = primitive.get("to_waste")
        if isinstance(to_waste, bool):
            if to_waste:
                return "Drop tips to waste"
            return "Drop tips to rack"
        return "Drop tips"

    if normalized == "MOVE_LABWARE":
        labware_id = _as_non_empty_str(primitive.get("labware_id"))
        from_position = _as_non_empty_str(primitive.get("from_position"))
        to_position = _as_non_empty_str(primitive.get("to_position"))
        if labware_id is None or to_position is None:
            return None
        if from_position is None:
            return f"Move {labware_id} to {to_position}"
        return f"Move {labware_id} from {from_position} to {to_position}"

    if normalized == "SET_TEMPERATURE":
        device_id = _as_non_empty_str(primitive.get("device_id"))
        temperature = _format_number(primitive.get("temperature_c"))
        if device_id is None or temperature is None:
            return None
        return f"Set {device_id} to {temperature} degC"

    if normalized == "INCUBATE":
        device_id = _as_non_empty_str(primitive.get("device_id"))
        temperature = _format_number(primitive.get("temperature_c"))
        duration = _format_number(primitive.get("duration_s"))
        if device_id is None:
            return None
        details: list[str] = []
        if temperature is not None:
            details.append(f"{temperature} degC")
        if duration is not None:
            details.append(f"{duration} s")
        if not details:
            return f"Incubate on {device_id}"
        return f"Incubate on {device_id} ({', '.join(details)})"

    if normalized == "HUMAN_STEP":
        instruction = _as_non_empty_str(primitive.get("instruction"))
        if instruction is not None:
            return instruction
        return "Manual execution step"

    if normalized == "PAUSE":
        reason = _as_non_empty_str(primitive.get("reason"))
        if reason is not None:
            return f"Pause: {reason}"
        return "Pause execution"

    if normalized == "RESUME":
        return "Resume execution"

    if normalized == "CHECKPOINT":
        checkpoint_id = _as_non_empty_str(primitive.get("checkpoint_id"))
        if checkpoint_id is not None:
            return f"Create checkpoint {checkpoint_id}"
        return "Create checkpoint"

    detail_text = _format_primitive_details(primitive)
    humanized = normalized.lower().replace("_", " ")
    if detail_text:
        return f"Execute {humanized} ({detail_text})"
    return f"Execute {humanized}"


def _format_primitive_details(primitive: Mapping[str, Any]) -> str:
    pairs: list[str] = []
    for key in sorted(primitive.keys()):
        if key in {"__type__", "primitive_type"}:
            continue
        value = _format_compact_value(primitive.get(key))
        if value is None:
            continue
        pairs.append(f"{key}={value}")
    return ", ".join(pairs)


def _format_compact_value(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return _format_number(value)
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        location = _format_location(value)
        if location is not None:
            return location
        return json.dumps(dict(value), sort_keys=True)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        rendered_items = []
        for item in value:
            rendered = _format_compact_value(item)
            if rendered is not None:
                rendered_items.append(rendered)
        return "[" + ", ".join(rendered_items) + "]"
    return str(value)


def _format_location(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, str) and value:
        return value
    if isinstance(value, Mapping):
        plate_id = _as_non_empty_str(value.get("plate_id"))
        well_id = _as_non_empty_str(value.get("well_id"))
        if plate_id is not None and well_id is not None:
            return f"{plate_id}:{well_id}"

        container_id = _as_non_empty_str(value.get("container_id"))
        if container_id is not None:
            return container_id

        rack_id = _as_non_empty_str(value.get("rack_id"))
        if rack_id is not None:
            return rack_id
    return None


def _format_tip_rack(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        rack_id = _as_non_empty_str(value.get("rack_id"))
        tip_type = _as_non_empty_str(value.get("tip_type"))
        if rack_id is None:
            return None
        if tip_type is None:
            return rack_id
        return f"{rack_id} ({tip_type})"
    return None


def _format_string_list(value: object) -> str | None:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        return None
    entries = [item for item in value if isinstance(item, str) and item]
    if not entries:
        return None
    return ", ".join(entries)


def _format_volume(value: object) -> str | None:
    number = _format_number(value)
    if number is None:
        return None
    return f"{number} uL"


def _format_number(value: object) -> str | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return f"{value:g}"
    return None


def _dependencies(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str) and item]


def _format_source_span(annotations: object) -> str | None:
    if not isinstance(annotations, Mapping):
        return None
    span = annotations.get("source_span")
    if not isinstance(span, Mapping):
        return None

    file = _as_non_empty_str(span.get("file"))
    start_line = _format_number(span.get("start_line"))
    end_line = _format_number(span.get("end_line"))

    if file is None or start_line is None:
        return None
    if end_line is None or end_line == start_line:
        return f"{file}:{start_line}"
    return f"{file}:{start_line}-{end_line}"


def _extract_well_ref(value: object) -> tuple[str, str] | None:
    if not isinstance(value, Mapping):
        return None
    plate_id = _as_non_empty_str(value.get("plate_id"))
    well_id = _as_non_empty_str(value.get("well_id"))
    if plate_id is None or well_id is None:
        return None
    return plate_id, well_id.upper()


def _well_row_col(well_id: str) -> tuple[str, int] | None:
    match = re.fullmatch(r"([A-Za-z])0*([1-9]|1[0-2])", well_id.strip())
    if match is None:
        return None
    row = match.group(1).upper()
    col = int(match.group(2))
    if row < "A" or row > "H":
        return None
    return row, col


def _as_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _as_non_empty_str(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if not stripped:
        return None
    return stripped


def _escape_table(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", "<br>")


def _truncate(value: str, max_len: int) -> str:
    if len(value) <= max_len:
        return value
    if max_len <= 1:
        return value[:max_len]
    return value[: max_len - 1] + "…"
