"""
Worklist exporter for generating CSV/Excel files from BPL protocols.

This module exports transfer operations from BPL Plan IR to standard worklist
formats compatible with lab automation systems (Biomek, Hamilton, etc.).
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import math
import csv
import io

from bpl.export.transfer_modes import TransferMode
from bpl.export.volume_constraints import VolumeConstraints, VolumeTracker
from bpl.location import export_well_ref_to_canonical, normalize_well_id


class WorklistFormat(Enum):
    """Output format for worklist files."""

    CSV = auto()
    EXCEL = auto()

    def __str__(self) -> str:
        return self.name.lower()


class WorklistError(Exception):
    """Error during worklist generation."""

    pass


@dataclass
class WorklistConfig:
    """Configuration for worklist export."""

    format: WorklistFormat = WorklistFormat.CSV
    include_metadata: bool = True
    include_set_identifier: bool = True
    sort_by: List[str] = field(
        default_factory=lambda: ["destination_plate", "destination_well"]
    )
    csv_delimiter: str = ","
    volume_constraints: Optional[VolumeConstraints] = None
    initial_volumes_ul: Dict[str, float] = field(default_factory=dict)


@dataclass
class WorklistRow:
    """
    Single row in a worklist.

    Represents one transfer operation from source to destination.
    """

    source_plate: str
    source_well: Optional[str]
    destination_plate: str
    destination_well: Optional[str]
    transfer_volume_ul: float
    set_identifier: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self, include_set_id: bool = True) -> Dict[str, Any]:
        """Convert row to dictionary for CSV export."""
        d = {
            "source_plate": self.source_plate,
            "source_well": self.source_well or "",
            "destination_plate": self.destination_plate,
            "destination_well": self.destination_well or "",
            "transfer_volume_uL": self.transfer_volume_ul,
        }
        if include_set_id and self.set_identifier:
            d["set_identifier"] = self.set_identifier
        d.update(self.metadata)
        return d


@dataclass
class WellRef:
    """Reference to a well in a plate."""

    plate: str
    well: str

    def __post_init__(self) -> None:
        self.well = normalize_well_id(self.well)

    def __str__(self) -> str:
        return f"{self.plate}:{self.well}"

    def to_canonical(self, plate_format: str | None = None):
        """Convert to canonical location DTO."""
        return export_well_ref_to_canonical(self, plate_format=plate_format)

    @classmethod
    def from_canonical(cls, address):
        """Create export WellRef from canonical location DTO."""
        return cls(plate=address.labware_id, well=address.well)


@dataclass
class WorklistResult:
    """Result of worklist export."""

    success: bool
    content: str
    filename: str
    row_count: int
    format: WorklistFormat = WorklistFormat.CSV
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        return len(self.warnings) > 0


class WorklistExporter:
    """
    Export BPL transfer operations to worklist CSV/Excel files.

    Supports multiple export patterns:
    - Stamp: Full plate-to-plate transfer (no well specification)
    - Cherrypick: Specific well-to-well transfers
    - Serial dilution: Multi-step dilution chains
    """

    def __init__(self, config: Optional[WorklistConfig] = None):
        """
        Initialize worklist exporter.

        Args:
            config: Export configuration (defaults to WorklistConfig())
        """
        self.config = config or WorklistConfig()
        self._labware_registry: Dict[str, Any] = {}

    def register_labware(
        self,
        plate_id: str,
        barcode: Optional[str] = None,
        set_identifier: Optional[str] = None,
    ) -> None:
        """
        Register labware metadata for worklist generation.

        Args:
            plate_id: Internal plate identifier
            barcode: External barcode (used in worklist output)
            set_identifier: Batch/set grouping identifier
        """
        self._labware_registry[plate_id] = {
            "barcode": barcode,
            "set_identifier": set_identifier,
        }

    def get_plate_barcode(self, plate_id: str) -> str:
        """Get barcode for a plate, falling back to plate_id if not registered."""
        metadata = self._labware_registry.get(plate_id, {})
        return metadata.get("barcode") or plate_id

    def get_set_identifier(self, plate_id: str) -> Optional[str]:
        """Get set identifier for a plate."""
        metadata = self._labware_registry.get(plate_id, {})
        return metadata.get("set_identifier")

    def export_with_mode(
        self,
        sources: List[WellRef],
        destinations: List[WellRef],
        volume_ul: float,
        mode: TransferMode,
        set_identifier: Optional[str] = None,
    ) -> List[WorklistRow]:
        """
        Generate worklist rows based on transfer mode.

        Args:
            sources: List of source well references
            destinations: List of destination well references
            volume_ul: Transfer volume in microliters
            mode: Transfer mode (ONE_TO_ONE, ONE_TO_MANY, MANY_TO_ONE)
            set_identifier: Optional set identifier to apply

        Returns:
            List of WorklistRow for the transfers

        Raises:
            WorklistError: If mode constraints aren't met
        """
        if mode == TransferMode.ONE_TO_ONE:
            if len(sources) != len(destinations):
                raise WorklistError(
                    f"ONE_TO_ONE requires equal source/dest counts: "
                    f"got {len(sources)} sources, {len(destinations)} destinations"
                )
            rows = [
                WorklistRow(
                    source_plate=self.get_plate_barcode(src.plate),
                    source_well=src.well,
                    destination_plate=self.get_plate_barcode(dst.plate),
                    destination_well=dst.well,
                    transfer_volume_ul=volume_ul,
                    set_identifier=set_identifier or self.get_set_identifier(src.plate),
                )
                for src, dst in zip(sources, destinations)
            ]
            self._validate_rows_with_constraints(rows)
            return rows

        elif mode == TransferMode.ONE_TO_MANY:
            if len(sources) != 1:
                raise WorklistError(
                    f"ONE_TO_MANY requires exactly 1 source, got {len(sources)}"
                )
            src = sources[0]
            rows = [
                WorklistRow(
                    source_plate=self.get_plate_barcode(src.plate),
                    source_well=src.well,
                    destination_plate=self.get_plate_barcode(dst.plate),
                    destination_well=dst.well,
                    transfer_volume_ul=volume_ul,
                    set_identifier=set_identifier or self.get_set_identifier(src.plate),
                )
                for dst in destinations
            ]
            self._validate_rows_with_constraints(rows)
            return rows

        elif mode == TransferMode.MANY_TO_ONE:
            if len(destinations) != 1:
                raise WorklistError(
                    f"MANY_TO_ONE requires exactly 1 destination, got {len(destinations)}"
                )
            dst = destinations[0]
            rows = [
                WorklistRow(
                    source_plate=self.get_plate_barcode(src.plate),
                    source_well=src.well,
                    destination_plate=self.get_plate_barcode(dst.plate),
                    destination_well=dst.well,
                    transfer_volume_ul=volume_ul,
                    set_identifier=set_identifier or self.get_set_identifier(src.plate),
                )
                for src in sources
            ]
            self._validate_rows_with_constraints(rows)
            return rows

        else:
            raise WorklistError(f"Unknown transfer mode: {mode}")

    def _validate_rows_with_constraints(self, rows: List[WorklistRow]) -> None:
        """Validate generated rows with configured volume constraints."""
        for row in rows:
            if row.transfer_volume_ul <= 0:
                raise WorklistError(
                    f"Invalid transfer volume {row.transfer_volume_ul} uL; volume must be positive"
                )

        constraints = self.config.volume_constraints
        if constraints is None:
            return

        tracker = VolumeTracker(constraints)

        for index, row in enumerate(rows, start=1):
            source_id = self._row_well_id(row.source_plate, row.source_well)
            destination_id = self._row_well_id(row.destination_plate, row.destination_well)

            if not tracker.has_container(source_id):
                tracker.set_initial_volume(
                    source_id,
                    self.config.initial_volumes_ul.get(source_id, math.inf),
                )

            if not tracker.has_container(destination_id):
                tracker.set_initial_volume(
                    destination_id,
                    self.config.initial_volumes_ul.get(destination_id, 0.0),
                )

            is_valid, error = tracker.can_transfer(
                source_id=source_id,
                dest_id=destination_id,
                transfer_volume_ul=row.transfer_volume_ul,
            )
            if not is_valid:
                raise WorklistError(f"Transfer {index} volume validation failed: {error}")

            tracker.record_transfer(source_id, destination_id, row.transfer_volume_ul)

    def _row_well_id(self, plate: str, well: Optional[str]) -> str:
        if well:
            return f"{plate}:{well}"
        return plate

    def export_stamp(
        self,
        source_plate: str,
        dest_plate: str,
        volume_ul: float,
        set_identifier: Optional[str] = None,
    ) -> WorklistResult:
        """
        Generate stamp worklist (plate-level, no wells specified).

        A stamp operation transfers the entire plate without specifying
        individual wells - useful for 1:1 plate replication.

        Args:
            source_plate: Source plate identifier
            dest_plate: Destination plate identifier
            volume_ul: Transfer volume per well
            set_identifier: Optional set identifier

        Returns:
            WorklistResult with CSV content
        """
        row = WorklistRow(
            source_plate=self.get_plate_barcode(source_plate),
            source_well=None,
            destination_plate=self.get_plate_barcode(dest_plate),
            destination_well=None,
            transfer_volume_ul=volume_ul,
            set_identifier=set_identifier or self.get_set_identifier(source_plate),
        )

        return self._format_result(
            rows=[row],
            filename=f"stamp_{source_plate}_to_{dest_plate}.csv",
            include_wells=False,
        )

    def export_cherrypick(
        self,
        source_plate: str,
        source_wells: List[str],
        dest_plate: str,
        dest_wells: List[str],
        volume_ul: float,
        set_identifier: Optional[str] = None,
    ) -> WorklistResult:
        """
        Generate cherrypick worklist (specific well-to-well transfers).

        Args:
            source_plate: Source plate identifier
            source_wells: List of source well IDs (e.g., ["A1", "B3", "C5"])
            dest_plate: Destination plate identifier
            dest_wells: List of destination well IDs
            volume_ul: Transfer volume
            set_identifier: Optional set identifier

        Returns:
            WorklistResult with CSV content
        """
        sources = [WellRef(source_plate, w) for w in source_wells]
        destinations = [WellRef(dest_plate, w) for w in dest_wells]

        rows = self.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=volume_ul,
            mode=TransferMode.ONE_TO_ONE,
            set_identifier=set_identifier,
        )

        return self._format_result(
            rows=rows,
            filename=f"cherrypick_{source_plate}_to_{dest_plate}.csv",
            include_wells=True,
        )

    def export_serial_dilution(
        self,
        source_plate: str,
        dest_plates: List[str],
        volume_ul: float,
        well_count: int = 96,
        set_identifier: Optional[str] = None,
    ) -> List[WorklistResult]:
        """
        Generate serial dilution worklist files.

        Creates one worklist per dilution step for multi-plate serial dilution.

        Args:
            source_plate: Initial source plate
            dest_plates: List of destination plates in dilution order
            volume_ul: Transfer volume per step
            well_count: Number of wells (96 or 384)
            set_identifier: Optional set identifier

        Returns:
            List of WorklistResult (one per dilution step)
        """
        results = []
        current_source = source_plate

        for i, dest_plate in enumerate(dest_plates):
            # Generate wells based on well_count
            wells = self._generate_wells(well_count)
            sources = [WellRef(current_source, w) for w in wells]
            destinations = [WellRef(dest_plate, w) for w in wells]

            rows = self.export_with_mode(
                sources=sources,
                destinations=destinations,
                volume_ul=volume_ul,
                mode=TransferMode.ONE_TO_ONE,
                set_identifier=set_identifier,
            )

            result = self._format_result(
                rows=rows,
                filename=f"serial_dilution_step_{i + 1}_{current_source}_to_{dest_plate}.csv",
                include_wells=True,
            )
            results.append(result)

            # Next step uses this plate as source
            current_source = dest_plate

        return results

    def export_distribute(
        self,
        source_plate: str,
        source_well: str,
        dest_plate: str,
        dest_wells: List[str],
        volume_ul: float,
        set_identifier: Optional[str] = None,
    ) -> WorklistResult:
        """
        Generate distribution worklist (1 source → N destinations).

        Args:
            source_plate: Source plate identifier
            source_well: Source well ID
            dest_plate: Destination plate identifier
            dest_wells: List of destination well IDs
            volume_ul: Transfer volume
            set_identifier: Optional set identifier

        Returns:
            WorklistResult with CSV content
        """
        sources = [WellRef(source_plate, source_well)]
        destinations = [WellRef(dest_plate, w) for w in dest_wells]

        rows = self.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=volume_ul,
            mode=TransferMode.ONE_TO_MANY,
            set_identifier=set_identifier,
        )

        return self._format_result(
            rows=rows,
            filename=f"distribute_{source_plate}_{source_well}_to_{dest_plate}.csv",
            include_wells=True,
        )

    def export_pool(
        self,
        source_plate: str,
        source_wells: List[str],
        dest_plate: str,
        dest_well: str,
        volume_ul: float,
        set_identifier: Optional[str] = None,
    ) -> WorklistResult:
        """
        Generate pooling worklist (N sources → 1 destination).

        Args:
            source_plate: Source plate identifier
            source_wells: List of source well IDs
            dest_plate: Destination plate identifier
            dest_well: Destination well ID
            volume_ul: Transfer volume per source
            set_identifier: Optional set identifier

        Returns:
            WorklistResult with CSV content
        """
        sources = [WellRef(source_plate, w) for w in source_wells]
        destinations = [WellRef(dest_plate, dest_well)]

        rows = self.export_with_mode(
            sources=sources,
            destinations=destinations,
            volume_ul=volume_ul,
            mode=TransferMode.MANY_TO_ONE,
            set_identifier=set_identifier,
        )

        return self._format_result(
            rows=rows,
            filename=f"pool_{source_plate}_to_{dest_plate}_{dest_well}.csv",
            include_wells=True,
        )

    def _generate_wells(self, well_count: int) -> List[str]:
        """Generate well IDs for a plate."""
        if well_count == 96:
            rows = "ABCDEFGH"
            cols = range(1, 13)
        elif well_count == 384:
            rows = "ABCDEFGHIJKLMNOP"
            cols = range(1, 25)
        else:
            # Default to 96-well format
            rows = "ABCDEFGH"
            cols = range(1, 13)

        return [f"{row}{col}" for row in rows for col in cols]

    def _format_result(
        self,
        rows: List[WorklistRow],
        filename: str,
        include_wells: bool = True,
    ) -> WorklistResult:
        """Format rows into CSV content."""
        if self.config.format == WorklistFormat.CSV:
            content = self._to_csv(rows, include_wells)
        else:
            # Excel support would go here
            content = self._to_csv(rows, include_wells)
            filename = filename.replace(".csv", ".xlsx")

        return WorklistResult(
            success=True,
            content=content,
            filename=filename,
            row_count=len(rows),
            format=self.config.format,
        )

    def _to_csv(self, rows: List[WorklistRow], include_wells: bool = True) -> str:
        """Convert rows to CSV string."""
        if not rows:
            return ""

        output = io.StringIO()

        # Determine fieldnames
        if include_wells:
            fieldnames = [
                "source_plate",
                "source_well",
                "destination_plate",
                "destination_well",
                "transfer_volume_uL",
            ]
        else:
            fieldnames = [
                "source_plate",
                "destination_plate",
                "transfer_volume_uL",
            ]

        if self.config.include_set_identifier:
            fieldnames.append("set_identifier")

        # Add any metadata fields from first row
        if rows and rows[0].metadata:
            fieldnames.extend(rows[0].metadata.keys())

        writer = csv.DictWriter(
            output,
            fieldnames=fieldnames,
            delimiter=self.config.csv_delimiter,
            extrasaction="ignore",
        )
        writer.writeheader()

        for row in rows:
            row_dict = row.to_dict(include_set_id=self.config.include_set_identifier)
            if not include_wells:
                row_dict.pop("source_well", None)
                row_dict.pop("destination_well", None)
            writer.writerow(row_dict)

        return output.getvalue()

    def save_to_file(
        self,
        result: WorklistResult,
        output_dir: Union[str, Path],
    ) -> Path:
        """
        Save worklist result to file.

        Args:
            result: WorklistResult to save
            output_dir: Directory to save to

        Returns:
            Path to saved file
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        output_path = output_dir / result.filename
        output_path.write_text(result.content, encoding="utf-8")

        return output_path
