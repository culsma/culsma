"""
Transfer modes for worklist generation.

Defines the three transfer modes matching production automation systems:
- ONE_TO_ONE: N sources → N destinations (paired/zip)
- ONE_TO_MANY: 1 source → N destinations (broadcast/replicate)
- MANY_TO_ONE: N sources → 1 destination (pool/consolidate)
"""

from enum import Enum, auto


class TransferMode(Enum):
    """
    Transfer mode for worklist operations.

    These modes define how source and destination wells are paired:

    ONE_TO_ONE:
        N sources → N destinations (paired by index)
        source[0] → dest[0], source[1] → dest[1], ...
        Requires equal source and destination counts.
        Example: Transferring samples from tube rack to plate in order.

    ONE_TO_MANY:
        1 source → N destinations (broadcast/replicate)
        source[0] → dest[0], source[0] → dest[1], ...
        Requires exactly 1 source.
        Example: Distributing master mix to multiple wells.

    MANY_TO_ONE:
        N sources → 1 destination (pool/consolidate)
        source[0] → dest[0], source[1] → dest[0], ...
        Requires exactly 1 destination.
        Example: Pooling samples from multiple wells into one tube.
    """

    ONE_TO_ONE = auto()
    ONE_TO_MANY = auto()
    MANY_TO_ONE = auto()

    def __str__(self) -> str:
        return self.name

    @classmethod
    def from_string(cls, value: str) -> "TransferMode":
        """
        Parse transfer mode from string.

        Args:
            value: String representation (case-insensitive)

        Returns:
            TransferMode enum value

        Raises:
            ValueError: If value doesn't match any mode
        """
        value_upper = value.upper().replace("-", "_")
        try:
            return cls[value_upper]
        except KeyError:
            valid = ", ".join(m.name for m in cls)
            raise ValueError(f"Invalid transfer mode: {value}. Valid modes: {valid}")

    @property
    def description(self) -> str:
        """Human-readable description of the transfer mode."""
        descriptions = {
            TransferMode.ONE_TO_ONE: "N sources → N destinations (paired)",
            TransferMode.ONE_TO_MANY: "1 source → N destinations (broadcast)",
            TransferMode.MANY_TO_ONE: "N sources → 1 destination (pool)",
        }
        return descriptions[self]
