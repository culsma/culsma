"""
Volume constraints for worklist generation.

Provides models for tracking volume usage and enforcing physical constraints
during worklist export, such as minimum transfer volumes and dead volumes.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class VolumeConstraints:
    """
    Volume constraints for worklist generation.

    These constraints model physical limitations of liquid handling systems:
    - minimum_volume_ul: Smallest volume that can be accurately transferred
    - tip_residual_coefficient: Fraction of volume lost to tip residue
    - max_volume_per_well_ul: Maximum volume a destination well can hold
    """

    minimum_volume_ul: float = 20.0
    tip_residual_coefficient: float = 0.2
    max_volume_per_well_ul: float = 160.0

    @property
    def dead_volume_ul(self) -> float:
        """
        Calculate dead volume for a given transfer.

        Dead volume is the minimum amount that must remain in a source
        container to ensure accurate aspiration.
        """
        return self.minimum_volume_ul

    def required_source_volume(self, transfer_volume_ul: float) -> float:
        """
        Calculate minimum source volume needed for a transfer.

        Args:
            transfer_volume_ul: Desired transfer volume in microliters

        Returns:
            Minimum source volume required (dead volume + transfer + residual)
        """
        return self.dead_volume_ul + (1 + self.tip_residual_coefficient) * transfer_volume_ul

    def validate_transfer(
        self,
        transfer_volume_ul: float,
        source_volume_ul: float,
        dest_current_volume_ul: float = 0.0,
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate that a transfer is physically possible.

        Args:
            transfer_volume_ul: Volume to transfer
            source_volume_ul: Available volume in source
            dest_current_volume_ul: Current volume in destination

        Returns:
            Tuple of (is_valid, error_message or None)
        """
        # Check minimum volume
        if transfer_volume_ul < self.minimum_volume_ul:
            return (
                False,
                f"Transfer volume {transfer_volume_ul} uL below minimum {self.minimum_volume_ul} uL",
            )

        # Check source has enough
        required = self.required_source_volume(transfer_volume_ul)
        if source_volume_ul < required:
            return (
                False,
                f"Source volume {source_volume_ul} uL insufficient (need {required} uL)",
            )

        # Check destination won't overflow
        final_dest_volume = dest_current_volume_ul + transfer_volume_ul
        if final_dest_volume > self.max_volume_per_well_ul:
            return (
                False,
                f"Destination would overflow: {final_dest_volume} uL > {self.max_volume_per_well_ul} uL max",
            )

        return (True, None)


class VolumeTracker:
    """
    Track cumulative volume usage per container.

    Used during worklist generation to ensure transfers don't exceed
    available source volumes or overflow destinations.
    """

    def __init__(self, constraints: Optional[VolumeConstraints] = None):
        """
        Initialize volume tracker.

        Args:
            constraints: Volume constraints to use (defaults to VolumeConstraints())
        """
        self.constraints = constraints or VolumeConstraints()
        self._used_volumes: Dict[str, float] = {}
        self._current_volumes: Dict[str, float] = {}

    def set_initial_volume(self, container_id: str, volume_ul: float) -> None:
        """
        Set the initial volume for a container.

        Args:
            container_id: Container identifier
            volume_ul: Initial volume in microliters
        """
        self._current_volumes[container_id] = volume_ul
        self._used_volumes[container_id] = 0.0

    def has_container(self, container_id: str) -> bool:
        """Return whether a container is being tracked."""
        return container_id in self._current_volumes

    def get_available_volume(self, container_id: str) -> float:
        """
        Get available volume in a container.

        Args:
            container_id: Container identifier

        Returns:
            Available volume (initial - used - dead volume)
        """
        initial = self._current_volumes.get(container_id, 0.0)
        used = self._used_volumes.get(container_id, 0.0)
        return max(0.0, initial - used - self.constraints.dead_volume_ul)

    def can_transfer(
        self,
        source_id: str,
        dest_id: str,
        transfer_volume_ul: float,
    ) -> Tuple[bool, Optional[str]]:
        """
        Check if a transfer is possible given current volumes.

        Args:
            source_id: Source container identifier
            dest_id: Destination container identifier
            transfer_volume_ul: Volume to transfer

        Returns:
            Tuple of (is_valid, error_message or None)
        """
        source_volume = self._current_volumes.get(source_id, 0.0)
        source_used = self._used_volumes.get(source_id, 0.0)
        dest_volume = self._current_volumes.get(dest_id, 0.0)

        return self.constraints.validate_transfer(
            transfer_volume_ul=transfer_volume_ul,
            source_volume_ul=source_volume - source_used,
            dest_current_volume_ul=dest_volume,
        )

    def record_transfer(
        self,
        source_id: str,
        dest_id: str,
        volume_ul: float,
    ) -> None:
        """
        Record a transfer for volume tracking.

        Updates used volumes and current volumes to reflect the transfer.

        Args:
            source_id: Source container identifier
            dest_id: Destination container identifier
            volume_ul: Volume transferred
        """
        # Update source used volume (including residual)
        effective_volume = volume_ul * (1 + self.constraints.tip_residual_coefficient)
        current_used = self._used_volumes.get(source_id, 0.0)
        self._used_volumes[source_id] = current_used + effective_volume

        # Update destination volume
        current_dest = self._current_volumes.get(dest_id, 0.0)
        self._current_volumes[dest_id] = current_dest + volume_ul

    def reset(self) -> None:
        """Reset all tracked volumes."""
        self._used_volumes.clear()
        self._current_volumes.clear()

    def get_summary(self) -> Dict[str, Dict[str, float]]:
        """
        Get a summary of all tracked containers.

        Returns:
            Dict mapping container_id to {initial, used, remaining}
        """
        summary = {}
        for container_id in set(self._current_volumes.keys()) | set(self._used_volumes.keys()):
            initial = self._current_volumes.get(container_id, 0.0)
            used = self._used_volumes.get(container_id, 0.0)
            summary[container_id] = {
                "initial_ul": initial,
                "used_ul": used,
                "remaining_ul": max(0.0, initial - used),
            }
        return summary
