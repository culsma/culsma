"""
Format-specific exporters for worklist files.

This module provides formatters for CSV and Excel worklist output.
Excel support requires the 'excel' optional dependency: pip install bpl[excel]
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from io import BytesIO, StringIO
from typing import TYPE_CHECKING, List, Literal, Optional
import csv

if TYPE_CHECKING:
    from bpl.export.worklist_exporter import WorklistRow


@dataclass
class FormatConfig:
    """Base configuration for formatters."""

    include_set_identifier: bool = True
    include_wells: bool = True


@dataclass
class CSVConfig(FormatConfig):
    """Configuration for CSV output."""

    delimiter: str = ","
    quoting: Literal[0, 1, 2, 3] = csv.QUOTE_MINIMAL
    encoding: str = "utf-8"


@dataclass
class ExcelConfig(FormatConfig):
    """Configuration for Excel output."""

    sheet_name: str = "Worklist"
    header_style: str = "bold"
    auto_column_width: bool = True


class WorklistFormatter(ABC):
    """Abstract base class for worklist formatters."""

    @abstractmethod
    def format(
        self,
        rows: List["WorklistRow"],
        config: FormatConfig,
    ) -> bytes:
        """
        Format worklist rows to bytes.

        Args:
            rows: List of WorklistRow objects
            config: Format-specific configuration

        Returns:
            Formatted output as bytes
        """
        pass

    @abstractmethod
    def get_extension(self) -> str:
        """Get file extension for this format."""
        pass

    def _get_fieldnames(self, config: FormatConfig) -> List[str]:
        """Get field names based on configuration."""
        if config.include_wells:
            fieldnames = [
                "source_plate",
                "source_well",
                "destination_plate",
                "destination_well",
                "transfer_volume_uL",
            ]
        else:
            fieldnames = [
                "source_plate",
                "destination_plate",
                "transfer_volume_uL",
            ]

        if config.include_set_identifier:
            fieldnames.append("set_identifier")

        return fieldnames


class CSVFormatter(WorklistFormatter):
    """CSV formatter for worklist output."""

    def format(
        self,
        rows: List["WorklistRow"],
        config: Optional[FormatConfig] = None,
    ) -> bytes:
        """
        Format worklist rows to CSV bytes.

        Args:
            rows: List of WorklistRow objects
            config: CSV configuration (defaults to CSVConfig())

        Returns:
            CSV content as UTF-8 bytes
        """
        if config is None:
            config = CSVConfig()

        if not isinstance(config, CSVConfig):
            # Convert base config to CSV config
            config = CSVConfig(
                include_set_identifier=config.include_set_identifier,
                include_wells=config.include_wells,
            )

        if not rows:
            return b""

        output = StringIO()
        fieldnames = self._get_fieldnames(config)

        # Add metadata fields from first row if present
        if rows[0].metadata:
            fieldnames.extend(rows[0].metadata.keys())

        writer = csv.DictWriter(
            output,
            fieldnames=fieldnames,
            delimiter=config.delimiter,
            quoting=config.quoting,
            extrasaction="ignore",
        )
        writer.writeheader()

        for row in rows:
            row_dict = row.to_dict(include_set_id=config.include_set_identifier)
            if not config.include_wells:
                row_dict.pop("source_well", None)
                row_dict.pop("destination_well", None)
            writer.writerow(row_dict)

        return output.getvalue().encode(config.encoding)

    def get_extension(self) -> str:
        return ".csv"


class ExcelFormatter(WorklistFormatter):
    """
    Excel formatter for worklist output.

    Requires openpyxl: pip install bpl[excel]
    """

    def __init__(self):
        """Initialize Excel formatter, checking for openpyxl dependency."""
        self._openpyxl = None

    def _ensure_openpyxl(self):
        """Lazy import openpyxl to avoid hard dependency."""
        if self._openpyxl is None:
            try:
                import openpyxl
                from openpyxl.styles import Font, PatternFill
                from openpyxl.utils.cell import get_column_letter

                self._openpyxl = openpyxl
                self._Font = Font
                self._PatternFill = PatternFill
                self._get_column_letter = get_column_letter
            except ImportError:
                raise ImportError(
                    "Excel export requires openpyxl. "
                    "Install with: pip install bpl[excel]"
                )

    def format(
        self,
        rows: List["WorklistRow"],
        config: Optional[FormatConfig] = None,
    ) -> bytes:
        """
        Format worklist rows to Excel bytes.

        Args:
            rows: List of WorklistRow objects
            config: Excel configuration (defaults to ExcelConfig())

        Returns:
            Excel workbook as bytes
        """
        self._ensure_openpyxl()
        assert self._openpyxl is not None

        if config is None:
            config = ExcelConfig()

        if not isinstance(config, ExcelConfig):
            # Convert base config to Excel config
            config = ExcelConfig(
                include_set_identifier=config.include_set_identifier,
                include_wells=config.include_wells,
            )

        openpyxl = self._openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        assert ws is not None
        ws.title = config.sheet_name

        fieldnames = self._get_fieldnames(config)

        # Add metadata fields from first row if present
        if rows and rows[0].metadata:
            fieldnames.extend(rows[0].metadata.keys())

        # Write header
        header_font = self._Font(bold=True)
        header_fill = self._PatternFill(
            start_color="CCCCCC", end_color="CCCCCC", fill_type="solid"
        )

        for col_idx, header in enumerate(fieldnames, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            if config.header_style == "bold":
                cell.font = header_font
                cell.fill = header_fill

        # Write data rows
        for row_idx, row in enumerate(rows, start=2):
            row_dict = row.to_dict(include_set_id=config.include_set_identifier)
            if not config.include_wells:
                row_dict.pop("source_well", None)
                row_dict.pop("destination_well", None)

            for col_idx, field in enumerate(fieldnames, start=1):
                value = row_dict.get(field, "")
                ws.cell(row=row_idx, column=col_idx, value=value)

        # Auto-size columns
        if config.auto_column_width:
            for col_idx, header in enumerate(fieldnames, start=1):
                max_length = len(header)
                for row in ws.iter_rows(
                    min_row=2, max_row=len(rows) + 1, min_col=col_idx, max_col=col_idx
                ):
                    for cell in row:
                        if cell.value:
                            max_length = max(max_length, len(str(cell.value)))
                # Add some padding
                col_letter = self._get_column_letter(col_idx)
                ws.column_dimensions[col_letter].width = max_length + 2

        # Save to bytes
        output = BytesIO()
        wb.save(output)
        return output.getvalue()

    def get_extension(self) -> str:
        return ".xlsx"


def get_formatter(format_type: str) -> WorklistFormatter:
    """
    Get a formatter for the specified format type.

    Args:
        format_type: "csv" or "excel"

    Returns:
        Appropriate WorklistFormatter instance

    Raises:
        ValueError: If format_type is unknown
    """
    format_type = format_type.lower()

    if format_type in ("csv", "text"):
        return CSVFormatter()
    elif format_type in ("excel", "xlsx", "xls"):
        return ExcelFormatter()
    else:
        raise ValueError(
            f"Unknown format type: {format_type}. Supported: csv, excel"
        )


def is_excel_available() -> bool:
    """Check if Excel export is available (openpyxl installed)."""
    try:
        import openpyxl  # noqa: F401

        return True
    except ImportError:
        return False
