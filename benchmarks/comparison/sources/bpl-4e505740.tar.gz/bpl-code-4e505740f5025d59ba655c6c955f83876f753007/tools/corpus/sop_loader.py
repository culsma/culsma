"""SOP Loader - Parse SOP markdown files from docs/ folder as seeds for dataset generation."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class Reagent:
    """A reagent extracted from an SOP."""
    name: str
    name_cn: Optional[str] = None
    cas: Optional[str] = None
    concentration: Optional[str] = None
    mass: Optional[str] = None


@dataclass
class SOPDocument:
    """A parsed SOP document."""
    sop_id: str  # e.g., "SOP-RD-013"
    title: str  # e.g., "LB培养基的配置"
    title_en: Optional[str] = None
    raw_content: str = ""
    purpose: str = ""
    scope: str = ""
    reagents: List[Reagent] = field(default_factory=list)
    equipment: List[str] = field(default_factory=list)
    steps: List[str] = field(default_factory=list)
    sections: Dict[str, str] = field(default_factory=dict)


def extract_title(content: str) -> tuple[str, Optional[str]]:
    """Extract title from first heading. Returns (title_cn, title_en)."""
    # Match first # heading
    match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if not match:
        return ("Unknown", None)

    title = match.group(1).strip()

    # Some titles have format: "SOP-RD-013 LB培养基的配置"
    # Remove SOP ID prefix if present
    title = re.sub(r'^SOP-\w+-\d+\s*', '', title).strip()

    # Check if there's an English title (some SOPs have both)
    # e.g., "分枝杆菌菌种转化流程" or "Biomek i7 Operation Biomek Procedure"
    if re.search(r'[a-zA-Z]{3,}', title):
        # Likely English or mixed
        return (title, title)

    return (title, None)


def extract_sections(content: str) -> Dict[str, Dict[str, str]]:
    """Extract numbered sections from SOP."""
    sections = {}

    # Pattern for section headers: ## 1. 目的, ## 4.1 Equipment, etc.
    section_pattern = r'^##\s+(\d+(?:\.\d+)*\.?)\s+(.+?)$'

    matches = list(re.finditer(section_pattern, content, re.MULTILINE))

    for i, match in enumerate(matches):
        section_num = match.group(1).rstrip('.')
        section_title = match.group(2).strip()

        # Get content until next section
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        section_content = content[start:end].strip()

        sections[section_num] = {
            'title': section_title,
            'content': section_content
        }

    return sections


def extract_reagents(content: str) -> List[Reagent]:
    """Extract reagents from markdown tables."""
    reagents = []

    # Pattern for table rows with reagent info
    # Common formats:
    # | 胰蛋白胨 Tryptone (Oxoid) | CAS 91079-40-2 |
    # | LB | 胰蛋白胨 Tryptone (Oxoid) | 91079-40-2 | 10 g | 10 g/L |

    # Find all table rows
    table_rows = re.findall(r'^\|(.+)\|$', content, re.MULTILINE)

    for row in table_rows:
        cells = [c.strip() for c in row.split('|')]
        cells = [c for c in cells if c]  # Remove empty cells

        if len(cells) < 2:
            continue

        # Skip header rows
        if any(h in cells[0].lower() for h in ['试剂', 'reagent', '组成', '溶液', 'solution', '---', '人员', 'personnel']):
            continue

        # Try to extract reagent info
        reagent = None
        cas = None
        concentration = None
        mass = None

        for cell in cells:
            # Check for CAS number
            cas_match = re.search(r'(?:CAS\s*)?(\d{2,7}-\d{2}-\d)', cell)
            if cas_match:
                cas = cas_match.group(1)
                continue

            # Check for concentration (g/L, mg/mL, etc.)
            conc_match = re.search(r'(\d+(?:\.\d+)?\s*(?:g/L|mg/mL|mg/L|mM|M|%|ug/mL|μg/mL))', cell, re.IGNORECASE)
            if conc_match:
                concentration = conc_match.group(1)
                continue

            # Check for mass (10 g, 5 mL, etc.)
            mass_match = re.search(r'^(\d+(?:\.\d+)?\s*(?:g|mg|mL|uL|L))$', cell.strip())
            if mass_match:
                mass = mass_match.group(1)
                continue

            # Otherwise, might be reagent name
            if len(cell) > 2 and not cell.replace('-', '').isdigit():
                # Extract Chinese and English names
                name_cn = None
                name_en = None

                # Pattern: "胰蛋白胨 Tryptone (Oxoid)"
                cn_en_match = re.match(r'([^\x00-\x7F]+)\s+([A-Za-z].+)', cell)
                if cn_en_match:
                    name_cn = cn_en_match.group(1).strip()
                    name_en = cn_en_match.group(2).strip()
                    reagent = Reagent(name=name_en, name_cn=name_cn)
                elif re.search(r'[^\x00-\x7F]', cell):
                    # Chinese only
                    reagent = Reagent(name=cell, name_cn=cell)
                elif re.search(r'[A-Za-z]', cell):
                    # English only
                    reagent = Reagent(name=cell)

        if reagent:
            if cas:
                reagent.cas = cas
            if concentration:
                reagent.concentration = concentration
            if mass:
                reagent.mass = mass
            reagents.append(reagent)

    return reagents


def extract_equipment(content: str) -> List[str]:
    """Extract equipment list from SOP."""
    equipment = []

    # Look for equipment section
    equip_section = re.search(
        r'(?:仪器|设备|Equipment|Instrument).*?\n((?:[-•*]\s*.+\n?)+)',
        content,
        re.IGNORECASE | re.DOTALL
    )

    if equip_section:
        items = re.findall(r'[-•*]\s*(.+)', equip_section.group(1))
        equipment.extend([item.strip() for item in items if item.strip()])

    # Also look for numbered equipment lists
    equip_numbered = re.findall(
        r'^\s*(?:\d+\.)+\d*\s*(.+?(?:仪|机|锅|箱|柜|计|器|泵|仪器|Equipment|Instrument|System).+?)$',
        content,
        re.MULTILINE | re.IGNORECASE
    )
    equipment.extend([item.strip() for item in equip_numbered if item.strip()])

    return list(set(equipment))


def extract_steps(content: str) -> List[str]:
    """Extract procedure steps from SOP."""
    steps = []

    # Look for step patterns:
    # a) Step text
    # - Step text
    # 4.2.1 Step text

    # Pattern for lettered steps: a), b), c) etc.
    letter_steps = re.findall(r'^([a-z]\))\s*(.+?)(?=\n[a-z]\)|$)', content, re.MULTILINE | re.DOTALL)
    for letter, step_text in letter_steps:
        clean_step = step_text.strip().replace('\n', ' ')
        if clean_step and len(clean_step) > 10:
            steps.append(clean_step)

    # Pattern for numbered sub-steps: 4.2.1, 4.2.2 etc.
    numbered_steps = re.findall(
        r'^\s*(\d+\.\d+\.\d+)\s+(.+?)(?=\n\s*\d+\.\d+\.\d+|\n##|$)',
        content,
        re.MULTILINE | re.DOTALL
    )
    for num, step_text in numbered_steps:
        clean_step = step_text.strip().replace('\n', ' ')
        if clean_step and len(clean_step) > 10:
            steps.append(clean_step)

    return steps


def parse_sop(path: Path) -> SOPDocument:
    """Parse a single SOP markdown file."""
    content = path.read_text(encoding='utf-8')

    # Extract SOP ID from filename
    # Format: "SOP-RD-013  LB培养基的配置 04 20250630.md"
    filename = path.stem
    sop_id_match = re.search(r'(SOP-\w+-\d+)', filename)
    sop_id = sop_id_match.group(1) if sop_id_match else filename.split()[0]

    # Extract title
    title_cn, title_en = extract_title(content)

    # Extract sections
    sections = extract_sections(content)

    # Extract purpose (usually section 1)
    purpose = ""
    for key, val in sections.items():
        if '目的' in val.get('title', '') or 'purpose' in val.get('title', '').lower():
            purpose = val.get('content', '')[:500]
            break

    # Extract scope
    scope = ""
    for key, val in sections.items():
        if '范围' in val.get('title', '') or 'scope' in val.get('title', '').lower():
            scope = val.get('content', '')[:500]
            break

    # Extract reagents
    reagents = extract_reagents(content)

    # Extract equipment
    equipment = extract_equipment(content)

    # Extract steps
    steps = extract_steps(content)

    return SOPDocument(
        sop_id=sop_id,
        title=title_cn,
        title_en=title_en,
        raw_content=content,
        purpose=purpose,
        scope=scope,
        reagents=reagents,
        equipment=equipment,
        steps=steps,
        sections={k: v.get('content', '') for k, v in sections.items()},
    )


def load_all_sops(docs_dir: Path) -> List[SOPDocument]:
    """Load and parse all SOP markdown files from docs directory."""
    sops = []

    for md_file in sorted(docs_dir.glob("*SOP-*.md")):
        try:
            sop = parse_sop(md_file)
            sops.append(sop)
        except Exception as e:
            print(f"Warning: Failed to parse {md_file.name}: {e}")

    return sops


def get_sop_summary(sop: SOPDocument) -> str:
    """Get a text summary of an SOP for use in prompts."""
    lines = [
        f"**SOP ID**: {sop.sop_id}",
        f"**Title**: {sop.title}",
    ]

    if sop.title_en and sop.title_en != sop.title:
        lines.append(f"**Title (EN)**: {sop.title_en}")

    if sop.purpose:
        lines.append(f"\n**Purpose**: {sop.purpose[:300]}")

    if sop.reagents:
        reagent_strs = []
        for r in sop.reagents[:10]:
            parts = [r.name]
            if r.concentration:
                parts.append(f"({r.concentration})")
            if r.cas:
                parts.append(f"[CAS: {r.cas}]")
            reagent_strs.append(" ".join(parts))
        lines.append(f"\n**Reagents**: {', '.join(reagent_strs)}")

    if sop.equipment:
        lines.append(f"\n**Equipment**: {', '.join(sop.equipment[:8])}")

    if sop.steps:
        lines.append("\n**Key Steps**:")
        for i, step in enumerate(sop.steps[:5], 1):
            lines.append(f"  {i}. {step[:150]}...")

    return "\n".join(lines)


if __name__ == "__main__":
    # Test the loader

    repo_root = Path(__file__).resolve().parents[2]
    docs_dir = repo_root / "docs"

    print(f"Loading SOPs from: {docs_dir}")
    sops = load_all_sops(docs_dir)
    print(f"Loaded {len(sops)} SOPs\n")

    for sop in sops[:3]:
        print("=" * 60)
        print(get_sop_summary(sop))
        print()
