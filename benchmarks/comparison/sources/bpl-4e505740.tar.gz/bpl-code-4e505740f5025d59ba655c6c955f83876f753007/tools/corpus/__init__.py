"""Utilities for generating and validating synthetic BPL corpora.

The validator (`validator.py`) and the lightweight schema/loader helpers
depend only on:
- the local `bpl` package (parser + types)
- Python standard library

The dataset-generation entry points (`generate_dataset.py`,
`runner.py`, `seed_expander.py`, `quality_critic.py`) additionally
require an LLM API client and configuration loader:
- `httpx` for HTTP transport
- `openai` for the OpenAI-compatible chat completion client
- `python-dotenv` for `.env`-based configuration
- `tenacity` for retry policies
- `pydantic-ai` for typed agent loops (used by `runner_pydantic.py`)

See `tools/corpus/README.md` for usage and the project root
`pyproject.toml` for pinned versions.
"""
