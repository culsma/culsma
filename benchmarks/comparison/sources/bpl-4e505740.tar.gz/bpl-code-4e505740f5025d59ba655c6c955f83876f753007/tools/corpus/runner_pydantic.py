"""Pydantic AI runner for corpus generation.

This module provides sync and async LLM completion functions using Pydantic AI
with built-in features for:
- HTTP retries via AsyncTenacityTransport with exponential backoff
- Output validation retries via Agent's retries parameter
- Structured outputs with Pydantic models or StructuredDict
- Web search via built-in WebSearchTool
- Thinking mode via ModelSettings extra_body

Environment variables:
- PYDANTIC_AI_GATEWAY_API_KEY: API key for Pydantic AI Gateway
- PYDANTIC_AI_MODEL: Model name (default: gateway/anthropic:claude-sonnet-4-5)
- PYDANTIC_AI_MAX_CONCURRENT: Max concurrent requests (default: 5)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from httpx import AsyncClient, HTTPStatusError
from pydantic_ai import Agent
from pydantic_ai.builtin_tools import WebSearchTool
from pydantic_ai.output import StructuredDict
from pydantic_ai.retries import AsyncTenacityTransport, RetryConfig, wait_retry_after
from pydantic_ai.settings import ModelSettings
from tenacity import retry_if_exception_type, stop_after_attempt, wait_exponential

from tools.corpus.runner import LLMResult
from tools.corpus.schemas import (
    BPL_GENERATION_SCHEMA,
    CRITIC_SCHEMA,
    EVOLUTION_SCHEMA,
    EXPANSION_SCHEMA,
    RATIONALE_SCHEMA,
)

# Logger for this module
logger = logging.getLogger("corpus.runner_pydantic")

# Default configuration
DEFAULT_MODEL = "gateway/anthropic:claude-sonnet-4-5"
DEFAULT_MAX_CONCURRENT = 5
DEFAULT_MAX_RETRIES = 3

# Module-level async HTTP client with retry transport (singleton)
_async_http_client: AsyncClient | None = None


def _load_env() -> None:
    """Load environment variables from .env file."""
    env_paths = [
        Path(__file__).parent / ".env",
        Path(__file__).parents[2] / ".env",
    ]
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path)
            break


def load_pydantic_api_key() -> str:
    """Load and validate Pydantic AI Gateway API key.

    Returns:
        The API key.

    Raises:
        ValueError: If API key is not set.
    """
    _load_env()
    api_key = os.getenv("PYDANTIC_AI_GATEWAY_API_KEY")
    if not api_key:
        raise ValueError(
            "PYDANTIC_AI_GATEWAY_API_KEY not set. "
            "Please create a .env file with your API key or set the environment variable."
        )
    return api_key


def get_pydantic_model() -> str:
    """Get the configured model name.

    Returns:
        The Pydantic AI model identifier.
    """
    _load_env()
    return os.getenv("PYDANTIC_AI_MODEL", DEFAULT_MODEL)


def get_pydantic_max_concurrent() -> int:
    """Get the maximum number of concurrent requests.

    Returns:
        Maximum concurrent request count.
    """
    _load_env()
    return int(os.getenv("PYDANTIC_AI_MAX_CONCURRENT", str(DEFAULT_MAX_CONCURRENT)))


# Schema mapping: convert existing JSON schemas to StructuredDict
def _get_schema_map() -> dict[str, type]:
    """Get mapping of schema names to StructuredDict types."""
    return {
        "expanded_scenarios": StructuredDict(
            EXPANSION_SCHEMA["schema"], name="expanded_scenarios"
        ),
        "bpl_generation": StructuredDict(
            BPL_GENERATION_SCHEMA["schema"], name="bpl_generation"
        ),
        "critic_result": StructuredDict(CRITIC_SCHEMA["schema"], name="critic_result"),
        "evolution_result": StructuredDict(
            EVOLUTION_SCHEMA["schema"], name="evolution_result"
        ),
        "cot_rationale": StructuredDict(
            RATIONALE_SCHEMA["schema"], name="cot_rationale"
        ),
    }


def _create_retrying_transport() -> AsyncTenacityTransport:
    """Create an async HTTP transport with built-in retry logic.

    Returns:
        Configured AsyncTenacityTransport with exponential backoff.
    """

    def should_retry_status(response: httpx.Response) -> None:
        """Raise exception for retryable HTTP status codes."""
        if response.status_code in (429, 502, 503, 504):
            response.raise_for_status()

    return AsyncTenacityTransport(
        config=RetryConfig(
            retry=retry_if_exception_type((HTTPStatusError, ConnectionError)),
            wait=wait_retry_after(
                fallback_strategy=wait_exponential(multiplier=2, min=2, max=60),
                max_wait=300,
            ),
            stop=stop_after_attempt(5),
            reraise=True,
        ),
        validate_response=should_retry_status,
    )


def _get_async_http_client() -> AsyncClient:
    """Get or create the async HTTP client with retry transport (singleton)."""
    global _async_http_client
    if _async_http_client is None:
        _async_http_client = AsyncClient(
            transport=_create_retrying_transport(),
            timeout=httpx.Timeout(timeout=120.0, connect=30.0, read=90.0, write=30.0),
        )
    return _async_http_client


def _convert_to_llm_result(
    result: Any,
    reasoning: str | None = None,
) -> LLMResult:
    """Convert Pydantic AI AgentRunResult to LLMResult.

    Args:
        result: The AgentRunResult from Pydantic AI.
        reasoning: Optional reasoning content.

    Returns:
        LLMResult compatible with existing code.
    """
    try:
        usage = result.usage()
        raw_response: dict[str, Any] = {
            "usage": {
                "prompt_tokens": usage.request_tokens if usage else 0,
                "completion_tokens": usage.response_tokens if usage else 0,
                "total_tokens": usage.total_tokens if usage else 0,
            }
        }
    except Exception:
        raw_response = {"usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}}

    # Convert output to text
    output = result.output
    if isinstance(output, str):
        text = output
    elif isinstance(output, dict):
        text = json.dumps(output)
    elif hasattr(output, "model_dump_json"):
        text = output.model_dump_json()
    else:
        text = str(output)

    return LLMResult(
        ok=True,
        text=text,
        reasoning=reasoning,
        raw_response=raw_response,
        error=None,
    )


async def run_llm_completion_pydantic_async(
    *,
    prompt: str,
    system_prompt: str = "",
    model: str | None = None,
    enable_thinking: bool = False,
    thinking_budget: int | None = None,
    response_schema: dict[str, Any] | None = None,
    enable_web_search: bool = False,
    retries: int = DEFAULT_MAX_RETRIES,
) -> LLMResult:
    """Run LLM completion via Pydantic AI (asynchronous).

    Args:
        prompt: The user prompt to send.
        system_prompt: Optional system prompt for context.
        model: Model name (uses config default if None).
        enable_thinking: Enable deep thinking mode for complex reasoning.
        thinking_budget: Max tokens for thinking process (only used if enable_thinking=True).
        response_schema: JSON schema for structured output (from schemas.py).
        enable_web_search: Enable web search for grounding.
        retries: Number of retries for output validation.

    Returns:
        LLMResult with the completion text, reasoning, and metadata.
    """
    import uuid

    request_id = uuid.uuid4().hex[:8]
    resolved_model = model or get_pydantic_model()

    logger.info(
        f"[{request_id}] Starting Pydantic AI completion",
        extra={
            "model": resolved_model,
            "enable_thinking": enable_thinking,
            "has_schema": response_schema is not None,
            "prompt_length": len(prompt),
            "web_search": enable_web_search,
        },
    )

    try:
        # Build extra_body for thinking mode
        extra_body: dict[str, Any] = {}
        if enable_thinking:
            extra_body["enable_thinking"] = True
            if thinking_budget is not None:
                extra_body["thinking_budget"] = thinking_budget

        model_settings = ModelSettings(extra_body=extra_body) if extra_body else None

        # Determine output type
        output_type: Any = str
        if response_schema:
            schema_name = response_schema.get("name", "output")
            schema_map = _get_schema_map()
            if schema_name in schema_map:
                output_type = schema_map[schema_name]
            else:
                # Create StructuredDict dynamically for unknown schemas
                output_type = StructuredDict(
                    response_schema.get("schema", response_schema),
                    name=schema_name,
                )

        # Add web search via builtin_tools
        builtin_tools: list[Any] = []
        if enable_web_search:
            builtin_tools.append(WebSearchTool())

        # Create agent with built-in retries for validation
        agent = Agent(
            resolved_model,
            instructions=system_prompt if system_prompt else None,
            output_type=output_type,
            retries=retries,
            model_settings=model_settings,
            builtin_tools=builtin_tools if builtin_tools else None,
        )

        # Run the agent
        result = await agent.run(prompt)

        logger.info(
            f"[{request_id}] Pydantic AI completion successful",
            extra={"model": resolved_model},
        )

        return _convert_to_llm_result(result)

    except Exception as e:
        logger.error(
            f"[{request_id}] Pydantic AI completion failed: {e}",
            extra={"model": resolved_model, "error_type": type(e).__name__},
        )
        return LLMResult(
            ok=False,
            text=None,
            reasoning=None,
            raw_response=None,
            error=str(e),
        )


def run_llm_completion_pydantic(
    *,
    prompt: str,
    system_prompt: str = "",
    model: str | None = None,
    enable_thinking: bool = False,
    thinking_budget: int | None = None,
    response_schema: dict[str, Any] | None = None,
    enable_web_search: bool = False,
    retries: int = DEFAULT_MAX_RETRIES,
) -> LLMResult:
    """Run LLM completion via Pydantic AI (synchronous).

    Args:
        prompt: The user prompt to send.
        system_prompt: Optional system prompt for context.
        model: Model name (uses config default if None).
        enable_thinking: Enable deep thinking mode for complex reasoning.
        thinking_budget: Max tokens for thinking process (only used if enable_thinking=True).
        response_schema: JSON schema for structured output (from schemas.py).
        enable_web_search: Enable web search for grounding.
        retries: Number of retries for output validation.

    Returns:
        LLMResult with the completion text, reasoning, and metadata.
    """
    return asyncio.run(
        run_llm_completion_pydantic_async(
            prompt=prompt,
            system_prompt=system_prompt,
            model=model,
            enable_thinking=enable_thinking,
            thinking_budget=thinking_budget,
            response_schema=response_schema,
            enable_web_search=enable_web_search,
            retries=retries,
        )
    )


async def run_batch_completions_pydantic(
    requests: list[dict[str, Any]],
    max_concurrent: int | None = None,
) -> list[LLMResult]:
    """Run multiple completions concurrently with rate limiting.

    Args:
        requests: List of dicts with kwargs for run_llm_completion_pydantic_async.
        max_concurrent: Maximum concurrent requests (uses config default if None).

    Returns:
        List of LLMResult in the same order as requests.
    """
    if max_concurrent is None:
        max_concurrent = get_pydantic_max_concurrent()

    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_with_limit(request: dict[str, Any]) -> LLMResult:
        async with semaphore:
            return await run_llm_completion_pydantic_async(**request)

    tasks = [run_with_limit(req) for req in requests]
    return await asyncio.gather(*tasks)


async def cleanup_pydantic_async() -> None:
    """Clean up async HTTP clients. Call this when done with all async requests."""
    global _async_http_client

    if _async_http_client is not None:
        await _async_http_client.aclose()
        _async_http_client = None
