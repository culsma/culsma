"""JSON Schemas for structured outputs in corpus generation.

These schemas enforce type-safe responses from the LLM for each generation step.
DashScope uses response_format with json_schema to validate model outputs.
"""

from __future__ import annotations

from typing import Any


# L1: Seed Expansion - array of diverse instruction scenarios
EXPANSION_SCHEMA: dict[str, Any] = {
    "name": "expanded_scenarios",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {
            "scenarios": {
                "type": "array",
                "description": "List of expanded scenarios from the SOP seed",
                "items": {
                    "type": "object",
                    "properties": {
                        "instruction_zh": {
                            "type": "string",
                            "description": "Chinese instruction for the scenario",
                        },
                        "instruction_en": {
                            "type": "string",
                            "description": "English instruction for the scenario",
                        },
                        "context_zh": {
                            "type": "string",
                            "description": "Chinese context/background for the scenario",
                        },
                        "context_en": {
                            "type": "string",
                            "description": "English context/background for the scenario",
                        },
                        "scenario_type": {
                            "type": "string",
                            "description": "Type of scenario (e.g., scale_up, troubleshooting, automation)",
                        },
                        "key_parameters": {
                            "type": "object",
                            "description": "Key parameters modified in this scenario",
                            "additionalProperties": True,
                        },
                    },
                    "required": [
                        "instruction_zh",
                        "instruction_en",
                        "context_zh",
                        "context_en",
                        "scenario_type",
                        "key_parameters",
                    ],
                    "additionalProperties": False,
                },
            },
        },
        "required": ["scenarios"],
        "additionalProperties": False,
    },
}


# L2: BPL Generation - generated BPL code with optional explanation
BPL_GENERATION_SCHEMA: dict[str, Any] = {
    "name": "bpl_generation",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {
            "bpl": {
                "type": "string",
                "description": "Generated BPL protocol code",
            },
            "explanation": {
                "type": "string",
                "description": "Brief explanation of the generated protocol",
            },
        },
        "required": ["bpl"],
        "additionalProperties": False,
    },
}


# L3: Critic Result - evaluation and refinement
CRITIC_SCHEMA: dict[str, Any] = {
    "name": "critic_result",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {
            "score": {
                "type": "integer",
                "description": "Overall quality score from 0-100",
            },
            "passed": {
                "type": "boolean",
                "description": "Whether the BPL code passes quality threshold",
            },
            "strengths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of strengths in the BPL code",
            },
            "weaknesses": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of weaknesses or issues found",
            },
            "suggestions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Suggestions for improvement",
            },
            "refined_bpl": {
                "type": ["string", "null"],
                "description": "Refined BPL code if score < 80, null otherwise",
            },
        },
        "required": ["score", "passed", "strengths", "weaknesses", "suggestions"],
        "additionalProperties": False,
    },
}


# L4: Evolution Result - variation of successful BPL
EVOLUTION_SCHEMA: dict[str, Any] = {
    "name": "evolution_result",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {
            "instruction_zh": {
                "type": "string",
                "description": "Chinese instruction for the evolved scenario",
            },
            "instruction_en": {
                "type": "string",
                "description": "English instruction for the evolved scenario",
            },
            "context_zh": {
                "type": "string",
                "description": "Chinese context for the evolved scenario",
            },
            "context_en": {
                "type": "string",
                "description": "English context for the evolved scenario",
            },
            "bpl": {
                "type": "string",
                "description": "Evolved BPL protocol code",
            },
            "evolution_type": {
                "type": "string",
                "description": "Type of evolution applied (e.g., scale_up, automation, error_handling)",
            },
        },
        "required": [
            "instruction_zh",
            "instruction_en",
            "context_zh",
            "context_en",
            "bpl",
            "evolution_type",
        ],
        "additionalProperties": False,
    },
}


# CoT Rationale - chain-of-thought reasoning steps
RATIONALE_SCHEMA: dict[str, Any] = {
    "name": "cot_rationale",
    "strict": True,
    "schema": {
        "type": "object",
        "properties": {
            "rationale": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Step-by-step reasoning for the BPL generation",
            },
        },
        "required": ["rationale"],
        "additionalProperties": False,
    },
}


def get_response_format(schema: dict[str, Any]) -> dict[str, Any]:
    """Convert a schema dict to DashScope/OpenAI response_format parameter.

    Args:
        schema: One of the schema constants defined above.

    Returns:
        A dict suitable for the response_format parameter in API calls.
    """
    return {
        "type": "json_schema",
        "json_schema": schema,
    }
