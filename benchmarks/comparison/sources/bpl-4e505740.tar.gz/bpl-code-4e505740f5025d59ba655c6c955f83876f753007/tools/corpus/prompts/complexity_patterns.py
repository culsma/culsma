"""Complexity patterns and requirements for BPL dataset generation."""

from __future__ import annotations

from typing import Dict, List, Union

# BPL examples for each complexity level
COMPLEXITY_EXAMPLES: Dict[str, str] = {
    "L1_Linear": '''// L1_Linear: Sequential steps without control flow
protocol example_linear {
  manual(instruction: "Prepare reagent tubes on ice", state_effects: StateDelta {
    master_mix_stock: { volume: 500.0 uL, capacity: 1500.0 uL }
    template_dna: { volume: 100.0 uL, capacity: 1500.0 uL }
    primer_mix: { volume: 200.0 uL, capacity: 1500.0 uL }
    reaction_tube: { volume: 0.0 uL, capacity: 1500.0 uL }
  })

  transfer(from: master_mix_stock, to: reaction_tube, volume: 45.0 uL)
  transfer(from: template_dna, to: reaction_tube, volume: 5.0 uL)
  transfer(from: primer_mix, to: reaction_tube, volume: 2.0 uL)

  incubate(container: reaction_tube, temperature: 95 degC, duration: 5 min)
}''',

    "L2_Logic": '''// L2_Logic: Control flow with for/while/if
// L2 requires: at least one control flow (for/while/if), 4+ transfers, 5+ containers
protocol example_logic {
  manual(instruction: "Prepare 96-well plate and master mix", state_effects: StateDelta {
    master_mix: { volume: 2500.0 uL, capacity: 5000.0 uL }
    plate_96: { volume: 0.0 uL, capacity: 28800.0 uL }
    sample_rack: { volume: 1000.0 uL, capacity: 5000.0 uL }
    buffer_stock: { volume: 2000.0 uL, capacity: 5000.0 uL }
    enzyme_stock: { volume: 500.0 uL, capacity: 1500.0 uL }
    waste_container: { volume: 0.0 uL, capacity: 20000.0 uL }
  })

  // Initial transfers (2 transfers)
  transfer(from: buffer_stock, to: plate_96, volume: 100.0 uL)
  transfer(from: enzyme_stock, to: plate_96, volume: 20.0 uL)

  // Loop through samples (adds 2 more transfers in structure)
  for sample in 1..8 {
    transfer(from: master_mix, to: plate_96, volume: 25.0 uL)
    transfer(from: sample_rack, to: plate_96, volume: 10.0 uL)
  }

  incubate(container: plate_96, temperature: 37 degC, duration: 30 min)
}''',

    "L3_Parallel": '''// L3_Parallel: Parallel execution blocks
// L3 requires: parallel { } block, 4+ transfers, 5+ containers
protocol example_parallel {
  manual(instruction: "Set up multiple plates for parallel processing", state_effects: StateDelta {
    reagent_a: { volume: 1000.0 uL, capacity: 5000.0 uL }
    reagent_b: { volume: 1000.0 uL, capacity: 5000.0 uL }
    buffer_stock: { volume: 2000.0 uL, capacity: 5000.0 uL }
    plate_1: { volume: 0.0 uL, capacity: 28800.0 uL }
    plate_2: { volume: 0.0 uL, capacity: 28800.0 uL }
  })

  // Parallel dispensing to multiple plates (4 transfers total)
  parallel {
    sequence {
      transfer(from: buffer_stock, to: plate_1, volume: 100.0 uL)
      transfer(from: reagent_a, to: plate_1, volume: 50.0 uL)
      incubate(container: plate_1, temperature: 37 degC, duration: 30 min)
    }
    sequence {
      transfer(from: buffer_stock, to: plate_2, volume: 100.0 uL)
      transfer(from: reagent_b, to: plate_2, volume: 50.0 uL)
      incubate(container: plate_2, temperature: 37 degC, duration: 30 min)
    }
  }
}''',

    "L4_Resilient": '''// ============================================================
// L4_Resilient: Error handling with @on_error and recovery blocks
// ============================================================
// CRITICAL SYNTAX RULES:
// 1. Recovery blocks MUST be declared BEFORE the protocol (at top level)
// 2. Recovery block syntax: @for_error(ErrorType) followed by recovery Name { ... }
// 3. Inside protocol, use @on_error(RecoveryName) or @on_error(Retry, max_attempts: N)
// 4. L4 requires: 8+ steps, 5+ transfers, 6+ containers
// ============================================================

// STEP 1: Declare recovery blocks OUTSIDE and BEFORE the protocol
@for_error(TipClog)
recovery TipClogRecovery {
  drop_tips(target: tip_waste)
  pick_tips(source: tip_rack, count: 8)
}

@for_error(AspirateFail)
recovery AspirateRecovery {
  manual(instruction: "Check source volume and retry", state_effects: StateDelta {})
}

// STEP 2: Now define the protocol
protocol example_resilient {
  // Initialize ALL containers (L4 needs 6+ containers)
  manual(instruction: "Initialize liquid handler with reagents", state_effects: StateDelta {
    source_plate: { volume: 5000.0 uL, capacity: 20000.0 uL }
    dest_plate: { volume: 0.0 uL, capacity: 20000.0 uL }
    buffer_reservoir: { volume: 10000.0 uL, capacity: 50000.0 uL }
    wash_buffer: { volume: 5000.0 uL, capacity: 20000.0 uL }
    tip_rack: { volume: 96.0 uL, capacity: 1000.0 uL }
    tip_waste: { volume: 0.0 uL, capacity: 1000.0 uL }
  })

  // Use @on_error with Retry for simple retries
  @on_error(Retry, max_attempts: 3)
  transfer(from: buffer_reservoir, to: dest_plate, volume: 100.0 uL)

  // Use @on_error with recovery name for custom recovery
  @on_error(TipClogRecovery)
  transfer(from: source_plate, to: dest_plate, volume: 50.0 uL)

  @on_error(Retry, max_attempts: 2)
  transfer(from: wash_buffer, to: dest_plate, volume: 200.0 uL)

  incubate(container: dest_plate, temperature: 37 degC, duration: 10 min)

  @on_error(AspirateRecovery)
  transfer(from: source_plate, to: dest_plate, volume: 75.0 uL)

  @on_error(Retry, max_attempts: 3)
  transfer(from: buffer_reservoir, to: source_plate, volume: 100.0 uL)

  @on_error(Retry, max_attempts: 2)
  transfer(from: wash_buffer, to: dest_plate, volume: 150.0 uL)

  // Checkpoint for verification
  @checkpoint("Verify all transfers completed")
  manual(instruction: "Inspect plates for bubbles", state_effects: StateDelta {})
}

// ============================================================
// COMMON L4_Resilient SYNTAX ERRORS TO AVOID:
// ============================================================
// ❌ WRONG: recovery block inside protocol
//    protocol x { recovery MyRecovery { ... } }  // SYNTAX ERROR!
//
// ❌ WRONG: missing @for_error before recovery
//    recovery MyRecovery { ... }  // SYNTAX ERROR! Need @for_error(ErrorType) first
//
// ❌ WRONG: @on_error with wrong syntax
//    @on_error("TipClogRecovery")  // WRONG! No quotes around recovery name
//    @on_error(Retry: 3)           // WRONG! Use max_attempts: 3
//
// ✅ CORRECT pattern:
//    @for_error(ErrorType)
//    recovery RecoveryName { ... }
//    protocol x { @on_error(RecoveryName) transfer(...) }
// ============================================================''',
}

# v2.5 Worklist intent examples
WORKLIST_EXAMPLES: Dict[str, str] = {
    "stamp": '''// Stamp: Full plate 1:1 transfer
labware pcr_reaction_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "PCRP001"
    set_identifier: "Set1"
}

labware cleanup_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "CLEANUP001"
    set_identifier: "Set1"
}

protocol pcr_cleanup {
  manual(instruction: "Load plates", state_effects: StateDelta {
    pcr_reaction_plate: { volume: 2000.0 uL, capacity: 19200.0 uL }
    cleanup_plate: { volume: 0.0 uL, capacity: 19200.0 uL }
  })

  // Stamp all wells from PCR plate to cleanup plate
  stamp(from: pcr_reaction_plate, to: cleanup_plate, volume: 10 uL)
}''',

    "cherrypick": '''// Cherrypick: Selective well-to-well transfers
labware template_inventory {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "TEMPLATE001"
    set_identifier: "BatchA"
}

labware pcr_setup_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "PCRSETUP001"
    set_identifier: "BatchA"
}

protocol pcr_template_selection {
  manual(instruction: "Load plates", state_effects: StateDelta {
    template_inventory: { volume: 2000.0 uL, capacity: 19200.0 uL }
    pcr_setup_plate: { volume: 0.0 uL, capacity: 19200.0 uL }
  })

  // Cherry-pick specific wells for template selection
  cherrypick(
      from: template_inventory[A1, B3, C5, D7],
      to: pcr_setup_plate[A1, A2, A3, A4],
      volume: 2 uL
  )
}''',

    "serial_dilute": '''// Serial Dilution: Multi-step dilution chain
labware growth_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "GROWTH001"
}

labware dilution_1 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "DIL001"
    set_identifier: "DilutionSet1"
}

labware dilution_2 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "DIL002"
    set_identifier: "DilutionSet1"
}

labware dilution_3 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "DIL003"
    set_identifier: "DilutionSet1"
}

labware dilution_4 {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "DIL004"
    set_identifier: "DilutionSet1"
}

protocol serial_dilution_workflow {
  manual(instruction: "Prepare plates", state_effects: StateDelta {
    growth_plate: { volume: 5000.0 uL, capacity: 19200.0 uL }
    dilution_1: { volume: 0.0 uL, capacity: 19200.0 uL }
    dilution_2: { volume: 0.0 uL, capacity: 19200.0 uL }
    dilution_3: { volume: 0.0 uL, capacity: 19200.0 uL }
    dilution_4: { volume: 0.0 uL, capacity: 19200.0 uL }
  })

  // Perform 4-step serial dilution
  serial_dilute(
      source: growth_plate,
      destinations: [dilution_1, dilution_2, dilution_3, dilution_4],
      volume: 20 uL,
      steps: 4
  )
}''',

    "combined_worklist": '''// Combined worklist workflow with multiple transfer types
labware source_samples {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "SAMPLES001"
    set_identifier: "ExperimentA"
}

labware reaction_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "REACTION001"
    set_identifier: "ExperimentA"
}

labware analysis_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "ANALYSIS001"
    set_identifier: "ExperimentA"
}

labware dilution_series_1 {
    footprint: SBS_Standard
    well_count: 96
    category: Plate_96
    barcode: "DILSERIES1"
}

labware dilution_series_2 {
    footprint: SBS_Standard
    well_count: 96
    category: Plate_96
    barcode: "DILSERIES2"
}

protocol high_throughput_assay {
  manual(instruction: "Setup assay plates", state_effects: StateDelta {
    source_samples: { volume: 5000.0 uL, capacity: 19200.0 uL }
    reaction_plate: { volume: 0.0 uL, capacity: 19200.0 uL }
    analysis_plate: { volume: 0.0 uL, capacity: 19200.0 uL }
    dilution_series_1: { volume: 0.0 uL, capacity: 19200.0 uL }
    dilution_series_2: { volume: 0.0 uL, capacity: 19200.0 uL }
  })

  // Step 1: Stamp samples to reaction plate
  stamp(from: source_samples, to: reaction_plate, volume: 5 uL)

  // Step 2: Cherry-pick controls
  cherrypick(
      from: source_samples[H1, H2, H3],
      to: reaction_plate[A12, B12, C12],
      volume: 5 uL
  )

  // Step 3: Serial dilution for dose-response
  serial_dilute(
      source: reaction_plate,
      destinations: [dilution_series_1, dilution_series_2],
      volume: 25 uL,
      steps: 2
  )

  // Step 4: Final stamp to analysis plate
  stamp(from: dilution_series_2, to: analysis_plate, volume: 10 uL)
}''',
}

# Minimum requirements for each complexity level
COMPLEXITY_REQUIREMENTS: Dict[str, Dict[str, Union[int, List[str]]]] = {
    "L1_Linear": {
        "min_steps": 4,
        "min_transfers": 3,
        "min_containers": 4,
    },
    "L2_Logic": {
        "min_steps": 6,
        "min_transfers": 4,
        "min_containers": 5,
        "required_constructs": ["for", "while", "if"],  # at least one
    },
    "L3_Parallel": {
        "min_steps": 6,
        "min_transfers": 4,
        "min_containers": 5,
        "required_constructs": ["parallel"],
    },
    "L4_Resilient": {
        "min_steps": 8,
        "min_transfers": 5,
        "min_containers": 6,
        "required_constructs": ["@on_error", "recovery"],
    },
}

# Human-readable descriptions for each complexity level
COMPLEXITY_DESCRIPTIONS: Dict[str, str] = {
    "L1_Linear": "Linear sequential steps without any control flow (no loops, no conditionals)",
    "L2_Logic": "Control flow using for/while loops and/or if conditionals",
    "L3_Parallel": "Parallel execution blocks using parallel { } syntax",
    "L4_Resilient": "Error handling with @on_error annotations and recovery declarations",
}


def get_complexity_instruction(complexity: str) -> str:
    """Get instruction text for a given complexity level."""
    required = COMPLEXITY_REQUIREMENTS.get(complexity, {})
    desc = COMPLEXITY_DESCRIPTIONS.get(complexity, "")

    lines = [f"**Complexity Level**: {complexity}", f"**Description**: {desc}"]

    if "required_constructs" in required:
        constructs = required["required_constructs"]
        if isinstance(constructs, list):
            if complexity == "L2_Logic":
                lines.append(f"**Required**: Must use at least one of: {', '.join(constructs)}")
            else:
                lines.append(f"**Required**: Must use: {', '.join(constructs)}")

    lines.append(f"**Minimum Steps**: {required.get('min_steps', 4)}")
    lines.append(f"**Minimum Transfers**: {required.get('min_transfers', 3)}")
    lines.append(f"**Minimum Containers**: {required.get('min_containers', 4)}")

    return "\n".join(lines)


def get_required_constructs(complexity: str) -> List[str]:
    """Get the required BPL constructs for a complexity level."""
    req = COMPLEXITY_REQUIREMENTS.get(complexity, {})
    constructs = req.get("required_constructs", [])
    if isinstance(constructs, list):
        return constructs
    return []


def get_worklist_example(intent_type: str) -> str:
    """Get a worklist intent example by type.

    Args:
        intent_type: One of "stamp", "cherrypick", "serial_dilute", "combined_worklist"

    Returns:
        BPL code example for the worklist intent.
    """
    return WORKLIST_EXAMPLES.get(intent_type, "")


def get_all_worklist_examples() -> Dict[str, str]:
    """Get all worklist intent examples."""
    return WORKLIST_EXAMPLES.copy()


def get_worklist_syntax_reference() -> str:
    """Get a concise reference for worklist syntax."""
    return """\
## BPL v2.5 Worklist Intents

### Labware Declaration (with worklist fields):
```bpl
labware plate_name {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "BARCODE001"        // Optional: external identifier for CSV export
    set_identifier: "Set1"       // Optional: batch grouping for worklist
}
```

### Stamp (full plate 1:1 transfer):
```bpl
stamp(from: source_plate, to: dest_plate, volume: 10 uL)
```

### Cherrypick (selective well transfers):
```bpl
cherrypick(
    from: source_plate[A1, B3, C5],
    to: dest_plate[A1, A2, A3],
    volume: 2 uL
)
```

### Serial Dilute (multi-step dilution chain):
```bpl
serial_dilute(
    source: source_plate,
    destinations: [dilution_1, dilution_2, dilution_3],
    volume: 20 uL,
    steps: 3
)
```
"""
