"""System and user prompts for SOP-seeded BPL dataset generation."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tools.corpus.sop_loader import SOPDocument

from .complexity_patterns import COMPLEXITY_EXAMPLES, get_complexity_instruction

# System prompt for SOP-seeded generation
SYSTEM_PROMPT_SOP_SEEDED = """\
You are generating training data for a BPL (Biology Programming Language) translator.

## 🚨 GMP COMPLIANCE CHECKLIST (if compliance="GMP") - READ FIRST!

If you are generating a GMP protocol, you MUST include ALL of these:

| # | Requirement | Example |
|---|-------------|---------|
| 1 | `@compliance(GMP)` BEFORE protocol | `@compliance(GMP) protocol x { ...` |
| 2 | At least ONE `@checkpoint("...")` | `@checkpoint("Verify setup")` |
| 3 | At least ONE `@step(critical)` on transfer/add | `@step(critical) transfer(...)` |
| 4 | EVERY manual/transfer/add/incubate must have annotation above it | `@audit("...") transfer(...)` |

❌ **WRONG** (missing `@compliance(GMP)` - causes GMP_COMPLIANCE_MISSING error):
```bpl
protocol my_gmp_protocol {
  manual(instruction: "Setup", state_effects: StateDelta { ... })  // ERROR!
  transfer(from: a, to: b, volume: 100 uL)  // No @compliance(GMP)!
}
```

✅ **CORRECT** (all GMP requirements met):
```bpl
@compliance(GMP)                             // 1. BEFORE protocol declaration!
protocol my_gmp_protocol {
  @checkpoint("Initial setup verification")  // 2. At least one checkpoint
  manual(instruction: "Setup", state_effects: StateDelta {
    reagent: { volume: 500.0 uL, capacity: 1000.0 uL }
    dest: { volume: 0.0 uL, capacity: 1000.0 uL }
  })

  @step(critical)                            // 3. At least one @step(critical)
  @audit("Transfer reagent to destination")  // 4. Audit annotation
  transfer(from: reagent, to: dest, volume: 100.0 uL)
}
```

## ⚠️ MANDATORY: Container Initialization (causes 80% of failures if wrong)

The FIRST statement in EVERY protocol MUST be `manual()` with `state_effects: StateDelta { ... }`.
EVERY container used anywhere in the protocol MUST be initialized here.

### ✅ CORRECT FORMAT (use this exactly):
```bpl
protocol my_protocol {
  manual(instruction: "Setup", state_effects: StateDelta {
    reagent_a: { volume: 500.0 uL, capacity: 1500.0 uL }
    reagent_b: { volume: 1000.0 uL, capacity: 2000.0 uL }
    dest_tube: { volume: 0.0 uL, capacity: 1500.0 uL }
  })

  transfer(from: reagent_a, to: dest_tube, volume: 100.0 uL)
  transfer(from: reagent_b, to: dest_tube, volume: 50.0 uL)
}
```

### ❌ WRONG FORMATS (causes STATE / UNINITIALIZED_CONTAINER errors):
```bpl
// WRONG: Missing capacity
reagent_a: { volume: 500.0 uL }

// WRONG: Just a quantity, not an object
reagent_a: 500.0 uL

// WRONG: Using a variable in StateDelta
reagent_a: { volume: initial_vol, capacity: max_cap }

// WRONG: Container not in StateDelta but used in transfer
transfer(from: my_buffer, to: dest, volume: 100.0 uL)  // my_buffer not initialized!
```

### Rules:
1. EVERY entry needs BOTH `volume` AND `capacity` with units
2. EVERY container in `transfer(from: X, to: Y)` MUST be in StateDelta
3. Use literal quantities ONLY (no variables like `total_vol`)
4. Capacity must be > 0
5. Container names are STATIC - you CANNOT use loop variables as containers
6. NO COMMAS between StateDelta entries - use whitespace/newlines only

### ❌ COMMON MISTAKE - Using commas in StateDelta (JSON-style):
```bpl
// WRONG: Commas between entries cause SYNTAX errors!
state_effects: StateDelta {
    reagent_a: { volume: 500.0 uL, capacity: 1500.0 uL },  // WRONG - trailing comma!
    reagent_b: { volume: 1000.0 uL, capacity: 2000.0 uL }, // WRONG - trailing comma!
}
```

### ✅ CORRECT - NO commas between StateDelta entries:
```bpl
state_effects: StateDelta {
    reagent_a: { volume: 500.0 uL, capacity: 1500.0 uL }
    reagent_b: { volume: 1000.0 uL, capacity: 2000.0 uL }
}
```

### ❌ COMMON MISTAKE - Using undefined container names:
```bpl
// WRONG: 'bottle' is not in StateDelta!
for i in 1..4 {
  transfer(from: source, to: bottle, volume: 100 uL)  // ERROR: 'bottle' undefined
}

// WRONG: Loop variable 'b' cannot be a container!
for b in 1..4 {
  transfer(from: source, to: b, volume: 100 uL)  // ERROR: 'b' is not a container
}
```

### ✅ CORRECT - All containers must be pre-declared:
```bpl
manual(instruction: "Setup", state_effects: StateDelta {
  source: { volume: 500.0 uL, capacity: 1000.0 uL }
  bottle_1: { volume: 0.0 uL, capacity: 200.0 uL }
  bottle_2: { volume: 0.0 uL, capacity: 200.0 uL }
  bottle_3: { volume: 0.0 uL, capacity: 200.0 uL }
  bottle_4: { volume: 0.0 uL, capacity: 200.0 uL }
})

// Option 1: Use the same container in a loop
for i in 1..4 {
  transfer(from: source, to: bottle_1, volume: 25 uL)
}

// Option 2: For multiple containers, use separate transfers
transfer(from: source, to: bottle_1, volume: 100 uL)
transfer(from: source, to: bottle_2, volume: 100 uL)
transfer(from: source, to: bottle_3, volume: 100 uL)
transfer(from: source, to: bottle_4, volume: 100 uL)
```

## CRITICAL: BPL Syntax Rules

BPL v2.4 has a SPECIFIC syntax. DO NOT invent keywords or constructs.

### ⚠️ BPL STRUCTURE HIERARCHY (causes 90% of SYNTAX errors if wrong)

BPL has THREE levels - you MUST put things in the correct level:

```
┌─────────────────────────────────────────────────────────────┐
│ LEVEL 1: TOP-LEVEL DECLARATIONS (outside any braces)        │
│   recovery, labware, reagent, stock, function, type, etc.   │
├─────────────────────────────────────────────────────────────┤
│ LEVEL 2: PROTOCOL BODY (inside protocol { })                │
│   @settings, manual(), transfer(), incubate(), for, if, etc.│
├─────────────────────────────────────────────────────────────┤
│ LEVEL 3: BLOCK BODY (inside { } of for/if/parallel/etc.)    │
│   Same as Level 2, but NO @settings                         │
└─────────────────────────────────────────────────────────────┘
```

**TOP-LEVEL ONLY (NEVER inside protocol):**
- `recovery Name { ... }` - error handling procedures
- `labware Name { ... }` - plate/container definitions
- `function name() { ... }` - reusable functions
- `reagent Name { ... }`, `stock Name { ... }`

**PROTOCOL BODY ONLY:**
- `@setting: value` - protocol metadata (note the `@` prefix!)
- Statements: `manual()`, `transfer()`, `incubate()`, `for`, `if`, `parallel`

### ❌ COMMON STRUCTURE MISTAKES:

```bpl
// WRONG: recovery inside protocol!
protocol bad {
  recovery MyRecovery { ... }  // ERROR! recovery is top-level only
}

// WRONG: bare key:value metadata (missing @)
protocol bad {
  author: "John"  // ERROR! Use @author: "John" or omit entirely
  version: "1.0"  // ERROR! Use @version: "1.0" or omit entirely
}
```

### ✅ CORRECT STRUCTURE:

```bpl
// Recovery at TOP LEVEL (before protocol)
@for_error(TipClog)
recovery MyRecovery {
  drop_tips(target: tip_waste)
}

// Protocol with @settings
protocol good {
  @author: "John"
  @version: "1.0"

  manual(instruction: "Setup", state_effects: StateDelta {
    source_tube: { volume: 100.0 uL, capacity: 500.0 uL }
    dest_tube: { volume: 0.0 uL, capacity: 500.0 uL }
  })
  transfer(from: source_tube, to: dest_tube, volume: 50.0 uL)
}
```

### VALID BPL Constructs:
1. Protocol declaration: `protocol name { ... }`
2. Container initialization via manual():
   ```
   manual(instruction: "description", state_effects: StateDelta {
     container_name: { volume: 1000.0 uL, capacity: 1500.0 uL }
   })
   ```
3. Liquid transfer: `transfer(from: source, to: dest, volume: 50.0 uL)`
4. Incubation: `incubate(container: name, temperature: 37 degC, duration: 30 min)`
5. Control flow: `for var in 1..10 { }`, `if condition { }`, `while condition { }`
6. Parallel execution: `parallel { sequence { ... } sequence { ... } }`
7. Annotations: `@compliance(GMP)`, `@checkpoint("label")`, `@step(critical)`
8. Protocol settings: `@author: "name"`, `@version: "1.0"` (inside protocol, with @ prefix)

### CRITICAL: Allowed Unit Tokens (avoid SYNTAX/UNIT failures)
- Use EXACT unit tokens: `uL`, `mL`, `L`, `g`, `mg`, `ug`, `ng`, `min`, `h`, `s`, `ms`, `degC`, `rpm`, `rcf`, `%`.
- DO NOT use: `hr`, `hrs`, `hour`, `hours`, `mins`, `°C`, `μL`.

### Complexity Level Requirements - CRITICAL:

**L1_Linear REQUIREMENTS** (sequential only):
1. At least 3 transfer operations
2. At least 4 containers initialized
3. NO control flow constructs required (just linear steps)

**L2_Logic REQUIREMENTS** (must meet ALL):
1. At least ONE control flow construct: `for`, `while`, or `if`
2. At least 4 transfer operations total
3. At least 5 containers initialized
4. Example: `for sample in 1..8 { transfer(...) }`

**L3_Parallel REQUIREMENTS** (must meet ALL):
1. Must have `parallel { sequence { ... } sequence { ... } }` block
2. At least 4 transfer operations total
3. At least 5 containers initialized

### ⚠️ MINIMUM TRANSFER COUNT (causes COMPLETENESS_TRANSFERS error if not met):
| Complexity | Min Transfers | Min Containers |
|------------|---------------|----------------|
| L1_Linear  | 3             | 4              |
| L2_Logic   | 4             | 5              |
| L3_Parallel| 4             | 5              |
| L4_Resilient| 5            | 6              |

**TIP**: Count your `transfer()` calls before outputting. If you have a `for` loop with 1 transfer inside, that still counts as 1 transfer call (not the number of iterations).

### Error Handling (L4_Resilient complexity) - CRITICAL:
Recovery declarations and @on_error annotations are VALID BPL syntax for error handling.

**L4_Resilient REQUIREMENTS** (must meet ALL):
1. At least ONE recovery declaration at top level (outside protocol)
2. At least ONE @on_error annotation on a transfer/action
3. At least 8 steps total (including manual, transfers, incubate)
4. At least 5 transfer operations total
5. At least 6 containers initialized (including tip_rack, tip_waste)
6. All containers must use `{ volume: X, capacity: Y }` format

```
// Recovery declaration (OUTSIDE the protocol, at top level)
@for_error(TipClog)
recovery TipClogRecovery {
  drop_tips(target: tip_waste)
  pick_tips(source: tip_rack, count: 8)
}

@for_error(AspirateFail)
recovery AspirateRecovery {
  manual(instruction: "Check source and retry", state_effects: StateDelta {})
}

// In the protocol, use @on_error to attach error handling:
protocol example {
  // Initialize ALL containers with { volume: X, capacity: Y } format
  manual(instruction: "Setup", state_effects: StateDelta {
    source: { volume: 5000.0 uL, capacity: 20000.0 uL }
    dest: { volume: 0.0 uL, capacity: 20000.0 uL }
    tip_rack: { volume: 96.0 uL, capacity: 1000.0 uL }
    tip_waste: { volume: 0.0 uL, capacity: 1000.0 uL }
  })

  @on_error(Retry, max_attempts: 3)
  transfer(from: source, to: dest, volume: 100.0 uL)

  @on_error(TipClogRecovery)
  transfer(from: source, to: dest, volume: 50.0 uL)
}
```
- `@for_error(ErrorType)` declares which error type triggers this recovery
- `recovery Name { ... }` contains the recovery steps
- `@on_error(Retry, max_attempts: N)` retries the step up to N times
- `@on_error(RecoveryName)` runs the named recovery procedure on error

### INVALID - DO NOT USE (causes SYNTAX errors):
**Invented keywords:**
- `container x = ...` (NO container keyword)
- `new Container(...)` (NO new keyword)
- `materials { }` (NOT supported)
- `steps { }` (NOT supported)
- `try/catch` (NOT supported)
- `def`, `class`, `var`, `const` (NOT Python/JS!)

**Wrong placement:**
- `recovery { }` inside protocol (must be TOP-LEVEL)
- `labware { }` inside protocol (must be TOP-LEVEL)
- `function { }` inside protocol (must be TOP-LEVEL)

**Wrong syntax:**
- `author: "..."` bare metadata (use `@author: "..."` with @ prefix)
- `version: "1.0"` bare metadata (use `@version: "1.0"` with @ prefix)
- Commas between StateDelta entries (use newlines, no commas)
- Semicolons at end of statements (BPL has no semicolons)

### Labware Declaration (for worklist integration):
```
labware pcr_plate {
    footprint: SBS_Standard
    well_count: 96
    well_volume: 200 uL
    category: Plate_96
    barcode: "PCRP001"           // External barcode for worklist export
    set_identifier: "Set1"       // Batch/set grouping for worklist generation
}
```
- `barcode`: Optional external identifier used in worklist CSV export (e.g., "PCRP001")
- `set_identifier`: Optional group identifier for batch operations (e.g., "Set1", "BatchA")

### Worklist Intents (v2.5 - High-throughput operations):
1. **Stamp** - Full plate 1:1 transfer:
   ```
   stamp(from: source_plate, to: dest_plate, volume: 10 uL)
   ```

2. **Cherrypick** - Selective well-to-well transfers:
   ```
   cherrypick(
       from: template_plate[A1, B3, C5, D7],
       to: pcr_plate[A1, A2, A3, A4],
       volume: 2 uL
   )
   ```

3. **Serial Dilute** - Multi-step dilution chain:
   ```
   serial_dilute(
       source: growth_plate,
       destinations: [dilution_1, dilution_2, dilution_3, dilution_4],
       volume: 20 uL,
       steps: 4
   )
   ```

### Example Valid BPL:
```
protocol lb_media_prep {
  manual(instruction: "Prepare containers and reagents", state_effects: StateDelta {
    tryptone_stock: { volume: 500.0 uL, capacity: 1500.0 uL }
    yeast_stock: { volume: 500.0 uL, capacity: 1500.0 uL }
    nacl_stock: { volume: 500.0 uL, capacity: 1500.0 uL }
    reaction_tube: { volume: 0.0 uL, capacity: 1500.0 uL }
  })

  transfer(from: tryptone_stock, to: reaction_tube, volume: 100.0 uL)
  transfer(from: yeast_stock, to: reaction_tube, volume: 50.0 uL)
  transfer(from: nacl_stock, to: reaction_tube, volume: 100.0 uL)

  incubate(container: reaction_tube, temperature: 37 degC, duration: 60 min)
}
```

## Volume and Container Guidelines

### Container Naming and Capacity
**Strict Definition Rule**:
1. **Define BOTH Volume and Capacity**: Every container MUST be defined in the FIRST `manual` step with BOTH its current volume and its maximum capacity.
   ```
   protocol my_protocol {
     manual(instruction: "Setup reagents", state_effects: StateDelta {
       source_bottle: { volume: 500.0 mL, capacity: 500.0 mL }
       dest_beaker: { volume: 0.0 uL, capacity: 1000.0 mL }
     })
     ...
   }
   ```
2. **No Implicit Creation**: Any container used in transfers/add/worklist operations that is not present in the initialization StateDelta will cause a validation error.
3. **No Name-Based Inference**: Capacity is NEVER inferred from container names.

### CRITICAL: StateDelta must be evaluatable (avoid STATE / UNINITIALIZED_CONTAINER)
1. The FIRST protocol statement MUST be a `manual(..., state_effects: StateDelta { ... })` that initializes ALL containers used later.
2. Every StateDelta entry MUST be an object with BOTH fields:
   `name: { volume: 0 uL, capacity: 1500 uL }`
3. Capacity MUST be a positive quantity (> 0 uL).
4. StateDelta values must be simple literal quantities only (no undefined variables, no function calls).
5. If you use tips (pick_tips/drop_tips), still initialize `tip_rack` and `tip_waste` with positive capacities.

### CRITICAL: Compliance Annotations (avoid SYNTAX errors)
- **Valid `@compliance()` values**: `GMP`, `GLP`, `GxP`, `Part11` (only these are valid BPL identifiers)
- **R&D mode**: Do NOT use `@compliance(R&D)` - the `&` character is INVALID in BPL syntax!
  - For R&D protocols, simply omit the `@compliance()` annotation entirely
- **Only GMP mode requires the annotation**: `@compliance(GMP)`

### CRITICAL: GMP Compliance Declaration (causes GMP_COMPLIANCE_MISSING if wrong)

For GMP protocols, `@compliance(GMP)` MUST be placed BEFORE the `protocol` keyword (as a protocol annotation).

GMP Protocol Structure:
```bpl
@compliance(GMP)                             // REQUIRED: BEFORE protocol!
protocol my_gmp_protocol {
  @checkpoint("Initial setup verification")  // REQUIRED: at least one
  manual(instruction: "Setup", state_effects: StateDelta {
    reagent: { volume: 500.0 uL, capacity: 1000.0 uL }
    dest: { volume: 0.0 uL, capacity: 1000.0 uL }
  })

  @step(critical)                            // REQUIRED: at least one on transfer/add
  @audit("Transfer reagent to destination")
  transfer(from: reagent, to: dest, volume: 100.0 uL)
}
```

GMP Requirements (all mandatory):
1. `@compliance(GMP)` - placed BEFORE the protocol keyword
2. At least one `@checkpoint("description")` for audit trail
3. At least one `@step(critical)` on a liquid-handling operation (transfer/add)
4. Every state-changing call (manual, transfer, add, incubate) must have an audit annotation:
   `@step(...)`, `@checkpoint(...)`, `@audit(...)`, `@record(...)`, or `@on_error(...)`

### CRITICAL: Control-flow constraints (avoid EVAL failures)
1. `for` loops must iterate over numeric ranges/lists only (e.g., `for i in 1..96 { ... }`).
2. `if`/`while` conditions must evaluate to a boolean.
3. Avoid comparing quantity values in conditions; prefer simple numeric/bool flags.

### Volume Conservation Rules (CRITICAL - causes OVERFLOW/NEGATIVE_VOLUME errors)

**BEFORE writing any protocol, verify your math:**

| Check | Formula | If violated |
|-------|---------|-------------|
| Source has enough | `source_initial >= Σ(all_transfers_out)` | NEGATIVE_VOLUME error |
| Dest won't overflow | `dest_initial + Σ(all_transfers_in) <= capacity` | OVERFLOW error |

**Common mistakes that cause volume errors:**

❌ **WRONG - NEGATIVE_VOLUME** (source runs out):
```bpl
manual(... StateDelta { stock: { volume: 100.0 uL, capacity: 500.0 uL } ... })
for i in 1..8 {
  transfer(from: stock, to: dest, volume: 20.0 uL)  // 8 × 20 = 160 uL needed, but only 100 uL!
}
```

❌ **WRONG - OVERFLOW** (destination overflows):
```bpl
manual(... StateDelta { well: { volume: 0.0 uL, capacity: 200.0 uL } ... })
for i in 1..4 {
  transfer(from: stock, to: well, volume: 75.0 uL)  // 4 × 75 = 300 uL, but capacity is 200 uL!
}
```

✅ **CORRECT - Volume math verified**:
```bpl
protocol example {
  // Source: 500 uL available. Destination: 0 uL, 24000 uL capacity.
  manual(instruction: "Prepare reagents", state_effects: StateDelta {
    master_mix: { volume: 500.0 uL, capacity: 1500.0 uL }
    sample_plate: { volume: 0.0 uL, capacity: 24000.0 uL }
  })

  // Math check: 8 × 50 = 400 uL needed from source (have 500 ✓)
  // Math check: 0 + 400 = 400 uL in dest (capacity 24000 ✓)
  for i in 1..8 {
    transfer(from: master_mix, to: sample_plate, volume: 50.0 uL)
  }
  // master_mix now has 100 uL remaining (500 - 400 = 100)
}
```

**Volume verification checklist:**
1. Count TOTAL transfers from each source (including loop iterations)
2. Verify: source_volume >= total_transfers_out
3. Count TOTAL transfers to each destination (including loop iterations)
4. Verify: dest_volume + total_transfers_in <= dest_capacity

## Task Requirements

1. Generate DIVERSE natural language instructions (not just SOP title copies)
2. Output BILINGUAL: both Chinese and English versions
3. Ensure VOLUME CONSERVATION: transfers don't exceed source volumes, destinations don't overflow
4. Use ONLY valid BPL v2.4 syntax as shown above
5. Use container names that match their actual capacity (e.g., use `culture_flask` not just `flask` for large cultures)

## Output Format

Return ONLY a JSON object (no markdown, no extra text):
{
  "instruction_zh": "Chinese instruction",
  "instruction_en": "English instruction",
  "input_zh": "Chinese context",
  "input_en": "English context",
  "rationale": [
    "Step 1: ...",
    "Step 2: ..."
  ],
  "bpl": "protocol name { ... }"
}

Requirements for rationale:
- Provide explicit, step-by-step chain-of-thought reasoning with intermediate calculations/decisions.
- Do NOT include meta text about generation (e.g., "as an AI", "evolved from", "generated by").
- Do NOT include markdown or code fences.
"""


def build_user_prompt(
    sop: "SOPDocument",
    complexity: str,
    compliance: str,
    sop_summary: str,
) -> str:
    """Build the user prompt for generating a BPL sample from an SOP seed."""
    complexity_instruction = get_complexity_instruction(complexity)
    complexity_example = COMPLEXITY_EXAMPLES.get(complexity, "")

    compliance_note = ""
    if compliance == "GMP":
        compliance_note = """
## 🚨 GMP COMPLIANCE REQUIREMENTS - MANDATORY FOR THIS PROTOCOL

⚠️ **THIS IS A GMP PROTOCOL** - You MUST include ALL of these annotations:

### GMP Checklist (verify before submitting):
| ✓ | Requirement | Error if missing |
|---|-------------|------------------|
| □ | `@compliance(GMP)` BEFORE `protocol name {{` | GMP_COMPLIANCE_MISSING |
| □ | At least 1 `@checkpoint("...")` | GMP_CHECKPOINT_MISSING |
| □ | At least 1 `@step(critical)` on transfer/add | GMP_CRITICAL_STEP_MISSING |
| □ | Annotation on EVERY manual/transfer/add/incubate | GMP_AUDIT_MISSING |

### Correct GMP Structure:
```bpl
@compliance(GMP)                      // ← REQUIRED: BEFORE protocol!
protocol your_protocol_name {{
  @checkpoint("Setup verification")   // ← REQUIRED: at least one
  manual(instruction: "...", state_effects: StateDelta {{ ... }})

  @step(critical)                     // ← REQUIRED: at least one
  @audit("Critical transfer step")    // ← REQUIRED: every transfer needs annotation
  transfer(from: source, to: dest, volume: 100.0 uL)

  @audit("Second transfer")           // ← Every transfer needs annotation
  transfer(from: source2, to: dest, volume: 50.0 uL)

  @record("Incubation started")       // ← Every incubate needs annotation
  incubate(container: dest, temperature: 37 degC, duration: 30 min)
}}
```

### Valid audit annotations (use any of these):
- `@step(...)` or `@step(critical)` - marks step importance
- `@checkpoint("description")` - audit checkpoint
- `@audit("description")` - audit trail entry
- `@record("description")` - record keeping
- `@on_error(...)` - error handling (also counts as audit)
"""
    elif compliance == "R&D":
        compliance_note = """
## R&D Compliance (IMPORTANT)
Since compliance is R&D (Research & Development):
- Do NOT add any `@compliance(...)` annotation - R&D protocols have no compliance annotation
- ⚠️ NEVER use `@compliance(R&D)` - the `&` character is INVALID in BPL syntax and will cause SYNTAX errors!
- You may optionally add `@step("...")` or `@checkpoint("...")` for documentation, but they are not required
"""

    prompt = f"""\
## Reference SOP (Use as seed for generation)

{sop_summary}

## Generation Task

Based on the above SOP, generate a BPL protocol with:

### Complexity: {complexity}
{complexity_instruction}

### Compliance: {compliance}
{compliance_note}

### Example for {complexity}:
```bpl
{complexity_example}
```

## CRITICAL: Container Initialization (avoid STATE / UNINITIALIZED_CONTAINER errors)

The FIRST statement in your protocol MUST be a `manual()` with `state_effects: StateDelta {{ ... }}` that initializes ALL containers:

```bpl
protocol my_protocol {{
  manual(instruction: "Setup reagents", state_effects: StateDelta {{
    reagent_stock: {{ volume: 500.0 uL, capacity: 1500.0 uL }}
    buffer_stock: {{ volume: 1000.0 uL, capacity: 2000.0 uL }}
    dest_tube: {{ volume: 0.0 uL, capacity: 1500.0 uL }}
  }})

  transfer(from: reagent_stock, to: dest_tube, volume: 100.0 uL)
  // ...
}}
```

**Rules**:
1. Every container entry MUST have BOTH `volume` and `capacity` as quantities with units
2. Every container used in `transfer(from: X, to: Y, ...)` MUST be initialized above
3. Use simple literal quantities only (NO variables, NO expressions like `total_vol / 2`)
4. Capacity must be > 0

## Instructions

1. **Web Search**: Search for relevant manufacturer protocols or scientific literature to ground your values (concentrations, temperatures, timing).

2. **Diverse Instruction**: Generate a natural, varied instruction that a lab scientist might actually say/type. Do NOT just copy the SOP title. Be creative but realistic.

3. **Realistic Values**: Use actual reagent concentrations, volumes, and parameters from the SOP or your web search.

4. **Complete Protocol**: Include all necessary steps, transfers, and incubations. Meet the minimum requirements for {complexity}.

5. **Volume Conservation**: Ensure all transfers are valid (source has enough volume, destination won't overflow).

Output the JSON object with instruction_zh, instruction_en, input_zh, input_en, rationale, and bpl fields.
"""
    return prompt


def build_retry_prompt(
    original_prompt: str,
    validation_errors: list[str],
    attempt: int,
) -> str:
    """Build a retry prompt when validation fails."""
    errors_text = "\n".join(f"- {err}" for err in validation_errors)

    # Add specific guidance based on error types
    specific_fixes = []
    errors_joined = " ".join(validation_errors).upper()

    if "STATE" in errors_joined or "STATEDELTA" in errors_joined:
        specific_fixes.append(
            "**STATE error**: StateDelta entries must be objects with BOTH volume AND capacity:\n"
            "   `tube: { volume: 100.0 uL, capacity: 1500.0 uL }`\n"
            "   NOT `tube: 100.0 uL` (wrong format)"
        )

    if "UNINITIALIZED" in errors_joined:
        specific_fixes.append(
            "**UNINITIALIZED_CONTAINER error**: Every container used in transfer/add MUST be initialized in the FIRST manual() StateDelta.\n"
            "   - If you use `transfer(from: my_reagent, to: dest, ...)`, BOTH `my_reagent` AND `dest` must appear in StateDelta\n"
            "   - Container names are STATIC - you CANNOT use loop variables (like `b` or `i`) as containers\n"
            "   - You CANNOT use generic names like `bottle` without initializing them first\n"
            "   - FIX: Add ALL containers to the FIRST `manual(... state_effects: StateDelta { container: { volume: X, capacity: Y } })`"
        )

    if "CAPACITY" in errors_joined:
        specific_fixes.append(
            "**CAPACITY error**: Capacity must be a positive quantity (> 0 uL)."
        )

    if "NEGATIVE_VOLUME" in errors_joined or "NEGATIVE" in errors_joined:
        specific_fixes.append(
            "**NEGATIVE_VOLUME error**: You are transferring MORE than the source contains!\n"
            "   - Count ALL transfers from the source (including loop iterations)\n"
            "   - Example: `for i in 1..8 { transfer(..., 20 uL) }` = 8 × 20 = 160 uL total\n"
            "   - FIX: Either increase source volume OR reduce transfer volume/count\n"
            "   - Formula: source_volume MUST be >= sum of all transfers out"
        )

    if "OVERFLOW" in errors_joined:
        specific_fixes.append(
            "**OVERFLOW error**: Destination container cannot hold all the volume!\n"
            "   - Count ALL transfers TO the destination (including loop iterations)\n"
            "   - Example: `for i in 1..4 { transfer(..., 75 uL) }` adds 4 × 75 = 300 uL\n"
            "   - FIX: Either increase destination capacity OR reduce transfer volume/count\n"
            "   - Formula: dest_initial + all_transfers_in MUST be <= dest_capacity"
        )

    if "GMP_COMPLIANCE_MISSING" in errors_joined:
        specific_fixes.append(
            "**GMP_COMPLIANCE_MISSING error**: You MUST add `@compliance(GMP)` BEFORE the protocol!\n"
            "   - WRONG: `protocol x { ... }` ← missing @compliance(GMP)!\n"
            "   - CORRECT: `@compliance(GMP) protocol x { ... }` ← annotation BEFORE protocol!\n"
            "   - GMP protocols REQUIRE this annotation placed BEFORE the protocol keyword!"
        )

    if "GMP_AUDIT_MISSING" in errors_joined:
        specific_fixes.append(
            "**GMP_AUDIT_MISSING error**: EVERY state-changing operation needs an audit annotation!\n"
            "   - Each manual(), transfer(), add(), incubate() MUST have one of:\n"
            "     @step(...), @checkpoint(...), @audit(...), @record(...), or @on_error(...)\n"
            "   - FIX: Add `@audit(\"description\")` above EVERY liquid handling operation"
        )

    if "GMP_CHECKPOINT_MISSING" in errors_joined:
        specific_fixes.append(
            "**GMP_CHECKPOINT_MISSING error**: GMP protocols need at least ONE @checkpoint!\n"
            "   - Add `@checkpoint(\"description\")` above at least one manual() statement"
        )

    if "GMP_CRITICAL_STEP_MISSING" in errors_joined:
        specific_fixes.append(
            "**GMP_CRITICAL_STEP_MISSING error**: GMP protocols need at least ONE @step(critical)!\n"
            "   - Add `@step(critical)` above at least one transfer() or add() statement"
        )

    if "SYNTAX" in errors_joined:
        errors_lower = " ".join(validation_errors).lower()

        # Check for recovery placement error
        if "recovery" in errors_lower:
            specific_fixes.append(
                "**SYNTAX error (recovery placement)**: Recovery declarations MUST be at TOP LEVEL (outside protocol).\n"
                "   - WRONG: `protocol x { recovery foo { ... } }` ← recovery inside protocol!\n"
                "   - CORRECT: Put recovery BEFORE the protocol:\n"
                "     ```\n"
                "     recovery foo { ... }\n"
                "     protocol x { ... }\n"
                "     ```"
            )
        # Check for comma-related syntax error
        if "," in " ".join(validation_errors):
            specific_fixes.append(
                "**SYNTAX error (StateDelta commas)**: DO NOT use commas between StateDelta entries!\n"
                "   - WRONG: `a: { volume: 100 uL, capacity: 500 uL },` ← trailing comma!\n"
                "   - CORRECT: `a: { volume: 100 uL, capacity: 500 uL }` ← no comma\n"
                "   - StateDelta entries are whitespace/newline separated, NOT comma separated"
            )
        # Check for bare metadata (missing @ prefix)
        if any(field in errors_lower for field in ["author", "version", "title", "description", "date"]):
            specific_fixes.append(
                "**SYNTAX error (bare metadata)**: Protocol metadata MUST use @ prefix!\n"
                "   - WRONG: `author: \"name\"` ← missing @ prefix!\n"
                "   - CORRECT: `@author: \"name\"` ← with @ prefix\n"
                "   - Or simply OMIT metadata fields entirely - they are optional"
            )
        # Check for colon syntax error (general case for bare key:value)
        if "expected one of: equal, lpar" in errors_lower or "expected one of: lpar, equal" in errors_lower:
            specific_fixes.append(
                "**SYNTAX error (invalid statement)**: BPL does NOT support bare `key: value` syntax in protocol body.\n"
                "   - For metadata: use `@key: value` (with @ prefix)\n"
                "   - For function calls: use `func_name(arg: value)`\n"
                "   - For assignments: use `let x = value`"
            )

    specific_fixes_text = ""
    if specific_fixes:
        specific_fixes_text = "\n\n## How to Fix These Specific Errors\n\n" + "\n\n".join(specific_fixes)

    return f"""\
{original_prompt}

## VALIDATION FAILED (Attempt {attempt})

Your previous output had the following issues:
{errors_text}
{specific_fixes_text}

Please fix these issues and regenerate the BPL protocol. Ensure:
1. Valid BPL v2.4 syntax (parseable by bpl.parser.parse())
2. Valid units (uL, mL, L, degC, min, s, rpm, g, mg, ug, etc.)
3. Volume conservation (transfers don't exceed source, containers don't overflow)
4. Required complexity constructs are present
5. ALL containers initialized in FIRST manual() with {{ volume: X, capacity: Y }} format
6. Output is valid JSON format

Output ONLY the corrected JSON object.
"""
