"""Prompts module for BPL dataset generation."""

from __future__ import annotations

from .complexity_patterns import (
    COMPLEXITY_EXAMPLES,
    COMPLEXITY_REQUIREMENTS,
    WORKLIST_EXAMPLES,
    get_complexity_instruction,
    get_worklist_example,
    get_all_worklist_examples,
    get_worklist_syntax_reference,
)
from .system_prompts import (
    SYSTEM_PROMPT_SOP_SEEDED,
    build_user_prompt,
)

__all__ = [
    "COMPLEXITY_EXAMPLES",
    "COMPLEXITY_REQUIREMENTS",
    "WORKLIST_EXAMPLES",
    "get_complexity_instruction",
    "get_worklist_example",
    "get_all_worklist_examples",
    "get_worklist_syntax_reference",
    "SYSTEM_PROMPT_SOP_SEEDED",
    "build_user_prompt",
]
