"""Seed Expander - Use LLM to derive diverse instruction variants from SOP seeds.

This module adds a pre-generation layer that expands each SOP seed into multiple
diverse, realistic lab instruction scenarios before BPL code generation.

Pipeline:
  SOP Seed → [Layer 1: LLM Expander] → Diverse Instructions → [Layer 2: LLM Generator] → BPL Code
"""

from __future__ import annotations

import json
import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, TYPE_CHECKING

import sys

_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from tools.corpus.runner import run_llm_completion, run_llm_completion_async
from tools.corpus.schemas import EXPANSION_SCHEMA
from tools.corpus.sop_loader import SOPDocument, get_sop_summary

if TYPE_CHECKING:
    pass


_logger = logging.getLogger("bpl_generation")


@dataclass
class ExpandedScenario:
    """A single expanded scenario derived from an SOP seed."""

    instruction_zh: str
    instruction_en: str
    context_zh: str
    context_en: str
    scenario_type: str  # e.g., "scale_up", "troubleshooting", "automation", etc.
    key_parameters: dict  # Extracted/modified parameters for this scenario


# System prompt for seed expansion
EXPANDER_SYSTEM_PROMPT = """\
You are a senior lab scientist helping to create diverse, realistic lab instruction scenarios.

Your task: Given an SOP (Standard Operating Procedure), generate DIVERSE instruction variants that a real scientist might use to request this protocol in different contexts.

## Scenario Types to Consider

1. **Standard Execution**: Normal protocol execution as written
2. **Scale Variation**: Scale up (10x, 100x) or scale down (miniprep, microscale)
3. **Automation Adaptation**: Adapt for liquid handler, 96-well format, high-throughput
4. **Troubleshooting**: Protocol after a failed attempt, with specific issues to address
5. **Teaching/Training**: Simplified version for new lab members
6. **Time Constraint**: Rushed version, what can be parallelized or shortened
7. **Resource Constraint**: Limited reagents, substitute alternatives
8. **Quality Control**: Add extra verification steps, checkpoints
9. **Documentation**: GMP/GLP compliant version with full audit trail
10. **Optimization**: Improve yield, reduce waste, increase efficiency

## Requirements

1. Each scenario must be REALISTIC - something a scientist would actually say/type
2. Vary the TONE: formal requests, casual notes, urgent asks, detailed specifications
3. Include SPECIFIC PARAMETERS when relevant (volumes, concentrations, temperatures)
4. Both Chinese and English versions should be NATURAL (not direct translations)
5. Context should provide additional details that inform the protocol

## Output Format

Return a JSON array of scenario objects:
[
  {
    "instruction_zh": "中文指令",
    "instruction_en": "English instruction",
    "context_zh": "中文背景信息",
    "context_en": "English context",
    "scenario_type": "scale_up",
    "key_parameters": {
      "scale_factor": 10,
      "target_volume": "500 mL"
    }
  },
  ...
]

Generate exactly the number of scenarios requested. Each must be UNIQUE and DIVERSE.
"""


def _build_expander_prompt(
    sop: SOPDocument,
    sop_summary: str,
    num_scenarios: int,
    complexity: str,
    compliance: str,
) -> str:
    """Build the user prompt for seed expansion."""

    # Suggest scenario types based on complexity/compliance
    suggested_types = []
    if complexity == "L1_Linear":
        suggested_types = ["standard", "teaching", "scale_down"]
    elif complexity == "L2_Logic":
        suggested_types = ["conditional", "troubleshooting", "optimization"]
    elif complexity == "L3_Parallel":
        suggested_types = ["automation", "high_throughput", "time_constraint"]
    elif complexity == "L4_Resilient":
        suggested_types = ["error_recovery", "quality_control", "gmp_audit"]

    if compliance == "GMP":
        suggested_types.append("documentation")
        suggested_types.append("audit_trail")

    prompt = f"""\
## Source SOP

{sop_summary}

## Full SOP Content (for reference)

```
{sop.raw_content[:3000]}
```

## Task

Generate **{num_scenarios}** diverse instruction scenarios based on this SOP.

**Target Complexity**: {complexity}
**Target Compliance**: {compliance}

**Suggested Scenario Types** (but feel free to be creative):
{', '.join(suggested_types)}

## Important Notes

1. Each instruction should sound like a REAL scientist's request
2. Vary sentence structure, length, and formality
3. Include specific parameters from the SOP (reagent names, concentrations, etc.)
4. Context should add useful information (why this is needed, constraints, goals)
5. Chinese and English should both be natural, idiomatic expressions

Generate {num_scenarios} unique scenarios as a JSON array.
"""
    return prompt


def _parse_scenarios(raw_text: str) -> List[ExpandedScenario]:
    """Parse the LLM output into ExpandedScenario objects."""
    scenarios = []

    # Try to extract JSON array
    text = raw_text.strip()

    # Find JSON array bounds
    start = text.find("[")
    end = text.rfind("]")

    if start < 0 or end <= start:
        return scenarios

    try:
        arr = json.loads(text[start : end + 1])
        if not isinstance(arr, list):
            return scenarios

        for item in arr:
            if not isinstance(item, dict):
                continue

            scenario = ExpandedScenario(
                instruction_zh=str(item.get("instruction_zh", "")).strip(),
                instruction_en=str(item.get("instruction_en", "")).strip(),
                context_zh=str(item.get("context_zh", "")).strip(),
                context_en=str(item.get("context_en", "")).strip(),
                scenario_type=str(item.get("scenario_type", "standard")).strip(),
                key_parameters=item.get("key_parameters", {}) or {},
            )

            # Validate required fields
            if scenario.instruction_zh and scenario.instruction_en:
                scenarios.append(scenario)

    except json.JSONDecodeError:
        pass

    return scenarios


def expand_sop_seed(
    sop: SOPDocument,
    *,
    num_scenarios: int = 5,
    complexity: str = "L1_Linear",
    compliance: str = "R&D",
    model: str = "opus",
    enable_web_search: bool = False,
    reasoning_budget: int = 8000,
) -> List[ExpandedScenario]:
    """Expand an SOP seed into multiple diverse instruction scenarios using LLM.

    Args:
        sop: The source SOP document
        num_scenarios: Number of diverse scenarios to generate
        complexity: Target complexity level (L1-L4)
        compliance: Target compliance mode (R&D/GMP)
        model: Model to use (default: opus)
        enable_web_search: Whether to enable web search for scientific grounding
        reasoning_budget: Max tokens for reasoning

    Returns:
        List of ExpandedScenario objects
    """
    sop_summary = get_sop_summary(sop)
    user_prompt = _build_expander_prompt(
        sop, sop_summary, num_scenarios, complexity, compliance
    )

    result = run_llm_completion(
        prompt=user_prompt,
        system_prompt=EXPANDER_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=EXPANSION_SCHEMA,
        enable_web_search=enable_web_search,  # L1-EXPAND can use web search for scientific grounding
    )

    if not result.ok:
        _logger.warning(
            f"[L1-EXPAND] LLM expander failed: {result.error}"
        )
        return []

    # Parse the structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict) and "scenarios" in parsed:
        scenarios = []
        for item in parsed["scenarios"]:
            if not isinstance(item, dict):
                continue
            scenario = ExpandedScenario(
                instruction_zh=str(item.get("instruction_zh", "")).strip(),
                instruction_en=str(item.get("instruction_en", "")).strip(),
                context_zh=str(item.get("context_zh", "")).strip(),
                context_en=str(item.get("context_en", "")).strip(),
                scenario_type=str(item.get("scenario_type", "standard")).strip(),
                key_parameters=item.get("key_parameters", {}) or {},
            )
            if scenario.instruction_zh and scenario.instruction_en:
                scenarios.append(scenario)
        return scenarios

    # Fallback to text parsing if structured output fails
    raw_text = result.text or ""
    return _parse_scenarios(raw_text)


def expand_sop_seed_single(
    sop: SOPDocument,
    *,
    complexity: str = "L1_Linear",
    compliance: str = "R&D",
    model: str = "opus",
    scenario_hint: Optional[str] = None,
    enable_web_search: bool = False,
    reasoning_budget: int = 8000,
) -> Optional[ExpandedScenario]:
    """Expand an SOP seed into a single diverse instruction scenario.

    More efficient for one-at-a-time generation in the main loop.

    Args:
        sop: The source SOP document
        complexity: Target complexity level (L1-L4)
        compliance: Target compliance mode (R&D/GMP)
        model: Model to use (default: opus)
        scenario_hint: Optional hint for scenario type
        enable_web_search: Whether to enable web search for scientific grounding
        reasoning_budget: Max tokens for reasoning

    Returns:
        A single ExpandedScenario or None if generation failed
    """
    sop_summary = get_sop_summary(sop)

    # Simplified prompt for single scenario
    hint_text = ""
    if scenario_hint:
        hint_text = f"\n**Scenario Type Hint**: {scenario_hint}"

    user_prompt = f"""\
## Source SOP

{sop_summary}

## Key Reagents and Steps

```
{sop.raw_content[:2000]}
```

## Task

Generate ONE realistic lab instruction scenario based on this SOP.

**Target Complexity**: {complexity}
**Target Compliance**: {compliance}{hint_text}

## Requirements

1. Instruction should sound like a REAL scientist's request (not a template)
2. Be SPECIFIC: include reagent names, volumes, concentrations from the SOP
3. Context should explain WHY this protocol is needed
4. Both Chinese and English should be natural, idiomatic
5. Vary from typical textbook language - be conversational or professional as fits

## Output Format

Return a JSON object with "scenarios" array containing exactly ONE scenario:
{{
  "scenarios": [
    {{
      "instruction_zh": "中文指令 - 自然、具体、像真实科学家的请求",
      "instruction_en": "English instruction - natural, specific, like a real scientist's request",
      "context_zh": "中文背景 - 为什么需要这个实验",
      "context_en": "English context - why this experiment is needed",
      "scenario_type": "type of scenario",
      "key_parameters": {{}}
    }}
  ]
}}
"""

    result = run_llm_completion(
        prompt=user_prompt,
        system_prompt=EXPANDER_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=EXPANSION_SCHEMA,
        enable_web_search=enable_web_search,  # L1-EXPAND can use web search for scientific grounding
    )

    if not result.ok:
        _logger.warning(
            f"[L1-EXPAND] LLM expander failed: {result.error}"
        )
        return None

    # Parse the structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict) and "scenarios" in parsed:
        scenarios_list = parsed["scenarios"]
        if scenarios_list and isinstance(scenarios_list, list) and len(scenarios_list) > 0:
            item = scenarios_list[0]
            if isinstance(item, dict):
                scenario = ExpandedScenario(
                    instruction_zh=str(item.get("instruction_zh", "")).strip(),
                    instruction_en=str(item.get("instruction_en", "")).strip(),
                    context_zh=str(item.get("context_zh", "")).strip(),
                    context_en=str(item.get("context_en", "")).strip(),
                    scenario_type=str(item.get("scenario_type", "standard")).strip(),
                    key_parameters=item.get("key_parameters", {}) or {},
                )
                if scenario.instruction_zh and scenario.instruction_en:
                    return scenario

    # Fallback to text parsing
    raw_text = result.text or ""
    if raw_text:
        _logger.debug(f"[L1-EXPAND] Structured output failed, trying text parse. raw_response:\n{raw_text}")

    text = raw_text.strip()
    start_obj = text.find("{")
    end_obj = text.rfind("}")
    if start_obj >= 0 and end_obj > start_obj:
        try:
            obj = json.loads(text[start_obj : end_obj + 1])
            if isinstance(obj, dict):
                scenario = ExpandedScenario(
                    instruction_zh=str(obj.get("instruction_zh", "")).strip(),
                    instruction_en=str(obj.get("instruction_en", "")).strip(),
                    context_zh=str(obj.get("context_zh", "")).strip(),
                    context_en=str(obj.get("context_en", "")).strip(),
                    scenario_type=str(obj.get("scenario_type", "standard")).strip(),
                    key_parameters=obj.get("key_parameters", {}) or {},
                )
                if scenario.instruction_zh and scenario.instruction_en:
                    return scenario
        except json.JSONDecodeError:
            pass

    if raw_text:
        _logger.debug(f"[L1-EXPAND] Parsed scenario missing required fields. raw_response:\n{raw_text}")

    return None


# Scenario type hints for variety
SCENARIO_HINTS = [
    "standard_execution",
    "scale_up_10x",
    "scale_down_microscale",
    "automation_96well",
    "high_throughput",
    "troubleshooting_retry",
    "teaching_simplified",
    "time_optimized",
    "resource_limited",
    "quality_control",
    "gmp_documentation",
    "yield_optimization",
    "waste_reduction",
    "new_organism_adaptation",
    "temperature_sensitive",
]


async def expand_sop_seed_single_async(
    sop: SOPDocument,
    *,
    complexity: str = "L1_Linear",
    compliance: str = "R&D",
    model: str = "opus",
    scenario_hint: Optional[str] = None,
    enable_web_search: bool = False,
    reasoning_budget: int = 8000,
) -> Optional[ExpandedScenario]:
    """Async version of expand_sop_seed_single.

    Expand an SOP seed into a single diverse instruction scenario.

    Args:
        sop: The source SOP document
        complexity: Target complexity level (L1-L4)
        compliance: Target compliance mode (R&D/GMP)
        model: Model to use (default: opus)
        scenario_hint: Optional hint for scenario type
        enable_web_search: Whether to enable web search for scientific grounding
        reasoning_budget: Max tokens for reasoning

    Returns:
        A single ExpandedScenario or None if generation failed
    """
    sop_summary = get_sop_summary(sop)

    # Simplified prompt for single scenario
    hint_text = ""
    if scenario_hint:
        hint_text = f"\n**Scenario Type Hint**: {scenario_hint}"

    user_prompt = f"""\
## Source SOP

{sop_summary}

## Key Reagents and Steps

```
{sop.raw_content[:2000]}
```

## Task

Generate ONE realistic lab instruction scenario based on this SOP.

**Target Complexity**: {complexity}
**Target Compliance**: {compliance}{hint_text}

## Requirements

1. Instruction should sound like a REAL scientist's request (not a template)
2. Be SPECIFIC: include reagent names, volumes, concentrations from the SOP
3. Context should explain WHY this protocol is needed
4. Both Chinese and English should be natural, idiomatic
5. Vary from typical textbook language - be conversational or professional as fits

## Output Format

Return a JSON object with "scenarios" array containing exactly ONE scenario:
{{
  "scenarios": [
    {{
      "instruction_zh": "中文指令 - 自然、具体、像真实科学家的请求",
      "instruction_en": "English instruction - natural, specific, like a real scientist's request",
      "context_zh": "中文背景 - 为什么需要这个实验",
      "context_en": "English context - why this experiment is needed",
      "scenario_type": "type of scenario",
      "key_parameters": {{}}
    }}
  ]
}}
"""

    result = await run_llm_completion_async(
        prompt=user_prompt,
        system_prompt=EXPANDER_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=EXPANSION_SCHEMA,
        enable_web_search=enable_web_search,  # L1-EXPAND can use web search for scientific grounding
    )

    if not result.ok:
        _logger.warning(
            f"[L1-EXPAND] LLM expander failed: {result.error}"
        )
        return None

    # Parse the structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict) and "scenarios" in parsed:
        scenarios_list = parsed["scenarios"]
        if scenarios_list and isinstance(scenarios_list, list) and len(scenarios_list) > 0:
            item = scenarios_list[0]
            if isinstance(item, dict):
                scenario = ExpandedScenario(
                    instruction_zh=str(item.get("instruction_zh", "")).strip(),
                    instruction_en=str(item.get("instruction_en", "")).strip(),
                    context_zh=str(item.get("context_zh", "")).strip(),
                    context_en=str(item.get("context_en", "")).strip(),
                    scenario_type=str(item.get("scenario_type", "standard")).strip(),
                    key_parameters=item.get("key_parameters", {}) or {},
                )
                if scenario.instruction_zh and scenario.instruction_en:
                    return scenario

    # Fallback to text parsing
    raw_text = result.text or ""
    if raw_text:
        _logger.debug(f"[L1-EXPAND] Structured output failed, trying text parse. raw_response:\n{raw_text}")

    text = raw_text.strip()
    start_obj = text.find("{")
    end_obj = text.rfind("}")
    if start_obj >= 0 and end_obj > start_obj:
        try:
            obj = json.loads(text[start_obj : end_obj + 1])
            if isinstance(obj, dict):
                scenario = ExpandedScenario(
                    instruction_zh=str(obj.get("instruction_zh", "")).strip(),
                    instruction_en=str(obj.get("instruction_en", "")).strip(),
                    context_zh=str(obj.get("context_zh", "")).strip(),
                    context_en=str(obj.get("context_en", "")).strip(),
                    scenario_type=str(obj.get("scenario_type", "standard")).strip(),
                    key_parameters=obj.get("key_parameters", {}) or {},
                )
                if scenario.instruction_zh and scenario.instruction_en:
                    return scenario
        except json.JSONDecodeError:
            pass

    if raw_text:
        _logger.debug(f"[L1-EXPAND] Parsed scenario missing required fields. raw_response:\n{raw_text}")

    return None


def get_random_scenario_hint(rng: random.Random, complexity: str, compliance: str) -> str:
    """Get a random scenario hint appropriate for the complexity/compliance."""
    hints = SCENARIO_HINTS.copy()

    # Weight hints based on complexity
    if complexity == "L3_Parallel":
        hints.extend(["automation_96well", "high_throughput", "parallel_processing"] * 2)
    elif complexity == "L4_Resilient":
        hints.extend(["troubleshooting_retry", "error_recovery", "quality_control"] * 2)
    elif complexity == "L2_Logic":
        hints.extend(["conditional_branching", "optimization", "variable_handling"] * 2)

    # Weight hints based on compliance
    if compliance == "GMP":
        hints.extend(["gmp_documentation", "audit_trail", "quality_control"] * 3)

    return rng.choice(hints)


if __name__ == "__main__":
    # Test the expander
    from tools.corpus.sop_loader import load_all_sops

    docs_dir = _REPO_ROOT / "docs"
    sops = load_all_sops(docs_dir)

    if sops:
        print(f"Testing with SOP: {sops[0].sop_id} - {sops[0].title}")
        print("=" * 60)

        # Test single expansion
        scenario = expand_sop_seed_single(
            sops[0],
            complexity="L2_Logic",
            compliance="R&D",
            scenario_hint="automation_96well",
        )

        if scenario:
            print(f"Scenario Type: {scenario.scenario_type}")
            print(f"\nInstruction (ZH): {scenario.instruction_zh}")
            print(f"\nInstruction (EN): {scenario.instruction_en}")
            print(f"\nContext (ZH): {scenario.context_zh}")
            print(f"\nContext (EN): {scenario.context_en}")
            print(f"\nKey Parameters: {scenario.key_parameters}")
        else:
            print("Failed to generate scenario")
