from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Union

# Ensure repo root on sys.path when executed as a script.
import sys

_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from bpl.parser import parse
from bpl.ast import (
    ProtocolDecl,
    LabwareDecl,
    Annotation,
    ProtocolSetting,
    LetStmt,
    AssignStmt,
    CallStmt,
    IfStmt,
    ForStmt,
    WhileStmt,
    ReturnStmt,
    Block,
    ParallelBlock,
    SequenceBlock,
    # Expressions
    Expression,
    QuantityExpr,
    IdentifierExpr,
    BinaryExpr,
    UnaryExpr,
    ConditionalExpr,
    RangeExpr,
    ListExpr,
    MapExpr,
    StringLit,
    NumberLit,
    BoolLit,
    FieldAccessExpr,
    MethodCallExpr,
    IndexExpr,
    CallExpr,
    StateDeltaExpr,
    StampStmt,
    CherrypickStmt,
    SerialDiluteStmt,
)

from bpl.types import Quantity, create_quantity, get_unit


# Complexity requirements for validation
COMPLEXITY_REQUIREMENTS = {
    "L1_Linear": {
        "min_steps": 4,
        "min_transfers": 3,
        "min_containers": 4,
    },
    "L2_Logic": {
        "min_steps": 6,
        "min_transfers": 4,
        "min_containers": 5,
    },
    "L3_Parallel": {
        "min_steps": 6,
        "min_transfers": 4,
        "min_containers": 5,
    },
    "L4_Resilient": {
        "min_steps": 8,
        "min_transfers": 5,
        "min_containers": 6,
    },
}


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str
    detail: Optional[str] = None


@dataclass
class ValidationResult:
    ok: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)


class ValidationError(Exception):
    pass


Value = Union[None, float, bool, str, Quantity, List[Any], Dict[str, Any]]


@dataclass
class LabwareInfo:
    well_volume_ul: Optional[float] = None
    well_count: Optional[int] = None


@dataclass
class SimulationState:
    volumes_ul: Dict[str, float] = field(default_factory=dict)  # container_id -> current uL
    capacities_ul: Dict[str, float] = field(default_factory=dict)  # container_id -> max uL


def _qty_to_ul(qty: Quantity) -> float:
    return qty.to(get_unit("uL")).value


def _infer_capacity_ul(container_id: str, labware_by_prefix: Dict[str, LabwareInfo]) -> Optional[float]:
    """Get container capacity from explicit LabwareDecl matches only.
    Returns None if no labware definition is found.
    """
    # If container name matches or is prefixed by a labware decl name, honor its well volume.
    for prefix, info in labware_by_prefix.items():
        if (container_id == prefix or container_id.startswith(prefix + "_")) and info.well_volume_ul is not None:
            count = info.well_count or 1
            if count < 1:
                count = 1
            return info.well_volume_ul * float(count)

    return None


def _get_named_arg(call: CallStmt, name: str) -> Optional[Expression]:
    for arg in getattr(call, "arguments", []) or []:
        if getattr(arg, "name", None) == name:
            return getattr(arg, "value", None)
    return None


def _get_positional_args(call: CallStmt) -> List[Expression]:
    out: List[Expression] = []
    for arg in getattr(call, "arguments", []) or []:
        if getattr(arg, "name", None) is None:
            value = getattr(arg, "value", None)
            if value is not None:
                out.append(value)
    return out


def _as_container_id(expr: Optional[Expression]) -> Optional[str]:
    if expr is None:
        return None
    if isinstance(expr, IdentifierExpr):
        return expr.name
    if isinstance(expr, StringLit):
        return expr.value
    return None


class ExprEvaluator:
    def __init__(self, env: Dict[str, Value]):
        self.env = env

    def eval(self, expr: Optional[Expression]) -> Value:
        if expr is None:
            return None

        if isinstance(expr, QuantityExpr):
            if expr.unit is None:
                raise ValidationError("QuantityExpr.unit is None")
            if isinstance(expr.value, NumberLit):
                return create_quantity(float(expr.value.value), str(expr.unit.text))
            # Fallback: try evaluating nested value expression
            inner = self.eval(expr.value)  # type: ignore[arg-type]
            if isinstance(inner, (int, float)):
                return create_quantity(float(inner), str(expr.unit.text))
            raise ValidationError("Unsupported QuantityExpr value")

        if isinstance(expr, NumberLit):
            return float(expr.value)
        if isinstance(expr, BoolLit):
            return bool(expr.value)
        if isinstance(expr, StringLit):
            return str(expr.value)

        if isinstance(expr, IdentifierExpr):
            return self.env.get(expr.name)

        if isinstance(expr, UnaryExpr):
            operand = self.eval(expr.operand)
            if expr.op == "-":
                if isinstance(operand, Quantity):
                    return operand * -1
                if isinstance(operand, (int, float)):
                    return -float(operand)
            if expr.op in ("!", "not"):
                if isinstance(operand, bool):
                    return not operand
            raise ValidationError(f"Unsupported unary op: {expr.op}")

        if isinstance(expr, BinaryExpr):
            left = self.eval(expr.left)
            right = self.eval(expr.right)
            op = expr.op

            # Quantity arithmetic
            if isinstance(left, Quantity) or isinstance(right, Quantity):
                if op in ("+", "-", "*", "/"):
                    return _apply_qty_binop(left, right, op)
                raise ValidationError(f"Unsupported quantity op: {op}")

            # Scalar/bool arithmetic
            if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                a = float(left)
                b = float(right)
                if op == "+":
                    return a + b
                if op == "-":
                    return a - b
                if op == "*":
                    return a * b
                if op == "/":
                    return a / b
                if op == "<":
                    return a < b
                if op == "<=":
                    return a <= b
                if op == ">":
                    return a > b
                if op == ">=":
                    return a >= b
                if op == "==":
                    return a == b
                if op == "!=":
                    return a != b

            if op in ("&&", "||") and isinstance(left, bool) and isinstance(right, bool):
                return (left and right) if op == "&&" else (left or right)

            # Equality for other primitive types
            if op == "==":
                return left == right
            if op == "!=":
                return left != right

            raise ValidationError(f"Unsupported binary expr: {op}")

        if isinstance(expr, ConditionalExpr):
            cond = self.eval(expr.condition)
            if not isinstance(cond, bool):
                raise ValidationError("Conditional condition must be bool")
            return self.eval(expr.then_expr if cond else expr.else_expr)

        if isinstance(expr, RangeExpr):
            start = self.eval(expr.start)
            end = self.eval(expr.end)
            if isinstance(start, (int, float)) and isinstance(end, (int, float)):
                a = int(start)
                b = int(end)
                # Inclusive range in BPL examples: 1..10
                step = 1 if b >= a else -1
                return list(range(a, b + step, step))
            raise ValidationError("Range bounds must be numeric")

        if isinstance(expr, ListExpr):
            return [self.eval(e) for e in expr.elements]

        if isinstance(expr, MapExpr):
            return {k: self.eval(v) for k, v in (expr.entries or {}).items()}

        if isinstance(expr, StateDeltaExpr):
            # Evaluate to a dict of values
            return {k: self.eval(v) for k, v in (expr.fields or {}).items()}

        # Opaque expressions we do not evaluate in MVP
        if isinstance(expr, (FieldAccessExpr, MethodCallExpr, IndexExpr, CallExpr)):
            return None

        raise ValidationError(f"Unsupported expression type: {type(expr).__name__}")


def _apply_qty_binop(left: Value, right: Value, op: str) -> Quantity:
    if op in ("+", "-"):
        if not isinstance(left, Quantity) or not isinstance(right, Quantity):
            raise ValidationError("Quantity +/− requires both operands be Quantity")
        return left + right if op == "+" else left - right

    # * and /: allow scalar
    if op == "*":
        if isinstance(left, Quantity) and isinstance(right, (int, float)):
            return left * float(right)
        if isinstance(right, Quantity) and isinstance(left, (int, float)):
            return right * float(left)
        if isinstance(left, Quantity) and isinstance(right, Quantity):
            return left * right
        raise ValidationError("Unsupported quantity multiplication")

    if op == "/":
        if isinstance(left, Quantity) and isinstance(right, (int, float)):
            return left / float(right)
        if isinstance(left, Quantity) and isinstance(right, Quantity):
            return left / right
        raise ValidationError("Unsupported quantity division")

    raise ValidationError(f"Unknown op: {op}")


def validate_bpl_source(
    source: str,
    *,
    required_compliance: str | None = None,
    required_complexity: str | None = None,
) -> ValidationResult:
    """Validate BPL source code.

    Args:
        source: BPL source code string
        required_compliance: If "GMP", enforce GMP compliance annotations
        required_complexity: If set (L1_Linear, L2_Logic, L3_Parallel, L4_Resilient),
                            validate that the required constructs are present

    Returns:
        ValidationResult with ok=True if all checks pass
    """
    issues: List[ValidationIssue] = []
    metrics: Dict[str, Any] = {}

    try:
        program = parse(source)
    except Exception as e:
        return ValidationResult(
            ok=False,
            issues=[ValidationIssue(code="SYNTAX", message="BPL parse failed", detail=str(e))],
        )

    labware_by_prefix: Dict[str, LabwareInfo] = {}
    for decl in program.declarations:
        if isinstance(decl, LabwareDecl) and decl.well_volume is not None:
            try:
                qty = ExprEvaluator(env={}).eval(decl.well_volume)
                if isinstance(qty, Quantity):
                    labware_by_prefix[decl.name] = LabwareInfo(
                        well_volume_ul=_qty_to_ul(qty),
                        well_count=decl.well_count,
                    )
            except Exception:
                # Ignore malformed labware volumes; they will be caught later.
                pass

    protocols = [d for d in program.declarations if isinstance(d, ProtocolDecl)]
    if not protocols:
        issues.append(ValidationIssue(code="NO_PROTOCOL", message="No protocol declaration found"))

    # Check for recovery declarations (for L4_Resilient)
    has_recovery_decl = any(
        hasattr(decl, "__class__") and decl.__class__.__name__ == "RecoveryDecl"
        for decl in program.declarations
    )

    # Validate every protocol independently
    for protocol in protocols:
        protocol_metrics = _validate_protocol(
            protocol,
            labware_by_prefix,
            issues,
            required_compliance=required_compliance,
            required_complexity=required_complexity,
            has_recovery_decl=has_recovery_decl,
        )
        metrics.update(protocol_metrics)

    metrics["protocol_count"] = len(protocols)

    ok = len(issues) == 0
    return ValidationResult(
        ok=ok,
        issues=issues,
        metrics=metrics,
    )


def _validate_protocol(
    protocol: ProtocolDecl,
    labware_by_prefix: Dict[str, LabwareInfo],
    issues: List[ValidationIssue],
    *,
    required_compliance: str | None,
    required_complexity: str | None = None,
    has_recovery_decl: bool = False,
) -> Dict[str, Any]:
    """Validate a single protocol and return metrics."""
    env: Dict[str, Value] = {}
    evaluator = ExprEvaluator(env)
    state = SimulationState()
    metrics: Dict[str, Any] = {}

    # Collect protocol structure metrics
    structure = _analyze_protocol_structure(protocol)
    metrics.update(structure)

    if required_compliance == "GMP":
        _validate_gmp_audit(protocol, evaluator, issues)

    if required_complexity:
        _validate_complexity(
            protocol,
            required_complexity,
            structure,
            has_recovery_decl,
            issues,
        )

    def ensure_capacity(container_id: str) -> None:
        if container_id not in state.capacities_ul:
            cap = _infer_capacity_ul(container_id, labware_by_prefix)
            if cap is not None:
                state.capacities_ul[container_id] = cap

    def set_volume(container_id: str, volume_ul: float) -> None:
        ensure_capacity(container_id)
        
        if container_id not in state.capacities_ul:
            issues.append(
                ValidationIssue(
                    code="UNDEFINED_CONTAINER",
                    message=(
                        f"Container '{container_id}' has no defined capacity. "
                        "Define it in the FIRST manual() StateDelta as {volume: ..., capacity: ...} (or via labware)."
                    ),
                )
            )
            return

        cap = state.capacities_ul[container_id]
        if volume_ul < -1e-9:
            shortfall = abs(volume_ul)
            issues.append(ValidationIssue(
                code="NEGATIVE_VOLUME",
                message=f"{container_id} volume < 0",
                detail=f"Result: {volume_ul:.1f} uL (need {shortfall:.1f} uL more initial volume)"
            ))
        if volume_ul - cap > 1e-6:
            overflow_by = volume_ul - cap
            issues.append(ValidationIssue(
                code="OVERFLOW",
                message=f"{container_id} exceeds capacity",
                detail=f"{volume_ul:.1f} uL > {cap:.1f} uL capacity (overflow by {overflow_by:.1f} uL, increase capacity to {volume_ul * 1.2:.0f} uL)"
            ))
        state.volumes_ul[container_id] = volume_ul

    def add_volume(container_id: str, delta_ul: float) -> None:
        if container_id not in state.volumes_ul:
            issues.append(
                ValidationIssue(
                    code="UNINITIALIZED_CONTAINER",
                    message=(
                        f"Container '{container_id}' has no initialized volume. "
                        "Initialize it in the FIRST manual() StateDelta as {volume: ..., capacity: ...}."
                    ),
                )
            )
            return
        current = state.volumes_ul[container_id]
        set_volume(container_id, current + delta_ul)

    def _count_for_container(container_id: str) -> int:
        for prefix, info in labware_by_prefix.items():
            if container_id == prefix or container_id.startswith(prefix + "_"):
                if info.well_count is None:
                    return 1
                return max(int(info.well_count), 1)
        return 1

    def exec_block(block: Optional[Block]) -> None:
        if not block:
            return
        for stmt in block.statements:
            exec_stmt(stmt)

    def exec_stmt(stmt: Any) -> None:
        if isinstance(stmt, LetStmt):
            try:
                env[stmt.name] = evaluator.eval(stmt.value)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message=f"Failed to evaluate let {stmt.name}", detail=str(e)))
            return

        if isinstance(stmt, AssignStmt):
            try:
                env[stmt.target] = evaluator.eval(stmt.value)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message=f"Failed to evaluate assign {stmt.target}", detail=str(e)))
            return

        if isinstance(stmt, CallStmt):
            _exec_call(stmt)
            return

        if isinstance(stmt, StampStmt):
            try:
                _validate_units_in_expr(stmt.volume, evaluator)
                vol = evaluator.eval(stmt.volume)
                if not isinstance(vol, Quantity):
                    issues.append(ValidationIssue(code="SEMANTICS", message="stamp volume must be a Quantity"))
                    return
                vol_ul = _qty_to_ul(vol)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate stamp volume", detail=str(e)))
                return

            src = stmt.source_plate
            dst = stmt.dest_plate
            total_ul = vol_ul * float(_count_for_container(src))
            add_volume(src, -total_ul)
            add_volume(dst, +total_ul)
            return

        if isinstance(stmt, CherrypickStmt):
            try:
                _validate_units_in_expr(stmt.volume, evaluator)
                vol = evaluator.eval(stmt.volume)
                if not isinstance(vol, Quantity):
                    issues.append(ValidationIssue(code="SEMANTICS", message="cherrypick volume must be a Quantity"))
                    return
                vol_ul = _qty_to_ul(vol)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate cherrypick volume", detail=str(e)))
                return

            count = max(len(stmt.source_wells or []), 0)
            if count == 0:
                return
            total_ul = vol_ul * float(count)
            add_volume(stmt.source_plate, -total_ul)
            add_volume(stmt.dest_plate, +total_ul)
            return

        if isinstance(stmt, SerialDiluteStmt):
            try:
                _validate_units_in_expr(stmt.volume, evaluator)
                vol = evaluator.eval(stmt.volume)
                if not isinstance(vol, Quantity):
                    issues.append(ValidationIssue(code="SEMANTICS", message="serial_dilute volume must be a Quantity"))
                    return
                vol_ul = _qty_to_ul(vol)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate serial_dilute volume", detail=str(e)))
                return

            steps = int(getattr(stmt, "dilution_steps", 0) or 0)
            dests = list(getattr(stmt, "dest_plates", []) or [])
            if steps <= 0:
                return
            steps = min(steps, len(dests))

            prev = stmt.source_plate
            for i in range(steps):
                dst = dests[i]
                add_volume(prev, -vol_ul)
                add_volume(dst, +vol_ul)
                prev = dst
            return

        if isinstance(stmt, IfStmt):
            try:
                cond = evaluator.eval(stmt.condition)
                if isinstance(cond, bool) and cond:
                    exec_block(stmt.then_block)
                elif isinstance(cond, bool):
                    # else-if chain
                    handled = False
                    for (elif_cond, elif_block) in stmt.else_ifs:
                        v = evaluator.eval(elif_cond)
                        if isinstance(v, bool) and v:
                            exec_block(elif_block)
                            handled = True
                            break
                    if not handled:
                        exec_block(stmt.else_block)
                else:
                    issues.append(ValidationIssue(code="EVAL", message="If condition did not evaluate to bool"))
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate if", detail=str(e)))
            return

        if isinstance(stmt, ForStmt):
            try:
                iterable = evaluator.eval(stmt.iterable)
                if isinstance(iterable, list):
                    for item in iterable:
                        env[stmt.variable] = item
                        exec_block(stmt.body)
                else:
                    issues.append(ValidationIssue(code="EVAL", message="For iterable is not a list (MVP only supports ranges/lists)"))
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to execute for", detail=str(e)))
            return

        if isinstance(stmt, WhileStmt):
            # Safety cap to avoid infinite loops
            for _ in range(100):
                try:
                    cond = evaluator.eval(stmt.condition)
                except Exception as e:
                    issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate while condition", detail=str(e)))
                    return
                if not isinstance(cond, bool):
                    issues.append(ValidationIssue(code="EVAL", message="While condition did not evaluate to bool"))
                    return
                if not cond:
                    return
                exec_block(stmt.body)
            issues.append(ValidationIssue(code="LOOP", message="While loop exceeded max iterations (100)"))
            return

        if isinstance(stmt, (ParallelBlock, SequenceBlock)):
            # MVP: execute deterministically in written order.
            for inner in stmt.statements:
                exec_stmt(inner)
            return

        if isinstance(stmt, ReturnStmt):
            return

        # Unknown statement types are ignored in MVP.

    def _exec_call(call: CallStmt) -> None:
        name = call.name

        # 1) Unit validation: validate all quantity literals in arguments.
        for arg in call.arguments or []:
            try:
                _validate_units_in_expr(getattr(arg, "value", None), evaluator)
            except Exception as e:
                issues.append(ValidationIssue(code="UNIT", message=f"Unit validation failed in call {name}", detail=str(e)))

        # 2) StateDelta initialization / edits via manual(..., state_effects: StateDelta { ... })
        if name == "manual":
            se = _get_named_arg(call, "state_effects")
            if isinstance(se, StateDeltaExpr):
                try:
                    delta = evaluator.eval(se)
                    if isinstance(delta, dict):
                        for k, v in delta.items():
                            container_id = str(k)
                            # Strict container spec: { volume: <qty>, capacity: <qty> }
                            if isinstance(v, dict):
                                vol = v.get("volume")
                                cap = v.get("capacity")

                                if not isinstance(vol, Quantity) or not isinstance(cap, Quantity):
                                    issues.append(
                                        ValidationIssue(
                                            code="MANUAL_CONTAINER_SPEC",
                                            message=(
                                                f"manual() StateDelta for '{container_id}' must define both volume and capacity "
                                                "as quantities: { volume: 100 uL, capacity: 1500 uL }."
                                            ),
                                        )
                                    )
                                    continue

                                vol_ul = _qty_to_ul(vol)
                                cap_ul = _qty_to_ul(cap)
                                if cap_ul <= 0:
                                    issues.append(
                                        ValidationIssue(
                                            code="CAPACITY_INVALID",
                                            message=f"{container_id} capacity must be > 0",
                                            detail=str(cap),
                                        )
                                    )
                                    continue

                                # If capacity already exists (e.g., labware decl), require consistency.
                                ensure_capacity(container_id)
                                if container_id in state.capacities_ul:
                                    existing = state.capacities_ul[container_id]
                                    if abs(existing - cap_ul) > 1e-6:
                                        issues.append(
                                            ValidationIssue(
                                                code="CAPACITY_MISMATCH",
                                                message=f"{container_id} capacity conflicts with existing definition",
                                                detail=f"manual={cap_ul} uL vs existing={existing} uL",
                                            )
                                        )
                                        continue
                                else:
                                    state.capacities_ul[container_id] = cap_ul

                                set_volume(container_id, vol_ul)
                                continue

                            # Backwards incompatible: quantities alone no longer allowed.
                            if isinstance(v, Quantity):
                                issues.append(
                                    ValidationIssue(
                                        code="MANUAL_CONTAINER_SPEC",
                                        message=(
                                            f"manual() StateDelta for '{container_id}' must be an object with both volume and capacity. "
                                            "Example: tube1: { volume: 100 uL, capacity: 1500 uL }."
                                        ),
                                    )
                                )
                except Exception as e:
                    issues.append(ValidationIssue(code="STATE", message="Failed to apply StateDelta", detail=str(e)))
            return

        # 3) Transfer-like operations
        if name in {"transfer", "pipette", "move_liquid"}:
            src = _as_container_id(_get_named_arg(call, "from"))
            dst = _as_container_id(_get_named_arg(call, "to"))
            vol_expr = _get_named_arg(call, "volume")

            if not src or not dst or not vol_expr:
                issues.append(ValidationIssue(code="SEMANTICS", message="transfer requires from/to/volume named args"))
                return

            try:
                vol = evaluator.eval(vol_expr)
                if not isinstance(vol, Quantity):
                    issues.append(ValidationIssue(code="SEMANTICS", message="transfer volume must be a Quantity"))
                    return
                vol_ul = _qty_to_ul(vol)
            except Exception as e:
                issues.append(ValidationIssue(code="EVAL", message="Failed to evaluate transfer volume", detail=str(e)))
                return

            ensure_capacity(src)
            ensure_capacity(dst)
            add_volume(src, -vol_ul)
            add_volume(dst, +vol_ul)
            return

        # 4) add(reagent, volume: X, to: dst) treated as transfer from stock_<reagent>
        if name == "add":
            dst = _as_container_id(_get_named_arg(call, "to"))
            vol_expr = _get_named_arg(call, "volume")
            pos = _get_positional_args(call)
            reagent = _as_container_id(pos[0]) if pos else None
            if not dst or not vol_expr or not reagent:
                # If missing pieces, we cannot do physics; still accept syntactically.
                return
            try:
                vol = evaluator.eval(vol_expr)
                if not isinstance(vol, Quantity):
                    return
                vol_ul = _qty_to_ul(vol)
                src = f"stock_{reagent}"
                ensure_capacity(src)
                ensure_capacity(dst)
                add_volume(src, -vol_ul)
                add_volume(dst, +vol_ul)
            except Exception:
                return

    # Execute protocol statements
    for stmt in protocol.body:
        exec_stmt(stmt)

    return metrics


def _analyze_protocol_structure(protocol: ProtocolDecl) -> Dict[str, Any]:
    """Analyze protocol structure and return metrics."""
    metrics = {
        "has_for": False,
        "has_while": False,
        "has_if": False,
        "has_parallel": False,
        "has_sequence": False,
        "has_on_error": False,
        "step_count": 0,
        "transfer_count": 0,
        "container_count": 0,
    }

    containers: set[str] = set()

    def analyze_stmt(stmt: Any) -> None:
        metrics["step_count"] += 1

        if isinstance(stmt, ForStmt):
            metrics["has_for"] = True
            if stmt.body:
                for s in stmt.body.statements:
                    analyze_stmt(s)
            return

        if isinstance(stmt, WhileStmt):
            metrics["has_while"] = True
            if stmt.body:
                for s in stmt.body.statements:
                    analyze_stmt(s)
            return

        if isinstance(stmt, IfStmt):
            metrics["has_if"] = True
            if stmt.then_block:
                for s in stmt.then_block.statements:
                    analyze_stmt(s)
            for _, blk in stmt.else_ifs:
                for s in blk.statements:
                    analyze_stmt(s)
            if stmt.else_block:
                for s in stmt.else_block.statements:
                    analyze_stmt(s)
            return

        if isinstance(stmt, ParallelBlock):
            metrics["has_parallel"] = True
            for s in stmt.statements:
                analyze_stmt(s)
            return

        if isinstance(stmt, SequenceBlock):
            metrics["has_sequence"] = True
            for s in stmt.statements:
                analyze_stmt(s)
            return

        if isinstance(stmt, CallStmt):
            # Check for @on_error annotation
            for ann in getattr(stmt, "annotations", []) or []:
                if isinstance(ann, Annotation) and ann.name == "on_error":
                    metrics["has_on_error"] = True

            if stmt.name in {"transfer", "pipette", "move_liquid"}:
                metrics["transfer_count"] += 1
                # Track containers
                src = _as_container_id(_get_named_arg(stmt, "from"))
                dst = _as_container_id(_get_named_arg(stmt, "to"))
                if src:
                    containers.add(src)
                if dst:
                    containers.add(dst)

            if stmt.name == "add":
                metrics["transfer_count"] += 1
                dst = _as_container_id(_get_named_arg(stmt, "to"))
                if dst:
                    containers.add(dst)

            if stmt.name == "manual":
                se = _get_named_arg(stmt, "state_effects")
                if isinstance(se, StateDeltaExpr):
                    for k in (se.fields or {}).keys():
                        containers.add(str(k))

    for stmt in protocol.body:
        analyze_stmt(stmt)

    metrics["container_count"] = len(containers)
    return metrics


def _validate_complexity(
    protocol: ProtocolDecl,
    required_complexity: str,
    structure: Dict[str, Any],
    has_recovery_decl: bool,
    issues: List[ValidationIssue],
) -> None:
    """Validate that the protocol meets complexity requirements."""

    if required_complexity == "L1_Linear":
        # L1 should NOT have control flow
        if structure.get("has_for") or structure.get("has_while") or structure.get("has_if"):
            # This is actually fine - L1 just means linear is acceptable, not required
            pass
        if structure.get("has_parallel"):
            pass  # Also fine

    elif required_complexity == "L2_Logic":
        # Must have at least one of: for, while, if
        has_control = (
            structure.get("has_for") or
            structure.get("has_while") or
            structure.get("has_if")
        )
        if not has_control:
            issues.append(ValidationIssue(
                code="COMPLEXITY_L2_MISSING",
                message="L2_Logic requires at least one control flow construct (for/while/if)",
                detail="No for, while, or if statement found in protocol",
            ))

    elif required_complexity == "L3_Parallel":
        # Must have parallel { }
        if not structure.get("has_parallel"):
            issues.append(ValidationIssue(
                code="COMPLEXITY_L3_MISSING",
                message="L3_Parallel requires a parallel { } block",
                detail="No parallel block found in protocol",
            ))

    elif required_complexity == "L4_Resilient":
        # Must have @on_error AND recovery declaration
        if not structure.get("has_on_error"):
            issues.append(ValidationIssue(
                code="COMPLEXITY_L4_ON_ERROR_MISSING",
                message="L4_Resilient requires @on_error annotation",
                detail="No @on_error annotation found in protocol",
            ))
        if not has_recovery_decl:
            issues.append(ValidationIssue(
                code="COMPLEXITY_L4_RECOVERY_MISSING",
                message="L4_Resilient requires a recovery declaration",
                detail="No recovery { } declaration found",
            ))

    # Validate completeness (min steps, transfers, containers)
    reqs = COMPLEXITY_REQUIREMENTS.get(required_complexity, {})
    min_steps = reqs.get("min_steps", 0)
    min_transfers = reqs.get("min_transfers", 0)
    min_containers = reqs.get("min_containers", 0)

    if structure.get("step_count", 0) < min_steps:
        issues.append(ValidationIssue(
            code="COMPLETENESS_STEPS",
            message=f"{required_complexity} requires at least {min_steps} steps",
            detail=f"Found {structure.get('step_count', 0)} steps",
        ))

    if structure.get("transfer_count", 0) < min_transfers:
        issues.append(ValidationIssue(
            code="COMPLETENESS_TRANSFERS",
            message=f"{required_complexity} requires at least {min_transfers} transfers",
            detail=f"Found {structure.get('transfer_count', 0)} transfers",
        ))

    if structure.get("container_count", 0) < min_containers:
        issues.append(ValidationIssue(
            code="COMPLETENESS_CONTAINERS",
            message=f"{required_complexity} requires at least {min_containers} containers",
            detail=f"Found {structure.get('container_count', 0)} containers",
        ))


def _expr_to_text(expr: Any) -> Optional[str]:
    if expr is None:
        return None
    if isinstance(expr, IdentifierExpr):
        return expr.name
    if isinstance(expr, StringLit):
        return expr.value
    if isinstance(expr, NumberLit):
        return str(expr.value)
    if isinstance(expr, BoolLit):
        return "true" if expr.value else "false"
    return None


def _protocol_declares_compliance_gmp(protocol: ProtocolDecl) -> bool:
    # 1) @compliance(GMP) on protocol annotations
    for ann in getattr(protocol, "annotations", []) or []:
        if not isinstance(ann, Annotation):
            continue
        if ann.name != "compliance":
            continue
        v = _expr_to_text(ann.get_positional(0))
        if v and v.upper() == "GMP":
            return True

    # 2) @default_compliance: GMP in protocol settings
    for setting in getattr(protocol, "settings", []) or []:
        if not isinstance(setting, ProtocolSetting):
            continue
        if setting.name != "default_compliance":
            continue
        v = _expr_to_text(setting.value)
        if v and v.upper() == "GMP":
            return True

    return False


def _iter_stmt_tree(stmt: Any) -> Iterable[Any]:
    yield stmt

    if isinstance(stmt, IfStmt):
        if stmt.then_block:
            for s in stmt.then_block.statements:
                yield from _iter_stmt_tree(s)
        for _, blk in stmt.else_ifs:
            for s in blk.statements:
                yield from _iter_stmt_tree(s)
        if stmt.else_block:
            for s in stmt.else_block.statements:
                yield from _iter_stmt_tree(s)
        return

    if isinstance(stmt, ForStmt):
        if stmt.body:
            for s in stmt.body.statements:
                yield from _iter_stmt_tree(s)
        return

    if isinstance(stmt, WhileStmt):
        if stmt.body:
            for s in stmt.body.statements:
                yield from _iter_stmt_tree(s)
        return

    if isinstance(stmt, (ParallelBlock, SequenceBlock)):
        for s in stmt.statements:
            yield from _iter_stmt_tree(s)
        return


def _iter_protocol_statements(protocol: ProtocolDecl) -> Iterable[Any]:
    for stmt in getattr(protocol, "body", []) or []:
        yield from _iter_stmt_tree(stmt)


def _has_any_annotation(stmt: Any, names: set[str]) -> bool:
    for ann in getattr(stmt, "annotations", []) or []:
        if isinstance(ann, Annotation) and ann.name in names:
            return True
    return False


def _has_step_critical(stmt: Any) -> bool:
    for ann in getattr(stmt, "annotations", []) or []:
        if not isinstance(ann, Annotation):
            continue
        if ann.name != "step":
            continue
        v = _expr_to_text(ann.get_positional(0))
        if v and v.lower() == "critical":
            return True
    return False


def _validate_gmp_audit(protocol: ProtocolDecl, evaluator: ExprEvaluator, issues: List[ValidationIssue]) -> None:
    if not _protocol_declares_compliance_gmp(protocol):
        issues.append(
            ValidationIssue(
                code="GMP_COMPLIANCE_MISSING",
                message="GMP protocol must declare @compliance(GMP) (or @default_compliance: GMP).",
            )
        )

    checkpoint_found = False
    critical_step_found = False
    init_state_fields = 0
    init_found = False

    for stmt in _iter_protocol_statements(protocol):
        # 1) Checkpoint labels
        for ann in getattr(stmt, "annotations", []) or []:
            if not isinstance(ann, Annotation):
                continue
            if ann.name != "checkpoint":
                continue
            checkpoint_found = True
            label_expr = ann.get_positional(0)
            label = _expr_to_text(label_expr)
            if not label or not isinstance(label_expr, StringLit):
                issues.append(
                    ValidationIssue(
                        code="GMP_CHECKPOINT_LABEL",
                        message="GMP checkpoint must be a non-empty string literal: @checkpoint(\"...\").",
                    )
                )

        # 2) Audit annotations on state-changing calls
        if isinstance(stmt, CallStmt):
            if stmt.name in {"transfer", "pipette", "move_liquid", "add", "manual"}:
                if not _has_any_annotation(stmt, {"step", "checkpoint", "audit", "record", "on_error"}):
                    issues.append(
                        ValidationIssue(
                            code="GMP_AUDIT_MISSING",
                            message="GMP requires audit annotations on state-changing steps.",
                            detail=f"Missing annotation on call: {stmt.name}(...)",
                        )
                    )

            if stmt.name in {"transfer", "pipette", "move_liquid", "add"} and _has_step_critical(stmt):
                critical_step_found = True

            # 3) manual(...) instruction + initialization StateDelta size
            if stmt.name == "manual":
                instr_expr = _get_named_arg(stmt, "instruction")
                instr_text = _expr_to_text(instr_expr)
                if not instr_text or not isinstance(instr_expr, StringLit):
                    issues.append(
                        ValidationIssue(
                            code="GMP_MANUAL_INSTRUCTION",
                            message="GMP requires manual(...) to include a non-empty string instruction.",
                        )
                    )

                se = _get_named_arg(stmt, "state_effects")
                if isinstance(se, StateDeltaExpr):
                    init_found = True
                    init_state_fields = max(init_state_fields, len(getattr(se, "fields", {}) or {}))

    if not checkpoint_found:
        issues.append(
            ValidationIssue(
                code="GMP_CHECKPOINT_MISSING",
                message="GMP protocol must include at least one @checkpoint(\"...\").",
            )
        )

    if not critical_step_found:
        issues.append(
            ValidationIssue(
                code="GMP_CRITICAL_STEP_MISSING",
                message="GMP protocol must mark at least one liquid-handling step as critical: @step(critical).",
            )
        )

    if not init_found:
        issues.append(
            ValidationIssue(
                code="GMP_INIT_MISSING",
                message="GMP protocol must initialize containers via manual(..., state_effects: StateDelta { ... }).",
            )
        )
    elif init_state_fields < 3:
        issues.append(
            ValidationIssue(
                code="GMP_INIT_TOO_SMALL",
                message="GMP initialization StateDelta must include at least 3 containers.",
                detail=f"found={init_state_fields}",
            )
        )


def _validate_units_in_expr(expr: Optional[Expression], evaluator: ExprEvaluator) -> None:
    if expr is None:
        return

    if isinstance(expr, QuantityExpr):
        # Raises if unknown unit
        q = evaluator.eval(expr)
        if not isinstance(q, Quantity):
            raise ValidationError("QuantityExpr did not evaluate to Quantity")
        return

    # Recurse into composite expressions
    if isinstance(expr, UnaryExpr):
        _validate_units_in_expr(expr.operand, evaluator)
        return

    if isinstance(expr, BinaryExpr):
        _validate_units_in_expr(expr.left, evaluator)
        _validate_units_in_expr(expr.right, evaluator)
        return

    if isinstance(expr, ConditionalExpr):
        _validate_units_in_expr(expr.condition, evaluator)
        _validate_units_in_expr(expr.then_expr, evaluator)
        _validate_units_in_expr(expr.else_expr, evaluator)
        return

    if isinstance(expr, RangeExpr):
        _validate_units_in_expr(expr.start, evaluator)
        _validate_units_in_expr(expr.end, evaluator)
        return

    if isinstance(expr, ListExpr):
        for e in expr.elements:
            _validate_units_in_expr(e, evaluator)
        return

    if isinstance(expr, MapExpr):
        for v in (expr.entries or {}).values():
            _validate_units_in_expr(v, evaluator)
        return

    if isinstance(expr, StateDeltaExpr):
        for v in (expr.fields or {}).values():
            _validate_units_in_expr(v, evaluator)
        return

    if isinstance(expr, (IdentifierExpr, NumberLit, BoolLit, StringLit)):
        return

    # Ignore opaque expressions in MVP.
    if isinstance(expr, (FieldAccessExpr, MethodCallExpr, IndexExpr, CallExpr)):
        return

    # Unknown expression types: attempt evaluation and let it fail if unit-related.
    evaluator.eval(expr)
