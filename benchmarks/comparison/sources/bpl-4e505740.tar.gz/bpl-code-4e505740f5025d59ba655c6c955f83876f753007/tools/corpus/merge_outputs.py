"""Merge and deduplicate worker outputs from parallel generation.

This script combines output files from multiple workers, removing any
duplicates that may have slipped through the shared deduplication.

Usage:
    python -m tools.corpus.merge_outputs data/parallel_output/
    python -m tools.corpus.merge_outputs data/run_001/ --output-alpaca data/final.jsonl
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Set

# Ensure repo root is in path
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))


@dataclass
class MergeStats:
    """Statistics from merge operation."""

    total_records: int
    unique_records: int
    duplicates_removed: int
    files_processed: int


def hash_bpl(bpl_code: str) -> str:
    """Generate hash for deduplication.

    Handles BPL code that may be wrapped in <thinking> tags.

    Args:
        bpl_code: Raw BPL code or output with thinking tags

    Returns:
        16-character hash prefix
    """
    # Strip thinking tags if present
    if "</thinking>" in bpl_code:
        bpl_code = bpl_code.split("</thinking>", 1)[1]
    normalized = bpl_code.strip()
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


def merge_jsonl_files(
    input_dir: Path,
    output_alpaca: Path,
    output_full: Path,
    pattern: str = "*_alpaca.jsonl",
) -> MergeStats:
    """Merge all worker output files with deduplication.

    Deduplication is based on BPL code hash to remove any cross-worker
    duplicates that may have occurred despite shared state.

    Args:
        input_dir: Directory containing worker output subdirectories
        output_alpaca: Path for merged Alpaca-format output
        output_full: Path for merged full-record output
        pattern: Glob pattern for finding alpaca files

    Returns:
        MergeStats with counts of processed records
    """
    seen_hashes: Set[str] = set()
    total_records = 0
    unique_records = 0
    files_processed = 0

    # Collect all alpaca and full file pairs
    alpaca_files = sorted(input_dir.rglob(pattern))

    if not alpaca_files:
        print(f"Warning: No files matching '{pattern}' found in {input_dir}")
        return MergeStats(
            total_records=0,
            unique_records=0,
            duplicates_removed=0,
            files_processed=0,
        )

    # Ensure output directories exist
    output_alpaca.parent.mkdir(parents=True, exist_ok=True)
    output_full.parent.mkdir(parents=True, exist_ok=True)

    with output_alpaca.open("w", encoding="utf-8") as f_alpaca:
        with output_full.open("w", encoding="utf-8") as f_full:
            for alpaca_file in alpaca_files:
                # Find corresponding full file
                full_file = alpaca_file.with_name(
                    alpaca_file.name.replace("_alpaca.jsonl", "_full.jsonl")
                )
                if not full_file.exists():
                    print(f"Warning: Missing full file for {alpaca_file}")
                    continue

                files_processed += 1
                file_records = 0
                file_duplicates = 0

                # Process file pairs line by line
                with alpaca_file.open("r", encoding="utf-8") as fa:
                    with full_file.open("r", encoding="utf-8") as ff:
                        for alpaca_line, full_line in zip(fa, ff):
                            total_records += 1
                            file_records += 1

                            try:
                                # Parse and extract BPL for deduplication
                                full_record = json.loads(full_line)
                                bpl_code = full_record.get("output", "")
                                bpl_hash = hash_bpl(bpl_code)

                                if bpl_hash in seen_hashes:
                                    file_duplicates += 1
                                    continue  # Skip duplicate

                                seen_hashes.add(bpl_hash)
                                unique_records += 1

                                # Write to merged output
                                f_alpaca.write(alpaca_line)
                                f_full.write(full_line)

                            except json.JSONDecodeError as e:
                                print(f"Warning: Invalid JSON in {full_file}: {e}")
                                continue

                print(
                    f"  Processed {alpaca_file.name}: "
                    f"{file_records} records, {file_duplicates} duplicates"
                )

    return MergeStats(
        total_records=total_records,
        unique_records=unique_records,
        duplicates_removed=total_records - unique_records,
        files_processed=files_processed,
    )


def validate_merged_output(output_path: Path) -> bool:
    """Validate merged output file.

    Checks that all lines are valid JSON and contain required fields.

    Args:
        output_path: Path to JSONL file to validate

    Returns:
        True if valid, False otherwise
    """
    if not output_path.exists():
        print(f"Error: Output file does not exist: {output_path}")
        return False

    line_count = 0
    error_count = 0

    with output_path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line_count += 1
            try:
                record = json.loads(line)
                # Check for required fields (Alpaca format)
                if "instruction" not in record or "output" not in record:
                    print(f"Warning: Line {i} missing required fields")
                    error_count += 1
            except json.JSONDecodeError as e:
                print(f"Error: Line {i} is invalid JSON: {e}")
                error_count += 1

    if error_count > 0:
        print(f"Validation completed with {error_count} errors in {line_count} lines")
        return False

    print(f"Validation passed: {line_count} valid records")
    return True


def main():
    """CLI entry point for merging worker outputs."""
    parser = argparse.ArgumentParser(
        description="Merge and deduplicate worker outputs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m tools.corpus.merge_outputs data/parallel_output/
  python -m tools.corpus.merge_outputs data/run_001/ --output-alpaca data/final_alpaca.jsonl
  python -m tools.corpus.merge_outputs data/run_001/ --validate
        """,
    )
    parser.add_argument(
        "input_dir", type=Path, help="Directory containing worker output subdirectories"
    )
    parser.add_argument(
        "--output-alpaca",
        type=Path,
        default=Path("data/bpl_train_alpaca.jsonl"),
        help="Output path for Alpaca-format records",
    )
    parser.add_argument(
        "--output-full",
        type=Path,
        default=Path("data/bpl_train_full.jsonl"),
        help="Output path for full records",
    )
    parser.add_argument(
        "--pattern",
        default="*_alpaca.jsonl",
        help="Glob pattern for finding alpaca files",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Validate output after merging",
    )
    args = parser.parse_args()

    print(f"Merging worker outputs from: {args.input_dir}")
    print(f"Output Alpaca: {args.output_alpaca}")
    print(f"Output Full: {args.output_full}")
    print("=" * 60)

    stats = merge_jsonl_files(
        args.input_dir,
        args.output_alpaca,
        args.output_full,
        args.pattern,
    )

    print("=" * 60)
    print("\nMerge Complete!")
    print(f"  Files processed: {stats.files_processed}")
    print(f"  Total records: {stats.total_records}")
    print(f"  Unique records: {stats.unique_records}")
    print(f"  Duplicates removed: {stats.duplicates_removed}")
    if stats.total_records > 0:
        dedup_rate = stats.duplicates_removed / stats.total_records * 100
        print(f"  Deduplication rate: {dedup_rate:.1f}%")

    if args.validate:
        print("\nValidating output...")
        validate_merged_output(args.output_alpaca)


if __name__ == "__main__":
    main()
