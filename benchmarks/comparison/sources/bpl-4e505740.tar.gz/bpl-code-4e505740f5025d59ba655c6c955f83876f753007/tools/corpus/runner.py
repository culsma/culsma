"""DashScope (Alibaba Cloud Bailian) API runner for corpus generation.

This module provides sync and async LLM completion functions using DashScope API
via the OpenAI-compatible SDK. Features:
- HTTP/2 support via custom httpx client
- Structured outputs with JSON schema validation
- Deep thinking mode support (enable_thinking)
- Web search support (enable_search)
- Detailed logging for each request
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import traceback
import uuid
from dataclasses import dataclass
from typing import Any

import httpx
from openai import AsyncOpenAI, OpenAI

from tools.corpus.config import (
    get_max_concurrent,
    get_model,
    get_web_search_enabled,
    load_api_key,
)
from tools.corpus.schemas import get_response_format

# Logger for this module
logger = logging.getLogger("corpus.runner")

# Retry configuration
DEFAULT_MAX_RETRIES = 3
DEFAULT_INITIAL_DELAY = 2.0  # seconds
DEFAULT_MAX_DELAY = 60.0  # seconds
DEFAULT_BACKOFF_FACTOR = 2.0

# Module-level HTTP clients (singletons)
_sync_http_client: httpx.Client | None = None
_async_http_client: httpx.AsyncClient | None = None

# Module-level OpenAI clients (singletons)
_sync_openai_client: OpenAI | None = None
_async_openai_client: AsyncOpenAI | None = None


@dataclass(frozen=True)
class LLMResult:
    """Result from an LLM completion request."""

    ok: bool
    text: str | None
    reasoning: str | None
    raw_response: dict[str, Any] | None
    error: str | None

    @property
    def parsed_json(self) -> dict[str, Any] | list[Any] | None:
        """Parse the text response as JSON.

        Returns:
            Parsed JSON object, or None if parsing fails.
        """
        if not self.text:
            return None
        try:
            return json.loads(self.text)
        except json.JSONDecodeError:
            return None


def resolve_model(model: str | None) -> str:
    """Resolve model name to DashScope model ID.

    Args:
        model: Model name or None to use env default.

    Returns:
        DashScope model identifier from DASHSCOPE_MODEL env var or the provided model.
    """
    if model is None:
        return get_model()
    return model


def _get_connection_limits() -> httpx.Limits:
    """Get connection pool limits for HTTP clients."""
    return httpx.Limits(
        max_connections=100,  # Max total connections
        max_keepalive_connections=20,  # Max idle connections to keep alive
        keepalive_expiry=30.0,  # Seconds to keep idle connections
    )


def _get_timeout() -> httpx.Timeout:
    """Get timeout configuration for HTTP clients."""
    return httpx.Timeout(
        timeout=120.0,  # Total request timeout
        connect=30.0,  # Connection timeout
        read=90.0,  # Read timeout
        write=30.0,  # Write timeout
    )


def _get_sync_http_client() -> httpx.Client:
    """Get or create the sync HTTP/2 client singleton."""
    global _sync_http_client
    if _sync_http_client is None:
        _sync_http_client = httpx.Client(
            http2=True,
            timeout=_get_timeout(),
            limits=_get_connection_limits(),
        )
    return _sync_http_client


def _get_async_http_client() -> httpx.AsyncClient:
    """Get or create the async HTTP/2 client singleton."""
    global _async_http_client
    if _async_http_client is None:
        _async_http_client = httpx.AsyncClient(
            http2=True,
            timeout=_get_timeout(),
            limits=_get_connection_limits(),
        )
    return _async_http_client


def get_openai_client() -> OpenAI:
    """Get OpenAI client configured for DashScope with HTTP/2.

    Returns:
        Configured OpenAI client instance.
    """
    global _sync_openai_client
    if _sync_openai_client is None:
        _sync_openai_client = OpenAI(
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            api_key=load_api_key(),
            http_client=_get_sync_http_client(),
        )
    return _sync_openai_client


def get_async_openai_client() -> AsyncOpenAI:
    """Get async OpenAI client configured for DashScope with HTTP/2.

    Returns:
        Configured AsyncOpenAI client instance.
    """
    global _async_openai_client
    if _async_openai_client is None:
        _async_openai_client = AsyncOpenAI(
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            api_key=load_api_key(),
            http_client=_get_async_http_client(),
        )
    return _async_openai_client


def run_llm_completion(
    *,
    prompt: str,
    system_prompt: str = "",
    model: str | None = None,
    enable_thinking: bool = False,
    thinking_budget: int | None = None,
    response_schema: dict[str, Any] | None = None,
    enable_web_search: bool | None = None,
    max_retries: int = DEFAULT_MAX_RETRIES,
    initial_delay: float = DEFAULT_INITIAL_DELAY,
    max_delay: float = DEFAULT_MAX_DELAY,
    backoff_factor: float = DEFAULT_BACKOFF_FACTOR,
    reasoning_budget: int | None = None,  # Deprecated, kept for backwards compatibility
) -> LLMResult:
    """Run LLM completion via DashScope API (synchronous) with retry.

    Args:
        prompt: The user prompt to send.
        system_prompt: Optional system prompt for context.
        model: Model name (uses config default if None).
        enable_thinking: Enable deep thinking mode for complex reasoning.
        thinking_budget: Max tokens for thinking process (only used if enable_thinking=True).
        response_schema: JSON schema for structured output (from schemas.py).
        enable_web_search: Enable web search for grounding (uses config default if None).
        max_retries: Maximum number of retry attempts for retryable errors.
        initial_delay: Initial delay in seconds before first retry.
        max_delay: Maximum delay in seconds between retries.
        backoff_factor: Factor to multiply delay by after each retry.

    Returns:
        LLMResult with the completion text, reasoning, and metadata.
    """
    request_id = uuid.uuid4().hex[:8]
    resolved_model = resolve_model(model)
    web_search = (
        enable_web_search if enable_web_search is not None else get_web_search_enabled()
    )

    logger.info(
        f"[{request_id}] Starting LLM completion",
        extra={
            "model": resolved_model,
            "enable_thinking": enable_thinking,
            "has_schema": response_schema is not None,
            "prompt_length": len(prompt),
            "web_search": web_search,
        },
    )

    last_error: Exception | None = None
    current_delay = initial_delay

    for attempt in range(max_retries + 1):
        if attempt > 0:
            logger.info(
                f"[{request_id}] Retry attempt {attempt}/{max_retries} after {current_delay:.1f}s delay"
            )
            time.sleep(current_delay)
            current_delay = min(current_delay * backoff_factor, max_delay)

        start_time = time.perf_counter()

        try:
            client = get_openai_client()

            # Build messages
            messages: list[dict[str, str]] = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            # Build extra_body for DashScope-specific parameters
            extra_body: dict[str, Any] = {}

            # Add thinking mode if enabled
            if enable_thinking:
                extra_body["enable_thinking"] = True
                if thinking_budget is not None:
                    extra_body["thinking_budget"] = thinking_budget

            # Add web search if enabled
            if web_search:
                extra_body["enable_search"] = True

            # Build kwargs
            kwargs: dict[str, Any] = {
                "model": resolved_model,
                "messages": messages,
            }

            # Only add extra_body if it has content
            if extra_body:
                kwargs["extra_body"] = extra_body

            # Add response_format if schema provided
            if response_schema is not None:
                kwargs["response_format"] = get_response_format(response_schema)

            # Log the request configuration
            logger.debug(
                f"[{request_id}] Request config (attempt {attempt + 1}/{max_retries + 1})",
                extra={
                    "model": resolved_model,
                    "has_system_prompt": bool(system_prompt),
                    "prompt_chars": len(prompt),
                    "has_schema": response_schema is not None,
                    "web_search": web_search,
                    "enable_thinking": enable_thinking,
                },
            )

            # Make the API call
            response = client.chat.completions.create(**kwargs)

            duration = time.perf_counter() - start_time

            # Log raw response info
            logger.debug(
                f"[{request_id}] Raw response received",
                extra={
                    "response_id": getattr(response, "id", None),
                    "model": getattr(response, "model", None),
                    "choices_count": len(response.choices) if response.choices else 0,
                    "has_usage": response.usage is not None,
                },
            )

            # Validate response has choices
            if not response.choices or len(response.choices) == 0:
                logger.error(
                    f"[{request_id}] Empty response choices after {duration:.2f}s",
                    extra={
                        "duration_s": duration,
                        "response_id": getattr(response, "id", None),
                    },
                )
                return LLMResult(
                    ok=False,
                    text=None,
                    reasoning=None,
                    raw_response=None,
                    error="API returned empty choices",
                )

            # Extract response content
            message = response.choices[0].message
            text = message.content
            # DashScope returns reasoning in reasoning_content field
            reasoning = getattr(message, "reasoning_content", None)

            # Log content extraction
            logger.debug(
                f"[{request_id}] Content extracted",
                extra={
                    "text_length": len(text) if text else 0,
                    "has_reasoning": reasoning is not None,
                    "finish_reason": getattr(
                        response.choices[0], "finish_reason", None
                    ),
                },
            )

            # Build raw response dict
            raw_response: dict[str, Any] = {
                "id": response.id,
                "model": response.model,
                "usage": {
                    "prompt_tokens": (
                        response.usage.prompt_tokens if response.usage else 0
                    ),
                    "completion_tokens": (
                        response.usage.completion_tokens if response.usage else 0
                    ),
                    "total_tokens": (
                        response.usage.total_tokens if response.usage else 0
                    ),
                },
            }

            # Log success with metrics
            logger.info(
                f"[{request_id}] Completed in {duration:.2f}s",
                extra={
                    "duration_s": duration,
                    "prompt_tokens": raw_response["usage"]["prompt_tokens"],
                    "completion_tokens": raw_response["usage"]["completion_tokens"],
                    "has_reasoning": reasoning is not None,
                },
            )

            return LLMResult(
                ok=True,
                text=text,
                reasoning=reasoning,
                raw_response=raw_response,
                error=None,
            )

        except Exception as e:
            duration = time.perf_counter() - start_time
            error_msg = str(e)
            error_type = type(e).__name__
            last_error = e

            # Check if this error is retryable
            is_retryable = _is_retryable_error(e)
            remaining_retries = max_retries - attempt

            # Log the error
            if is_retryable and remaining_retries > 0:
                logger.warning(
                    f"[{request_id}] Retryable error after {duration:.2f}s (attempt {attempt + 1}/{max_retries + 1}): {error_msg}",
                    extra={
                        "error_type": error_type,
                        "duration_s": duration,
                        "remaining_retries": remaining_retries,
                    },
                )
            else:
                # Log comprehensive error details for final failure
                logger.error(
                    f"[{request_id}] Failed after {duration:.2f}s: {error_msg}",
                    extra={
                        "error_type": error_type,
                        "duration_s": duration,
                        "total_attempts": attempt + 1,
                    },
                )

                # Log additional details for connection errors
                _log_connection_error_details(
                    request_id=request_id,
                    error=e,
                    duration=duration,
                    model=resolved_model,
                    prompt_length=len(prompt),
                    attempt=attempt,
                    max_retries=max_retries,
                )

            # If not retryable or no more retries, break out of the loop
            if not is_retryable or remaining_retries <= 0:
                break

            # Log traceback for retryable errors too (at warning level)
            logger.warning(
                f"[{request_id}] Retryable error traceback:\n{traceback.format_exc()}"
            )

            # Continue to next retry attempt
            continue

    # All retries exhausted - return the last error
    error_msg = str(last_error) if last_error else "Unknown error after retries"
    return LLMResult(
        ok=False,
        text=None,
        reasoning=None,
        raw_response=None,
        error=error_msg,
    )


def _is_retryable_error(error: Exception) -> bool:
    """Check if an error is retryable (connection, timeout, rate limit).

    Args:
        error: The exception to check.

    Returns:
        True if the error is retryable, False otherwise.
    """
    error_msg = str(error).lower()

    # Connection errors
    if isinstance(error, (ConnectionError, OSError)):
        return True

    # Check error message for common retryable patterns
    retryable_patterns = [
        "connection",
        "timeout",
        "timed out",
        "temporarily unavailable",
        "service unavailable",
        "503",
        "502",
        "504",
        "rate limit",
        "too many requests",
        "429",
        "overloaded",
        "capacity",
        "try again",
        "retry",
    ]

    for pattern in retryable_patterns:
        if pattern in error_msg:
            return True

    # Check for httpx-specific errors
    if hasattr(error, "__class__"):
        error_class = error.__class__.__name__.lower()
        if any(p in error_class for p in ["timeout", "connect", "network"]):
            return True

    return False


def _log_connection_error_details(
    *,
    request_id: str,
    error: Exception,
    duration: float,
    model: str,
    prompt_length: int,
    attempt: int = 0,
    max_retries: int = 0,
) -> None:
    """Log comprehensive details about connection errors with full traceback."""
    error_type = type(error).__name__
    error_msg = str(error)

    # Classify error type
    is_timeout = "timeout" in error_msg.lower() or "timed out" in error_msg.lower()
    is_connection = "connection" in error_msg.lower() or isinstance(
        error, (ConnectionError, OSError)
    )
    is_ssl = "ssl" in error_msg.lower() or "certificate" in error_msg.lower()
    is_dns = "name resolution" in error_msg.lower() or "dns" in error_msg.lower()
    is_rate_limit = (
        "rate" in error_msg.lower()
        or "429" in error_msg
        or "too many" in error_msg.lower()
    )
    is_pool_timeout = "pool" in error_msg.lower() or "acquire" in error_msg.lower()

    # Build classification
    classifications = []
    if is_timeout:
        classifications.append("TIMEOUT")
    if is_connection:
        classifications.append("CONNECTION")
    if is_ssl:
        classifications.append("SSL/TLS")
    if is_dns:
        classifications.append("DNS")
    if is_rate_limit:
        classifications.append("RATE_LIMIT")
    if is_pool_timeout:
        classifications.append("POOL_TIMEOUT")
    if not classifications:
        classifications.append("UNKNOWN")

    classification = ", ".join(classifications)

    # Log error details
    logger.error(f"  [{request_id}] === ERROR DETAILS ===")
    logger.error(f"  [{request_id}] Classification: {classification}")
    logger.error(f"  [{request_id}] Error type: {error_type}")
    logger.error(f"  [{request_id}] Error message: {error_msg}")
    logger.error(f"  [{request_id}] Model: {model}")
    logger.error(f"  [{request_id}] Prompt length: {prompt_length} chars")
    logger.error(f"  [{request_id}] Duration before failure: {duration:.2f}s")
    logger.error(f"  [{request_id}] Attempt: {attempt + 1}/{max_retries + 1}")

    # Log exception chain
    if error.__cause__:
        logger.error(
            f"  [{request_id}] Caused by: {type(error.__cause__).__name__}: {error.__cause__}"
        )
    if error.__context__ and error.__context__ is not error.__cause__:
        logger.error(
            f"  [{request_id}] Context: {type(error.__context__).__name__}: {error.__context__}"
        )

    # Log full traceback at error level for debugging
    tb_str = traceback.format_exc()
    logger.error(f"  [{request_id}] Full traceback:\n{tb_str}")


async def run_llm_completion_async(
    *,
    prompt: str,
    system_prompt: str = "",
    model: str | None = None,
    enable_thinking: bool = False,
    thinking_budget: int | None = None,
    response_schema: dict[str, Any] | None = None,
    enable_web_search: bool | None = None,
    max_retries: int = DEFAULT_MAX_RETRIES,
    initial_delay: float = DEFAULT_INITIAL_DELAY,
    max_delay: float = DEFAULT_MAX_DELAY,
    backoff_factor: float = DEFAULT_BACKOFF_FACTOR,
    reasoning_budget: int | None = None,  # Deprecated, kept for backwards compatibility
) -> LLMResult:
    """Run LLM completion via DashScope API (asynchronous) with retry.

    Args:
        prompt: The user prompt to send.
        system_prompt: Optional system prompt for context.
        model: Model name (uses config default if None).
        enable_thinking: Enable deep thinking mode for complex reasoning.
        thinking_budget: Max tokens for thinking process (only used if enable_thinking=True).
        response_schema: JSON schema for structured output (from schemas.py).
        enable_web_search: Enable web search for grounding (uses config default if None).
        max_retries: Maximum number of retry attempts for retryable errors.
        initial_delay: Initial delay in seconds before first retry.
        max_delay: Maximum delay in seconds between retries.
        backoff_factor: Factor to multiply delay by after each retry.

    Returns:
        LLMResult with the completion text, reasoning, and metadata.
    """
    request_id = uuid.uuid4().hex[:8]
    resolved_model = resolve_model(model)
    web_search = (
        enable_web_search if enable_web_search is not None else get_web_search_enabled()
    )

    logger.info(
        f"[{request_id}] Starting async LLM completion",
        extra={
            "model": resolved_model,
            "enable_thinking": enable_thinking,
            "has_schema": response_schema is not None,
            "prompt_length": len(prompt),
            "web_search": web_search,
        },
    )

    last_error: Exception | None = None
    current_delay = initial_delay

    for attempt in range(max_retries + 1):
        if attempt > 0:
            logger.info(
                f"[{request_id}] Retry attempt {attempt}/{max_retries} after {current_delay:.1f}s delay"
            )
            await asyncio.sleep(current_delay)
            current_delay = min(current_delay * backoff_factor, max_delay)

        start_time = time.perf_counter()

        try:
            client = get_async_openai_client()

            # Build messages
            messages: list[dict[str, str]] = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})

            # Build extra_body for DashScope-specific parameters
            extra_body: dict[str, Any] = {}

            # Add thinking mode if enabled
            if enable_thinking:
                extra_body["enable_thinking"] = True
                if thinking_budget is not None:
                    extra_body["thinking_budget"] = thinking_budget

            # Add web search if enabled
            if web_search:
                extra_body["enable_search"] = True

            # Build kwargs
            kwargs: dict[str, Any] = {
                "model": resolved_model,
                "messages": messages,
            }

            # Only add extra_body if it has content
            if extra_body:
                kwargs["extra_body"] = extra_body

            # Add response_format if schema provided
            if response_schema is not None:
                kwargs["response_format"] = get_response_format(response_schema)

            # Log the request configuration
            logger.debug(
                f"[{request_id}] Request config (attempt {attempt + 1}/{max_retries + 1})",
                extra={
                    "model": resolved_model,
                    "has_system_prompt": bool(system_prompt),
                    "prompt_chars": len(prompt),
                    "has_schema": response_schema is not None,
                    "web_search": web_search,
                    "enable_thinking": enable_thinking,
                },
            )

            # Make the API call
            response = await client.chat.completions.create(**kwargs)

            duration = time.perf_counter() - start_time

            # Log raw response info
            logger.debug(
                f"[{request_id}] Raw response received",
                extra={
                    "response_id": getattr(response, "id", None),
                    "model": getattr(response, "model", None),
                    "choices_count": len(response.choices) if response.choices else 0,
                    "has_usage": response.usage is not None,
                },
            )

            # Validate response has choices
            if not response.choices or len(response.choices) == 0:
                logger.error(
                    f"[{request_id}] Empty response choices after {duration:.2f}s",
                    extra={
                        "duration_s": duration,
                        "response_id": getattr(response, "id", None),
                    },
                )
                return LLMResult(
                    ok=False,
                    text=None,
                    reasoning=None,
                    raw_response=None,
                    error="API returned empty choices",
                )

            # Extract response content
            message = response.choices[0].message
            text = message.content
            # DashScope returns reasoning in reasoning_content field
            reasoning = getattr(message, "reasoning_content", None)

            # Log content extraction
            logger.debug(
                f"[{request_id}] Content extracted",
                extra={
                    "text_length": len(text) if text else 0,
                    "has_reasoning": reasoning is not None,
                    "finish_reason": getattr(
                        response.choices[0], "finish_reason", None
                    ),
                },
            )

            # Build raw response dict
            raw_response: dict[str, Any] = {
                "id": response.id,
                "model": response.model,
                "usage": {
                    "prompt_tokens": (
                        response.usage.prompt_tokens if response.usage else 0
                    ),
                    "completion_tokens": (
                        response.usage.completion_tokens if response.usage else 0
                    ),
                    "total_tokens": (
                        response.usage.total_tokens if response.usage else 0
                    ),
                },
            }

            # Log success with metrics
            logger.info(
                f"[{request_id}] Completed in {duration:.2f}s",
                extra={
                    "duration_s": duration,
                    "prompt_tokens": raw_response["usage"]["prompt_tokens"],
                    "completion_tokens": raw_response["usage"]["completion_tokens"],
                    "has_reasoning": reasoning is not None,
                },
            )

            return LLMResult(
                ok=True,
                text=text,
                reasoning=reasoning,
                raw_response=raw_response,
                error=None,
            )

        except Exception as e:
            duration = time.perf_counter() - start_time
            error_msg = str(e)
            error_type = type(e).__name__
            last_error = e

            # Check if this error is retryable
            is_retryable = _is_retryable_error(e)
            remaining_retries = max_retries - attempt

            # Log the error
            if is_retryable and remaining_retries > 0:
                logger.warning(
                    f"[{request_id}] Retryable error after {duration:.2f}s (attempt {attempt + 1}/{max_retries + 1}): {error_msg}",
                    extra={
                        "error_type": error_type,
                        "duration_s": duration,
                        "remaining_retries": remaining_retries,
                    },
                )
            else:
                # Log comprehensive error details for final failure
                logger.error(
                    f"[{request_id}] Failed after {duration:.2f}s: {error_msg}",
                    extra={
                        "error_type": error_type,
                        "duration_s": duration,
                        "total_attempts": attempt + 1,
                    },
                )

                # Log additional details for connection errors
                _log_connection_error_details(
                    request_id=request_id,
                    error=e,
                    duration=duration,
                    model=resolved_model,
                    prompt_length=len(prompt),
                    attempt=attempt,
                    max_retries=max_retries,
                )

            # If not retryable or no more retries, break out of the loop
            if not is_retryable or remaining_retries <= 0:
                break

            # Log traceback for retryable errors too (at warning level)
            logger.warning(
                f"[{request_id}] Retryable error traceback:\n{traceback.format_exc()}"
            )

            # Continue to next retry attempt
            continue

    # All retries exhausted - return the last error
    error_msg = str(last_error) if last_error else "Unknown error after retries"
    return LLMResult(
        ok=False,
        text=None,
        reasoning=None,
        raw_response=None,
        error=error_msg,
    )


async def run_batch_completions(
    requests: list[dict[str, Any]],
    max_concurrent: int | None = None,
) -> list[LLMResult]:
    """Run multiple completions concurrently with rate limiting.

    Args:
        requests: List of dicts with kwargs for run_llm_completion_async.
        max_concurrent: Maximum concurrent requests (uses config default if None).

    Returns:
        List of LLMResult in the same order as requests.
    """
    if max_concurrent is None:
        max_concurrent = get_max_concurrent()

    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_with_limit(request: dict[str, Any]) -> LLMResult:
        async with semaphore:
            return await run_llm_completion_async(**request)

    tasks = [run_with_limit(req) for req in requests]
    return await asyncio.gather(*tasks)


def cleanup() -> None:
    """Clean up HTTP clients. Call this when done with all requests."""
    global _sync_http_client, _async_http_client, _sync_openai_client, _async_openai_client

    if _sync_http_client is not None:
        _sync_http_client.close()
        _sync_http_client = None

    if _async_http_client is not None:
        # Note: For async client, you should use await cleanup_async() instead
        pass

    _sync_openai_client = None
    _async_openai_client = None


async def cleanup_async() -> None:
    """Clean up async HTTP clients. Call this when done with all async requests."""
    global _async_http_client, _async_openai_client

    if _async_http_client is not None:
        await _async_http_client.aclose()
        _async_http_client = None

    _async_openai_client = None
