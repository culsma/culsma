"""Quality Critic - LLM-based quality assessment and self-refinement for BPL generation.

This module adds:
1. Layer 3: LLM Critic - Opus reviews and scores generated BPL
2. Self-Refinement Loop - Iterative improvement based on critic feedback
3. Evolution Chains - Generate variations from successful outputs

Pipeline (Maximum Quality):
  Layer 1 (Opus): SOP Seed → Diverse instruction scenarios
  Layer 2 (Opus): Expanded prompt → Initial BPL code
  Layer 3 (Opus): Critic review → Score + Feedback
  Loop: If score < threshold → Refine with feedback → Re-critique
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import sys

_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from tools.corpus.runner import run_llm_completion, run_llm_completion_async
from tools.corpus.schemas import CRITIC_SCHEMA, EVOLUTION_SCHEMA
from tools.corpus.validator import validate_bpl_source


@dataclass
class CriticResult:
    """Result from the LLM critic evaluation."""

    score: float  # 0.0 - 1.0
    passed: bool  # score >= threshold
    strengths: List[str]
    weaknesses: List[str]
    suggestions: List[str]
    refined_bpl: Optional[str] = None  # If critic provides improved version


@dataclass
class EvolutionResult:
    """Result from evolving a successful BPL output."""

    instruction_zh: str
    instruction_en: str
    context_zh: str
    context_en: str
    bpl: str
    evolution_type: str  # e.g., "scale_variation", "error_handling", "optimization"
    reasoning: str = ""  # Model's reasoning tokens from API  # Model's reasoning tokens from API  # e.g., "scale_variation", "error_handling", "optimization"


# System prompt for the LLM critic
CRITIC_SYSTEM_PROMPT = """\
You are an expert BPL (Biology Programming Language) code reviewer and lab automation specialist.

Your task is to critically evaluate BPL code for:

## Evaluation Criteria

### 1. Scientific Accuracy (0-25 points)
- Realistic reagent volumes and concentrations
- Correct temperatures for biological processes
- Appropriate incubation times
- Proper handling of sensitive materials

### 2. BPL Syntax & Style (0-25 points)
- Valid BPL v2.4 syntax
- Proper use of constructs (manual, transfer, incubate, etc.)
- Consistent naming conventions
- Appropriate annotations with CORRECT syntax:
  - `@compliance(GMP)` - compliance mode (NOT `@compliance "GMP"`)
  - `@checkpoint("description")` - audit checkpoints
  - `@step(id: "name", description: "...")` - step metadata
  - `@on_error(recovery_name)` - error handling

**IMPORTANT: Compliance Annotation Rules**
- GMP compliance: MUST include `@compliance(GMP)` annotation
- R&D compliance: MUST NOT include any `@compliance(...)` annotation (R&D = no annotation needed)
- NEVER penalize R&D protocols for "missing compliance annotation" - that is CORRECT behavior for R&D!
- The `&` character is INVALID in BPL, so `@compliance(R&D)` would be a SYNTAX ERROR

### 3. Protocol Completeness (0-25 points)
- All necessary initialization steps
- Complete workflow from start to finish
- All containers explicitly initialized via StateDelta at start
- Volume conservation in transfers

### 4. Instruction Alignment (0-25 points)
- BPL code matches the natural language instruction
- Context is properly reflected in the protocol
- Complexity requirements are met
- Compliance requirements are satisfied

## ⚠️ CRITICAL: StateDelta Format (causes 80% of failures if wrong)

Container initialization MUST use object format with BOTH volume AND capacity:

✅ CORRECT:
```bpl
manual(instruction: "Setup", state_effects: StateDelta {
  reagent_a: { volume: 500.0 uL, capacity: 1500.0 uL }
  tube1: { volume: 0 uL, capacity: 1500.0 uL }
})
```

❌ WRONG (just quantities - WILL FAIL VALIDATION):
```bpl
manual(instruction: "Setup", state_effects: StateDelta {
  reagent_a: 500.0 uL
  tube1: 0.0 uL
})
```

## Complexity Constraints (CRITICAL)

When refining code, you MUST preserve the complexity level requirements:
- **L1_Linear**: No control flow required (linear steps only), ≥3 transfers, ≥4 containers
- **L2_Logic**: MUST contain at least one control flow construct (for, while, or if), ≥4 transfers, ≥5 containers
- **L3_Parallel**: MUST contain `parallel { }` block, ≥4 transfers, ≥5 containers
- **L4_Resilient**: MUST contain BOTH:
  - `@on_error(recovery_name)` annotation on at least one step
  - `recovery recovery_name { ... }` block with recovery logic
  - Also requires: ≥5 transfers, ≥6 containers, ≥8 total steps

If the original code has for/while/if loops, the refined code MUST also have them.
Do NOT simplify away control flow constructs - they are required for validation.

## Scoring

- 90-100: Excellent - Production ready
- 80-89: Good - Minor improvements possible
- 70-79: Acceptable - Some issues to address
- 60-69: Needs Work - Significant improvements required
- Below 60: Fail - Major issues, regenerate

## Output Format

Return ONLY a JSON object:
{
  "score": 85,
  "passed": true,
  "strengths": ["Clear structure", "Proper volume conservation"],
  "weaknesses": ["Missing checkpoint annotation"],
  "suggestions": ["Add @checkpoint after critical transfer"],
  "refined_bpl": null or "improved protocol code if score < 80"
}

If score < 80, you MUST provide refined_bpl with an improved version.
"""


EVOLUTION_SYSTEM_PROMPT = """\
You are an expert at creating variations of lab protocols.

Given a successful BPL protocol, create a meaningful VARIATION that:
1. Maintains scientific validity
2. Explores a different scenario or scale
3. Uses the same core technique but with modifications

## BPL Syntax Rules (CRITICAL)

1. Protocol starts with: protocol name { ... }
2. Annotations use PARENTHESES: @compliance(GMP), @step(id: "x"), @checkpoint("desc")
   NEVER use: @compliance "GMP" - this is INVALID syntax
3. All containers must be initialized in first manual() with StateDelta
4. Use proper units: mL, uL, degC, min, s, rpm
5. NEVER use @compliance(R&D) - the & character is INVALID! Only use: GMP, GLP, GxP, Part11
   For R&D protocols, simply omit @compliance() entirely

## CRITICAL: StateDelta format (causes 80% of failures if wrong)

✅ CORRECT: container: { volume: 500.0 uL, capacity: 1500.0 uL }
❌ WRONG: container: 500.0 uL (just quantity - WILL FAIL VALIDATION)

## Evolution Types

1. **scale_up**: Increase volumes 5-10x for larger batches
2. **scale_down**: Miniaturize for screening (96-well format)
3. **automation**: Adapt for robotic liquid handler
4. **error_handling**: Add recovery steps and @on_error(recovery_name) annotations
5. **optimization**: Improve efficiency, reduce steps or time
6. **gmp_upgrade**: Add @compliance(GMP) and @checkpoint("...") annotations
7. **multi_sample**: Parallelize for multiple samples
8. **time_sensitive**: Optimize for speed, minimize wait times
9. **resource_constrained**: Use minimal reagents
10. **teaching**: Simplify with more comments and checkpoints

## Output Format

Return ONLY a JSON object:
{
  "instruction_zh": "变体指令（中文）",
  "instruction_en": "Variation instruction in English",
  "context_zh": "变体背景（中文）",
  "context_en": "Variation context in English",
  "bpl": "protocol variation_name { ... }",
  "evolution_type": "scale_up"
}

The variation must be DIFFERENT from the original but scientifically valid.
"""


def critique_bpl(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    *,
    model: str = "opus",
    threshold: float = 0.80,
    reasoning_budget: int = 8000,
) -> CriticResult:
    """Have LLM critique and score the generated BPL code.

    Args:
        bpl_code: The generated BPL code to evaluate
        instruction_zh: Chinese instruction
        instruction_en: English instruction
        context_zh: Chinese context
        context_en: English context
        complexity: Target complexity level
        compliance: Target compliance mode
        model: Model to use (default: opus)
        threshold: Minimum score to pass (default: 0.80)
        reasoning_budget: Max tokens for reasoning

    Returns:
        CriticResult with score, feedback, and optional refined code
    """
    user_prompt = f"""\
## BPL Code to Evaluate

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}

**English**: {instruction_en}

## Context

**Chinese**: {context_zh}

**English**: {context_en}

## Requirements

**Complexity**: {complexity}
**Compliance**: {compliance}

## Task

Critically evaluate this BPL code against:
1. Scientific accuracy
2. BPL syntax and style
3. Protocol completeness
4. Alignment with instruction

Provide a score (0-100), list strengths/weaknesses/suggestions.
If score < 80, provide an improved version in refined_bpl.
"""

    result = run_llm_completion(
        prompt=user_prompt,
        system_prompt=CRITIC_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=CRITIC_SCHEMA,
        enable_web_search=False,  # L3-CRITIC: No web search needed
    )

    if not result.ok:
        return CriticResult(
            score=0.0,
            passed=False,
            strengths=[],
            weaknesses=[f"LLM call failed: {result.error}"],
            suggestions=["Regenerate the BPL code"],
            refined_bpl=None,
        )

    # Parse structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict):
        score = float(parsed.get("score", 0)) / 100.0  # Normalize to 0-1
        passed = score >= threshold

        return CriticResult(
            score=score,
            passed=passed,
            strengths=parsed.get("strengths", []) or [],
            weaknesses=parsed.get("weaknesses", []) or [],
            suggestions=parsed.get("suggestions", []) or [],
            refined_bpl=parsed.get("refined_bpl"),
        )

    # Fallback to text parsing
    raw_text = result.text or ""
    return _parse_critic_result(raw_text, threshold)


def _parse_critic_result(raw_text: str, threshold: float) -> CriticResult:
    """Parse the critic's JSON response."""
    text = raw_text.strip()
    start = text.find("{")
    end = text.rfind("}")

    if start < 0 or end <= start:
        # Failed to parse, return failing result
        return CriticResult(
            score=0.0,
            passed=False,
            strengths=[],
            weaknesses=["Failed to parse critic response"],
            suggestions=["Regenerate the BPL code"],
            refined_bpl=None,
        )

    try:
        obj = json.loads(text[start : end + 1])

        score = float(obj.get("score", 0)) / 100.0  # Normalize to 0-1
        passed = score >= threshold

        return CriticResult(
            score=score,
            passed=passed,
            strengths=obj.get("strengths", []) or [],
            weaknesses=obj.get("weaknesses", []) or [],
            suggestions=obj.get("suggestions", []) or [],
            refined_bpl=obj.get("refined_bpl"),
        )

    except (json.JSONDecodeError, ValueError, TypeError):
        return CriticResult(
            score=0.0,
            passed=False,
            strengths=[],
            weaknesses=["Failed to parse critic response"],
            suggestions=["Regenerate the BPL code"],
            refined_bpl=None,
        )


def refine_with_feedback(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    critic_feedback: CriticResult,
    *,
    model: str = "opus",
    reasoning_budget: int = 8000,
) -> Optional[str]:
    """Refine BPL code based on critic feedback.

    Args:
        bpl_code: Original BPL code
        instruction_zh: Chinese instruction
        instruction_en: English instruction
        context_zh: Chinese context
        context_en: English context
        complexity: Target complexity
        compliance: Target compliance
        critic_feedback: Feedback from the critic
        model: Model to use
        reasoning_budget: Max tokens for reasoning

    Returns:
        Refined BPL code or None if refinement failed
    """
    weaknesses_text = "\n".join(f"- {w}" for w in critic_feedback.weaknesses)
    suggestions_text = "\n".join(f"- {s}" for s in critic_feedback.suggestions)

    user_prompt = f"""\
## Original BPL Code

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}
**English**: {instruction_en}

## Context

**Chinese**: {context_zh}
**English**: {context_en}

## Requirements

**Complexity**: {complexity}
**Compliance**: {compliance}

## Complexity Constraints (CRITICAL)

You MUST preserve the complexity level requirements:
- L1_Linear: No control flow required (linear steps only), ≥3 transfers, ≥4 containers
- L2_Logic: MUST contain at least one control flow construct (for, while, or if), ≥4 transfers, ≥5 containers
- L3_Parallel: MUST contain `parallel {{ }}` block, ≥4 transfers, ≥5 containers
- L4_Resilient: MUST contain BOTH:
  - `@on_error(recovery_name)` annotation on at least one step
  - `recovery recovery_name {{ ... }}` block with recovery logic
  - Also requires: ≥5 transfers, ≥6 containers, ≥8 total steps

If the original code has for/while/if loops, the refined code MUST also have them.
Do NOT simplify away control flow constructs - they are REQUIRED for validation to pass.

## Critic Feedback (Score: {critic_feedback.score * 100:.0f}/100)

### Weaknesses to Address:
{weaknesses_text}

### Suggestions for Improvement:
{suggestions_text}

## Volume and Container Guidelines

**Strict Container Definition**:
- All containers MUST be initialized in the first `manual` step.
- Each container entry in `StateDelta` MUST define BOTH current volume AND max capacity:
  `tube1: {{ volume: 100 uL, capacity: 1500 uL }}`
- Volume inference from names is DISABLED. You cannot rely on "flask" implying 100 mL.
- Unknown/uninitialized containers used in transfers/add/worklist operations will cause validation errors.

CRITICAL volume rules:
1. Source must have enough for ALL transfers (including in loops!)
   - A loop of 10 iterations with 50 uL each uses 500 uL total
2. Destination must not exceed capacity
3. Use descriptive names for reagent stocks, initialize with enough volume

## Task

Improve the BPL code by addressing ALL the weaknesses and implementing the suggestions.
Maintain scientific validity and BPL v2.4 syntax compliance.
Ensure volume conservation and use appropriate container names.

Return ONLY the improved BPL code (no JSON wrapper, no explanation, just the code).
"""

    refine_system_prompt = """\
You are a BPL code improvement specialist. Output ONLY valid BPL v2.4 code.

CRITICAL SYNTAX RULES:
1. Protocol starts with: protocol name { ... }
2. Annotations use PARENTHESES: @compliance(GMP), @step(id: "x"), @checkpoint("desc")
   NEVER use: @compliance "GMP" or @compliance: "GMP" outside protocol body
3. Protocol settings inside body use colon: @metadata: value
4. All containers must be initialized in first manual() with StateDelta
5. Use proper units: mL, uL, degC, min, s, rpm
6. NEVER use @compliance(R&D) - the & character is INVALID! Only use: GMP, GLP, GxP, Part11
   For R&D protocols, simply omit @compliance() entirely

CRITICAL: StateDelta format (causes 80% of failures if wrong):
✅ CORRECT: container: { volume: 500.0 uL, capacity: 1500.0 uL }
❌ WRONG: container: 500.0 uL

L4_Resilient MUST have:
- @on_error(recovery_name) annotation on at least one step
- recovery recovery_name { ... } block declaration

Output ONLY the BPL code, no explanations or markdown."""

    result = run_llm_completion(
        prompt=user_prompt,
        system_prompt=refine_system_prompt,
        model=model,
        reasoning_budget=reasoning_budget,
        enable_web_search=False,  # L4-REFINE: No web search needed
    )

    if not result.ok:
        return None

    raw_text = result.text or ""
    return _extract_bpl_code(raw_text)


def _extract_bpl_code(text: str) -> Optional[str]:
    """Extract BPL code from response text."""
    text = text.strip()

    # Try markdown code block
    if "```bpl" in text:
        start = text.find("```bpl")
        start = text.find("\n", start) + 1
        end = text.find("```", start)
        if end > start:
            return text[start:end].strip()

    if "```" in text:
        start = text.find("```")
        start = text.find("\n", start) + 1
        end = text.find("```", start)
        if end > start:
            code = text[start:end].strip()
            if code.startswith("protocol") or code.startswith("@"):
                return code

    # Raw code
    if text.startswith("protocol") or text.startswith("@"):
        return text

    return None


def evolve_successful_bpl(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    evolution_type: Optional[str] = None,
    *,
    model: str = "opus",
    reasoning_budget: int = 8000,
) -> Optional[EvolutionResult]:
    """Evolve a successful BPL output into a meaningful variation.

    Args:
        bpl_code: Successful BPL code to evolve
        instruction_zh: Original Chinese instruction
        instruction_en: Original English instruction
        context_zh: Original Chinese context
        context_en: Original English context
        evolution_type: Optional specific evolution type
        model: Model to use
        reasoning_budget: Max tokens for reasoning

    Returns:
        EvolutionResult with the variation or None if evolution failed
    """
    type_hint = ""
    if evolution_type:
        type_hint = f"\n**Requested Evolution Type**: {evolution_type}"

    user_prompt = f"""\
## Successful BPL Protocol

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}
**English**: {instruction_en}

## Original Context

**Chinese**: {context_zh}
**English**: {context_en}
{type_hint}

## Task

Create a MEANINGFUL VARIATION of this successful protocol.
The variation should:
1. Be scientifically valid
2. Explore a different scenario, scale, or approach
3. Maintain the core technique but with modifications
4. Have new, natural-sounding instructions

Return the variation as a JSON object.
"""

    result = run_llm_completion(
        prompt=user_prompt,
        system_prompt=EVOLUTION_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=EVOLUTION_SCHEMA,
        enable_web_search=False,  # Evolution: No web search needed
    )

    if not result.ok:
        return None

    # Capture reasoning from API response
    reasoning = result.reasoning or ""

    # Parse structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict):
        return EvolutionResult(
            instruction_zh=str(parsed.get("instruction_zh", "")).strip(),
            instruction_en=str(parsed.get("instruction_en", "")).strip(),
            context_zh=str(parsed.get("context_zh", "")).strip(),
            context_en=str(parsed.get("context_en", "")).strip(),
            bpl=str(parsed.get("bpl", "")).strip(),
            evolution_type=str(parsed.get("evolution_type", "variation")).strip(),
            reasoning=reasoning,
        )

    # Fallback to text parsing
    raw_text = result.text or ""
    evolution_result = _parse_evolution_result(raw_text)
    if evolution_result:
        evolution_result.reasoning = reasoning
    return evolution_result


def _parse_evolution_result(raw_text: str) -> Optional[EvolutionResult]:
    """Parse the evolution JSON response."""
    text = raw_text.strip()
    start = text.find("{")
    end = text.rfind("}")

    if start < 0 or end <= start:
        return None

    try:
        obj = json.loads(text[start : end + 1])

        return EvolutionResult(
            instruction_zh=str(obj.get("instruction_zh", "")).strip(),
            instruction_en=str(obj.get("instruction_en", "")).strip(),
            context_zh=str(obj.get("context_zh", "")).strip(),
            context_en=str(obj.get("context_en", "")).strip(),
            bpl=str(obj.get("bpl", "")).strip(),
            evolution_type=str(obj.get("evolution_type", "variation")).strip(),
        )

    except (json.JSONDecodeError, ValueError, TypeError):
        return None


def critique_and_refine(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    *,
    model: str = "opus",
    threshold: float = 0.80,
    max_refinements: int = 2,
    reasoning_budget: int = 8000,
) -> Tuple[str, CriticResult]:
    """Critique BPL code and refine until it passes or max attempts reached.

    This implements the self-refinement loop:
    1. Critique the code
    2. If score < threshold, refine with feedback
    3. Validate refinement before accepting
    4. Re-critique the refined code
    5. Repeat until passed or max_refinements reached

    Args:
        bpl_code: Initial BPL code
        instruction_zh: Chinese instruction
        instruction_en: English instruction
        context_zh: Chinese context
        context_en: English context
        complexity: Target complexity
        compliance: Target compliance
        model: Model to use
        threshold: Minimum score to pass
        max_refinements: Maximum refinement attempts
        reasoning_budget: Max tokens for reasoning

    Returns:
        Tuple of (final_bpl_code, final_critic_result)
    """
    current_code = bpl_code
    best_result: Optional[CriticResult] = None
    best_code = bpl_code

    for attempt in range(max_refinements + 1):
        # Critique current code
        critic_result = critique_bpl(
            current_code,
            instruction_zh,
            instruction_en,
            context_zh,
            context_en,
            complexity,
            compliance,
            model=model,
            threshold=threshold,
            reasoning_budget=reasoning_budget,
        )

        # Track best result
        if best_result is None or critic_result.score > best_result.score:
            best_result = critic_result
            best_code = current_code

        print(f"    [Critic] Attempt {attempt + 1}: Score {critic_result.score * 100:.0f}/100")

        # If passed, we're done
        if critic_result.passed:
            return current_code, critic_result

        # If this was the last attempt, return best
        if attempt >= max_refinements:
            break

        # Try to refine
        print(f"    [Refine] Improving based on {len(critic_result.weaknesses)} weaknesses...")

        candidate = None
        if critic_result.refined_bpl:
            candidate = critic_result.refined_bpl
        else:
            # Generate our own refinement
            refined = refine_with_feedback(
                current_code,
                instruction_zh,
                instruction_en,
                context_zh,
                context_en,
                complexity,
                compliance,
                critic_result,
                model=model,
                reasoning_budget=reasoning_budget,
            )
            if refined:
                candidate = refined

        # Validate candidate before accepting
        if candidate:
            validation = validate_bpl_source(
                candidate,
                required_compliance=compliance,
                required_complexity=complexity,
            )
            if validation.ok:
                current_code = candidate
            else:
                print("    [Refine] Refinement failed validation, keeping current")
        else:
            print("    [Refine] Failed to generate refinement")
            break

    # best_result is guaranteed to be set after at least one loop iteration
    assert best_result is not None
    return best_code, best_result


# Evolution types for variety
EVOLUTION_TYPES = [
    "scale_up",
    "scale_down",
    "automation",
    "error_handling",
    "optimization",
    "gmp_upgrade",
    "multi_sample",
    "time_sensitive",
    "resource_constrained",
    "teaching",
]


# ============================================================================
# ASYNC VERSIONS
# ============================================================================


async def critique_bpl_async(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    *,
    model: str = "opus",
    threshold: float = 0.80,
    reasoning_budget: int = 8000,
) -> CriticResult:
    """Async version of critique_bpl."""
    user_prompt = f"""\
## BPL Code to Evaluate

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}

**English**: {instruction_en}

## Context

**Chinese**: {context_zh}

**English**: {context_en}

## Requirements

**Complexity**: {complexity}
**Compliance**: {compliance}

## Task

Critically evaluate this BPL code against:
1. Scientific accuracy
2. BPL syntax and style
3. Protocol completeness
4. Alignment with instruction

Provide a score (0-100), list strengths/weaknesses/suggestions.
If score < 80, provide an improved version in refined_bpl.
"""

    result = await run_llm_completion_async(
        prompt=user_prompt,
        system_prompt=CRITIC_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=CRITIC_SCHEMA,
        enable_web_search=False,  # L3-CRITIC: No web search needed, evaluate BPL directly
    )

    if not result.ok:
        return CriticResult(
            score=0.0,
            passed=False,
            strengths=[],
            weaknesses=[f"LLM call failed: {result.error}"],
            suggestions=["Regenerate the BPL code"],
            refined_bpl=None,
        )

    # Parse structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict):
        score = float(parsed.get("score", 0)) / 100.0
        passed = score >= threshold

        return CriticResult(
            score=score,
            passed=passed,
            strengths=parsed.get("strengths", []) or [],
            weaknesses=parsed.get("weaknesses", []) or [],
            suggestions=parsed.get("suggestions", []) or [],
            refined_bpl=parsed.get("refined_bpl"),
        )

    # Fallback to text parsing
    raw_text = result.text or ""
    return _parse_critic_result(raw_text, threshold)


async def refine_with_feedback_async(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    critic_feedback: CriticResult,
    *,
    model: str = "opus",
    reasoning_budget: int = 8000,
) -> Optional[str]:
    """Async version of refine_with_feedback."""
    weaknesses_text = "\n".join(f"- {w}" for w in critic_feedback.weaknesses)
    suggestions_text = "\n".join(f"- {s}" for s in critic_feedback.suggestions)

    user_prompt = f"""\
## Original BPL Code

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}
**English**: {instruction_en}

## Context

**Chinese**: {context_zh}
**English**: {context_en}

## Requirements

**Complexity**: {complexity}
**Compliance**: {compliance}

## Complexity Constraints (CRITICAL)

You MUST preserve the complexity level requirements:
- L1_Linear: No control flow required (linear steps only), ≥3 transfers, ≥4 containers
- L2_Logic: MUST contain at least one control flow construct (for, while, or if), ≥4 transfers, ≥5 containers
- L3_Parallel: MUST contain `parallel {{ }}` block, ≥4 transfers, ≥5 containers
- L4_Resilient: MUST contain BOTH:
  - `@on_error(recovery_name)` annotation on at least one step
  - `recovery recovery_name {{ ... }}` block with recovery logic
  - Also requires: ≥5 transfers, ≥6 containers, ≥8 total steps

If the original code has for/while/if loops, the refined code MUST also have them.
Do NOT simplify away control flow constructs - they are REQUIRED for validation to pass.

## Critic Feedback (Score: {critic_feedback.score * 100:.0f}/100)

### Weaknesses to Address:
{weaknesses_text}

### Suggestions for Improvement:
{suggestions_text}

## Volume and Container Guidelines

**Strict Container Definition**:
- All containers MUST be initialized in the first `manual` step.
- Each container entry in `StateDelta` MUST define BOTH current volume AND max capacity:
  `tube1: {{ volume: 100 uL, capacity: 1500 uL }}`
- Volume inference from names is DISABLED. You cannot rely on "flask" implying 100 mL.
- Unknown/uninitialized containers used in transfers/add/worklist operations will cause validation errors.

CRITICAL volume rules:
1. Source must have enough for ALL transfers (including in loops!)
   - A loop of 10 iterations with 50 uL each uses 500 uL total
2. Destination must not exceed capacity
3. Use descriptive names for reagent stocks, initialize with enough volume

## Task

Improve the BPL code by addressing ALL the weaknesses and implementing the suggestions.
Maintain scientific validity and BPL v2.4 syntax compliance.
Ensure volume conservation and use appropriate container names.

Return ONLY the improved BPL code (no JSON wrapper, no explanation, just the code).
"""

    refine_system_prompt = """\
You are a BPL code improvement specialist. Output ONLY valid BPL v2.4 code.

CRITICAL SYNTAX RULES:
1. Protocol starts with: protocol name { ... }
2. Annotations use PARENTHESES: @compliance(GMP), @step(id: "x"), @checkpoint("desc")
   NEVER use: @compliance "GMP" or @compliance: "GMP" outside protocol body
3. Protocol settings inside body use colon: @metadata: value
4. All containers must be initialized in first manual() with StateDelta
5. Use proper units: mL, uL, degC, min, s, rpm
6. NEVER use @compliance(R&D) - the & character is INVALID! Only use: GMP, GLP, GxP, Part11
   For R&D protocols, simply omit @compliance() entirely

CRITICAL: StateDelta format (causes 80% of failures if wrong):
✅ CORRECT: container: { volume: 500.0 uL, capacity: 1500.0 uL }
❌ WRONG: container: 500.0 uL

L4_Resilient MUST have:
- @on_error(recovery_name) annotation on at least one step
- recovery recovery_name { ... } block declaration

Output ONLY the BPL code, no explanations or markdown."""

    result = await run_llm_completion_async(
        prompt=user_prompt,
        system_prompt=refine_system_prompt,
        model=model,
        reasoning_budget=reasoning_budget,
        enable_web_search=False,  # L4-REFINE: No web search needed, refine BPL directly
    )

    if not result.ok:
        return None

    raw_text = result.text or ""
    return _extract_bpl_code(raw_text)


async def evolve_successful_bpl_async(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    evolution_type: Optional[str] = None,
    *,
    model: str = "opus",
    reasoning_budget: int = 8000,
) -> Optional[EvolutionResult]:
    """Async version of evolve_successful_bpl."""
    type_hint = ""
    if evolution_type:
        type_hint = f"\n**Requested Evolution Type**: {evolution_type}"

    user_prompt = f"""\
## Successful BPL Protocol

```bpl
{bpl_code}
```

## Original Instruction

**Chinese**: {instruction_zh}
**English**: {instruction_en}

## Original Context

**Chinese**: {context_zh}
**English**: {context_en}
{type_hint}

## Task

Create a MEANINGFUL VARIATION of this successful protocol.
The variation should:
1. Be scientifically valid
2. Explore a different scenario, scale, or approach
3. Maintain the core technique but with modifications
4. Have new, natural-sounding instructions

Return the variation as a JSON object.
"""

    result = await run_llm_completion_async(
        prompt=user_prompt,
        system_prompt=EVOLUTION_SYSTEM_PROMPT,
        model=model,
        reasoning_budget=reasoning_budget,
        response_schema=EVOLUTION_SCHEMA,
        enable_web_search=False,  # Evolution: No web search needed, evolve from existing BPL
    )

    if not result.ok:
        return None

    # Capture reasoning from API response
    reasoning = result.reasoning or ""

    # Parse structured output
    parsed = result.parsed_json
    if parsed and isinstance(parsed, dict):
        return EvolutionResult(
            instruction_zh=str(parsed.get("instruction_zh", "")).strip(),
            instruction_en=str(parsed.get("instruction_en", "")).strip(),
            context_zh=str(parsed.get("context_zh", "")).strip(),
            context_en=str(parsed.get("context_en", "")).strip(),
            bpl=str(parsed.get("bpl", "")).strip(),
            evolution_type=str(parsed.get("evolution_type", "variation")).strip(),
            reasoning=reasoning,
        )

    # Fallback to text parsing
    raw_text = result.text or ""
    evolution_result = _parse_evolution_result(raw_text)
    if evolution_result:
        evolution_result.reasoning = reasoning
    return evolution_result


async def critique_and_refine_async(
    bpl_code: str,
    instruction_zh: str,
    instruction_en: str,
    context_zh: str,
    context_en: str,
    complexity: str,
    compliance: str,
    *,
    model: str = "opus",
    threshold: float = 0.80,
    max_refinements: int = 2,
    reasoning_budget: int = 8000,
) -> Tuple[str, CriticResult]:
    """Async version of critique_and_refine.

    Validates refinements before accepting to prevent invalid code propagation.
    """
    current_code = bpl_code
    best_result: Optional[CriticResult] = None
    best_code = bpl_code

    for attempt in range(max_refinements + 1):
        # Critique current code
        critic_result = await critique_bpl_async(
            current_code,
            instruction_zh,
            instruction_en,
            context_zh,
            context_en,
            complexity,
            compliance,
            model=model,
            threshold=threshold,
            reasoning_budget=reasoning_budget,
        )

        # Track best result
        if best_result is None or critic_result.score > best_result.score:
            best_result = critic_result
            best_code = current_code

        # If passed, we're done
        if critic_result.passed:
            return current_code, critic_result

        # If this was the last attempt, return best
        if attempt >= max_refinements:
            break

        # Try to refine
        candidate = None
        if critic_result.refined_bpl:
            candidate = critic_result.refined_bpl
        else:
            # Generate our own refinement
            refined = await refine_with_feedback_async(
                current_code,
                instruction_zh,
                instruction_en,
                context_zh,
                context_en,
                complexity,
                compliance,
                critic_result,
                model=model,
                reasoning_budget=reasoning_budget,
            )
            if refined:
                candidate = refined

        # Validate candidate before accepting
        if candidate:
            validation = validate_bpl_source(
                candidate,
                required_compliance=compliance,
                required_complexity=complexity,
            )
            if validation.ok:
                current_code = candidate
            # If validation fails, continue with current_code (don't update)
            # This prevents invalid refinements from propagating

    # best_result is guaranteed to be set after at least one loop iteration
    assert best_result is not None
    return best_code, best_result


if __name__ == "__main__":
    # Test the critic
    test_bpl = """protocol test_pcr {
  manual(instruction: "Prepare PCR reagents", state_effects: StateDelta {
    master_mix: { volume: 500.0 uL, capacity: 1500.0 uL }
    template: { volume: 100.0 uL, capacity: 200.0 uL }
    reaction_tube: { volume: 0.0 uL, capacity: 200.0 uL }
  })

  transfer(from: master_mix, to: reaction_tube, volume: 45.0 uL)
  transfer(from: template, to: reaction_tube, volume: 5.0 uL)

  incubate(container: reaction_tube, temperature: 95 degC, duration: 5 min)
}"""

    print("Testing critique_bpl...")
    result = critique_bpl(
        test_bpl,
        "进行PCR扩增实验",
        "Perform PCR amplification",
        "需要扩增目标基因片段",
        "Need to amplify target gene fragment",
        "L1_Linear",
        "R&D",
    )

    print(f"Score: {result.score * 100:.0f}/100")
    print(f"Passed: {result.passed}")
    print(f"Strengths: {result.strengths}")
    print(f"Weaknesses: {result.weaknesses}")
    print(f"Suggestions: {result.suggestions}")
