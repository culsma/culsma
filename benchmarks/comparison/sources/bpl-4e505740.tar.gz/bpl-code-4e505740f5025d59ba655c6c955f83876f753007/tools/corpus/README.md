# BPL Synthetic Corpus Tools

本目录提供一个"**LLM 生成 (DashScope)** → **本地裁判硬校验** → **失败回灌重试** → **写 JSONL**"的闭环。

## 4-Layer Maximum Quality Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│  L1 Seed Expansion (seed_expander.py)                           │
│  SOP Markdown → 5-10 diverse instruction scenarios per SOP      │
│  Timeout: 300s (default)                                        │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│  L2 BPL Generation (generate_dataset.py)                        │
│  Scenario + System Prompt → Initial BPL code via LLM            │
│  Timeout: 600s (default)                                        │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│  L3 Quality Critic (quality_critic.py)                          │
│  Score 0-100: Scientific accuracy, syntax, completeness, align  │
│  Timeout: 600s (default)                                        │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│  L4 Evolution (quality_critic.py → evolve_successful_bpl)       │
│  Scale variations, error handling, optimization from proven     │
│  Timeout: 600s (default), 30% probability per record            │
└─────────────────────────────────────────────────────────────────┘
```

## Configuration

Set model via environment variable in `.env`:
```
DASHSCOPE_API_KEY=<your-api-key>
DASHSCOPE_MODEL=qwen-plus
DASHSCOPE_MAX_CONCURRENT=5
DASHSCOPE_WEB_SEARCH=true
```

## Quick Start

```powershell
# Generate 10 records with all features enabled
uv run python tools/corpus/generate_dataset.py --count 10

# Generate 3000 records for full training
uv run python tools/corpus/generate_dataset.py --count 3000

# Resume from existing output
uv run python tools/corpus/generate_dataset.py --count 3000 --resume

# Disable optional features for faster generation
uv run python tools/corpus/generate_dataset.py --count 10 --no-evolution --no-critic

# Override model from command line
uv run python tools/corpus/generate_dataset.py --count 10 --model google/gemini-2.0-flash-exp
```

## CLI Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--count` | 3000 | Number of records to generate |
| `--seed` | 42 | Random seed for reproducibility |
| `--model` | (from .env) | Model to use (overrides DASHSCOPE_MODEL) |
| `--dataset-id` | bpl_v3 | Dataset identifier |
| `--max-attempts` | 8 | Max retries per record |
| `--out` | auto | Alpaca format output |
| `--out-full` | auto | Full metadata output |
| `--no-web-search` | false | Disable web search |
| `--no-expansion` | false | Disable L1 seed expansion |
| `--no-critic` | false | Disable L3 LLM critic |
| `--no-evolution` | false | Disable L4 evolution |
| `--critic-threshold` | 0.8 | Min score to pass (0-1) |
| `--max-refinements` | 4 | Max refinement iterations |
| `--evolution-probability` | 0.3 | Probability of evolution |
| `--log-dir` | logs/ | Directory for detailed logs |
| `--resume` | false | Continue from existing output |
| `--concurrency` | (from .env) | Number of concurrent workers |

## Output Files

Output is written to timestamped run folders under `data/`:

```
data/run_YYYYMMDD_HHMMSS/
├── run_config.json         # Run configuration
├── bpl_train_alpaca.jsonl  # Alpaca format (instruction, input, output)
└── bpl_train_full.jsonl    # Full metadata + rationale + domain tags
```

## Validation (Zero Hallucination)

`tools/corpus/validator.py` performs:

1. **Syntax**: `parse()` must succeed against `bpl/grammar/bpl.lark` (v2.4)
2. **Units**: All `QuantityExpr` validated by `bpl.types.get_unit()`
3. **Volume Conservation**: Transfer source must have sufficient volume
4. **Capacity**: Container overflow detection

5. **Complexity Requirements**:
   - **L1_Linear**: ≥4 steps, ≥3 transfers, ≥4 containers
   - **L2_Logic**: + control flow (`if/for/while`)
   - **L3_Parallel**: + `parallel { }` blocks
   - **L4_Resilient**: + `@on_error()` + `recovery { }`

6. **GMP Compliance** (when `compliance=GMP`):
   - `@compliance(GMP)` declaration required
   - At least one `@checkpoint("...")`
   - Critical steps marked with `@step(critical)`

## Error Handling

- **Timeout Graceful Recovery**: Timeouts return failing result instead of crashing
- **Auto-retry**: Validation failures feed back to LLM for correction
- **L4-REFINE Retry**: Failed refinements retry up to 5 times with validation errors as feedback
- **Detailed Logging**: All operations logged to `logs/` directory

## Important Notes

- BPL grammar: `bpl/grammar/bpl.lark` (v2.4)
- `try/catch`, `materials {}`, `steps {}` are **NOT** in current grammar
- Error recovery uses `@on_error(...)` annotation + `recovery ... { ... }` declaration
