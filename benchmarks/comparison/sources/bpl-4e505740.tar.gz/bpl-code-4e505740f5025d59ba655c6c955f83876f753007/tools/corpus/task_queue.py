"""Task queue for concurrent corpus generation.

This module provides a queue-based task distribution system for running
corpus generation tasks concurrently with proper worker management.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Awaitable, Callable

logger = logging.getLogger("corpus.task_queue")


@dataclass
class GenerationTask:
    """A single corpus generation task."""

    task_id: str
    sop_id: str
    complexity: str
    compliance: str
    scenario_index: int
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskResult:
    """Result of a generation task."""

    task: GenerationTask
    success: bool
    record: dict[str, Any] | None
    error: str | None
    duration_s: float
    started_at: datetime
    completed_at: datetime


class TaskProgress:
    """Thread-safe progress tracker for task completion."""

    def __init__(self, total: int) -> None:
        self.total = total
        self.completed = 0
        self.succeeded = 0
        self.failed = 0
        self._lock = asyncio.Lock()

    async def record_completion(self, success: bool) -> tuple[int, int, int]:
        """Record a task completion and return current stats.

        Args:
            success: Whether the task succeeded.

        Returns:
            Tuple of (completed, succeeded, failed) counts.
        """
        async with self._lock:
            self.completed += 1
            if success:
                self.succeeded += 1
            else:
                self.failed += 1
            return self.completed, self.succeeded, self.failed

    @property
    def percentage(self) -> float:
        """Get completion percentage."""
        return (self.completed / self.total * 100) if self.total > 0 else 0.0


class ConcurrentTaskQueue:
    """Queue-based task distribution for concurrent corpus generation.

    This class manages a pool of worker coroutines that process tasks from
    a shared queue. It provides:
    - Rate limiting via max_workers
    - Progress tracking and callbacks
    - Graceful shutdown
    - Error isolation (one failed task doesn't affect others)
    """

    def __init__(
        self,
        max_workers: int = 5,
        on_task_complete: Callable[[TaskResult], None] | None = None,
        on_progress: Callable[[int, int, int, int], None] | None = None,
    ) -> None:
        """Initialize the task queue.

        Args:
            max_workers: Maximum number of concurrent worker coroutines.
            on_task_complete: Callback called after each task completes.
            on_progress: Callback called with (completed, succeeded, failed, total).
        """
        self.max_workers = max_workers
        self.on_task_complete = on_task_complete
        self.on_progress = on_progress
        self._queue: asyncio.Queue[GenerationTask | None] = asyncio.Queue()
        self._results: list[TaskResult] = []
        self._lock = asyncio.Lock()
        self._progress: TaskProgress | None = None

    async def add_tasks(self, tasks: list[GenerationTask]) -> None:
        """Add tasks to the queue.

        Args:
            tasks: List of generation tasks to process.
        """
        self._progress = TaskProgress(len(tasks))

        for task in tasks:
            await self._queue.put(task)

        # Add sentinel values to signal workers to stop
        for _ in range(self.max_workers):
            await self._queue.put(None)

        logger.info(
            f"Added {len(tasks)} tasks to queue with {self.max_workers} workers"
        )

    async def _worker(
        self,
        worker_id: int,
        process_fn: Callable[[GenerationTask], Awaitable[dict[str, Any] | None]],
    ) -> None:
        """Worker coroutine that processes tasks from the queue.

        Args:
            worker_id: Unique identifier for this worker.
            process_fn: Async function to process a single task.
        """
        while True:
            task = await self._queue.get()

            if task is None:  # Sentinel - stop worker
                self._queue.task_done()
                logger.debug(f"[Worker-{worker_id}] Received stop signal")
                break

            started_at = datetime.now()
            start_time = asyncio.get_event_loop().time()

            logger.info(f"[Worker-{worker_id}] Processing task {task.task_id}")

            try:
                record = await process_fn(task)
                duration = asyncio.get_event_loop().time() - start_time
                completed_at = datetime.now()

                result = TaskResult(
                    task=task,
                    success=True,
                    record=record,
                    error=None,
                    duration_s=duration,
                    started_at=started_at,
                    completed_at=completed_at,
                )

                logger.info(
                    f"[Worker-{worker_id}] Task {task.task_id} completed in {duration:.2f}s"
                )

            except Exception as e:
                duration = asyncio.get_event_loop().time() - start_time
                completed_at = datetime.now()
                error_msg = str(e)

                result = TaskResult(
                    task=task,
                    success=False,
                    record=None,
                    error=error_msg,
                    duration_s=duration,
                    started_at=started_at,
                    completed_at=completed_at,
                )

                logger.error(
                    f"[Worker-{worker_id}] Task {task.task_id} failed after {duration:.2f}s: {error_msg}"
                )

            # Record result and update progress
            async with self._lock:
                self._results.append(result)

                if self._progress:
                    completed, succeeded, failed = await self._progress.record_completion(
                        result.success
                    )
                    if self.on_progress:
                        self.on_progress(
                            completed, succeeded, failed, self._progress.total
                        )

                if self.on_task_complete:
                    self.on_task_complete(result)

            self._queue.task_done()

    async def run(
        self,
        process_fn: Callable[[GenerationTask], Awaitable[dict[str, Any] | None]],
    ) -> list[TaskResult]:
        """Run all workers and process tasks.

        Args:
            process_fn: Async function to process a single task.
                Should take a GenerationTask and return a record dict or None.

        Returns:
            List of TaskResult objects for all processed tasks.
        """
        logger.info(f"Starting {self.max_workers} workers")

        workers = [
            asyncio.create_task(self._worker(i, process_fn))
            for i in range(self.max_workers)
        ]

        await asyncio.gather(*workers)

        if self._progress:
            logger.info(
                f"All tasks completed: {self._progress.succeeded}/{self._progress.total} succeeded, "
                f"{self._progress.failed} failed"
            )

        return self._results

    @property
    def results(self) -> list[TaskResult]:
        """Get the list of completed task results."""
        return self._results.copy()

    @property
    def successful_results(self) -> list[TaskResult]:
        """Get only successful task results."""
        return [r for r in self._results if r.success]

    @property
    def failed_results(self) -> list[TaskResult]:
        """Get only failed task results."""
        return [r for r in self._results if not r.success]


async def generate_corpus_concurrent(
    tasks: list[GenerationTask],
    process_fn: Callable[[GenerationTask], Awaitable[dict[str, Any] | None]],
    max_concurrent: int = 5,
    on_progress: Callable[[int, int, int, int], None] | None = None,
) -> list[dict[str, Any]]:
    """Generate corpus records concurrently.

    This is a convenience function that sets up the task queue and runs it.

    Args:
        tasks: List of generation tasks to process.
        process_fn: Async function to process a single task.
        max_concurrent: Maximum number of concurrent workers.
        on_progress: Optional callback for progress updates.

    Returns:
        List of successfully generated records.
    """
    queue = ConcurrentTaskQueue(
        max_workers=max_concurrent,
        on_progress=on_progress,
    )

    await queue.add_tasks(tasks)
    results = await queue.run(process_fn)

    return [r.record for r in results if r.success and r.record is not None]
