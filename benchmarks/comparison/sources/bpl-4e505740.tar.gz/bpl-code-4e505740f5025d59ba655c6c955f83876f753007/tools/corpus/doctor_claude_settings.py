"""Local IDE-settings diagnostic — NOT part of the BPL paper workflow.

This is a one-off helper that the maintainer uses to sanity-check JSON
files under their user-level IDE-assistant settings directory
(``~/.claude/``). It has no dependency on the BPL compiler, the
evaluation pipeline, or the corpus-generation logic, and reviewers
reproducing the paper can ignore this file entirely.
"""

from __future__ import annotations

import json
import os
from json import JSONDecodeError
from pathlib import Path
from typing import Iterable


def _parse_json_file(path: Path) -> tuple[bool, str]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            keys = sorted(data.keys())
            return True, f"JSON object; keys={keys}"
        return True, f"JSON {type(data).__name__}"
    except UnicodeDecodeError:
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            if isinstance(data, dict):
                keys = sorted(data.keys())
                return True, f"JSON object (utf-8-sig); keys={keys}"
            return True, f"JSON {type(data).__name__} (utf-8-sig)"
        except Exception as e:
            return False, f"decode/parse error: {e}"
    except JSONDecodeError as e:
        return False, f"line {e.lineno}, col {e.colno}: {e.msg}"


def _iter_json_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*.json"):
        yield path


def main() -> None:
    home = Path(os.path.expanduser("~"))
    candidates = [home / ".claude.json", home / ".claude.json.backup"]

    print("== Global files ==")
    for p in candidates:
        if not p.exists():
            print(f"MISSING: {p}")
            continue
        ok, detail = _parse_json_file(p)
        status = "OK" if ok else "INVALID"
        print(f"{status}: {p} :: {detail}")

    claude_dir = home / ".claude"
    print("\n== ~/.claude directory ==")
    print(f"exists={claude_dir.exists()} path={claude_dir}")
    if not claude_dir.exists():
        return

    # Avoid dumping secrets; just validate syntax. Skip credentials file explicitly.
    bad: list[tuple[Path, str]] = []
    for p in _iter_json_files(claude_dir):
        if p.name.lower() == ".credentials.json":
            continue
        ok, detail = _parse_json_file(p)
        if not ok:
            bad.append((p, detail))

    if not bad:
        print("All JSON files under ~/.claude (excluding .credentials.json) parse OK")
        return

    print("INVALID_JSON_FILES")
    for p, detail in bad:
        print(f"- {p} :: {detail}")


if __name__ == "__main__":
    main()
