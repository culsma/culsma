from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List


@dataclass(frozen=True)
class ScenarioAxis:
    key: str
    values: List[str]


# Domain tags (18)
DOMAIN_TAGS: List[str] = [
    # Molecular Biology
    "PCR",
    "qPCR",
    "Gel_Electrophoresis",
    "Gibson_Assembly",
    "Golden_Gate",
    # Microbiology
    "Transformation_HeatShock",
    "Transformation_Electroporation",
    "Streaking",
    "Inoculation",
    "Glycerol_Stock",
    # Biochemistry
    "Protein_Purification_NiNTA",
    "Enzyme_Kinetics",
    "Dialysis",
    "Bradford_Assay",
    # Cell Culture / Automation
    "CellCulture_Passaging",
    # Worklist / High-Throughput (v2.5)
    "Worklist_Stamp",
    "Worklist_Cherrypick",
    "Worklist_SerialDilution",
]


# Complexity levels (4)
COMPLEXITY_LEVELS: List[str] = [
    "L1_Linear",
    "L2_Logic",
    "L3_Parallel",
    "L4_Resilient",
]


# Compliance modes
COMPLIANCE_MODES: List[str] = [
    "R&D",
    "GMP",
]


def iter_matrix() -> Iterable[tuple[str, str, str]]:
    """Cartesian product of (domain, complexity, compliance)."""
    for domain in DOMAIN_TAGS:
        for complexity in COMPLEXITY_LEVELS:
            for compliance in COMPLIANCE_MODES:
                yield (domain, complexity, compliance)
