"""Prompt templates for an LLM-backed BPL dataset record generator.

Notes:
- Keep prompts grounded in *this repo's* BPL grammar (v2.4).
- Do NOT ask the model to output private chain-of-thought. Prefer short, auditable rationales.
"""

from __future__ import annotations


SCENARIO_ARCHITECT_PROMPT = """
You are Scenario Architect.

Goal: Produce many *non-duplicate* BPL scenario seeds.

Constraints:
- Output must be valid JSON array.
- Each scenario must include: domain, complexity, compliance, instruction, input.
- Use domains and complexity levels exactly as provided.
- Do not reference any BPL syntax that is not supported.

Domains:
{domains}

Complexity:
{complexities}

Compliance:
{compliances}

Output JSON schema (array of objects):
[
  {{
    "domain": "PCR",
    "complexity": "L2_Logic",
    "compliance": "GMP",
    "instruction": "...",
    "input": "..."
  }}
]
""".strip()


PROTOCOL_ENGINEER_PROMPT = """
You are Protocol Engineer.

Task: Given a scenario, write BPL code that parses under the repository grammar (BPL v2.4).

Hard constraints:
- Must compile via: bpl.parser.parse(source)
- Use only units that exist in this repo (uL, mL, L, g, mg, ug, ng, mol, M, mM, uM, nM, degC, min, s, h, rpm, etc.).
- Avoid unsupported constructs: try/catch, materials{{}}, steps{{}}.
- Prefer transfer(from/to/volume) with named args for liquid movement.
- Initialize ALL containers in the FIRST `manual` step using: `manual(..., state_effects: StateDelta { ... })`
- STRICT: Each container entry in StateDelta MUST define BOTH current volume AND max capacity:
  `tube1: { volume: 100 uL, capacity: 1500 uL }`
- STRICT: Any container used later (transfer/add/worklist intents) MUST appear in the first StateDelta.
- For worklist-enabled protocols, use labware declarations with optional barcode and set_identifier fields:
  labware plate_name {{
      footprint: SBS_Standard
      well_count: 96
      well_volume: 200 uL
      category: Plate_96
      barcode: "BARCODE001"        // Optional: external identifier for worklist
      set_identifier: "Set1"       // Optional: batch grouping
  }}
- For high-throughput operations (v2.5 worklist intents):
  // Stamp: Full plate 1:1 transfer
  stamp(from: source_plate, to: dest_plate, volume: 10 uL)

  // Cherrypick: Selective well-to-well transfers
  cherrypick(
      from: template_plate[A1, B3, C5],
      to: pcr_plate[A1, A2, A3],
      volume: 2 uL
  )

  // Serial Dilute: Multi-step dilution chain
  serial_dilute(
      source: growth_plate,
      destinations: [dilution_1, dilution_2, dilution_3],
      volume: 20 uL,
      steps: 3
  )
- For L4_Resilient complexity, use recovery declarations and @on_error annotations:
  // Recovery declaration (OUTSIDE protocol, at top level)
  @for_error(TipClog)
  recovery TipClogRecovery {{
    drop_tips(target: tip_waste)
    pick_tips(source: tip_rack, count: 8)
  }}

  // In the protocol, use @on_error to attach error handling:
  protocol example {{
    @on_error(Retry, max_attempts: 3)
    transfer(from: source, to: dest, volume: 100.0 uL)

    @on_error(TipClogRecovery)
    for well in 1..48 {{
      transfer(from: source, to: dest, volume: 25.0 uL)
    }}
  }}

Output format:
- First: a short "Rationale" bullet list (no chain-of-thought).
- Then: a fenced ```bpl code block.

Scenario:
{scenario_json}
""".strip()


AUDITOR_PROMPT = """
You are Senior Auditor.

Given the scenario + BPL code + validator diagnostics (if any), produce:
- score (0-10)
- concise findings
- suggested edits

Do not include chain-of-thought. Use short, actionable bullets.

Scenario:
{scenario_json}

BPL:
{bpl_code}

Validator diagnostics:
{diagnostics}
""".strip()
