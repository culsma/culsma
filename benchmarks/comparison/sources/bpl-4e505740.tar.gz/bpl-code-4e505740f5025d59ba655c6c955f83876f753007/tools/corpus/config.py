"""Configuration loader for corpus generation with DashScope (Alibaba Cloud Bailian).

Loads configuration from .env file with fallback to environment variables.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TypedDict

from dotenv import load_dotenv


class Config(TypedDict):
    """Configuration dictionary type."""

    api_key: str | None
    model: str
    max_concurrent: int
    enable_web_search: bool


# Default values
DEFAULT_MODEL = "qwen-plus"  # Default model for DashScope
DEFAULT_MAX_CONCURRENT = 5
DEFAULT_WEB_SEARCH = True


def load_config() -> Config:
    """Load configuration from .env file.

    Searches for .env in the following order:
    1. tools/corpus/.env
    2. Project root .env

    Returns:
        Config dictionary with api_key, model, and max_concurrent settings.
    """
    # Try to load from .env files
    env_paths = [
        Path(__file__).parent / ".env",
        Path(__file__).parents[2] / ".env",
    ]
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path)
            break

    return {
        "api_key": os.getenv("DASHSCOPE_API_KEY"),
        "model": os.getenv("DASHSCOPE_MODEL", DEFAULT_MODEL),
        "max_concurrent": int(os.getenv("DASHSCOPE_MAX_CONCURRENT", str(DEFAULT_MAX_CONCURRENT))),
        "enable_web_search": os.getenv("DASHSCOPE_WEB_SEARCH", str(DEFAULT_WEB_SEARCH)).lower() in ("true", "1", "yes"),
    }


def load_api_key() -> str:
    """Load and validate API key.

    Returns:
        The DashScope API key.

    Raises:
        ValueError: If API key is not set.
    """
    config = load_config()
    if not config["api_key"]:
        raise ValueError(
            "DASHSCOPE_API_KEY not set. "
            "Please create a .env file with your API key or set the environment variable."
        )
    return config["api_key"]


def get_model() -> str:
    """Get the configured model name.

    Returns:
        The DashScope model identifier.
    """
    return load_config()["model"]


def get_max_concurrent() -> int:
    """Get the maximum number of concurrent requests.

    Returns:
        Maximum concurrent request count.
    """
    return load_config()["max_concurrent"]


def get_web_search_enabled() -> bool:
    """Get whether web search is enabled.

    Returns:
        True if web search (enable_search) is enabled.
    """
    return load_config()["enable_web_search"]
