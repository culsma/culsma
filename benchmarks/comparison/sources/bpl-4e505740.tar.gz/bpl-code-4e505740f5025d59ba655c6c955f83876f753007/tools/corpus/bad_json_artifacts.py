from __future__ import annotations

import hashlib
import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class BadJsonArtifact:
    path: Path
    sha256: str
    size_bytes: int


def _utc_stamp() -> str:
    # e.g. 20251228_141530_123456
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")


def persist_bad_json_body(
    run_dir: Path,
    *,
    body: str,
    layer: str,
    context: str,
    ext: str = ".txt",
) -> BadJsonArtifact:
    """Persist a verbatim raw body that failed JSON parsing.

    Privacy policy: callers MUST NOT log the body; log only the returned path.

    Args:
        run_dir: Run directory for the current dataset generation.
        body: Verbatim raw body.
        layer: Logical layer label (e.g. "L1-EXPAND", "L3-CRITIC", "RUNNER").
        context: Short context string (e.g. function name / failure reason).
        ext: File extension for the artifact.

    Returns:
        BadJsonArtifact with path, sha256, and size.
    """
    if not isinstance(run_dir, Path):
        run_dir = Path(run_dir)

    artifacts_dir = run_dir / "bad_json"
    artifacts_dir.mkdir(parents=True, exist_ok=True)

    # Use a stable hash for content + a timestamp for uniqueness.
    body_bytes = (body or "").encode("utf-8", errors="replace")
    digest = hashlib.sha256(body_bytes).hexdigest()

    safe_layer = _sanitize(layer)
    safe_context = _sanitize(context)
    stamp = _utc_stamp()

    filename = f"{stamp}__{safe_layer}__{safe_context}__{digest[:12]}{ext}"
    path = artifacts_dir / filename

    # Always write verbatim; never redact.
    path.write_text(body or "", encoding="utf-8", errors="replace")

    return BadJsonArtifact(path=path, sha256=digest, size_bytes=len(body_bytes))


def _sanitize(text: str) -> str:
    # Keep filenames safe on Windows.
    if not text:
        return "na"
    keep = []
    for ch in text:
        if ch.isalnum() or ch in ("-", "_", "."):
            keep.append(ch)
        elif ch.isspace():
            keep.append("_")
        else:
            keep.append("-")
    s = "".join(keep).strip("._-")
    if not s:
        return "na"
    # Avoid overly long filenames.
    return s[:64]


@dataclass
class JsonParseErrorDetails:
    """Structured details about a JSON parsing error."""

    error_type: str
    error_message: str
    position: Optional[int] = None
    line_number: Optional[int] = None
    column_number: Optional[int] = None
    body_size_bytes: int = 0
    body_preview: str = ""
    error_context_snippet: str = ""
    layer: str = ""
    context: str = ""
    artifact_path: Optional[Path] = None
    artifact_sha256: Optional[str] = None

    def to_log_dict(self) -> dict[str, Any]:
        """Convert to a dictionary suitable for structured logging."""
        return {
            "error_type": self.error_type,
            "error_message": self.error_message,
            "position": self.position,
            "line_number": self.line_number,
            "column_number": self.column_number,
            "body_size_bytes": self.body_size_bytes,
            "body_preview": self.body_preview,
            "error_context_snippet": self.error_context_snippet,
            "layer": self.layer,
            "context": self.context,
            "artifact_path": str(self.artifact_path) if self.artifact_path else None,
            "artifact_sha256": self.artifact_sha256,
        }


def _extract_error_context(body: str, position: Optional[int], window: int = 50) -> str:
    """Extract a snippet of text around the error position.

    Args:
        body: The full JSON body.
        position: Character position of the error.
        window: Number of characters to show before and after.

    Returns:
        A snippet showing the error context with position marker.
    """
    if not body or position is None or position < 0:
        return ""

    start = max(0, position - window)
    end = min(len(body), position + window)

    before = body[start:position]
    after = body[position:end]

    # Add ellipsis if truncated
    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(body) else ""

    # Mark the error position
    return f"{prefix}{before}▶HERE◀{after}{suffix}"


def _get_body_preview(body: str, max_length: int = 200) -> str:
    """Get a safe preview of the body for logging.

    Args:
        body: The full body text.
        max_length: Maximum length of the preview.

    Returns:
        A truncated preview of the body.
    """
    if not body:
        return "<empty>"
    if len(body) <= max_length:
        return body
    return body[:max_length] + f"... ({len(body) - max_length} more chars)"


def _compute_line_col(body: str, position: int) -> tuple[int, int]:
    """Compute line and column number from character position.

    Args:
        body: The full body text.
        position: Character position.

    Returns:
        Tuple of (line_number, column_number), 1-indexed.
    """
    if not body or position < 0:
        return (0, 0)

    position = min(position, len(body))
    prefix = body[:position]
    lines = prefix.split("\n")
    line_number = len(lines)
    column_number = len(lines[-1]) + 1 if lines else 1

    return (line_number, column_number)


def _detect_common_json_issues(body: str) -> list[str]:
    """Detect common JSON formatting issues.

    Args:
        body: The body text to analyze.

    Returns:
        List of detected issues.
    """
    issues = []

    if not body:
        issues.append("Empty body")
        return issues

    stripped = body.strip()

    # Check for common structural issues
    if not stripped:
        issues.append("Body contains only whitespace")
    elif not (stripped.startswith("{") or stripped.startswith("[")):
        issues.append(f"Does not start with '{{' or '['; starts with: {repr(stripped[:20])}")
    elif not (stripped.endswith("}") or stripped.endswith("]")):
        issues.append(f"Does not end with '}}' or ']'; ends with: {repr(stripped[-20:])}")

    # Check for unbalanced brackets
    open_braces = body.count("{")
    close_braces = body.count("}")
    if open_braces != close_braces:
        issues.append(f"Unbalanced braces: {open_braces} '{{' vs {close_braces} '}}'")

    open_brackets = body.count("[")
    close_brackets = body.count("]")
    if open_brackets != close_brackets:
        issues.append(f"Unbalanced brackets: {open_brackets} '[' vs {close_brackets} ']'")

    # Check for trailing commas (common issue)
    if re.search(r",\s*[}\]]", body):
        issues.append("Possible trailing comma before closing bracket/brace")

    # Check for single quotes (common mistake)
    if re.search(r"'[^']*'\s*:", body):
        issues.append("Possible use of single quotes instead of double quotes for keys")

    # Check for unquoted keys
    if re.search(r"{\s*[a-zA-Z_][a-zA-Z0-9_]*\s*:", body):
        issues.append("Possible unquoted object key")

    # Check for JavaScript-style comments
    if "//" in body or "/*" in body:
        issues.append("Possible JavaScript-style comments in JSON")

    # Check for control characters
    control_chars = [c for c in body[:1000] if ord(c) < 32 and c not in "\n\r\t"]
    if control_chars:
        issues.append(f"Contains control characters: {[hex(ord(c)) for c in control_chars[:5]]}")

    return issues


def log_json_parse_error(
    error: Exception,
    body: str,
    *,
    layer: str,
    context: str,
    run_dir: Optional[Path] = None,
    log_level: int = logging.ERROR,
) -> JsonParseErrorDetails:
    """Log a JSON parsing error with comprehensive details.

    This function logs detailed information about a JSON parsing error,
    including the error type, position, context snippet, and common issues.
    If run_dir is provided, the bad JSON body is persisted to disk.

    Args:
        error: The exception that was raised during parsing.
        body: The raw body that failed to parse.
        layer: Logical layer label (e.g. "L1-EXPAND", "L3-CRITIC").
        context: Short context string (e.g. function name).
        run_dir: Optional run directory to persist the bad JSON.
        log_level: Logging level to use (default: ERROR).

    Returns:
        JsonParseErrorDetails with all extracted information.
    """
    # Extract basic error info
    error_type = type(error).__name__
    error_message = str(error)

    # Extract position from JSONDecodeError if available
    position: Optional[int] = None
    line_number: Optional[int] = None
    column_number: Optional[int] = None

    if isinstance(error, json.JSONDecodeError):
        position = error.pos
        line_number = error.lineno
        column_number = error.colno
    elif hasattr(error, "pos"):
        position = getattr(error, "pos", None)

    # Compute line/col if not available from error but we have position
    if position is not None and (line_number is None or column_number is None):
        computed_line, computed_col = _compute_line_col(body, position)
        line_number = line_number or computed_line
        column_number = column_number or computed_col

    # Extract context snippet around error
    error_context_snippet = _extract_error_context(body, position)

    # Get body preview
    body_preview = _get_body_preview(body)

    # Detect common issues
    common_issues = _detect_common_json_issues(body)

    # Persist artifact if run_dir provided
    artifact_path: Optional[Path] = None
    artifact_sha256: Optional[str] = None

    if run_dir is not None:
        artifact = persist_bad_json_body(
            run_dir,
            body=body,
            layer=layer,
            context=context,
        )
        artifact_path = artifact.path
        artifact_sha256 = artifact.sha256

    # Build details object
    details = JsonParseErrorDetails(
        error_type=error_type,
        error_message=error_message,
        position=position,
        line_number=line_number,
        column_number=column_number,
        body_size_bytes=len(body.encode("utf-8", errors="replace")) if body else 0,
        body_preview=body_preview,
        error_context_snippet=error_context_snippet,
        layer=layer,
        context=context,
        artifact_path=artifact_path,
        artifact_sha256=artifact_sha256,
    )

    # Log the error with full details
    logger.log(
        log_level,
        "JSON parse error in %s/%s: %s: %s",
        layer,
        context,
        error_type,
        error_message,
    )

    if line_number and column_number:
        logger.log(log_level, "  Location: line %d, column %d (pos %d)", line_number, column_number, position or 0)

    if error_context_snippet:
        logger.log(log_level, "  Context: %s", error_context_snippet)

    if common_issues:
        logger.log(log_level, "  Detected issues: %s", "; ".join(common_issues))

    logger.log(log_level, "  Body size: %d bytes", details.body_size_bytes)

    if artifact_path:
        logger.log(log_level, "  Artifact saved: %s (sha256: %s)", artifact_path, artifact_sha256[:12] if artifact_sha256 else "N/A")

    # Log at debug level for even more details
    logger.debug("  Full error details: %s", details.to_log_dict())
    logger.debug("  Body preview: %s", body_preview)

    return details


def safe_json_loads(
    body: str,
    *,
    layer: str,
    context: str,
    run_dir: Optional[Path] = None,
    default: Any = None,
    raise_on_error: bool = True,
) -> Any:
    """Safely parse JSON with comprehensive error logging.

    Args:
        body: The JSON string to parse.
        layer: Logical layer label for logging.
        context: Context string for logging.
        run_dir: Optional run directory to persist bad JSON.
        default: Default value to return on error (if raise_on_error=False).
        raise_on_error: Whether to re-raise the exception after logging.

    Returns:
        Parsed JSON object, or default value on error.

    Raises:
        json.JSONDecodeError: If parsing fails and raise_on_error=True.
    """
    try:
        return json.loads(body)
    except json.JSONDecodeError as e:
        log_json_parse_error(
            e,
            body,
            layer=layer,
            context=context,
            run_dir=run_dir,
        )
        if raise_on_error:
            raise
        return default
    except Exception as e:
        # Handle other unexpected errors
        log_json_parse_error(
            e,
            body,
            layer=layer,
            context=context,
            run_dir=run_dir,
        )
        if raise_on_error:
            raise
        return default
