"""Recompute the BPL paper's structural-determinism headline metrics.

This script is the canonical recomputation of the numbers that label the
figure-3 (structural determinism) panel of the BPL paper. It reads two
shipped artifacts and emits a single summary JSON consumed by
``scripts/reproduce_paper.py``:

1. ``data/consistency_report.md`` — the regex step-count consistency table
   produced by ``analyze_consistency.py`` over the LLM-expanded SOP variants.
   This is the data source for the figure's headline numbers (mean range,
   identical-all-runs percentage, mean per-paper match-vs-digest rate).

2. ``data/variant_comparisons/per_paper/*.json`` — the LLM-judge per-paper
   records produced by ``compare_variants.py``. We surface their basic
   coverage (papers, total scored variants) so manifest assertions can fail
   loudly if the shipped data shape drifts.

The script does NOT compute "BPL-output step count vs reference paper step
count" — that is a different metric than the one the figure plots, and
reporting both side by side has caused reviewer-facing confusion in past
revisions.

Run::

    uv run python tools/bpl_eval/compute_determinism.py
"""
from __future__ import annotations

import argparse
import json
import re
import statistics as stats
from pathlib import Path
from typing import Any

_BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = _BASE_DIR / "data"
CONSISTENCY_REPORT = DATA_DIR / "consistency_report.md"
PER_PAPER_DIR = DATA_DIR / "variant_comparisons" / "per_paper"
OUT_PATH = DATA_DIR / "determinism_results.json"

EXPECTED_VARIANTS_PER_PAPER = 10

_PERCENT_RE = re.compile(r"([\d.]+)\s*%")


def parse_consistency_rows(markdown: str) -> list[dict[str, float | int | str]]:
    """Parse the per-paper consistency table from ``consistency_report.md``.

    Table header (case-sensitive)::

        | Paper | Digest | Mean | Min | Max | Range | Std | Match% | Variants |
    """
    rows: list[dict[str, float | int | str]] = []
    in_table = False
    for line in markdown.splitlines():
        stripped = line.strip()
        if stripped.startswith("| Paper") and "Digest" in stripped:
            in_table = True
            continue
        if in_table and stripped.startswith("|---"):
            continue
        if in_table and stripped.startswith("|"):
            parts = [p.strip() for p in stripped.strip("|").split("|")]
            if len(parts) < 9:
                continue
            try:
                match_match = _PERCENT_RE.search(parts[7])
                match_pct = float(match_match.group(1)) if match_match else float(
                    parts[7]
                )
                rows.append(
                    {
                        "paper": parts[0],
                        "digest": int(parts[1]),
                        "mean": float(parts[2]),
                        "min": int(parts[3]),
                        "max": int(parts[4]),
                        "range": int(parts[5]),
                        "std": float(parts[6]),
                        "match_pct": match_pct,
                        "variants": int(parts[8]),
                    }
                )
            except (ValueError, IndexError):
                continue
        elif in_table and stripped and not stripped.startswith("|"):
            in_table = False
    return rows


def figure_headline_stats(rows: list[dict[str, float | int | str]]) -> dict[str, float | int]:
    """Compute the headline statistics that appear on figure 3.

    These match (within rounding) the values labelled on the figure panel
    and the prose summary at the top of ``consistency_report.md``.
    """
    if not rows:
        raise SystemExit("consistency_report rows are empty; cannot summarise")
    n_papers = len(rows)
    ranges = [int(r["range"]) for r in rows]
    stds = [float(r["std"]) for r in rows]
    means = [float(r["mean"]) for r in rows]
    match_pcts = [float(r["match_pct"]) for r in rows]
    cv_pcts = [
        (s / m * 100.0) if m > 0 else 0.0
        for s, m in zip(stds, means, strict=True)
    ]

    identical = sum(1 for rng in ranges if rng == 0)
    return {
        "n_papers": n_papers,
        "mean_step_count_range": stats.fmean(ranges),
        "median_step_count_range": stats.median(ranges),
        "max_step_count_range": max(ranges),
        "mean_step_count_std": stats.fmean(stds),
        "mean_step_count_cv_pct": stats.fmean(cv_pcts),
        "median_step_count_cv_pct": stats.median(cv_pcts),
        "mean_match_vs_digest_pct": stats.fmean(match_pcts),
        "identical_all_runs_count": identical,
        "identical_all_runs_pct": identical / n_papers * 100.0,
    }


def coverage_stats(per_paper_dir: Path) -> dict[str, int | list[tuple[str, int]]]:
    """Surface variant_comparisons coverage so drift in the shipped LLM-judge
    data is caught by manifest assertions.
    """
    files = sorted(per_paper_dir.glob("*.json"))
    if not files:
        raise SystemExit(f"No paper files found under {per_paper_dir}")
    total_variants = 0
    nonstandard: list[tuple[str, int]] = []
    for fp in files:
        record = json.loads(fp.read_text())
        n = len(record.get("variants") or [])
        total_variants += n
        if n != EXPECTED_VARIANTS_PER_PAPER:
            nonstandard.append((record.get("paper_name", fp.stem), n))
    return {
        "n_papers": len(files),
        "total_scored_variants": total_variants,
        "expected_variants_per_paper": EXPECTED_VARIANTS_PER_PAPER,
        "papers_with_nonstandard_variant_count": nonstandard,
    }


def compute_determinism(
    consistency_report: Path = CONSISTENCY_REPORT,
    per_paper_dir: Path = PER_PAPER_DIR,
    out_path: Path = OUT_PATH,
) -> dict[str, Any]:
    """Recompute structural-determinism statistics and write the result JSON."""
    if not consistency_report.is_file():
        raise SystemExit(f"missing consistency report: {consistency_report}")

    rows = parse_consistency_rows(consistency_report.read_text(encoding="utf-8"))
    headline = figure_headline_stats(rows)
    coverage = coverage_stats(per_paper_dir)

    summary: dict[str, object] = {
        "data_source": {
            "consistency_report": str(
                consistency_report.relative_to(_BASE_DIR.parent.parent)
            ),
            "per_paper_dir": str(per_paper_dir.relative_to(_BASE_DIR.parent.parent)),
        },
        "metric": (
            "Inter-variant SOP step-count stability — for each Nature Protocols "
            "reference paper, the LLM expands the digest into 10 SOP variants. "
            "We measure whether the variants preserve the digest step count. "
            "This is the metric labelled on the structural-determinism figure."
        ),
        "generation_model": "anthropic/claude-sonnet-4-6",
        **headline,
        "coverage": coverage,
    }

    result = {"summary": summary, "per_paper": rows}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Recompute BPL paper structural-determinism statistics."
    )
    parser.add_argument(
        "--consistency-report",
        type=Path,
        default=CONSISTENCY_REPORT,
        help="Path to consistency_report.md (parsed for figure headline numbers).",
    )
    parser.add_argument(
        "--per-paper-dir",
        type=Path,
        default=PER_PAPER_DIR,
        help="Directory containing variant_comparisons/per_paper/*.json records.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=OUT_PATH,
        help="Output JSON path.",
    )
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    result = compute_determinism(args.consistency_report, args.per_paper_dir, args.out)
    summary = result["summary"]

    print("=" * 72)
    print(" BPL paper — structural-determinism summary (figure-3 headline)")
    print("=" * 72)
    print(f" Source           : {args.consistency_report}")
    print(f" Generation model : {summary['generation_model']}")
    print(f" Papers           : {summary['n_papers']}")
    print("-" * 72)
    print(f" Identical-runs   : "
          f"{summary['identical_all_runs_count']}/{summary['n_papers']} "
          f"({summary['identical_all_runs_pct']:5.2f}%)")
    print(f" Mean range       : {summary['mean_step_count_range']:7.3f}")
    print(f" Median range     : {summary['median_step_count_range']:7.3f}")
    print(f" Max range        : {summary['max_step_count_range']:7.0f}")
    print(f" Mean std         : {summary['mean_step_count_std']:7.3f}")
    print(f" Mean CV          : {summary['mean_step_count_cv_pct']:7.3f} %")
    print(f" Mean match%      : {summary['mean_match_vs_digest_pct']:7.2f}")
    print("-" * 72)
    coverage = summary["coverage"]
    print(f" Coverage         : {coverage['n_papers']} papers, "
          f"{coverage['total_scored_variants']} scored variants")
    if coverage["papers_with_nonstandard_variant_count"]:
        print(f" Non-{EXPECTED_VARIANTS_PER_PAPER} papers      : "
              f"{len(coverage['papers_with_nonstandard_variant_count'])}")
    print("-" * 72)
    print(f" Full results saved to: {args.out}")


if __name__ == "__main__":
    main()
