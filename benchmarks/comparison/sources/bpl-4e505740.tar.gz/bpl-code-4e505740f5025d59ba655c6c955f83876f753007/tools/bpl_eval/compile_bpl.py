#!/usr/bin/env python3
"""Compile exported SOP markdown files into BPL and composed protocols.

This is the orchestration layer for stage 5 of the eval pipeline. It runs
``bplc sop-generate`` and ``bplc compose`` over every per-paper-version
markdown file in ``bpl_input/`` (default) using a ThreadPoolExecutor.

The script shells out to ``python -m bpl.cli.main`` so it always picks up the
exact compiler version installed in the active environment, including local
edits. ``sop-generate`` requires ``OPENROUTER_API_KEY``; ``compose`` is
offline.

Usage:
    python tools/bpl_eval/compile_bpl.py                # generate + compose
    python tools/bpl_eval/compile_bpl.py --workers 8
    python tools/bpl_eval/compile_bpl.py --skip-generate  # compose-only re-run
    python tools/bpl_eval/compile_bpl.py --skip-compose
    python tools/bpl_eval/compile_bpl.py --no-resume      # rebuild everything
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any
from datetime import datetime
from pathlib import Path

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

from config import BPL_INPUT_DIR, BPL_OUTPUT_DIR, PROJECT_ROOT, PROTOCOLS_DIR  # noqa: E402

GENERATE_TIMEOUT_S = 600  # matches the worst-case bpl.agentic.workflow HTTP budget
COMPOSE_TIMEOUT_S = 300


@dataclass
class TaskResult:
    input_file: str
    output_file: str
    success: bool
    attempts: int | None = None
    duration_s: float = 0.0
    error: str = ""


@dataclass
class PhaseReport:
    phase: str
    total: int = 0
    succeeded: int = 0
    skipped: int = 0
    failed: int = 0
    total_duration_s: float = 0.0
    failures: list[TaskResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "total": self.total,
            "succeeded": self.succeeded,
            "skipped": self.skipped,
            "failed": self.failed,
            "total_duration_s": round(self.total_duration_s, 2),
            "failures": [
                {"input": f.input_file, "error": f.error} for f in self.failures
            ],
        }

    def print_summary(self) -> None:
        print()
        print("=" * 60)
        print(f"  {self.phase} summary")
        print("=" * 60)
        print(f"  Total:     {self.total}")
        print(f"  Succeeded: {self.succeeded}")
        print(f"  Skipped:   {self.skipped}")
        print(f"  Failed:    {self.failed}")
        print(f"  Duration:  {self.total_duration_s:.1f}s")
        if self.failures:
            print("  First failures:")
            for f in self.failures[:10]:
                print(f"    - {Path(f.input_file).name}: {f.error[:80]}")
        print("=" * 60)


def _python() -> str:
    return sys.executable


def _run_sop_generate(sop_path: Path, out_path: Path) -> TaskResult:
    start = time.monotonic()
    try:
        result = subprocess.run(
            [
                _python(),
                "-m",
                "bpl.cli.main",
                "sop-generate",
                "--sop",
                str(sop_path),
                "--out",
                str(out_path),
            ],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=GENERATE_TIMEOUT_S,
            env=os.environ.copy(),
        )
        duration = time.monotonic() - start
        if result.returncode == 0:
            attempts: int | None = None
            for line in result.stdout.strip().splitlines():
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(payload, dict):
                    attempts = payload.get("attempts_used")
                    break
            return TaskResult(
                input_file=str(sop_path),
                output_file=str(out_path),
                success=True,
                attempts=attempts,
                duration_s=duration,
            )
        error = (result.stderr or result.stdout).strip()[:200] or f"exit {result.returncode}"
        return TaskResult(
            input_file=str(sop_path),
            output_file=str(out_path),
            success=False,
            duration_s=duration,
            error=error,
        )
    except subprocess.TimeoutExpired:
        return TaskResult(
            input_file=str(sop_path),
            output_file=str(out_path),
            success=False,
            duration_s=float(GENERATE_TIMEOUT_S),
            error=f"timeout after {GENERATE_TIMEOUT_S}s",
        )


def _run_compose(bpl_path: Path, out_path: Path) -> TaskResult:
    start = time.monotonic()
    try:
        result = subprocess.run(
            [
                _python(),
                "-m",
                "bpl.cli.main",
                "compose",
                "--input-bpl",
                str(bpl_path),
                "--target",
                "human",
                "--out",
                str(out_path),
            ],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=COMPOSE_TIMEOUT_S,
            env=os.environ.copy(),
        )
        duration = time.monotonic() - start
        if result.returncode == 0:
            return TaskResult(
                input_file=str(bpl_path),
                output_file=str(out_path),
                success=True,
                duration_s=duration,
            )
        error = (result.stderr or result.stdout).strip()[:200] or f"exit {result.returncode}"
        return TaskResult(
            input_file=str(bpl_path),
            output_file=str(out_path),
            success=False,
            duration_s=duration,
            error=error,
        )
    except subprocess.TimeoutExpired:
        return TaskResult(
            input_file=str(bpl_path),
            output_file=str(out_path),
            success=False,
            duration_s=float(COMPOSE_TIMEOUT_S),
            error=f"timeout after {COMPOSE_TIMEOUT_S}s",
        )


def _phase(
    phase_name: str,
    work: list[tuple[Path, Path]],
    runner,
    workers: int,
    skipped: int,
) -> PhaseReport:
    report = PhaseReport(phase=phase_name)
    report.total = len(work) + skipped
    report.skipped = skipped
    report.succeeded = skipped

    if not work:
        report.print_summary()
        return report

    start = time.monotonic()
    done = skipped
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(runner, src, dst): (src, dst) for src, dst in work}
        for future in as_completed(futures):
            result = future.result()
            done += 1
            if result.success:
                report.succeeded += 1
            else:
                report.failed += 1
                report.failures.append(result)
            status = "OK" if result.success else "FAIL"
            attempts = (
                f" ({result.attempts} attempts)"
                if result.attempts and result.attempts > 1
                else ""
            )
            print(
                f"  [{done:>4}/{report.total}] "
                f"{done / report.total * 100:5.1f}% "
                f"{status:4s} {result.duration_s:5.1f}s "
                f"{Path(result.input_file).name}{attempts}"
            )
    report.total_duration_s = time.monotonic() - start
    report.print_summary()
    return report


def phase_generate(
    sop_dir: Path, out_dir: Path, workers: int, resume: bool
) -> PhaseReport:
    sop_files = sorted(sop_dir.glob("*.md"))
    if not sop_files:
        print(f"No .md files in {sop_dir}")
        return PhaseReport(phase="sop-generate")

    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nPhase 1 sop-generate: {len(sop_files)} files in {sop_dir} ({workers} workers)")

    work: list[tuple[Path, Path]] = []
    skipped = 0
    for sop_path in sop_files:
        out_path = out_dir / sop_path.with_suffix(".bpl").name
        if resume and out_path.exists() and out_path.stat().st_size > 0:
            skipped += 1
            continue
        work.append((sop_path, out_path))
    if skipped:
        print(f"  Skipping {skipped} already-generated outputs (resume mode)")
    return _phase("sop-generate", work, _run_sop_generate, workers, skipped)


def phase_compose(
    bpl_dir: Path, out_dir: Path, workers: int, resume: bool
) -> PhaseReport:
    bpl_files = sorted(bpl_dir.glob("*.bpl"))
    if not bpl_files:
        print(f"No .bpl files in {bpl_dir}")
        return PhaseReport(phase="compose")

    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nPhase 2 compose: {len(bpl_files)} files in {bpl_dir} ({workers} workers)")

    work: list[tuple[Path, Path]] = []
    skipped = 0
    for bpl_path in bpl_files:
        out_path = out_dir / bpl_path.with_suffix(".protocol.md").name
        if resume and out_path.exists() and out_path.stat().st_size > 0:
            skipped += 1
            continue
        work.append((bpl_path, out_path))
    if skipped:
        print(f"  Skipping {skipped} already-composed outputs (resume mode)")
    return _phase("compose", work, _run_compose, workers, skipped)


def main() -> int:
    parser = argparse.ArgumentParser(description="Compile BPL evaluation inputs")
    parser.add_argument("--input", default=BPL_INPUT_DIR, help="Per-paper-version SOP markdown dir")
    parser.add_argument("--bpl-out", default=BPL_OUTPUT_DIR, help="Compiled .bpl output dir")
    parser.add_argument("--protocols-out", default=PROTOCOLS_DIR, help="Composed protocol markdown dir")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--no-resume", action="store_true", help="Re-process all files")
    parser.add_argument("--skip-generate", action="store_true", help="Skip phase 1 (sop-generate)")
    parser.add_argument("--skip-compose", action="store_true", help="Skip phase 2 (compose)")
    parser.add_argument(
        "--report",
        help="Optional JSON report path (default: tools/bpl_eval/compile_report_<ts>.json)",
    )
    args = parser.parse_args()

    resume = not args.no_resume
    reports: list[PhaseReport] = []

    if not args.skip_generate:
        reports.append(
            phase_generate(Path(args.input), Path(args.bpl_out), args.workers, resume)
        )
    if not args.skip_compose:
        reports.append(
            phase_compose(Path(args.bpl_out), Path(args.protocols_out), args.workers, resume)
        )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = args.report or os.path.join(_BASE, f"compile_report_{timestamp}.json")
    Path(report_path).parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "timestamp": timestamp,
                "phases": [r.to_dict() for r in reports],
            },
            handle,
            indent=2,
        )
    print(f"Report saved to {report_path}")

    return 0 if all(r.failed == 0 for r in reports) else 1


if __name__ == "__main__":
    raise SystemExit(main())
