"""
Prompt templates for protocol vs. digest comparison.

Two comparison modes:
  1. BPL protocol (compiled .protocol.md) vs. digest
  2. Text variant (natural language SOP) vs. digest

Both return structured JSON evaluations across 7 scoring dimensions,
enabling before/after BPL comparison.
"""

import json


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# System prompt
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPARE_SYSTEM = """\
You are an expert protocol analyst who specializes in comparing laboratory \
protocols across different representations. You have deep knowledge of:

- Molecular biology laboratory procedures and techniques
- BPL (Biology Programming Language) primitives and their semantics:
  • ASPIRATE + DISPENSE = liquid transfer (together they represent adding a \
reagent, washing, mixing, etc.)
  • HUMAN_STEP = manual operations with semantic names (e.g., incubate, \
centrifuge, spin_coat, uv_expose, plasma_treat, mix). Some HUMAN_STEP entries \
are specific (spin_coat with speed), others are generic placeholders.
  • WAIT = timed pauses (incubation periods, reaction times, drying, etc.) — \
a bare WAIT with no semantic context is less specific than a named HUMAN_STEP.
- How high-level protocol steps decompose into low-level operations
- Critical parameters: temperatures, durations, concentrations, volumes, speeds
- That BPL encodes reagents as well positions (plate_1:A1) — use the Source \
Mapping section at the bottom to identify what each well contains

SCORING PHILOSOPHY: Score based on whether digest PHASES are covered and \
parameters are ACCURATE — not based on how many BPL steps exist. A compact \
BPL protocol that faithfully covers all phases is just as good as a verbose \
one. Score conservatively and penalize errors proportionally to their magnitude."""


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# User prompt template
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMPARE_USER_TEMPLATE = """\
Compare the following BPL-compiled execution protocol against its original \
protocol digest. The digest is the canonical ground truth.

<original_digest>
{digest_json}
</original_digest>

<bpl_protocol>
{protocol_md}
</bpl_protocol>

Analyze the BPL protocol against the digest across 7 dimensions. Provide \
your evaluation as a JSON object:

{{
  "phase_coverage": <0-100>,
  "parameter_accuracy": <0-100>,
  "operation_specificity": <0-100>,
  "reagent_traceability": <0-100>,
  "concentration_fidelity": <0-100>,
  "step_ordering": <0-100>,
  "workflow_structure": <0-100>,
  "completeness_score": <0-100>,
  "steps_analysis": [
    {{
      "digest_step_num": <step number from digest>,
      "digest_phase": "<phase name>",
      "digest_description_summary": "<brief summary, max 20 words>",
      "covered_in_bpl": <true|false>,
      "bpl_step_ids": ["step_XXXX", ...],
      "parameter_fidelity": "<exact|approximate|inaccurate|wrong|missing|n_a>",
      "notes": "<specific observations about coverage and accuracy>"
    }}
  ],
  "missing_digest_steps": [<step_nums NOT found in BPL>],
  "extra_bpl_steps": ["<BPL step_ids not mappable to any digest step>"],
  "reagents_found": ["<critical reagents traceable in BPL>"],
  "reagents_missing": ["<critical reagents NOT traceable in BPL>"],
  "concentrations_found": ["<concentrations/dilutions from digest preserved in BPL>"],
  "concentrations_missing": ["<concentrations/dilutions from digest NOT in BPL>"],
  "ordering_issues": ["<description of ordering problems, or empty list>"],
  "workflow_issues": ["<parallel paths falsely serialized, or empty list>"],
  "overall_assessment": "<2-3 sentence summary>"
}}

━━━ SCORING DIMENSIONS ━━━

1. PHASE COVERAGE (0-100): What percentage of the digest's phases/steps have \
corresponding operations in BPL?
   - Score = (phases_covered / total_digest_phases) × 100
   - A "covered" phase means there is at least one BPL step that semantically \
corresponds to the digest step's described action
   - Do NOT reward having more BPL steps per phase — 3 steps covering a phase \
is the same as 10 steps covering it

2. PARAMETER ACCURACY (0-100): How accurately are critical parameters \
(temperatures, durations, volumes, speeds) preserved?
   - For each digest step with critical_params, compare against BPL values
   - EXACT match: full credit
   - Within 10% error: "approximate", minor deduction (-5 per param)
   - 10-100% error: "inaccurate", moderate deduction (-15 per param)
   - >100% error (e.g., 1 uL when digest says 1 mL = 1000x error): "wrong", \
major deduction (-25 per param)
   - Parameter completely absent: "missing", full deduction (-25 per param)
   - Score = 100 - (sum of deductions), floor at 0

3. OPERATION SPECIFICITY (0-100): How many operations use semantically \
specific BPL primitives vs generic placeholders?
   - Specific: HUMAN_STEP with named operation (spin_coat, uv_expose, \
plasma_treat, centrifuge, develop_su8, apply_cyclic_stretch, etc.) = full credit
   - Moderate: HUMAN_STEP with generic name but clear parameters (incubate \
with temp/time) = 75% credit
   - Generic: Bare WAIT used where a specific operation should exist \
(e.g., WAIT for UV exposure instead of uv_expose) = 25% credit
   - Missing: Operation from digest has no BPL equivalent = 0% credit
   - Score = average credit across all digest operations that involve equipment

4. REAGENT TRACEABILITY (0-100): Can BPL well positions be traced back to \
named reagents from the digest?
   - Use the Source Mapping section and Action descriptions to identify reagents
   - Score = (traceable_reagents / total_critical_reagents) × 100
   - A reagent is "traceable" if its name or a clear synonym appears in Action \
text, Source Mapping comments, or target/source labels

5. CONCENTRATION FIDELITY (0-100): Are concentrations and dilution ratios \
from the digest preserved in BPL?
   - Check critical_params for concentration values (e.g., "30 µg/mL", \
"1:100", "1%", "0.1%", "4%")
   - Score = (concentrations_preserved / total_concentrations_in_digest) × 100
   - If the digest has no concentration values, score 100 (n/a)

6. STEP ORDERING (0-100): Is the logical phase order from the digest \
maintained in BPL?
   - Check that the sequence of phases in BPL follows the same order as digest
   - Deduct 10 points per out-of-order phase pair

7. WORKFLOW STRUCTURE (0-100): Does BPL correctly represent the digest's \
workflow branching?
   - Some digests describe PARALLEL ALTERNATIVES (e.g., "Caco-2 workflow" \
vs "organoid workflow", "gut-on-a-chip" vs "hybrid chip")
   - If the digest has no parallel alternatives, score 100
   - If parallel paths exist: does BPL represent them as alternatives or \
falsely serialize them as sequential steps with dependencies?
   - Deduct 15 points per parallel path that is falsely serialized
   - Deduct 25 points per parallel path that is entirely omitted

COMPLETENESS SCORE: Weighted aggregate:
  phase_coverage × 0.25 + parameter_accuracy × 0.20 + \
operation_specificity × 0.15 + reagent_traceability × 0.10 + \
concentration_fidelity × 0.10 + step_ordering × 0.10 + \
workflow_structure × 0.10

━━━ MAPPING RULES ━━━
- ASPIRATE+DISPENSE pairs = liquid transfers (reagent additions, washes)
- A single digest step may map to MULTIPLE BPL steps
- Look at Intent and Action columns for semantic matching
- Check Volume column against digest critical_params
- Use Source Mapping section to identify reagent identities for well positions
- Do NOT inflate scores because a protocol has many steps — evaluate \
PHASE COVERAGE not step count

Return ONLY the JSON object, no markdown fences, no commentary."""


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Helpers
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def extract_step_table(protocol_md: str) -> str:
    """Extract Overview + Primitive Distribution + Step Index + Source Mapping.

    Only strips Plate Map View (~20% token reduction) while preserving
    Source Mapping which contains reagent-to-well identity info.
    """
    lines = protocol_md.split('\n')
    result = []
    skip = False
    for line in lines:
        if line.startswith('## Plate Map View'):
            skip = True
            continue
        if skip and line.startswith('## '):
            skip = False
        if not skip:
            result.append(line)
    return '\n'.join(result)


def build_compare_prompt(digest: dict, protocol_md: str) -> list[dict]:
    """Build the BPL comparison prompt messages.

    Args:
        digest: The structured digest dict from the original JSON
        protocol_md: The full protocol.md content (will be trimmed)

    Returns:
        List of message dicts ready for the LLM API call
    """
    step_table = extract_step_table(protocol_md)
    digest_json = json.dumps(digest, ensure_ascii=False, indent=2)

    return [
        {"role": "system", "content": COMPARE_SYSTEM},
        {"role": "user", "content": COMPARE_USER_TEMPLATE.format(
            digest_json=digest_json,
            protocol_md=step_table,
        )},
    ]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Variant (text SOP) vs. digest comparison
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VARIANT_COMPARE_SYSTEM = """\
You are an expert protocol analyst who specializes in comparing laboratory \
protocols. You have deep knowledge of:

- Molecular biology laboratory procedures and techniques
- Critical parameters: temperatures, durations, concentrations, volumes, speeds
- How protocol steps decompose into sub-operations
- Equipment and reagent specificity in protocol descriptions

You are comparing a NATURAL LANGUAGE protocol (a text SOP variant generated \
from a digest) against the original structured digest. The digest is the \
canonical ground truth.

SCORING PHILOSOPHY: Score based on whether digest PHASES are covered and \
parameters are ACCURATE in the text variant. Score conservatively and \
penalize errors proportionally to their magnitude."""

VARIANT_COMPARE_USER_TEMPLATE = """\
Compare the following natural language protocol text against its original \
protocol digest. The digest is the canonical ground truth.

<original_digest>
{digest_json}
</original_digest>

<variant_text>
{variant_text}
</variant_text>

Analyze the text variant against the digest across 7 dimensions. Provide \
your evaluation as a JSON object:

{{
  "phase_coverage": <0-100>,
  "parameter_accuracy": <0-100>,
  "operation_specificity": <0-100>,
  "reagent_traceability": <0-100>,
  "concentration_fidelity": <0-100>,
  "step_ordering": <0-100>,
  "workflow_structure": <0-100>,
  "completeness_score": <0-100>,
  "steps_analysis": [
    {{
      "digest_step_num": <step number from digest>,
      "digest_phase": "<phase name>",
      "digest_description_summary": "<brief summary, max 20 words>",
      "covered_in_bpl": <true|false>,
      "bpl_step_ids": [],
      "parameter_fidelity": "<exact|approximate|inaccurate|wrong|missing|n_a>",
      "notes": "<specific observations about coverage and accuracy>"
    }}
  ],
  "missing_digest_steps": [<step_nums NOT found in variant text>],
  "extra_bpl_steps": [],
  "reagents_found": ["<critical reagents mentioned in variant text>"],
  "reagents_missing": ["<critical reagents NOT mentioned in variant text>"],
  "concentrations_found": ["<concentrations/dilutions from digest preserved in text>"],
  "concentrations_missing": ["<concentrations/dilutions from digest NOT in text>"],
  "ordering_issues": ["<description of ordering problems, or empty list>"],
  "workflow_issues": ["<parallel paths incorrectly described, or empty list>"],
  "overall_assessment": "<2-3 sentence summary>"
}}

━━━ SCORING DIMENSIONS ━━━

1. PHASE COVERAGE (0-100): What percentage of the digest's phases/steps are \
described in the text variant?
   - Score = (phases_covered / total_digest_phases) × 100
   - A "covered" phase means the variant describes the action from the digest step

2. PARAMETER ACCURACY (0-100): How accurately are critical parameters \
(temperatures, durations, volumes, speeds) preserved?
   - EXACT match: full credit
   - Within 10% error: "approximate", minor deduction (-5 per param)
   - 10-100% error: "inaccurate", moderate deduction (-15 per param)
   - >100% error (e.g., 1 uL when digest says 1 mL): "wrong", \
major deduction (-25 per param)
   - Parameter completely absent: "missing", full deduction (-25 per param)
   - Score = 100 - (sum of deductions), floor at 0

3. OPERATION SPECIFICITY (0-100): How specifically are equipment operations \
described?
   - Specific: Named equipment with operating parameters \
(e.g., "spin coat at 200 rpm", "UV expose for 10 min at 260 nm") = full credit
   - Moderate: Equipment mentioned but parameters vague \
(e.g., "incubate at 37°C") = 75% credit
   - Generic: Vague description (e.g., "let it sit", "process the sample") = 25% credit
   - Missing: Operation from digest not described = 0% credit
   - Score = average credit across all digest operations involving equipment

4. REAGENT TRACEABILITY (0-100): Are reagents from the digest mentioned by \
name in the text?
   - Score = (named_reagents / total_critical_reagents) × 100
   - A reagent is "traceable" if its name or a clear synonym appears in the text

5. CONCENTRATION FIDELITY (0-100): Are concentrations and dilution ratios \
from the digest preserved?
   - Check digest critical_params for concentration values
   - Score = (concentrations_preserved / total_concentrations_in_digest) × 100
   - If the digest has no concentration values, score 100 (n/a)

6. STEP ORDERING (0-100): Is the logical phase order from the digest \
maintained in the text?
   - Deduct 10 points per out-of-order phase pair

7. WORKFLOW STRUCTURE (0-100): Does the text correctly describe the digest's \
workflow branching?
   - If the digest has no parallel alternatives, score 100
   - Deduct 15 points per parallel path that is falsely serialized
   - Deduct 25 points per parallel path that is entirely omitted

COMPLETENESS SCORE: Weighted aggregate:
  phase_coverage × 0.25 + parameter_accuracy × 0.20 + \
operation_specificity × 0.15 + reagent_traceability × 0.10 + \
concentration_fidelity × 0.10 + step_ordering × 0.10 + \
workflow_structure × 0.10

NOTE: The "covered_in_bpl" and "bpl_step_ids" fields use BPL naming for \
schema compatibility. For text variants, "covered_in_bpl" means "covered \
in the variant text" and "bpl_step_ids" should be empty.

Return ONLY the JSON object, no markdown fences, no commentary."""


def build_variant_compare_prompt(digest: dict, variant_text: str) -> list[dict]:
    """Build the variant-vs-digest comparison prompt messages.

    Args:
        digest: The structured digest dict (ground truth)
        variant_text: The natural language protocol text

    Returns:
        List of message dicts ready for the LLM API call
    """
    digest_json = json.dumps(digest, ensure_ascii=False, indent=2)

    return [
        {"role": "system", "content": VARIANT_COMPARE_SYSTEM},
        {"role": "user", "content": VARIANT_COMPARE_USER_TEMPLATE.format(
            digest_json=digest_json,
            variant_text=variant_text,
        )},
    ]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Protocol-to-protocol comparison (v00 vs variant)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROTOCOL_COMPARE_SYSTEM = """\
You are checking whether a VARIANT BPL protocol is a legitimate \
laboratory protocol for the same experiment as a REFERENCE protocol.

Both come from the same source paper. The variant was rewritten by an \
LLM so differences in volumes, parameters, step counts, ordering, \
reagent names, and primitive choices (WAIT vs HUMAN_STEP) are ALL \
EXPECTED AND ACCEPTABLE.

Score 95-100 unless there is a SERIOUS problem. Serious problems are:
- The variant describes a COMPLETELY DIFFERENT experiment
- The variant is empty, truncated, or has no meaningful steps
- The variant is incoherent nonsense

Everything else is fine. Minor issues like unusual parameter values, \
missing sub-phases, or different primitive choices are NOT reasons to \
deduct points."""

PROTOCOL_COMPARE_USER_TEMPLATE = """\
Is this variant a legitimate protocol for the same experiment?

<reference_protocol>
{reference_md}
</reference_protocol>

<variant_protocol>
{variant_md}
</variant_protocol>

Return JSON:

{{
  "experiment_match": <0-100>,
  "protocol_validity": <0-100>,
  "phase_completeness": <0-100>,
  "overall_score": <0-100>,
  "ref_step_count": <int>,
  "variant_step_count": <int>,
  "experiment_type": "<what experiment both protocols describe>",
  "issues": ["<ONLY fatal problems — empty list if none>"],
  "overall_assessment": "<1 sentence: pass or fail with reason>"
}}

SCORING:
- experiment_match: 100 if same experiment type. 0 if completely different.
- protocol_validity: 100 if it has real steps. 0 if empty/nonsense.
- phase_completeness: 100 if it covers the experiment. Deduct only for \
ENTIRELY MISSING major phases (not for parameter or ordering differences).
- overall_score = experiment_match × 0.40 + protocol_validity × 0.35 + \
phase_completeness × 0.25

Default to 95-100 for all dimensions unless something is seriously wrong.

Return ONLY the JSON object, no markdown fences, no commentary."""


def build_protocol_compare_prompt(
    reference_md: str, variant_md: str,
) -> list[dict]:
    """Build the protocol-vs-protocol comparison prompt messages.

    Args:
        reference_md: The v00 reference protocol.md content
        variant_md: The variant protocol.md content

    Returns:
        List of message dicts ready for the LLM API call
    """
    ref_table = extract_step_table(reference_md)
    var_table = extract_step_table(variant_md)

    return [
        {"role": "system", "content": PROTOCOL_COMPARE_SYSTEM},
        {"role": "user", "content": PROTOCOL_COMPARE_USER_TEMPLATE.format(
            reference_md=ref_table,
            variant_md=var_table,
        )},
    ]
