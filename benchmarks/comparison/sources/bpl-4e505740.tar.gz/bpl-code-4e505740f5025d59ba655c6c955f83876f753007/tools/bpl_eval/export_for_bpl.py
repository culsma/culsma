#!/usr/bin/env python3
"""
Export generated variants and original protocols as individual .md files for BPL compilation.

For each paper, creates 11 MD files:
  - {paper}_v00.md  → original protocol text from extracted/
  - {paper}_v01.md  → generated protocol_text from variants/
  - ...
  - {paper}_v10.md  → generated protocol_text

Usage:
    python export_for_bpl.py                    # Export all
    python export_for_bpl.py --dry-run          # Preview without writing
    python export_for_bpl.py --limit 5          # Export first 5 papers
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

from config import BPL_INPUT_DIR, EXTRACTED_DIR, EXTRACTED_VISION_DIR, VARIANT_OUTPUT_DIR  # noqa: E402

EXPORT_DIR = BPL_INPUT_DIR

# Ligature replacements for normalized matching
_LIGATURES = str.maketrans({
    "\ufb01": "fi",  # ﬁ
    "\ufb02": "fl",  # ﬂ
    "\ufb00": "ff",  # ﬀ
    "\ufb03": "ffi", # ﬃ
    "\ufb04": "ffl", # ﬄ
    "\u02b9": "'",   # ʹ (prime)
    "\u2032": "'",   # ′ (prime)
})


def sanitize_filename(name: str) -> str:
    """Convert paper name to filesystem-safe format matching existing conventions."""
    # Replace spaces with underscores
    name = name.replace(" ", "_")
    # Replace problematic characters
    name = re.sub(r'[/:*?"<>|]', "_", name)
    # Collapse multiple underscores
    name = re.sub(r"_+", "_", name)
    # Trim trailing underscores/dots
    name = name.strip("_.")
    return name


def _normalize(name: str) -> str:
    """Normalize a name for fuzzy matching: strip ligatures, special chars, lowercase."""
    name = name.translate(_LIGATURES)
    return re.sub(r"[^a-zA-Z0-9]", "", name).lower()


def _build_extracted_index() -> dict[str, str]:
    """Build an index mapping stems to extracted JSON paths.

    Searches both extracted/ and extracted_vision/ directories.
    extracted/ takes priority over extracted_vision/.
    """
    index: dict[str, str] = {}

    # Vision files first (lower priority — will be overwritten by extracted/)
    vision_dir = Path(EXTRACTED_VISION_DIR)
    if vision_dir.exists():
        for ext_path in sorted(vision_dir.glob("*.json")):
            index[ext_path.stem] = str(ext_path)

    # extracted/ files overwrite vision entries for same stem
    for ext_path in sorted(Path(EXTRACTED_DIR).glob("*.json")):
        index[ext_path.stem] = str(ext_path)

    return index


def _find_extracted_path(paper_name: str, ext_index: dict[str, str]) -> str | None:
    """Find the extracted JSON path for a paper using multi-level matching."""
    # Exact match
    if paper_name in ext_index:
        return ext_index[paper_name]

    # Prefix match (handles truncation and year/volume suffixes)
    for ext_stem, ext_path in ext_index.items():
        if ext_stem.startswith(paper_name) or paper_name.startswith(ext_stem):
            return ext_path

    # Normalized match: handles ligatures (ﬁ→fi), special chars (ʹ→'), etc.
    paper_norm = _normalize(paper_name)[:50]
    for ext_stem, ext_path in ext_index.items():
        if _normalize(ext_stem)[:50] == paper_norm:
            return ext_path

    # Relaxed normalized prefix (30 chars)
    paper_norm_short = paper_norm[:30]
    for ext_stem, ext_path in ext_index.items():
        if _normalize(ext_stem)[:30] == paper_norm_short:
            return ext_path

    return None


def load_extracted_text(paper_name: str, ext_index: dict[str, str]) -> str | None:
    """Load original protocol text from extracted/ directory."""
    ext_path = _find_extracted_path(paper_name, ext_index)
    if ext_path is None:
        return None
    try:
        with open(ext_path, encoding="utf-8") as f:
            data = json.load(f)
        protocol = data.get("protocol_text", "")
        materials = data.get("materials_text", "")
        title = data.get("title", paper_name)

        if not protocol or len(protocol) < 100:
            return None

        # Build a complete MD document from extracted fields
        parts = [f"# {title}\n"]
        if materials:
            parts.append(f"## Materials and Reagents\n\n{materials}\n")
        parts.append(f"## Procedure\n\n{protocol}\n")
        return "\n".join(parts)
    except (json.JSONDecodeError, OSError):
        return None


def export_all(
    limit: int | None = None,
    dry_run: bool = False,
    export_dir: str = EXPORT_DIR,
):
    """Export all papers' variants + originals as MD files."""
    os.makedirs(export_dir, exist_ok=True)

    ext_index = _build_extracted_index()
    print(f"Built extracted index: {len(ext_index)} files")

    variant_files = sorted(Path(VARIANT_OUTPUT_DIR).glob("*.json"))
    variant_files = [f for f in variant_files if not f.name.startswith("_")]

    if limit:
        variant_files = variant_files[:limit]

    total_files = 0
    total_papers = 0
    skipped_originals = 0
    papers_summary = []

    for variant_path in variant_files:
        paper_name = variant_path.stem
        safe_name = sanitize_filename(paper_name)

        with open(variant_path, encoding="utf-8") as f:
            data = json.load(f)

        variants = data.get("variants", [])

        # ── v00: Original protocol from extracted/ ──
        original_text = load_extracted_text(paper_name, ext_index)
        has_original = original_text is not None

        if has_original:
            v00_path = os.path.join(export_dir, f"{safe_name}_v00.md")
            if not dry_run:
                with open(v00_path, "w", encoding="utf-8") as f:
                    f.write(original_text)
            total_files += 1
        else:
            skipped_originals += 1

        # ── v01..vNN: generated protocol variants ──
        variant_count = 0
        for i, variant in enumerate(variants):
            protocol_text = variant.get("protocol_text", "")
            if len(protocol_text) < 200:
                continue

            version = f"v{i + 1:02d}"
            md_path = os.path.join(export_dir, f"{safe_name}_{version}.md")

            if not dry_run:
                with open(md_path, "w", encoding="utf-8") as f:
                    f.write(protocol_text)

            total_files += 1
            variant_count += 1

        total_papers += 1
        papers_summary.append({
            "paper": paper_name[:60],
            "has_original": has_original,
            "variants": variant_count,
            "total_files": (1 if has_original else 0) + variant_count,
        })

    # ── Summary ──
    action = "Would export" if dry_run else "Exported"
    print(f"\n{'=' * 60}")
    print(f"  {action} {total_files} MD files from {total_papers} papers")
    print(f"  Originals (v00): {total_papers - skipped_originals}")
    print(f"  Skipped originals (no extracted text): {skipped_originals}")
    print(f"  Output directory: {export_dir}/")
    print(f"{'=' * 60}")

    # Papers with issues
    incomplete = [p for p in papers_summary if p["total_files"] < 11]
    if incomplete:
        print(f"\n  Papers with <11 files ({len(incomplete)}):")
        for p in incomplete[:20]:
            orig = "yes" if p["has_original"] else "NO"
            print(f"    {p['paper']} → orig={orig}, variants={p['variants']}")
        if len(incomplete) > 20:
            print(f"    ... and {len(incomplete) - 20} more")

    # Save manifest
    if not dry_run:
        manifest_path = os.path.join(export_dir, "_manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump({
                "total_papers": total_papers,
                "total_files": total_files,
                "skipped_originals": skipped_originals,
                "papers": papers_summary,
            }, f, ensure_ascii=False, indent=2)
        print(f"\n  Manifest saved to: {manifest_path}")


def main():
    parser = argparse.ArgumentParser(description="Export protocols as MD files for BPL")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    parser.add_argument("--limit", type=int, help="Limit number of papers")
    parser.add_argument("--out", default=EXPORT_DIR, help=f"Output directory (default: {EXPORT_DIR})")
    args = parser.parse_args()

    export_all(limit=args.limit, dry_run=args.dry_run, export_dir=args.out)


if __name__ == "__main__":
    main()
