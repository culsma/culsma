#!/usr/bin/env python3
"""Reproduce the BPL paper's HPLC→UHPLC method translation (Fig. 5).

Paper context (Methods §139-142):

* Source HPLC method: Agilent ValueLab LC C18 (170 Å, 4.6 × 250 mm, 5 μm),
  flow 1.0 mL/min, 10 μL injection, gradient 75% B held for 5.5 min →
  ramp to 100% B at 7.5 min → hold 100% B until 30 min → re-equilibrate
  75% B at 32 min, column 50 °C.
* Target UHPLC column: Phenomenex Kinetex C18 (100 Å, 2.1 × 50 mm, 1.7 μm),
  max 1000 bar.
* Translation rule: 2025 Chinese Pharmacopoeia General Chapter 0512 column-
  scaling formulae; flow ∝ (D₂/D₁)² × (dp₁/dp₂); gradient time scales by
  column-volume / flow ratio.
* Paper claim: BPL-COGEN computed flow 0.613 mL/min, injection 0.42 μL,
  run time 2.1 min (32→2.1 = 14.7× reduction; solvent 100→4.2 mL = 95.8 %
  saving). Compliance engine emitted 4 warnings (plate ratio,
  packing-type change, pore-size change, backpressure).

This script reads the canonical column + method definitions from
``bpl/agentic/column_catalog`` (which encode the exact paper inputs), calls
``convert_method`` (the ChP 0512 scaling engine the paper describes), and
writes the resulting translation to
``tools/bpl_eval/data/method_translation/hplc_to_uhplc.json``. The figure
script and unit tests read this JSON so the figure-5 panel and the
manuscript prose are guaranteed to stay in sync.

Run::

    uv run python tools/bpl_eval/method_translation.py
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from bpl.agentic.column_catalog import (  # noqa: E402
    ColumnMethodProfile,
    GradientStep,
    MethodParams,
    DetectionMode,
    convert_method,
    _KINETEX_SHORT,
    _VALUELAB_LONG,
)

_DATA_DIR = Path(_BASE) / "data" / "method_translation"
OUT_PATH = _DATA_DIR / "hplc_to_uhplc.json"


def paper_source_profile() -> ColumnMethodProfile:
    """The exact source method described in the paper Methods §139."""
    method = MethodParams(
        flow_rate_ml_min=1.0,
        injection_volume_ul=10.0,
        column_temp_c=50.0,
        detection_wavelengths_nm=(328.0, 382.0, 452.0, 475.0, 210.0),
        detection_mode=DetectionMode.DAD,
        mobile_phase_a="Ultrapure water",
        mobile_phase_b="Acetonitrile/Isopropanol 75:25",
        gradient_table=(
            GradientStep(0.0, 75.0),
            GradientStep(5.5, 75.0),
            GradientStep(7.5, 100.0),
            GradientStep(30.0, 100.0),
            GradientStep(32.0, 75.0),
        ),
        is_gradient=True,
    )
    return ColumnMethodProfile(
        column=_VALUELAB_LONG,
        method=method,
        target_analytes=(
            "Retinol", "Retinal", "Retinyl acetate",
            "Lycopene", "beta-Carotene",
        ),
        application="paper-fig5-source",
        description="Reference HPLC method as specified in BPL paper Methods §139",
    )


# Paper claims (Methods §137, §142) — used by the unit test as guard-rails.
PAPER_CLAIM_FLOW_RATE_ML_MIN = 0.613
PAPER_CLAIM_RUN_TIME_MIN = 2.1
PAPER_CLAIM_WARNING_COUNT = 4
PAPER_CLAIM_RUN_TIME_REDUCTION_FACTOR = 14.7  # 32 / 2.1 ≈ 15.24, paper rounds


def serialise_translation() -> dict[str, Any]:
    """Run convert_method on the paper's exact inputs and serialise the result."""
    src = paper_source_profile()
    result = convert_method(src, _KINETEX_SHORT)

    src_run_time = max(step.time_min for step in src.method.gradient_table)
    new_run_time = max(step.time_min for step in result.converted_method.gradient_table)
    src_solvent_volume_ml = src.method.flow_rate_ml_min * src_run_time
    new_solvent_volume_ml = result.converted_method.flow_rate_ml_min * new_run_time
    # Filter to severity == "warning" — the paper specifically claims four
    # *warnings* emitted by the compliance engine. The converter additionally
    # emits informational notices (e.g. "L/dp OK") that are not paper-counted.
    warning_only = [w for w in result.warnings if w.severity == "warning"]

    summary = {
        "source": {
            "column_id": src.column.column_id,
            "column_name": src.column.name,
            "inner_diameter_mm": src.column.inner_diameter_mm,
            "length_mm": src.column.length_mm,
            "particle_size_um": src.column.particle_size_um,
            "flow_rate_ml_min": src.method.flow_rate_ml_min,
            "injection_volume_ul": src.method.injection_volume_ul,
            "run_time_min": src_run_time,
            "gradient": [(s.time_min, s.percent_b) for s in src.method.gradient_table],
            "solvent_volume_ml": round(src_solvent_volume_ml, 3),
        },
        "target_column": {
            "column_id": _KINETEX_SHORT.column_id,
            "column_name": _KINETEX_SHORT.name,
            "inner_diameter_mm": _KINETEX_SHORT.inner_diameter_mm,
            "length_mm": _KINETEX_SHORT.length_mm,
            "particle_size_um": _KINETEX_SHORT.particle_size_um,
            "max_pressure_bar": _KINETEX_SHORT.max_pressure_bar,
        },
        "translation": {
            "flow_rate_ml_min": round(result.converted_method.flow_rate_ml_min, 3),
            "injection_volume_ul": round(result.converted_method.injection_volume_ul, 3),
            "run_time_min": round(new_run_time, 3),
            "gradient": [
                (s.time_min, s.percent_b) for s in result.converted_method.gradient_table
            ],
            "solvent_volume_ml": round(new_solvent_volume_ml, 3),
            "estimated_pressure_ratio": round(result.estimated_pressure_ratio, 3),
            "speed_factor": round(result.speed_factor, 3),
            "solvent_saving_percent_engine": round(result.solvent_saving_percent, 3),
        },
        "reduction": {
            "run_time_factor": round(src_run_time / new_run_time, 3) if new_run_time > 0 else None,
            "solvent_saving_pct": round(
                (1.0 - new_solvent_volume_ml / src_solvent_volume_ml) * 100.0, 3
            )
            if src_solvent_volume_ml > 0
            else None,
        },
        "warnings": [
            {"parameter": w.parameter, "severity": w.severity, "message": w.message}
            for w in result.warnings
        ],
        "warning_count": len(warning_only),
        "paper_claims": {
            "flow_rate_ml_min": PAPER_CLAIM_FLOW_RATE_ML_MIN,
            "run_time_min": PAPER_CLAIM_RUN_TIME_MIN,
            "run_time_reduction_factor": PAPER_CLAIM_RUN_TIME_REDUCTION_FACTOR,
            "warning_count": PAPER_CLAIM_WARNING_COUNT,
        },
    }
    return summary


def write_translation(out_path: Path = OUT_PATH) -> dict[str, Any]:
    summary = serialise_translation()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Reproduce paper Fig. 5 HPLC→UHPLC method translation"
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=OUT_PATH,
        help="Output JSON path",
    )
    args = parser.parse_args()
    summary = write_translation(args.out)

    print("=" * 72)
    print(" BPL paper — HPLC→UHPLC method translation (Fig. 5)")
    print("=" * 72)
    src = summary["source"]
    tgt = summary["translation"]
    red = summary["reduction"]
    print(f" Source:      {src['column_name']} ({src['inner_diameter_mm']}×{src['length_mm']} mm, {src['particle_size_um']} μm)")
    print(f"              flow {src['flow_rate_ml_min']} mL/min, run {src['run_time_min']} min")
    print(f" Target:      {summary['target_column']['column_name']} ({summary['target_column']['inner_diameter_mm']}×{summary['target_column']['length_mm']} mm, {summary['target_column']['particle_size_um']} μm)")
    print("-" * 72)
    print(f" Translated:  flow {tgt['flow_rate_ml_min']} mL/min "
          f"(paper claim {summary['paper_claims']['flow_rate_ml_min']})")
    print(f"              injection {tgt['injection_volume_ul']} μL")
    print(f"              run time {tgt['run_time_min']} min "
          f"(paper claim {summary['paper_claims']['run_time_min']})")
    print(f"              {red['run_time_factor']:.1f}× run-time reduction, "
          f"{red['solvent_saving_pct']:.1f} % solvent saving")
    print("-" * 72)
    print(f" Warnings ({len(summary['warnings'])}):")
    for w in summary["warnings"]:
        print(f"   [{w['severity']}] {w['parameter']}: {w['message'][:80]}")
    print("-" * 72)
    print(f" Saved to: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
