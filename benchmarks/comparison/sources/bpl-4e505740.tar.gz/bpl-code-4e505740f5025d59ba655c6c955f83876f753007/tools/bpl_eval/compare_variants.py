#!/usr/bin/env python3
"""
Protocol variant comparison: v00 (original) vs v01-v10 (LLM-expanded).

Compares BPL-compiled protocol.md files to verify that variants generated
from LLM-expanded SOPs produce semantically equivalent protocols to the
original paper's v00 protocol.

Usage:
    python compare_variants.py --test              # Test 1 paper (all variants)
    python compare_variants.py --test-n 3          # Test 3 papers
    python compare_variants.py                     # All papers
    python compare_variants.py --resume            # Resume from checkpoint
    python compare_variants.py --report-only       # Re-generate report
    python compare_variants.py --model <model>     # Override model
    python compare_variants.py --versions 3        # Only compare first N variants
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
from statistics import mean, stdev

import httpx
from dotenv import load_dotenv

# Load .env from project root and make the eval-package directory importable
# regardless of cwd.
_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)
_PROJECT_ROOT = os.path.normpath(os.path.join(_BASE, "..", ".."))
load_dotenv(os.path.join(_PROJECT_ROOT, ".env"))

from pydantic import BaseModel, Field  # noqa: E402

from config import COMPARISON_DIR, PROTOCOLS_DIR  # noqa: E402
from compare_prompts import build_protocol_compare_prompt  # noqa: E402
from llm_client import call_llm as _call_llm, parse_json_response  # noqa: E402

# ──────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────

RESULTS_DIR = COMPARISON_DIR
CHECKPOINT_FILE = os.path.join(RESULTS_DIR, "variant_checkpoint.json")

DEFAULT_MODEL = "anthropic/claude-sonnet-4-6"
DEFAULT_TEMPERATURE = 0.1
MAX_CONCURRENT = 8


async def call_llm(
    client: httpx.AsyncClient,
    messages: list[dict],
    model: str,
    temperature: float = DEFAULT_TEMPERATURE,
    max_tokens: int = 8192,
) -> str:
    return await _call_llm(client, messages, model, temperature, max_tokens=max_tokens)


# ──────────────────────────────────────────────────────────────
# Pydantic models
# ──────────────────────────────────────────────────────────────

class VariantResult(BaseModel):
    paper_name: str
    version: str
    model_used: str
    # 3 scoring dimensions
    experiment_match: int = Field(ge=0, le=100)
    protocol_validity: int = Field(ge=0, le=100)
    phase_completeness: int = Field(ge=0, le=100)
    overall_score: int = Field(ge=0, le=100)
    # Metadata
    ref_step_count: int = 0
    variant_step_count: int = 0
    experiment_type: str = ""
    # Details
    issues: list[str] = Field(default_factory=list)
    overall_assessment: str = ""


class PaperComparison(BaseModel):
    paper_name: str
    ref_step_count: int = 0
    variants: list[VariantResult] = Field(default_factory=list)
    avg_overall: float = 0.0
    min_overall: float = 0.0
    max_overall: float = 0.0
    std_overall: float = 0.0
    avg_experiment_match: float = 0.0
    avg_protocol_validity: float = 0.0
    avg_phase_completeness: float = 0.0
    consistency_score: float = 0.0


class ComparisonReport(BaseModel):
    total_papers: int = 0
    total_variants: int = 0
    overall_avg_score: float = 0.0
    overall_avg_experiment_match: float = 0.0
    overall_avg_protocol_validity: float = 0.0
    overall_avg_phase_completeness: float = 0.0
    overall_avg_consistency: float = 0.0
    papers: list[PaperComparison] = Field(default_factory=list)
    model_used: str = ""
    timestamp: str = ""


# ──────────────────────────────────────────────────────────────
# Discovery
# ──────────────────────────────────────────────────────────────

@dataclass
class PaperProtocols:
    """A paper with its v00 reference and v01-v10 variant paths."""
    name: str
    v00_path: str
    variant_paths: dict[str, str] = field(default_factory=dict)  # version -> path


def discover_papers(protocols_dir: str) -> list[PaperProtocols]:
    """Find papers that have a v00 reference and at least one variant."""
    version_pat = re.compile(r'^(.+)_(v\d{2})\.protocol\.md$')
    papers: dict[str, PaperProtocols] = {}

    for f in sorted(Path(protocols_dir).glob("*.protocol.md")):
        m = version_pat.match(f.name)
        if not m:
            continue
        base = m.group(1)
        version = m.group(2)

        if base not in papers:
            papers[base] = PaperProtocols(name=base, v00_path="")

        if version == "v00":
            papers[base].v00_path = str(f)
        else:
            papers[base].variant_paths[version] = str(f)

    # Filter to papers with both v00 and at least one variant
    result = [
        p for p in papers.values()
        if p.v00_path and p.variant_paths
    ]
    return sorted(result, key=lambda p: p.name)


# ──────────────────────────────────────────────────────────────
# LLM API
# ──────────────────────────────────────────────────────────────

# ──────────────────────────────────────────────────────────────
# Checkpoint
# ──────────────────────────────────────────────────────────────

def load_checkpoint() -> dict[str, Any]:
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE, encoding='utf-8') as f:
            return json.load(f)
    return {}


def save_checkpoint(ckpt: dict):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(CHECKPOINT_FILE, 'w', encoding='utf-8') as f:
        json.dump(ckpt, f, ensure_ascii=False)


# ──────────────────────────────────────────────────────────────
# Comparison engine
# ──────────────────────────────────────────────────────────────

async def compare_single_variant(
    client: httpx.AsyncClient,
    semaphore: asyncio.Semaphore,
    ref_md: str,
    variant_path: str,
    paper_name: str,
    version: str,
    model: str,
) -> VariantResult:
    """Compare one variant against the v00 reference."""
    async with semaphore:
        with open(variant_path, encoding='utf-8') as f:
            variant_md = f.read()

        messages = build_protocol_compare_prompt(ref_md, variant_md)

        print(f"    [{version}] Comparing...")
        t0 = time.time()
        raw = await call_llm(client, messages, model, max_tokens=8192)
        elapsed = time.time() - t0

        try:
            result = parse_json_response(raw)
        except ValueError as e:
            print(f"    [{version}] ⚠ JSON parse failed: {e}")
            return VariantResult(
                paper_name=paper_name,
                version=version,
                model_used=model,
                experiment_match=0,
                protocol_validity=0,
                phase_completeness=0,
                overall_score=0,
                overall_assessment=f"JSON parse error: {e}",
            )

        vr = VariantResult(
            paper_name=paper_name,
            version=version,
            model_used=model,
            experiment_match=int(result.get("experiment_match", 0)),
            protocol_validity=int(result.get("protocol_validity", 0)),
            phase_completeness=int(result.get("phase_completeness", 0)),
            overall_score=int(result.get("overall_score", 0)),
            ref_step_count=int(result.get("ref_step_count", 0)),
            variant_step_count=int(result.get("variant_step_count", 0)),
            experiment_type=result.get("experiment_type", ""),
            issues=result.get("issues", []),
            overall_assessment=result.get("overall_assessment", ""),
        )

        print(f"    [{version}] ✓ overall={vr.overall_score} "
              f"match={vr.experiment_match} valid={vr.protocol_validity} "
              f"phases={vr.phase_completeness} "
              f"steps={vr.ref_step_count}→{vr.variant_step_count} "
              f"({elapsed:.1f}s)")

        return vr


async def compare_paper(
    client: httpx.AsyncClient,
    semaphore: asyncio.Semaphore,
    paper: PaperProtocols,
    model: str,
    ckpt: dict,
    lock: asyncio.Lock,
    max_versions: int = 10,
) -> PaperComparison | None:
    """Compare all variants of a paper against its v00 reference."""
    print(f"\n  📄 {paper.name[:70]}...")

    # Load reference protocol
    with open(paper.v00_path, encoding='utf-8') as f:
        ref_md = f.read()

    ckpt_key = paper.name
    ckpt_entry = ckpt.get(ckpt_key, {})

    # Get variants to compare
    variants_to_compare = list(paper.variant_paths.items())[:max_versions]
    variant_results: list[VariantResult] = []

    tasks = []
    cached = []

    for version, var_path in variants_to_compare:
        if version in ckpt_entry and isinstance(ckpt_entry[version], dict):
            print(f"    [{version}] Using cached result")
            try:
                vr = VariantResult(**ckpt_entry[version])
                cached.append(vr)
            except Exception:
                tasks.append((version, var_path))
        else:
            tasks.append((version, var_path))

    # Run comparisons
    async def _compare_and_save(version: str, var_path: str) -> VariantResult:
        vr = await compare_single_variant(
            client, semaphore, ref_md, var_path,
            paper.name, version, model,
        )
        async with lock:
            if ckpt_key not in ckpt:
                ckpt[ckpt_key] = {}
            ckpt[ckpt_key][version] = vr.model_dump()
            save_checkpoint(ckpt)
        return vr

    if tasks:
        coros = [_compare_and_save(v, p) for v, p in tasks]
        results = await asyncio.gather(*coros, return_exceptions=True)
        for (version, _), result in zip(tasks, results):
            if isinstance(result, Exception):
                print(f"    [{version}] ✗ Failed: {result}")
            else:
                variant_results.append(result)

    variant_results = cached + variant_results
    variant_results.sort(key=lambda v: v.version)

    if not variant_results:
        print("    ✗ All variants failed")
        return None

    # Compute aggregates
    scores = [v.overall_score for v in variant_results]

    pc = PaperComparison(
        paper_name=paper.name,
        ref_step_count=variant_results[0].ref_step_count if variant_results else 0,
        variants=variant_results,
        avg_overall=mean(scores),
        min_overall=min(scores),
        max_overall=max(scores),
        std_overall=stdev(scores) if len(scores) > 1 else 0.0,
        avg_experiment_match=mean(v.experiment_match for v in variant_results),
        avg_protocol_validity=mean(v.protocol_validity for v in variant_results),
        avg_phase_completeness=mean(v.phase_completeness for v in variant_results),
        consistency_score=max(0.0, min(100.0, 100.0 - stdev(scores) * 2))
            if len(scores) > 1 else 100.0,
    )

    print(f"    → avg={pc.avg_overall:.0f} "
          f"min={pc.min_overall:.0f} max={pc.max_overall:.0f} "
          f"std={pc.std_overall:.1f} "
          f"consistency={pc.consistency_score:.0f}")

    # Save per-paper result
    per_paper_dir = os.path.join(RESULTS_DIR, "per_paper")
    os.makedirs(per_paper_dir, exist_ok=True)
    with open(os.path.join(per_paper_dir, f"{paper.name}.json"), 'w', encoding='utf-8') as f:
        json.dump(pc.model_dump(), f, ensure_ascii=False, indent=2)

    return pc


# ──────────────────────────────────────────────────────────────
# Report generation
# ──────────────────────────────────────────────────────────────

def generate_report(papers: list[PaperComparison], model: str) -> ComparisonReport:
    """Generate the summary report."""
    all_scores = [v.overall_score for p in papers for v in p.variants]

    report = ComparisonReport(
        total_papers=len(papers),
        total_variants=len(all_scores),
        overall_avg_score=mean(all_scores) if all_scores else 0.0,
        overall_avg_experiment_match=mean(v.experiment_match for p in papers for v in p.variants) if all_scores else 0.0,
        overall_avg_protocol_validity=mean(v.protocol_validity for p in papers for v in p.variants) if all_scores else 0.0,
        overall_avg_phase_completeness=mean(v.phase_completeness for p in papers for v in p.variants) if all_scores else 0.0,
        overall_avg_consistency=mean(p.consistency_score for p in papers) if papers else 0.0,
        papers=papers,
        model_used=model,
        timestamp=datetime.now().isoformat(),
    )

    return report


def print_report(report: ComparisonReport):
    """Print a readable summary table."""
    print("\n" + "=" * 100)
    print("VARIANT COMPARISON REPORT")
    print("=" * 100)
    print(f"Model: {report.model_used}")
    print(f"Papers: {report.total_papers}  |  Variants: {report.total_variants}")
    print(f"Timestamp: {report.timestamp}")
    print()

    # Overall averages
    print("── Overall Averages ──")
    print(f"  Overall Score:      {report.overall_avg_score:.1f}")
    print(f"  Experiment Match:   {report.overall_avg_experiment_match:.1f}")
    print(f"  Protocol Validity:  {report.overall_avg_protocol_validity:.1f}")
    print(f"  Phase Completeness: {report.overall_avg_phase_completeness:.1f}")
    print(f"  Cross-variant:      {report.overall_avg_consistency:.1f}")
    print()

    # Per-paper table
    header = (
        f"{'Paper':<60} {'Avg':>4} {'Min':>4} {'Max':>4} "
        f"{'Match':>5} {'Valid':>5} {'Phase':>5} {'Cons':>4}"
    )
    print(header)
    print("-" * len(header))

    for p in sorted(report.papers, key=lambda x: x.avg_overall, reverse=True):
        name = p.paper_name[:59]
        print(
            f"{name:<60} {p.avg_overall:4.0f} {p.min_overall:4.0f} {p.max_overall:4.0f} "
            f"{p.avg_experiment_match:5.0f} {p.avg_protocol_validity:5.0f} "
            f"{p.avg_phase_completeness:5.0f} {p.consistency_score:4.0f}"
        )

    print()

    # Per-variant detail for each paper
    for p in report.papers:
        print(f"\n  📄 {p.paper_name[:70]}")
        print(f"     Ref steps: {p.ref_step_count}")
        for v in p.variants:
            status = "✓" if v.overall_score >= 70 else "⚠" if v.overall_score >= 50 else "✗"
            print(
                f"     {status} {v.version}: overall={v.overall_score} "
                f"match={v.experiment_match} valid={v.protocol_validity} "
                f"phases={v.phase_completeness} "
                f"steps={v.ref_step_count}→{v.variant_step_count}"
            )
            if v.issues:
                for issue in v.issues[:2]:
                    print(f"       ⚠ {issue[:80]}")
            if v.overall_assessment:
                print(f"       → {v.overall_assessment[:100]}")


# ──────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(description="Compare protocol variants against v00 reference")
    parser.add_argument("--test", action="store_true", help="Test with 1 paper")
    parser.add_argument("--test-n", type=int, default=0, help="Test with N papers")
    parser.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    parser.add_argument("--report-only", action="store_true", help="Re-generate report from saved results")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"Model to use (default: {DEFAULT_MODEL})")
    parser.add_argument("--versions", type=int, default=10, help="Max variants to compare per paper")
    parser.add_argument("--protocols-dir", default=PROTOCOLS_DIR, help="Protocols directory")
    args = parser.parse_args()

    protocols_dir = args.protocols_dir

    print(f"🔍 Discovering papers in {protocols_dir}...")
    papers = discover_papers(protocols_dir)
    print(f"   Found {len(papers)} papers with v00 + variants")

    if not papers:
        print("   No papers found!")
        sys.exit(1)

    # Limit for testing
    if args.test:
        papers = papers[:1]
    elif args.test_n > 0:
        papers = papers[:args.test_n]

    # Report-only mode
    if args.report_only:
        per_paper_dir = os.path.join(RESULTS_DIR, "per_paper")
        loaded = []
        for p in papers:
            result_file = os.path.join(per_paper_dir, f"{p.name}.json")
            if os.path.exists(result_file):
                with open(result_file, encoding='utf-8') as f:
                    loaded.append(PaperComparison(**json.load(f)))
        if loaded:
            report = generate_report(loaded, args.model)
            print_report(report)
            report_path = os.path.join(RESULTS_DIR, "variant_report.json")
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report.model_dump(), f, ensure_ascii=False, indent=2)
            print(f"\n📊 Report saved to {report_path}")
        else:
            print("   No saved results found")
        return

    # Load checkpoint
    ckpt = load_checkpoint() if args.resume else {}
    lock = asyncio.Lock()
    semaphore = asyncio.Semaphore(MAX_CONCURRENT)

    print(f"📊 Comparing {len(papers)} papers, max {args.versions} variants each")
    print(f"   Model: {args.model}")
    print(f"   Concurrency: {MAX_CONCURRENT}")

    os.makedirs(RESULTS_DIR, exist_ok=True)

    async with httpx.AsyncClient() as client:
        results: list[PaperComparison] = []

        for i, paper in enumerate(papers, 1):
            print(f"\n[{i}/{len(papers)}] Processing...")
            pc = await compare_paper(
                client, semaphore, paper, args.model,
                ckpt, lock, args.versions,
            )
            if pc:
                results.append(pc)

    if results:
        report = generate_report(results, args.model)
        print_report(report)

        report_path = os.path.join(RESULTS_DIR, "variant_report.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report.model_dump(), f, ensure_ascii=False, indent=2)
        print(f"\n📊 Report saved to {report_path}")
    else:
        print("\n⚠ No results generated")


if __name__ == "__main__":
    asyncio.run(main())
