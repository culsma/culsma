"""Prompt templates for digest creation and step-count-enforced variants."""

import json

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# STAGE A: DIGEST — compress raw protocol text into structured ground truth
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DIGEST_SYSTEM = """\
You are an expert molecular biologist who specializes in distilling complex \
laboratory protocols into clear, structured summaries. You have 20 years of \
bench experience and can identify the essential vs. incidental details in any \
wet-lab procedure."""

DIGEST_USER_TEMPLATE = """\
Below is the full Procedure section extracted from a Nature Protocols paper.

<paper_title>{title}</paper_title>

<protocol_text>
{protocol_text}
</protocol_text>

{materials_block}

Produce a STRUCTURED DIGEST of this protocol in the following JSON format. \
Be precise and faithful to the source — do not invent steps that aren't there.

{{
  "title": "<paper title>",
  "objective": "<1-2 sentence summary of what this protocol accomplishes>",
  "organism_or_system": "<target organism, cell line, or in-vitro system>",
  "key_technique": "<primary technique name, e.g. CRISPR-Cas9, ChIP-seq>",
  "steps": [
    {{
      "step_num": 1,
      "phase": "<e.g. Preparation / Construction / Transfection / Analysis>",
      "description": "<1-3 sentences describing what is done>",
      "critical_params": "<key temperatures, times, concentrations, or null>"
    }}
  ],
  "critical_reagents": ["<reagent1>", "<reagent2>"],
  "critical_equipment": ["<equipment1>", "<equipment2>"],
  "total_time_estimate": "<e.g. 3-5 days, 2 weeks>",
  "output": "<what the protocol produces, e.g. transgenic plants, sequencing library>"
}}

Keep 15-30 steps. Each step should capture one logical action. \
Return ONLY the JSON, no commentary."""


def build_digest_prompt(title: str, protocol_text: str, materials_text: str = "") -> list[dict]:
    materials_block = ""
    if materials_text:
        materials_block = f"<materials>\n{materials_text}\n</materials>"

    return [
        {"role": "system", "content": DIGEST_SYSTEM},
        {"role": "user", "content": DIGEST_USER_TEMPLATE.format(
            title=title,
            protocol_text=protocol_text,
            materials_block=materials_block,
        )},
    ]

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EXPAND — step-count-enforced variant generation
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EXPAND_SYSTEM = """\
You are a scientific writing engine that simulates how different researchers \
would independently write up the SAME laboratory protocol for submission to \
a methods journal.

CRITICAL CONSTRAINT: Every variant must describe the EXACT SAME protocol — \
same organism, same technique, same reagents, same steps, same conditions. \
The ONLY differences between variants are writing style, tone, phrasing, \
formatting, and level of detail in descriptions. Think of it as 10 different \
people in 10 different labs all writing up the same procedure they just learned.

STEP COUNT RULE: The source digest has a specific number of steps. Every \
variant MUST have EXACTLY the same number of procedural steps. Do NOT split \
one digest step into multiple sub-steps. Do NOT merge multiple digest steps \
into one. Each digest step maps 1:1 to one variant step. This is NON-NEGOTIABLE.

You have deep knowledge of:
- How writing style varies by career stage (grad student → postdoc → PI)
- How writing style varies by lab background (biochemist vs geneticist vs \
synthetic biologist vs structural biologist vs genomics researcher)
- Journal conventions for protocol papers (Nature Protocols, STAR Protocols, \
Bio-Protocol, Methods in Molecular Biology, JoVE, Current Protocols)
- Common human writing imperfections in lab protocols: inconsistent \
abbreviation, varying detail levels, occasional wordiness, idiosyncratic \
formatting preferences"""

EXPAND_USER_TEMPLATE = """\
Below is a structured digest of a real Nature Protocols paper:

<digest>
{digest_json}
</digest>

The digest contains EXACTLY {step_count} procedural steps.

Generate exactly {num_variants} COMPLETE variant protocols. Each variant is the \
SAME protocol described in the digest above, but written by a different \
researcher in their own words and style.

⚠️ CRITICAL: The protocol content (organism, technique, reagents, steps, \
conditions, temperatures, concentrations, incubation times) must remain \
IDENTICAL across all variants. Only the writing style, phrasing, formatting, \
and level of descriptive detail should differ. Do NOT change the organism, \
do NOT swap techniques, do NOT alter the experimental procedure.

⚠️ STEP COUNT CONSTRAINT: Each variant MUST contain EXACTLY {step_count} \
numbered procedural steps — matching the digest 1:1. \
Do NOT split one step into sub-steps. Do NOT merge steps. Do NOT add or \
remove steps. Step 1 in every variant corresponds to step 1 in the digest, \
step 2 to step 2, etc. Different variants may describe each step in more or \
fewer words, but the step BOUNDARIES must be identical.

⚠️ STRICT LENGTH REQUIREMENT: Each variant MUST be between 1200 and 2000 words. \
Variants shorter than 1200 words are REJECTED. Aim for 1500 words on average.

━━━ MANDATORY RULES ━━━

1. PROTOCOL FIDELITY (the science must stay the same)
   • Same organism / cell line / system as the source
   • Same technique and method throughout
   • Same reagents and materials (though how they are listed may vary)
   • Same step order and procedure logic
   • Same critical parameters (temperatures, times, concentrations)
   • Same expected results and outputs
   • EXACTLY {step_count} procedural steps — no more, no less

2. STRUCTURAL VARIETY (vary the writing format)
   Distribute across these formats — NO more than 2 variants in the same format:
   • Format A — Classic numbered steps with bold action verbs
   • Format B — Narrative paragraphs organized by phase/day
   • Format C — Concise bullet points with timing annotations
   • Format D — Detailed stepwise with "Critical step" and "Troubleshooting" notes inline
   • Format E — Hierarchical: major stages with numbered sub-steps
   • Format F — Equipment-centric: organized by instrument/station

   ⚠️ MANDATORY NUMBERING RULE (applies to ALL formats, NO exceptions):
   Every variant MUST number its procedural steps using a FLAT sequential \
scheme: Step 1, Step 2, Step 3, ... Step {step_count}. Use the format \
"Step N." or "N." at the start of each procedural step.
   Do NOT use hierarchical numbering (e.g. 1.1, 1.2, 2.1), do NOT use \
section-based numbering (e.g. Phase 1 Step 1), do NOT restart numbering \
within sections. The numbers must run consecutively from 1 to {step_count}.
   Format E may group steps under stage headings, but the step numbers must \
still run sequentially 1 through {step_count} (e.g. "Stage: Preparation" \
followed by "Step 1. ..." "Step 2. ..." then "Stage: Assembly" followed \
by "Step 3. ..." etc.)
   Format B may use narrative paragraphs but must clearly mark each \
procedural action with "Step N." numbering.

3. WRITING STYLE VARIATION (simulate {num_variants} different authors writing \
the SAME protocol)
   For each variant, randomly assign and apply a combination of:
   • Career stage: grad student (verbose, over-explains every step) / \
postdoc (balanced, confident) / senior PI (terse, assumes reader knowledge) / \
industry scientist (SOP-style, very precise and standardized)
   • Jargon density: some spell out full reagent names, others abbreviate \
aggressively (e.g. "phosphate-buffered saline" vs "PBS")
   • Detail in descriptions: some add context/rationale for each step \
("this ensures complete lysis"), others state only the action ("lyse the cells")
   • Hedging language: some say "we found that X works best", others state \
flatly "Use X"; some add "approximately", others give exact values only
   • Connector style: "Next," / "Subsequently," / "Then" / "Following this," / \
numbered without connectors / no transitions at all
   • Measurement notation: µL vs μl vs uL; °C vs "degrees Celsius"; \
"room temperature" vs "RT" vs "22-25°C"
   • Voice: active ("Add 5 µL") vs passive ("5 µL is added") vs imperative \
("The solution should be mixed")
   • Title phrasing: some use "A protocol for...", others "Step-by-step guide \
to...", others just name the technique directly
   • Materials list style: some give catalog numbers, others say "commercially \
available"; some group by type, others list alphabetically
   • Occasional imperfections (apply to ≤3 variants):
     - A slightly awkward but grammatically correct sentence
     - An unnecessary parenthetical clarification
     - A step that's slightly more detailed than its neighbors
     - Inconsistent use of "we" vs passive voice within the same protocol
     - Minor inconsistency in abbreviation (spelling out a term after \
previously abbreviating it)

4. EACH VARIANT MUST INCLUDE ALL OF:
   • Title (8-25 words, varied phrasing but describing the SAME protocol)
   • Brief introduction/objective (2-4 sentences)
   • Materials/reagents list (5-15 items — same reagents, different listing style)
   • Step-by-step procedure (EXACTLY {step_count} steps — same steps, different wording)
   • Expected results (1-3 sentences)
   • At least one timing annotation

5. MUTUAL DISTINCTIVENESS
   • No two variants should share more than 3 consecutive sentences of \
identical wording
   • Each variant should read as if written by a different person
   • Despite different wording, a reader should recognize all variants as \
describing the same experiment

━━━ OUTPUT FORMAT ━━━

Return a JSON array of exactly {num_variants} objects:

[
  {{
    "variant_id": 1,
    "persona": "<brief description, e.g. 'junior postdoc, genetics lab'>",
    "format_type": "<A/B/C/D/E/F>",
    "style_notes": "<what makes this variant's writing distinctive, e.g. \
'verbose with full reagent names, passive voice, adds rationale for each step'>",
    "title": "<variant protocol title>",
    "protocol_text": "<the full 1200-2000 word protocol — MUST exceed 1200 words \
and contain EXACTLY {step_count} procedural steps>"
  }},
  ...
]

Return ONLY the JSON array. No markdown fences, no commentary."""


def build_expand_prompt(digest_json: str, num_variants: int = 10, step_count: int | None = None) -> list[dict]:
    """Build expand prompt with step count enforcement.

    If step_count is None, it's extracted from the digest JSON.
    """
    if step_count is None:
        digest = json.loads(digest_json)
        steps = digest.get("steps", [])
        step_count = len(steps) if isinstance(steps, list) else 0

    return [
        {"role": "system", "content": EXPAND_SYSTEM},
        {"role": "user", "content": EXPAND_USER_TEMPLATE.format(
            digest_json=digest_json,
            num_variants=num_variants,
            step_count=step_count,
        )},
    ]
