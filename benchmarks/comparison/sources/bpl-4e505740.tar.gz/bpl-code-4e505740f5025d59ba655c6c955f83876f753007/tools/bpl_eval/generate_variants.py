#!/usr/bin/env python3
"""
Generate variants with step-count enforcement.

Reads existing digests and generates variants that preserve the digest step
count exactly.

Usage:
    python generate_variants.py --test
    python generate_variants.py --test-n 3
    python generate_variants.py --resume
    python generate_variants.py --limit 300
    python generate_variants.py --merge
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import sys
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)
_PROJECT_ROOT = os.path.normpath(os.path.join(_BASE, "..", ".."))
load_dotenv(os.path.join(_PROJECT_ROOT, ".env"))

from config import (  # noqa: E402
    MODELS,
    VARIANTS_PER_PAPER,
    DIGEST_SOURCE_DIR,
    VARIANT_OUTPUT_DIR,
    CHECKPOINT_FILE,
)
from llm_client import parse_json_response, call_llm  # noqa: E402
from prompts import build_expand_prompt  # noqa: E402


# ──────────────────────────────────────────────────────────────
# Checkpoint
# ──────────────────────────────────────────────────────────────

def load_checkpoint() -> dict[str, Any]:
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE, encoding='utf-8') as f:
            return json.load(f)
    return {}


def save_checkpoint(ckpt: dict):
    with open(CHECKPOINT_FILE, 'w', encoding='utf-8') as f:
        json.dump(ckpt, f, ensure_ascii=False)


# ──────────────────────────────────────────────────────────────
# Source discovery
# ──────────────────────────────────────────────────────────────

def discover_papers(digest_dir: str = DIGEST_SOURCE_DIR) -> list[tuple[str, str, dict, int]]:
    """Find all papers in the digest directory.

    Returns list of (json_path, paper_name, digest, step_count).
    """
    papers = []
    for f in sorted(Path(digest_dir).glob("*.json")):
        if f.name.startswith(("_", ".")):
            continue
        try:
            with open(f, encoding='utf-8') as fh:
                data = json.load(fh)
            digest = data.get("digest", data)
            # Handle both formats: {"steps": [...]} and bare [...]
            if isinstance(digest, list):
                steps = digest
                digest = {"steps": digest}
            elif isinstance(digest, dict):
                steps = digest.get("steps", [])
            else:
                continue
            if not isinstance(steps, list) or len(steps) == 0:
                continue
            step_count = len(steps)
            paper_name = f.stem
            papers.append((str(f), paper_name, digest, step_count))
        except (json.JSONDecodeError, OSError):
            continue
    return papers


# ──────────────────────────────────────────────────────────────
# Expand with step count enforcement
# ──────────────────────────────────────────────────────────────

async def expand_single(
    client: httpx.AsyncClient,
    digest: dict,
    model: str,
    num_variants: int,
    step_count: int,
) -> list[dict]:
    """Call one model to generate N step-count-enforced variants."""
    digest_str = json.dumps(digest, ensure_ascii=False, indent=2)
    messages = build_expand_prompt(digest_str, num_variants=num_variants, step_count=step_count)
    temperature = round(random.uniform(0.85, 1.1), 2)

    print(f"    [B] {model.split('/')[-1]} → {num_variants} variants "
          f"(temp={temperature}, steps={step_count})...")
    max_tok = min(num_variants * 4000, 32000)
    raw = await call_llm(client, messages, model, temperature, max_tokens=max_tok)
    variants = parse_json_response(raw)

    if isinstance(variants, list):
        for v in variants:
            if isinstance(v, dict):
                v["generated_by"] = model
        # Filter out refusals / truncated responses (< 500 chars)
        valid = [
            v for v in variants
            if isinstance(v, dict) and len(v.get("protocol_text", "")) >= 500
        ]
        if len(valid) < len([v for v in variants if isinstance(v, dict)]):
            dropped = len([v for v in variants if isinstance(v, dict)]) - len(valid)
            print(f"    ⚠ Dropped {dropped} variant(s) with <500 char protocol_text (likely refusals)")
        return valid
    raise ValueError(f"Expected JSON array, got {type(variants)}")


async def expand_multi_model(
    client: httpx.AsyncClient,
    digest: dict,
    step_count: int,
) -> list[dict]:
    """Split 10 variants across ALL models and run concurrently."""
    n_models = len(MODELS)
    base_count = VARIANTS_PER_PAPER // n_models
    remainder = VARIANTS_PER_PAPER % n_models
    splits = []
    for i, model in enumerate(MODELS):
        n = base_count + (1 if i < remainder else 0)
        if n > 0:
            splits.append((model, n))

    label = " + ".join(f"{m.split('/')[-1]}×{n}" for m, n in splits)
    print(f"    [B] Multi-model expand: {label} (enforcing {step_count} steps)")

    tasks = [
        expand_single(client, digest, model, n, step_count)
        for model, n in splits
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    all_variants = []
    for (model, n), result in zip(splits, results):
        if isinstance(result, Exception):
            print(f"    ⚠ {model.split('/')[-1]} failed: {result}")
            continue
        all_variants.extend(result)

    if not all_variants:
        raise ValueError("All models failed in expand stage")

    for i, v in enumerate(all_variants):
        v["variant_id"] = i + 1

    return all_variants


# ──────────────────────────────────────────────────────────────
# Per-paper pipeline
# ──────────────────────────────────────────────────────────────

async def process_paper(
    client: httpx.AsyncClient,
    json_path: str,
    paper_name: str,
    digest: dict,
    step_count: int,
    paper_idx: int,
    ckpt: dict,
    lock: asyncio.Lock,
) -> dict | None:
    print(f"\n  📄 [{paper_idx}] {paper_name[:70]}... ({step_count} digest steps)")

    # Check checkpoint
    if paper_name in ckpt and ckpt[paper_name].get("done"):
        print("    ✓ Already done (cached)")
        return ckpt[paper_name].get("result")

    try:
        variants = await expand_multi_model(client, digest, step_count)
    except Exception as e:
        print(f"    ✗ Expand failed: {e}")
        return None

    # Read original source to preserve metadata
    with open(json_path, encoding='utf-8') as f:
        original = json.load(f)

    result = {
        "source_title": original.get("source_title", paper_name),
        "digest_model": original.get("digest_model", "unknown"),
        "expand_models": [m for m in MODELS],
        "digest": digest,
        "variants": variants,
        "num_variants": len(variants),
        "generation_method": "step_count_enforced",
    }

    # Save individual result
    out_path = os.path.join(VARIANT_OUTPUT_DIR, f"{paper_name}.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # Update checkpoint
    async with lock:
        ckpt[paper_name] = {"done": True}
        save_checkpoint(ckpt)

    n = len(variants)
    avg_words = sum(len(v.get("protocol_text", "").split()) for v in variants) // max(n, 1)
    print(f"    ✓ [{paper_idx}] Generated {n} variants (avg ~{avg_words} words, "
          f"target {step_count} steps each)")

    return result


# ──────────────────────────────────────────────────────────────
# Main orchestration
# ──────────────────────────────────────────────────────────────

async def run(
    papers: list[tuple[str, str, dict, int]],
    resume: bool = False,
    batch_size: int = 5,
):
    os.makedirs(VARIANT_OUTPUT_DIR, exist_ok=True)
    ckpt = load_checkpoint() if resume else {}

    if resume:
        todo = [(p, n, d, s) for p, n, d, s in papers if not ckpt.get(n, {}).get("done")]
    else:
        todo = papers

    total = len(papers)
    already = total - len(todo)
    if already > 0:
        print(f"✓ {already}/{total} already done, {len(todo)} remaining\n")

    success = 0
    failed = 0
    lock = asyncio.Lock()

    async def _process_one(client, json_path, paper_name, digest, step_count, idx):
        nonlocal success, failed
        result = await process_paper(
            client, json_path, paper_name, digest, step_count, idx, ckpt, lock,
        )
        async with lock:
            if result:
                success += 1
            else:
                failed += 1

    async with httpx.AsyncClient() as client:
        for batch_start in range(0, len(todo), batch_size):
            batch = todo[batch_start : batch_start + batch_size]
            batch_num = batch_start // batch_size + 1
            total_batches = (len(todo) + batch_size - 1) // batch_size

            print(f"\n── Batch {batch_num}/{total_batches} ({len(batch)} papers) ──")

            tasks = []
            for i, (json_path, paper_name, digest, step_count) in enumerate(batch):
                global_idx = already + batch_start + i + 1
                tasks.append(_process_one(
                    client, json_path, paper_name, digest, step_count, global_idx,
                ))

            await asyncio.gather(*tasks, return_exceptions=True)

    print(f"\n{'='*50}")
    print(f"Done! {success} succeeded, {failed} failed out of {len(todo)}")
    print(f"Total completed: {already + success}/{total}")
    print(f"Output directory: {VARIANT_OUTPUT_DIR}/")


# ──────────────────────────────────────────────────────────────
# Backfill: retry papers with <10 variants
# ──────────────────────────────────────────────────────────────

def find_incomplete_papers(
    papers: list[tuple[str, str, dict, int]],
) -> list[tuple[str, str, dict, int, dict]]:
    """Find papers with fewer than the target number of variants."""
    incomplete = []
    for json_path, paper_name, digest, step_count in papers:
        variant_path = os.path.join(VARIANT_OUTPUT_DIR, f"{paper_name}.json")
        if not os.path.exists(variant_path):
            continue
        with open(variant_path, encoding='utf-8') as f:
            data = json.load(f)
        variants = data.get("variants", [])
        if len(variants) >= VARIANTS_PER_PAPER:
            continue
        # Count existing variants per model
        existing_by_model = {}
        for v in variants:
            model = v.get("generated_by", "unknown")
            existing_by_model[model] = existing_by_model.get(model, 0) + 1
        incomplete.append((json_path, paper_name, digest, step_count, existing_by_model))
    return incomplete


async def backfill_paper(
    client: httpx.AsyncClient,
    json_path: str,
    paper_name: str,
    digest: dict,
    step_count: int,
    existing_by_model: dict,
    paper_idx: int,
) -> bool:
    """Generate only the missing variants for a paper."""
    # Determine target per model
    n_models = len(MODELS)
    base_count = VARIANTS_PER_PAPER // n_models
    remainder = VARIANTS_PER_PAPER % n_models
    targets = {}
    for i, model in enumerate(MODELS):
        targets[model] = base_count + (1 if i < remainder else 0)

    # Calculate what's needed
    needed = []
    for model in MODELS:
        target = targets[model]
        have = existing_by_model.get(model, 0)
        need = target - have
        if need > 0:
            needed.append((model, need))

    if not needed:
        return True

    total_existing = sum(existing_by_model.values())
    label = ", ".join(f"{m.split('/')[-1]}×{n}" for m, n in needed)
    print(f"\n  📄 [{paper_idx}] {paper_name[:70]}... "
          f"({total_existing}/10 have, need: {label})")

    tasks = [
        expand_single(client, digest, model, n, step_count)
        for model, n in needed
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    new_variants = []
    failed_counts = []  # (model, count) pairs that failed
    for (model, n), result in zip(needed, results):
        if isinstance(result, Exception):
            print(f"    ⚠ {model.split('/')[-1]} failed: {result}")
            failed_counts.append((model, n))
            continue
        new_variants.extend(result)

    # Fallback: retry failed counts with other models
    if failed_counts:
        total_still_needed = sum(n for _, n in failed_counts)
        failed_models = {m for m, _ in failed_counts}
        # Pick fallback models (ones that didn't fail)
        fallback_models = [m for m in MODELS if m not in failed_models]
        if not fallback_models:
            # All models failed — try each one individually as last resort
            fallback_models = list(MODELS)

        if fallback_models and total_still_needed > 0:
            print(f"    ↻ Retrying {total_still_needed} variants with fallback models...")
            # Distribute across available fallback models
            fb_tasks = []
            remaining = total_still_needed
            for i, fb_model in enumerate(fallback_models):
                n = remaining // (len(fallback_models) - i)
                remaining -= n
                if n > 0:
                    fb_tasks.append((fb_model, n))

            fb_coros = [
                expand_single(client, digest, model, n, step_count)
                for model, n in fb_tasks
            ]
            fb_results = await asyncio.gather(*fb_coros, return_exceptions=True)

            for (model, n), result in zip(fb_tasks, fb_results):
                if isinstance(result, Exception):
                    print(f"    ⚠ fallback {model.split('/')[-1]} also failed: {result}")
                    continue
                new_variants.extend(result)

    if not new_variants:
        print("    ✗ All backfill attempts failed (including fallbacks)")
        return False

    # Load existing, append new, re-number, save
    variant_path = os.path.join(VARIANT_OUTPUT_DIR, f"{paper_name}.json")
    with open(variant_path, encoding='utf-8') as f:
        data = json.load(f)

    data["variants"].extend(new_variants)
    for i, v in enumerate(data["variants"]):
        v["variant_id"] = i + 1
    data["num_variants"] = len(data["variants"])

    with open(variant_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"    ✓ [{paper_idx}] Now {len(data['variants'])}/10 variants")
    return True


async def run_backfill(
    papers: list[tuple[str, str, dict, int]],
    batch_size: int = 5,
):
    incomplete = find_incomplete_papers(papers)
    if not incomplete:
        print("All papers already have 10 variants!")
        return

    total_missing = sum(
        VARIANTS_PER_PAPER - sum(existing.values())
        for _, _, _, _, existing in incomplete
    )
    print(f"Found {len(incomplete)} papers with <10 variants ({total_missing} variants to generate)\n")

    success = 0
    failed = 0

    async with httpx.AsyncClient() as client:
        for batch_start in range(0, len(incomplete), batch_size):
            batch = incomplete[batch_start : batch_start + batch_size]
            batch_num = batch_start // batch_size + 1
            total_batches = (len(incomplete) + batch_size - 1) // batch_size

            print(f"\n── Backfill Batch {batch_num}/{total_batches} ({len(batch)} papers) ──")

            tasks = [
                backfill_paper(
                    client, json_path, paper_name, digest, step_count,
                    existing, batch_start + i + 1,
                )
                for i, (json_path, paper_name, digest, step_count, existing) in enumerate(batch)
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for r in results:
                if isinstance(r, Exception) or r is False:
                    failed += 1
                else:
                    success += 1

    print(f"\n{'='*50}")
    print(f"Backfill done! {success} succeeded, {failed} failed out of {len(incomplete)}")


def merge_outputs():
    all_results = []
    for f in sorted(Path(VARIANT_OUTPUT_DIR).glob("*.json")):
        if f.name.startswith("_"):
            continue
        with open(f, encoding='utf-8') as fh:
            all_results.append(json.load(fh))

    out = os.path.join(VARIANT_OUTPUT_DIR, "_all_variants.json")
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)

    total_variants = sum(len(r.get("variants", [])) for r in all_results)
    total_words = sum(
        len(v.get("protocol_text", "").split())
        for r in all_results for v in r.get("variants", [])
    )
    print(f"\nMerged {len(all_results)} papers → {total_variants} variant protocols")
    print(f"Total word count: ~{total_words:,}")
    print(f"Saved to: {out}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate variants with step-count enforcement"
    )
    parser.add_argument("--test", action="store_true", help="Test with 1 paper")
    parser.add_argument("--test-n", type=int, default=1, help="Number of papers to test")
    parser.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    parser.add_argument("--merge", action="store_true", help="Merge all outputs")
    parser.add_argument("--backfill", action="store_true", help="Retry papers with <10 variants")
    parser.add_argument("--batch", type=int, default=5, help="Concurrent papers (default 5)")
    parser.add_argument("--limit", type=int, default=300, help="Max papers (default 300)")
    args = parser.parse_args()

    if args.merge:
        merge_outputs()
        return

    papers = discover_papers()

    if args.backfill:
        print(f"Found {len(papers)} papers with valid digests in {DIGEST_SOURCE_DIR}/")
        print(f"Models: {MODELS}")
        print("Scanning generated variants for incomplete papers...\n")
        asyncio.run(run_backfill(papers, batch_size=args.batch))
        merge_outputs()
        return
    print(f"Found {len(papers)} papers with valid digests in {DIGEST_SOURCE_DIR}/")
    print(f"Models: {MODELS}")
    print(f"Output: {VARIANT_OUTPUT_DIR}/")

    if not papers:
        print(f"\n⚠ No papers with digests found in {DIGEST_SOURCE_DIR}/. Run generate_digests.py first!")
        sys.exit(1)

    # Step count stats
    step_counts = [s for _, _, _, s in papers]
    print(f"Step counts: min={min(step_counts)}, max={max(step_counts)}, "
          f"avg={sum(step_counts)/len(step_counts):.0f}")

    if args.test:
        papers = papers[:args.test_n]
        print(f"\n🧪 TEST MODE: {len(papers)} paper(s)\n")
    else:
        papers = papers[:args.limit]
        print(f"Processing: {len(papers)} papers (limit={args.limit})")
        print(f"Batch size: {args.batch} concurrent papers\n")

    asyncio.run(run(papers, resume=args.resume, batch_size=args.batch))

    if not args.test:
        merge_outputs()


if __name__ == "__main__":
    main()
