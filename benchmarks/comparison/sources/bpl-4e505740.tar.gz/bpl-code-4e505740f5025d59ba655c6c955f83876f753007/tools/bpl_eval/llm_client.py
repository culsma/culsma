"""OpenRouter helpers shared by the BPL evaluation scripts."""

from __future__ import annotations

import asyncio
import json
import os
import random
import re
import sys

import httpx

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

from config import (  # noqa: E402
    MAX_RETRIES,
    OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL,
    REQUEST_TIMEOUT,
    RETRY_DELAY,
)


def parse_json_response(text: str):
    """Extract JSON from an LLM response using direct parse and brace matching."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    for open_ch, close_ch in [("{", "}"), ("[", "]")]:
        start = text.find(open_ch)
        if start == -1:
            continue
        depth = 0
        in_string = False
        escape_next = False
        for idx in range(start, len(text)):
            ch = text[idx]
            if escape_next:
                escape_next = False
                continue
            if ch == "\\" and in_string:
                escape_next = True
                continue
            if ch == '"' and not escape_next:
                in_string = not in_string
                continue
            if in_string:
                continue
            if ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start : idx + 1])
                    except json.JSONDecodeError:
                        break

    raise ValueError(f"Could not parse JSON from response: {text[:300]}...")


async def call_llm(
    client: httpx.AsyncClient,
    messages: list[dict],
    model: str,
    temperature: float,
    max_tokens: int = 4096,
) -> str:
    """Call OpenRouter chat completions API with bounded retries."""
    if not OPENROUTER_API_KEY:
        raise RuntimeError("OPENROUTER_API_KEY is not set")

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "top_p": 0.95,
    }

    for attempt in range(MAX_RETRIES):
        try:
            resp = await client.post(
                f"{OPENROUTER_BASE_URL}/chat/completions",
                headers=headers,
                json=payload,
                timeout=REQUEST_TIMEOUT,
            )
            resp.raise_for_status()
            data = resp.json()
            if "error" in data:
                err_msg = data["error"].get("message", str(data["error"]))
                raise ValueError(f"API error: {err_msg}")
            content = data["choices"][0]["message"]["content"]
            if content is None:
                raise ValueError("API returned null content")
            return content
        except (httpx.HTTPStatusError, httpx.ReadTimeout, KeyError, ValueError) as e:
            if attempt < MAX_RETRIES - 1:
                wait = RETRY_DELAY * (2**attempt) + random.uniform(0, 1)
                print(f"    Retry {attempt + 1}/{MAX_RETRIES}: {e}")
                await asyncio.sleep(wait)
            else:
                raise
    # Unreachable: the final attempt either returns or re-raises.
    raise RuntimeError("call_llm exhausted retries without returning")
