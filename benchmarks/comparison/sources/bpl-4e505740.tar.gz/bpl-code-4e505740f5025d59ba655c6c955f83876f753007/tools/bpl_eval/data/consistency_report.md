# Variant Consistency Analysis

**Generated**: 2026-04-27T11:01:53.236469
**Papers Analyzed**: 301
**Method**: Regex-based step counting (no LLM)

## Overall Consistency

- Average step count range (max-min): **0.2**
- Average step count std dev: **0.1**
- Papers with step range <= 5: **298** / 301
- Papers with step range <= 2: **298** / 301
- Papers with step range = 0 (perfect): **296** / 301
- Papers with step range > 20: **1** / 301
- Average % variants matching digest step count: **99.4%**

## Per-Paper Step Count Analysis

| Paper | Digest | Mean | Min | Max | Range | Std | Match% | Variants |
|-------|---:|---:|---:|---:|---:|---:|---:|---:|
| Genome-wide piggyBac transposon-based mutagenesis and q | 21 | 17 | 0 | 21 | 21 | 8.1 | 80% | 10 |
| Purification of infection-associated macropinosomes by  | 24 | 22 | 4 | 24 | 20 | 7.1 | 70% | 10 |
| Detecting chromosomal interactions in Capture Hi-C data | 17 | 16 | 6 | 17 | 11 | 3.5 | 90% | 10 |
| Thioether-mediated protein ubiquitination in constructi | 16 | 16 | 16 | 18 | 2 | 0.6 | 90% | 10 |
| Visually guided in vivo single-cell electroporation for | 16 | 16 | 16 | 18 | 2 | 0.6 | 90% | 10 |
| 3D in vitro morphogenesis of human intestinal epitheliu | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| A bacterial three-hybrid assay for forward and reverse  | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| A bifunctional molecule-assisted synthesis of mimics fo | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| A bioswitchable delivery system for microRNA therapeuti | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| A comprehensive guide to dynamic analysis of microbial  | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| A comprehensive pipeline for translational top-down pro | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| A detailed guide to assessing genome assembly based on  | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| A dynamic DNA tetrahedron framework for active targetin | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| A graphic and command line protocol for quick and accur | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| A mass spectrometry workflow for measuring protein turn | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| A plate-based single-cell ATAC-seq workflow for fast an | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| A platform for whole-genome speed introgression from Ae | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| A quantitative thiol reactivity profiling platform to a | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| A scalable SCENIC workflow for single-cell gene regulat | 13 | 13 | 13 | 13 | 0 | 0.0 | 100% | 10 |
| A streamlined solution for processing_ elucidating and  | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| A systems-level mass spectrometry-based technique for a | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| A tripartite cell-free translation system to study mamm | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| A well plate-based multiplexed platform for incorporati | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| A whole-tissue RNA-seq toolkit for organism-wide studie | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Absolute quantification of prokaryotes in the microbiom | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| All-optical voltage imaging-guided postsynaptic single- | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| An accessible workflow for high-sensitivity proteomics  | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| An expanded CRISPR_Cas9-assisted recombineering toolkit | 17 | 17 | 17 | 17 | 0 | 0.0 | 80% | 10 |
| An inexpensive semi-automated sample processing pipelin | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| An optimized comet-based in vitro DNA repair assay to a | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| An unbiased method for evaluating the genome-wide speci | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Analysis framework and experimental design for evaluati | 30 | 30 | 30 | 30 | 0 | 0.0 | 100% | 10 |
| Analysis of combinatorial CRISPR screens with the Orthr | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Analysis pipelines for cancer genome sequencing in mice | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Analyzing somatic mutations by single-cell whole-genome | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Application of CHyMErA Cas9-Cas12a combinatorial genome | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Assembly and delivery of large DNA via chromosome elimi | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| BID-seq for transcriptome-wide quantitative sequencing  | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Bacterial genome engineering using CRISPR-associated tr | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Biolayer interferometry for measuring the kinetics of p | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Bioluminescence resonance energy transfer_based imaging | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Biomarker analysis from complex biofluids by an on-chip | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Biomimetic membrane in a microfluidic chip for the elec | 18 | 18 | 18 | 18 | 0 | 0.0 | 90% | 10 |
| BridGE_ a pathway-based analysis tool for detecting gen | 14 | 14 | 14 | 14 | 0 | 0.0 | 100% | 10 |
| CODEX multiplexed tissue imaging with DNA-conjugated an | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| CRISPR off-target detection with DISCOVER-seq | 30 | 30 | 30 | 30 | 0 | 0.0 | 100% | 10 |
| CRISPR somatic genome engineering and cancer modeling i | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| CRISPR-Combo_mediated orthogonal genome editing and tra | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| CRISPR-based engineering of gene knockout cells by homo | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| CRISPR_Cas9 genome engineering of primary CD4_ T cells  | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 11 |
| CRISPR_Cas9-mediated chromosome engineering in Arabidop | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| CRISPR_Cas9_ CRISPRi and CRISPR-BEST-mediated genetic m | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| CRISPRi-seq for genome-wide fitness quantification in b | 20 | 20 | 20 | 20 | 0 | 0.0 | 80% | 10 |
| Capture of the newly transcribed RNA interactome using  | 29 | 29 | 29 | 29 | 0 | 0.0 | 100% | 10 |
| Capture-C_ a modular and flexible approach for high-res | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Capturing 5_ and 3_ native ends of mRNAs concurrently w | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Carbon nanotube_mediated DNA delivery without transgene | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Cell-type-specific metabolic labeling_ detection and id | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| CellChat for systematic analysis of cell_cell communica | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Cellular thermal shift assay for the identification of  | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Characterizing the structure of mouse behavior using Mo | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| ChromEMT_ visualizing and reconstructing chromatin ultr | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Chromatin accessibility profiling by ATAC-seq | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Chromatin integration labeling for mapping DNA-binding  | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Chromatin tracing and multiplexed imaging of nucleome a | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Circular Vectors as an efficient_ fully synthetic_ cell | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Clonal tracking using embedded viral barcoding and high | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Cloning of ground-state intestinal stem cells from endo | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Combined proximity labeling and affinity purification_m | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Combined whole-mount fluorescence in situ hybridization | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Complex-centric proteome profiling by SEC-SWATH-MS for  | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Construction and utilization of a new generation of bac | 25 | 25 | 25 | 25 | 0 | 0.0 | 70% | 10 |
| Construction of RNA reference materials for improving t | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Control of DNA replication in vitro using a reversible  | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Creating CRISPR-responsive smart materials for diagnost | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Creating functional chromosome fusions in yeast with CR | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Creation of CRISPR-based germline-genome-engineered mic | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Culture and analysis of kidney tubuloids and perfused t | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Cytosine and adenosine base editing in human pluripoten | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| DNA copy-number measurement of genome replication dynam | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Defining genome-wide CRISPR_Cas genome-editing nuclease | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Design and application of the transformer base editor i | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Design and simulation of DNA_ RNA and hybrid protein_nu | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Design_ assembly_ and characterization of membrane-span | 30 | 30 | 30 | 30 | 0 | 0.0 | 100% | 10 |
| Design_ execution_ and analysis of CRISPR_Cas9-based de | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Design_ fabrication and applications of tetrahedral DNA | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Design_ performance_ processing_ and validation of a po | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Designer DNA nanostructures for viral inhibition | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Designing and executing prime editing experiments in ma | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Detect-seq_ a chemical labeling and biotin pull-down ap | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Detection and quantification of RNA decay intermediates | 29 | 29 | 29 | 29 | 0 | 0.0 | 100% | 10 |
| Detection of aberrant gene expression events in RNA seq | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Determining chromatin architecture with Micro Capture-C | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Development of RNA G-quadruplex _rG4_-targeting L-RNA a | 29 | 29 | 29 | 29 | 0 | 0.0 | 100% | 10 |
| Differential viral accessibility _DIVA_ identifies alte | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Direct and quantitative analysis of tRNA acylation usin | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Direct and simultaneous observation of transcription an | 29 | 29 | 29 | 29 | 0 | 0.0 | 100% | 10 |
| Diselenide_selenoester ligation for chemical protein sy | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Droplet-based functional CRISPR screening of cell_cell  | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Dual detection of chromatin accessibility and DNA methy | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Efficient and safe single-cell cloning of human pluripo | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Efficient and strand-specific profiling of replicating  | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Efficient low-cost chromatin profiling with CUT_Tag | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Efficient recovery of the RNA-bound proteome and protei | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Electro-elution-based purification of covalent DNA_prot | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Engineering DNA nanostructures for siRNA delivery in pl | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Engineering megabase-sized genomic deletions with MACHE | 22 | 22 | 22 | 22 | 0 | 0.0 | 90% | 10 |
| Engineering_ delivery_ and biological validation of art | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Enzyme-free targeted DNA demethylation using CRISPR_dCa | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| EpiTyping_ analysis of epigenetic aberrations in parent | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Establishment of human fetal hepatocyte organoids and C | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Extraction of nuclei from archived postmortem tissues f | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| FIND-seq_ high-throughput nucleic acid cytometry for ra | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| FLEP-seq_ simultaneous detection of RNA polymerase II p | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Fabrication and practical applications of molybdenum di | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| FiTAc-seq_ fixed-tissue ChIP-seq for H3K27ac profiling  | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Formaldehyde-assisted isolation of regulatory DNA eleme | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Full-length circular RNA profiling by nanopore sequenci | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Full-length sequencing of circular DNA viruses and extr | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Functionalized tetrahedral DNA frameworks for the captu | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| GLORI for absolute quantification of transcriptome-wide | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| GOTI_ a method to identify genome-wide off-target effec | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| GRID-seq for comprehensive analysis of global RNA_chrom | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Generation of CRISPR_Cas9-mediated genetic knockout hum | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Generation of human fetal brain organoids and their CRI | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Genome-wide analysis of the biophysical properties of c | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Genome-wide and sister chromatid-resolved profiling of  | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Genome-wide detection of DNA double-strand breaks by in | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Genome-wide mapping of nucleotide excision repair with  | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Genome-wide measurement of DNA replication fork directi | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Genome-wide pooled CRISPR screening in neurospheres | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| Genome-wide profiling of nucleosome position and chroma | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Genome-wide quantification of transcription factor bind | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Global analysis of RNA-binding protein dynamics by comp | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Global analysis of repetitive DNA from unassembled sequ | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Global in situ profiling of RNA-RNA spatial interaction | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Global mapping of RNA G-quadruplexes _G4-RNAs_ using G4 | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| HT-smFISH_ a cost-effective and flexible workflow for h | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Hi-CO_ 3D genome structure analysis with nucleosome res | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| High-quality and robust protein quantification in large | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| High-resolution_ strand-specific R-loop mapping via S9_ | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| High-resolution_ ultrasensitive and quantitative DNA do | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| High-throughput full-length single-cell RNA-seq automat | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| High-throughput identification and quantification of ba | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| High-throughput proteomic sample preparation using pres | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| High-throughput single-cell transcriptomics of bacteria | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Honey bee functional genomics using symbiont-mediated R | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| How to isolate channel-forming membrane proteins using  | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Human induced pluripotent stem cell-derived cardiomyocy | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Hybridization chain reaction-based DNA nanoframeworks f | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| INVADEseq to identify cell-adherent or invasive bacteri | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Identification of cancer-related mutations in human plu | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Identification of immunogenic commensal antigens using  | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Identification_ assembly and characterization of tumor  | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Identification_ quantification and bioinformatic analys | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Identifying genome-wide off-target sites of CRISPR RNA_ | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Identifying high-confidence capture Hi-C interactions u | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Identifying statistically significant chromatin contact | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Improved high-molecular-weight DNA extraction_ nanopore | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Integrative analysis of pooled CRISPR genetic screens u | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Investigating RNA editing in deep transcriptome dataset | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Isoform-specific RNA structure determination using Nano | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Isolating the human cochlea to generate bone powder for | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Isotope-dilution mass spectrometry for exact quantifica | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| KAS-seq_ genome-wide sequencing of single-stranded DNA  | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Large-scale F0 CRISPR screens in vivo using MIC-Drop | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Lineage barcoding in mice with homing CRISPR | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Linking single-cell transcriptomes with secretion using | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Long-read RNA sequencing of transposable elements from  | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Luciferase- and HaloTag-based reporter assays to measur | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| MARS-seq2_0_ an experimental and analytical pipeline fo | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| MOWChIP-seq for low-input and multiplexed profiling of  | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Machine learning workflows to estimate class probabilit | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Manipulating gene translation in plants by CRISPR_Cas9- | 26 | 26 | 26 | 26 | 0 | 0.0 | 90% | 10 |
| Manipulating the hydrophobicity of DNA as a universal s | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Manual and automated preparation of single-stranded DNA | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Manufacturing of CRISPR-edited primary mouse CAR T cell | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Mapping RNA_chromatin interactions by sequencing with i | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Mapping T cell dynamics to molecular profiles through b | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Mapping protein_DNA interactions with DiMeLo-seq | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Mapping protein_RNA binding in plants with individual-n | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Mapping replication timing domains genome wide in singl | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Mapping ribonucleotides embedded in genomic DNA to sing | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Massively parallel sample preparation for multiplexed s | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Measurement of differential chromatin interactions with | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Measuring DNA modifications with the comet assay_ a com | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Metagenome analysis using the Kraken software suite | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Metagenome-assembled genome extraction and analysis fro | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Mitochondrial single-cell ATAC-seq for high-throughput  | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Molecular recording using DNA Typewriter | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Monitoring genome-wide replication fork directionality  | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Multi-contact 4C_ long-molecule sequencing of complex p | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Multigenerational laboratory culture of pelagic ctenoph | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Multimodal detection of protein isoforms and nucleic ac | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Multiparameter screening method for developing optimize | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Multiplexed bioluminescence-mediated tracking of DNA do | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Multiplexed chromatin immunoprecipitation sequencing fo | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Multiplexed single-cell proteomics using SCoPE2 | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Mutate-and-chemical-shift-fingerprint _MCSF_ to charact | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| NAD tagSeq for transcriptome-wide identification and ch | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Nano-CUT_Tag for multimodal chromatin profiling at sing | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Nano3P-seq_ charting the coding and noncoding transcrip | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| NovoSpaRc_ flexible spatial reconstruction of single-ce | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| OCTAD_ an open workspace for virtually screening therap | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| On-chip 3D neuromuscular model for drug screening and p | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| On-chip electrocatalytic microdevices | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Optimized prime editing in monocot plants using PlantPe | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Optimized single-nucleus transcriptional profiling by c | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Optimized whole-genome sequencing workflow for tumor di | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| PEPPI-MS_ gel-based sample pre-fractionation for deep t | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| PepSeq_ a fully in vitro platform for highly multiplexe | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Peptide-enabled ribonucleoprotein delivery for CRISPR e | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Plant sperm cell sequencing for genome phasing and dete | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Preamplification-free viral RNA diagnostics with single | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Precise genome engineering in Pseudomonas using phage-e | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Precise mutagenesis in zebrafish using cytosine base ed | 31 | 31 | 31 | 31 | 0 | 0.0 | 100% | 10 |
| Precision genome editing using cytosine and adenine bas | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Preparation of selective organ-targeting _SORT_ lipid n | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| ProBac-seq_ a bacterial single-cell RNA sequencing meth | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Profiling human brain vascular cells using single-cell  | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Protein transfection via spherical nucleic acids | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Proteome-wide analysis of protein lipidation using chem | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Proteome-wide structural changes measured with limited  | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Proximity sequencing for the detection of mRNA_ extrace | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| Purification of mammalian telomeric DNA for single-mole | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Purification_ full-length sequencing and genomic origin | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Quantification of mRNA translation in live cells using  | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Quantification of organelle contact sites by split-GFP- | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Quantifying genome-wide transcription factor binding af | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Quantitative nucleotide resolution profiling of RNA cyt | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| RASER-FISH_ non-denaturing fluorescence in situ hybridi | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| RNA sample optimization for cryo-EM analysis | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| RNA-extraction-free nano-amplified colorimetric test fo | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Rapid _30-second__ equipment-free purification of nucle | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Rapid generation of homozygous fluorescent knock-in hum | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Rapid in situ identification of biological specimens vi | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Rapid ordering of barcoded transposon insertion librari | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Reading and writing digital data in DNA | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Recombinant extracellular vesicles as biological refere | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Reconstructing phylogenetic trees from genome-wide soma | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Recording transcriptional histories using Record-seq | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Recovering prokaryotic genomes from host-associated_ sh | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Reference-free deconvolution_ visualization and interpr | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Reliable detection of somatic mutations in solid tissue | 16 | 16 | 16 | 16 | 0 | 0.0 | 100% | 10 |
| Revealing nascent RNA processing dynamics with nano-COP | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Rolling circle amplification _RCA_-based DNA hydrogel | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| SPRITE_ a genome-wide method for mapping higher-order 3 | 19 | 19 | 19 | 19 | 0 | 0.0 | 100% | 10 |
| Scalable characterization of the PAM requirements of CR | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |
| Scalable dual-omics profiling with single-nucleus chrom | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Scalable single-cell profiling of chromatin modificatio | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Scaling up reproducible research for single-cell transc | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Scanorama_ integrating large and diverse single-cell tr | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Screening circular RNAs with functional potential using | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Seamless site-directed mutagenesis in complex cloned DN | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Seed amplification assay for the detection of pathologi | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Selective isolation of large segments from individual m | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Seq-Scope_ repurposing Illumina sequencing flow cells f | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Sialic acid aptamer and RNA in situ hybridization-media | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Simple and reliable detection of CRISPR-induced on-targ | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Simple_ efficient and thorough shotgun proteomic analys | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Simultaneous quantification of protein_DNA interactions | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Simultaneously measuring the methylation of parent and  | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Single microorganism RNA sequencing of microbiomes usin | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Single-cell RNA and protein profiling of immune cells f | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Single-cell RNA-seq of maize meiocytes and pollen grain | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| Single-molecule magnetic tweezers to probe the equilibr | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Single-molecule parallel analysis for rapid exploration | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Single-nucleus total RNA sequencing of formalin-fixed p | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Sister chromatid_sensitive Hi-C to map the conformation | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Smart-RRBS for single-cell methylome and transcriptome  | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Solid-phase DNA-encoded library synthesis_ a master bui | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Solid-state nanopore fabrication by automated controlle | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Sonication-assisted protein extraction improves proteom | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| SorTn-seq_ a high-throughput functional genomics approa | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Spatially resolved analysis of FFPE tissue proteomes by | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| Spatially resolved epigenome sequencing via Tn5 transpo | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Spatially resolved genome-wide joint profiling of epige | 15 | 15 | 15 | 15 | 0 | 0.0 | 100% | 10 |
| Spatiotemporal control of RNA metabolism and CRISPR_Cas | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Structure-guided AAV capsid evolution strategies for en | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| SubCellBarCode_ integrated workflow for robust spatial  | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Superresolution imaging of chromatin fibers to visualiz | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Synthesis and use of an amphiphilic dendrimer for siRNA | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| Synthesis of siRNA nanoparticles to silence plaque-dest | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Temporally resolved transcriptional recording in E_ col | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| The GFP thermal shift assay for screening ligand and li | 23 | 23 | 23 | 23 | 0 | 0.0 | 100% | 10 |
| The Nodewalk assay to quantitate chromatin fiber intera | 20 | 20 | 20 | 20 | 0 | 0.0 | 100% | 10 |
| The design_ manufacture and LNP formulation of mRNA for | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| The use of sonicated lipid vesicles for mass spectromet | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Three-dimensional human neural culture on a chip recapi | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Tracing DNA paths and RNA profiles in cultured cells an | 17 | 17 | 17 | 17 | 0 | 0.0 | 100% | 10 |
| Tracking endocytosis and intracellular distribution of  | 21 | 21 | 21 | 21 | 0 | 0.0 | 100% | 10 |
| Transcription factor chromatin profiling genome-wide us | 26 | 26 | 26 | 26 | 0 | 0.0 | 100% | 10 |
| Transcriptome-wide identification of RNA-binding protei | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Transcriptome-wide measurement of poly_A_ tail length a | 18 | 18 | 18 | 18 | 0 | 0.0 | 100% | 10 |
| Unraveling cell_cell communication with NicheNet by inf | 28 | 28 | 28 | 28 | 0 | 0.0 | 100% | 10 |
| Use of human peripheral blood mononuclear cells to defi | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Using TTchem-seq for profiling nascent transcription an | 25 | 25 | 25 | 25 | 0 | 0.0 | 100% | 10 |
| Viral crosslinking and solid-phase purification enables | 22 | 22 | 22 | 22 | 0 | 0.0 | 100% | 10 |
| Visualizing epigenetic modifications and their spatial  | 24 | 24 | 24 | 24 | 0 | 0.0 | 100% | 10 |
| cfSNV_ a software tool for the sensitive detection of s | 11 | 11 | 11 | 11 | 0 | 0.0 | 100% | 10 |
| lentiMPRA and MPRAflow for high-throughput functional c | 27 | 27 | 27 | 27 | 0 | 0.0 | 100% | 10 |

## Top 10 Highest Range Papers

- **Genome-wide piggyBac transposon-based mutagenesis and quanti**: digest=21, counts=[21, 21, 21, 21, 21, 21, 21, 4, 0, 21], range=21
- **Purification of infection-associated macropinosomes by magne**: digest=24, counts=[24, 24, 24, 24, 4, 24, 24, 24], range=20
- **Detecting chromosomal interactions in Capture Hi-C data with**: digest=17, counts=[17, 17, 17, 17, 17, 17, 17, 17, 6, 17], range=11
- **Thioether-mediated protein ubiquitination in constructing af**: digest=16, counts=[16, 16, 16, 18, 16, 16, 16, 16, 16, 16], range=2
- **Visually guided in vivo single-cell electroporation for moni**: digest=16, counts=[16, 16, 16, 18, 16, 16, 16, 16, 16, 16], range=2
- **3D in vitro morphogenesis of human intestinal epithelium in **: digest=22, counts=[22, 22, 22, 22, 22, 22, 22, 22, 22, 22], range=0
- **A bacterial three-hybrid assay for forward and reverse genet**: digest=16, counts=[16, 16, 16, 16, 16, 16, 16, 16, 16, 16], range=0
- **A bifunctional molecule-assisted synthesis of mimics for use**: digest=24, counts=[24, 24, 24, 24, 24, 24, 24, 24, 24, 24], range=0
- **A bioswitchable delivery system for microRNA therapeutics ba**: digest=24, counts=[24, 24, 24, 24, 24, 24, 24, 24, 24, 24], range=0
- **A comprehensive guide to dynamic analysis of microbial gene **: digest=17, counts=[17, 17, 17, 17, 17, 17, 17, 17, 17, 17], range=0

## Top 10 Most Consistent Papers

- **3D in vitro morphogenesis of human intestinal epithelium in **: digest=22, counts=[22, 22, 22, 22, 22, 22, 22, 22, 22, 22], range=0
- **A bacterial three-hybrid assay for forward and reverse genet**: digest=16, counts=[16, 16, 16, 16, 16, 16, 16, 16, 16, 16], range=0
- **A bifunctional molecule-assisted synthesis of mimics for use**: digest=24, counts=[24, 24, 24, 24, 24, 24, 24, 24, 24, 24], range=0
- **A bioswitchable delivery system for microRNA therapeutics ba**: digest=24, counts=[24, 24, 24, 24, 24, 24, 24, 24, 24, 24], range=0
- **A comprehensive guide to dynamic analysis of microbial gene **: digest=17, counts=[17, 17, 17, 17, 17, 17, 17, 17, 17, 17], range=0
- **A comprehensive pipeline for translational top-down proteomi**: digest=21, counts=[21, 21, 21, 21, 21, 21, 21, 21, 21, 21], range=0
- **A detailed guide to assessing genome assembly based on long-**: digest=18, counts=[18, 18, 18, 18, 18, 18, 18, 18, 18, 18], range=0
- **A dynamic DNA tetrahedron framework for active targeting**: digest=17, counts=[17, 17, 17, 17, 17, 17, 17, 17, 17, 17], range=0
- **A graphic and command line protocol for quick and accurate c**: digest=22, counts=[22, 22, 22, 22, 22, 22, 22, 22, 22, 22], range=0
- **A mass spectrometry workflow for measuring protein turnover **: digest=20, counts=[20, 20, 20, 20, 20, 20, 20, 20, 20, 20], range=0