#!/usr/bin/env python3
"""Redraw BPL manuscript figures with one publication style system."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.axes import Axes

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import generate_figures as benchmark  # noqa: E402  (sys.path bootstrap above)
from figure_style_system import (  # noqa: E402  (sys.path bootstrap above)
    FIGURE_SIZES,
    FONT_SIZES,
    PALETTE,
    add_panel_label,
    apply_global_matplotlib_style,
    make_compact_legend,
    save_figure,
    style_axes,
)


OUT = SCRIPT_DIR / "figures" / "publication_redraw"
OUT.mkdir(parents=True, exist_ok=True)

FIG2_ARCH = {
    "bg": "#FFFFFF",
    "bg2": "#FFFFFF",
    "border": "#222222",
    "grid": "#D9D9D9",
    "text": "#2B2F33",
    "blue": "#6F97B3",
    "blue_light": "#DCE6F0",
    "green": "#7E9F69",
    "teal": "#6AA09C",
    "brown": "#A07828",
    "red": "#B87563",
    "amber": "#DCBE78",
}

FIG2_BAR_COLORS = {
    "natural_language": "#C97B4B",
    "processed_variants": "#4E88AE",
}


def _style_fig2_arch_axes(ax: Axes, grid: str = "y") -> None:
    ax.set_facecolor(PALETTE["white"])
    for spine in ax.spines.values():
        spine.set_visible(False)
        spine.set_linewidth(0.55)
        spine.set_color(FIG2_ARCH["border"])
    ax.spines["left"].set_visible(True)
    ax.spines["bottom"].set_visible(True)
    ax.spines["left"].set_color(PALETTE["gray_900"])
    ax.spines["bottom"].set_color(PALETTE["gray_900"])
    ax.spines["left"].set_linewidth(0.75)
    ax.spines["bottom"].set_linewidth(0.75)
    ax.tick_params(axis="both", width=0.55, length=2.0, pad=1.8, colors=FIG2_ARCH["text"])
    ax.xaxis.label.set_size(FONT_SIZES["small"])
    ax.yaxis.label.set_size(FONT_SIZES["small"])
    ax.title.set_size(FONT_SIZES["axis_label"])
    ax.title.set_color(FIG2_ARCH["text"])
    if grid == "none":
        ax.grid(False)
    elif grid == "both":
        ax.grid(True, axis="both", color=FIG2_ARCH["grid"], linewidth=0.45, alpha=0.55)
    else:
        ax.grid(True, axis=grid, color=FIG2_ARCH["grid"], linewidth=0.45, alpha=0.55)


def _fig2_tag(ax: Axes, text: str, xy: tuple[float, float] = (0.985, 0.985)) -> None:
    ax.text(
        xy[0],
        xy[1],
        text,
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=FONT_SIZES["small"],
        color=FIG2_ARCH["text"],
        bbox={
            "boxstyle": "round,pad=0.18,rounding_size=0.08",
            "facecolor": "#FFFFFF",
            "edgecolor": FIG2_ARCH["border"],
            "linewidth": 0.45,
            "alpha": 0.86,
        },
    )


def _flat_variants(papers: list[dict]) -> list[dict]:
    rows = []
    for paper in papers:
        for variant in paper.get("variants", []):
            if variant is None:
                continue
            rows.append(
                {
                    "overall": float(variant.get("overall_score", 0)),
                    "exp_match": float(variant.get("experiment_match", 0)),
                    "validity": float(variant.get("protocol_validity", 0)),
                    "phase": float(variant.get("phase_completeness", 0)),
                }
            )
    return rows


def _draw_card(
    ax: Axes,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    body: str,
    color: str,
    face: str | None = None,
) -> None:
    rect = mpatches.FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.02,rounding_size=0.025",
        linewidth=0.8,
        edgecolor=color,
        facecolor=face or PALETTE["white"],
    )
    ax.add_patch(rect)
    ax.text(
        x + 0.04 * w,
        y + h - 0.28 * h,
        title,
        ha="left",
        va="top",
        fontsize=FONT_SIZES["axis_label"],
        fontweight="bold",
        color=color,
    )
    ax.text(
        x + 0.04 * w,
        y + 0.30 * h,
        body,
        ha="left",
        va="top",
        fontsize=FONT_SIZES["small"],
        color=PALETTE["gray_900"],
        linespacing=1.2,
    )


def _arrow(ax: Axes, x0: float, y0: float, x1: float, y1: float, color: str | None = None) -> None:
    ax.annotate(
        "",
        xy=(x1, y1),
        xytext=(x0, y0),
        arrowprops={
            "arrowstyle": "-|>",
            "lw": 0.9,
            "color": color or PALETTE["gray_700"],
            "shrinkA": 0,
            "shrinkB": 0,
        },
    )


def _setup_diagram_axis(ax: Axes) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")


def draw_validation_panel(ax: Axes, papers: list[dict]) -> None:
    metrics = [
        ("Overall", "avg_overall", "#6F97B3"),
        ("Exp. match", "avg_experiment_match", "#7E9F69"),
        ("Validity", "avg_protocol_validity", "#6AA09C"),
        ("Phase", "avg_phase_completeness", "#B87563"),
    ]
    rng = np.random.default_rng(42)
    box_width = 0.36
    for xpos, (label, key, color) in enumerate(metrics):
        values = np.array([float(paper[key]) for paper in papers], dtype=float)
        jitter = np.clip(rng.normal(0, 0.095, size=len(values)), -0.24, 0.24)
        ax.scatter(
            xpos + jitter,
            values,
            s=6.0,
            color=color,
            alpha=0.46,
            linewidths=0,
            rasterized=True,
            zorder=2,
        )

        q1, med, q3 = np.percentile(values, [25, 50, 75])
        ax.add_patch(
            mpatches.Rectangle(
                (xpos - box_width / 2, q1),
                box_width,
                q3 - q1,
                facecolor=color,
                edgecolor=color,
                linewidth=0.85,
                alpha=0.14,
                zorder=3,
            )
        )
        ax.hlines(med, xpos - box_width / 2, xpos + box_width / 2, color=color, linewidth=1.05, alpha=0.75, zorder=4)

        mean = float(np.mean(values))
        ax.scatter(
            [xpos],
            [mean],
            marker="D",
            s=25,
            color=color,
            edgecolor="white",
            linewidth=0.35,
            zorder=5,
        )
        ax.text(
            xpos,
            101.8,
            f"{mean:.1f}",
            ha="center",
            va="top",
            fontsize=FONT_SIZES["small"],
            fontweight="bold",
            color=color,
        )
    ax.set_title("LLM validation scores per metric", pad=4)
    ax.set_ylabel("Score (0-100)")
    ax.set_xticks(range(len(metrics)), [m[0] for m in metrics])
    ax.set_xlim(-0.55, len(metrics) - 0.45)
    ax.set_ylim(74, 102)
    _style_fig2_arch_axes(ax, grid="y")
    handles = [
        mlines.Line2D([], [], marker="D", linestyle="None", markersize=3.5, color=PALETTE["gray_700"], label="Mean"),
        mlines.Line2D([], [], color=PALETTE["gray_900"], linewidth=1.0, label="Median"),
        mpatches.Patch(facecolor=PALETTE["gray_100"], edgecolor=PALETTE["gray_700"], linewidth=0.65, label="Q1-Q3"),
    ]
    ax.legend(
        handles=handles,
        loc="lower right",
        bbox_to_anchor=(0.965, 0.035),
        frameon=False,
        ncol=1,
        fontsize=FONT_SIZES["legend"],
        handlelength=1.0,
        handletextpad=0.35,
        labelspacing=0.15,
        borderaxespad=0.0,
    )
    ax.text(0.03, 0.02, f"n = {len(papers)}", transform=ax.transAxes, fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"])


def draw_consistency_panel(ax: Axes, papers: list[dict], rows: list[dict]) -> None:
    stable = np.array(benchmark.classify_step_stability(papers, rows), dtype=bool)
    xs = np.array([float(p["avg_overall"]) for p in papers], dtype=float)
    ys = np.array([float(p.get("std_overall", 0)) for p in papers], dtype=float)

    ax.scatter(xs[stable], ys[stable], s=8, color=FIG2_ARCH["blue"], alpha=0.52, linewidths=0, rasterized=True, label=f"Step-stable (n={stable.sum()})")
    ax.scatter(
        xs[~stable],
        ys[~stable],
        s=24,
        marker="D",
        color=FIG2_ARCH["red"],
        edgecolor="white",
        linewidth=0.45,
        alpha=0.9,
        label=f"Step-variable (n={(~stable).sum()})",
    )
    mean_score = float(np.mean(xs))
    mean_sd = float(np.mean(ys))
    ax.axvline(mean_score, color=FIG2_ARCH["blue"], linestyle="--", linewidth=0.7, alpha=0.55)
    ax.axhline(mean_sd, color=PALETTE["gray_500"], linestyle="--", linewidth=0.75, alpha=0.65)
    ax.text(mean_score - 1.2, ax.get_ylim()[1] * 0.95 if ax.get_ylim()[1] else 45, f"Mean = {mean_score:.1f}", ha="right", va="top", fontsize=FONT_SIZES["small"], color=FIG2_ARCH["blue"])
    ax.text(51, mean_sd + 0.6, f"Mean SD = {mean_sd:.1f}", fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"])
    ax.set_title("Score level vs. inter-variant consistency", pad=4)
    ax.set_xlabel("Mean overall score")
    ax.set_ylabel("SD of overall score (across 10 variants)")
    ax.set_xlim(49, 101)
    ax.set_ylim(0, max(46, float(np.max(ys)) + 3))
    _style_fig2_arch_axes(ax, grid="both")
    make_compact_legend(ax, loc="upper left")


def draw_pca_panel(ax: Axes, projection: dict[str, object]) -> None:
    projected = np.array(projection["projected"], dtype=float)
    is_raw = np.array(projection["is_raw"], dtype=bool)
    pca = projection["pca"]

    ax.scatter(
        projected[~is_raw, 0],
        projected[~is_raw, 1],
        s=4.5,
        color=FIG2_ARCH["blue"],
        alpha=0.14,
        linewidths=0,
        rasterized=True,
        label="Processed variants",
    )
    ax.scatter(
        projected[is_raw, 0],
        projected[is_raw, 1],
        s=8.5,
        marker="s",
        color=FIG2_ARCH["brown"],
        alpha=0.72,
        linewidths=0,
        rasterized=True,
        label="Natural language",
    )
    ax.annotate(
        "Processed variants\n(unified structure)",
        xy=(-0.35, 0.85),
        xytext=(-1.95, -1.15),
        fontsize=FONT_SIZES["small"],
        color=FIG2_ARCH["blue"],
        bbox={"boxstyle": "round,pad=0.16", "facecolor": "#FFFFFF", "edgecolor": FIG2_ARCH["blue"], "linewidth": 0.42, "alpha": 0.78},
        arrowprops={"arrowstyle": "->", "lw": 0.72, "color": FIG2_ARCH["blue"]},
    )
    ax.annotate(
        "Natural language\n(diverse structure)",
        xy=(4.05, -1.25),
        xytext=(3.45, 0.25),
        fontsize=FONT_SIZES["small"],
        color=FIG2_ARCH["brown"],
        bbox={"boxstyle": "round,pad=0.16", "facecolor": "#FFFFFF", "edgecolor": FIG2_ARCH["brown"], "linewidth": 0.42, "alpha": 0.78},
        arrowprops={"arrowstyle": "->", "lw": 0.72, "color": FIG2_ARCH["brown"]},
    )
    explained = np.array(pca.explained_variance_ratio_, dtype=float) * 100
    ax.set_title("Style unification in structural feature space", pad=4)
    ax.set_xlabel(f"PC1 ({explained[0]:.1f}% variance)")
    ax.set_ylabel(f"PC2 ({explained[1]:.1f}% variance)")
    _style_fig2_arch_axes(ax, grid="both")
    handles = [
        mlines.Line2D([], [], marker="s", linestyle="None", markersize=4.0, color=FIG2_ARCH["brown"], label="Natural language"),
        mlines.Line2D([], [], marker="o", linestyle="None", markersize=4.0, color=FIG2_ARCH["blue"], label="Processed variants"),
    ]
    ax.legend(handles=handles, loc="upper left", frameon=False, fontsize=FONT_SIZES["legend"], handletextpad=0.35, borderpad=0.1, labelspacing=0.2)


def draw_structural_protocolization_panel(ax: Axes, text_data: dict, projection: dict[str, object]) -> None:
    metrics = benchmark.summarize_before_after_structure(text_data, projection)
    labels = [
        "Explicit\nsteps (%)",
        "Schema\ncoverage (%)",
        "Protocol\nproximity (%)",
        "Structural\ncompactness (%)",
    ]
    raw = np.array([float(row["raw"]) for row in metrics], dtype=float)
    after = np.array([float(row["after"]) for row in metrics], dtype=float)
    x = np.arange(len(labels))
    width = 0.33
    ax.bar(x - width / 2, raw, width=width, color=FIG2_BAR_COLORS["natural_language"], alpha=0.98, label="Natural language")
    ax.bar(x + width / 2, after, width=width, color=FIG2_BAR_COLORS["processed_variants"], alpha=0.98, label="Processed variants")
    for xpos, value in zip(x - width / 2, raw):
        ax.text(xpos, value + 2.0, f"{value:.1f}", ha="center", va="bottom", fontsize=FONT_SIZES["small"], color=PALETTE["gray_900"])
    for xpos, value in zip(x + width / 2, after):
        ax.text(xpos, value + 2.0, f"{value:.1f}", ha="center", va="bottom", fontsize=FONT_SIZES["small"], color=PALETTE["gray_900"])
    ax.set_title("BPL vs natural language: structural protocolization", pad=4)
    ax.set_ylabel("Value")
    ax.set_ylim(0, 108)
    ax.set_xticks(x, labels)
    _style_fig2_arch_axes(ax, grid="y")
    make_compact_legend(ax, loc="upper right", bbox_to_anchor=(1.0, 1.03))


def make_fig2_benchmark(papers: list[dict], rows: list[dict], text_data: dict, projection: dict[str, object]) -> None:
    fig, axes = plt.subplots(2, 2, figsize=FIGURE_SIZES["double"], constrained_layout=False)
    fig.patch.set_facecolor(PALETTE["white"])
    draw_validation_panel(axes[0, 0], papers)
    draw_consistency_panel(axes[0, 1], papers, rows)
    draw_pca_panel(axes[1, 0], projection)
    draw_structural_protocolization_panel(axes[1, 1], text_data, projection)
    for ax in axes.flat:
        ax.grid(False)
    for label, ax in zip("abcd", axes.flat):
        add_panel_label(ax, label, x=-0.12, y=1.05)
    fig.subplots_adjust(left=0.085, right=0.99, top=0.955, bottom=0.095, wspace=0.30, hspace=0.44)
    save_figure(fig, str(OUT), "fig2_benchmark_validation")


def make_fig2_panel_a(papers: list[dict]) -> None:
    fig, ax = plt.subplots(figsize=FIGURE_SIZES["single"])
    fig.patch.set_facecolor(PALETTE["white"])
    draw_validation_panel(ax, papers)
    ax.grid(False)
    add_panel_label(ax, "a", x=-0.18, y=1.05)
    fig.subplots_adjust(left=0.16, right=0.98, top=0.88, bottom=0.18)
    save_figure(fig, str(OUT), "fig2a_llm_validation_scores")


def make_fig1_pipeline() -> None:
    fig, axes = plt.subplots(2, 1, figsize=(7.1, 4.05))
    ax = axes[0]
    _setup_diagram_axis(ax)
    add_panel_label(ax, "a", x=-0.02, y=1.0)
    ax.text(0.02, 0.94, "Bounded compiler-guided generation workflow", fontsize=FONT_SIZES["title"], fontweight="bold", color=PALETTE["gray_900"])

    cards = [
        (0.02, "Natural-language\nprotocol", "SOP + optional\nlab catalog", PALETTE["natural_language"]),
        (0.22, "BPL-Nano-30B", "candidate BPL\nprogram", PALETTE["bpl"]),
        (0.42, "Compiler gates", "parse + semantic\n+ validate", PALETTE["teal"]),
        (0.62, "Repair loop", "structured diagnostic\nmax 3 attempts", PALETTE["warning"]),
        (0.82, "Artifacts", "manual protocol\nrobot worklist", PALETTE["success"]),
    ]
    for x, title, body, color in cards:
        _draw_card(ax, x, 0.34, 0.15, 0.40, title, body, color, face=PALETTE["gray_100"])
    for x0 in [0.17, 0.37, 0.57, 0.77]:
        _arrow(ax, x0, 0.54, x0 + 0.045, 0.54)
    ax.annotate(
        "",
        xy=(0.46, 0.33),
        xytext=(0.69, 0.33),
        arrowprops={"arrowstyle": "<|-", "lw": 0.8, "color": PALETTE["warning"], "connectionstyle": "arc3,rad=-0.42"},
    )

    ax = axes[1]
    _setup_diagram_axis(ax)
    add_panel_label(ax, "b", x=-0.02, y=1.0)
    ax.text(0.02, 0.94, "Compiler architecture", fontsize=FONT_SIZES["title"], fontweight="bold", color=PALETTE["gray_900"])
    layers = [
        ("Source", "declarations\nprotocol blocks", PALETTE["natural_language"]),
        ("Grammar", "Lark PEG\nAST modules", PALETTE["bpl"]),
        ("Typed AST", "12 dimensions\nunit registry", PALETTE["teal"]),
        ("Semantic", "unit checks\nstate tracking", PALETTE["success"]),
        ("Intent IR", "lab intents\nprimitives", PALETTE["warning"]),
        ("Plan IR", "DAG schedule\nbackends", PALETTE["failure"]),
    ]
    x0 = 0.02
    for idx, (title, body, color) in enumerate(layers):
        x = x0 + idx * 0.158
        _draw_card(ax, x, 0.29, 0.125, 0.40, title, body, color, face=PALETTE["white"])
        if idx < len(layers) - 1:
            _arrow(ax, x + 0.125, 0.49, x + 0.155, 0.49)
    ax.text(0.50, 0.13, "Each gate rejects non-canonical structures before execution artifacts are emitted.", ha="center", fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"])
    fig.subplots_adjust(left=0.03, right=0.99, top=0.97, bottom=0.04, hspace=0.26)
    save_figure(fig, str(OUT), "fig1_pipeline_architecture")


def make_fig3_structural_determinism(rows: list[dict]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.95))
    ranges = [int(row["range"]) for row in rows]
    labels, counts = benchmark.bucket_step_ranges(ranges)
    colors = [PALETTE["success"], PALETTE["teal"], PALETTE["warning"], PALETTE["warning"], PALETTE["failure"], PALETTE["failure"]]
    ax = axes[0]
    ax.bar(labels, counts, color=colors, width=0.72)
    for i, c in enumerate(counts):
        if c:
            ax.text(i, c + max(counts) * 0.02, str(c), ha="center", va="bottom", fontsize=FONT_SIZES["small"], color=PALETTE["gray_900"])
    ax.set_title("Step-count range across independent runs", pad=4)
    ax.set_xlabel("Step-count range")
    ax.set_ylabel("Number of protocols")
    style_axes(ax, grid="y")
    ax.text(
        0.96,
        0.86,
        f"{sum(np.array(ranges) == 0)}/{len(ranges)}\nrange = 0",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=FONT_SIZES["annotation"],
        color=PALETTE["success"],
        fontweight="bold",
    )

    ax = axes[1]
    metric_labels = [
        "Step-count\nstd",
        "Structure\nmatch (%)",
        "Identical\nruns (%)",
        "Step-count\nrange",
    ]
    # BPL values are derived from the recomputed determinism summary so the
    # panel always tells the same story as compute_determinism.py and the
    # manuscript's text claims. The natural-language comparator values are
    # illustrative estimates carried over from the manuscript and have no
    # underlying measurement in this repo — they are annotated as "est."
    # in the legend. See tools/bpl_eval/README.md for the rationale.
    determinism_summary = json.loads(
        (SCRIPT_DIR / "data" / "determinism_results.json").read_text()
    )["summary"]
    bpl_values = np.array(
        [
            float(determinism_summary["mean_step_count_std"]),
            float(determinism_summary["mean_match_vs_digest_pct"]),
            float(determinism_summary["identical_all_runs_pct"]),
            float(determinism_summary["mean_step_count_range"]),
        ]
    )
    # Natural-language comparator: estimated, not measured. See
    # tools/bpl_eval/README.md "Natural-language comparator" section.
    nl_values = np.array([35.0, 45.0, 5.0, 8.5])
    x = np.arange(len(metric_labels))
    width = 0.34
    ax.bar(x - width / 2, bpl_values, width, color=PALETTE["bpl"], label="BPL")
    ax.bar(
        x + width / 2,
        nl_values,
        width,
        color=PALETTE["failure"],
        label="Natural language (est.)",
    )
    # Per-metric label format: percentages keep two decimals so 98.34 / 99.40
    # are fully visible; std and range get three decimals to surface the
    # small-value contrast against the natural-language comparator.
    bpl_label_formats = ["{:.3f}", "{:.2f}", "{:.2f}", "{:.3f}"]
    nl_label_formats = ["{:.1f}", "{:.1f}", "{:.1f}", "{:.1f}"]
    for xpos, value, fmt in zip(x - width / 2, bpl_values, bpl_label_formats):
        ax.text(
            xpos,
            value + 2.2 if value > 5 else value + 1.7,
            fmt.format(value),
            ha="center",
            va="bottom",
            fontsize=FONT_SIZES["small"],
        )
    for xpos, value, fmt in zip(x + width / 2, nl_values, nl_label_formats):
        ax.text(
            xpos,
            value + 2.2 if value > 5 else value + 1.7,
            fmt.format(value),
            ha="center",
            va="bottom",
            fontsize=FONT_SIZES["small"],
        )
    ax.set_title("BPL vs natural language structural consistency", pad=4)
    ax.set_ylabel("Value")
    ax.set_xticks(x, metric_labels)
    ax.set_ylim(0, 110)
    style_axes(ax, grid="y")
    make_compact_legend(ax, loc="upper left")
    for label, ax in zip("ab", axes):
        add_panel_label(ax, label, x=-0.12, y=1.05)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.90, bottom=0.20, wspace=0.32)
    save_figure(fig, str(OUT), "fig3_structural_determinism")


def make_fig4_diagnostics() -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.75), gridspec_kw={"width_ratios": [1.05, 0.75, 1.2]})

    # Diagnostic-category counts and repair-loop outcome percentages are
    # loaded from frozen JSON so the figure panel always matches the
    # numbers the paper text reports. See data/diagnostics/ for provenance.
    diag_data = json.loads(
        (SCRIPT_DIR / "data" / "diagnostics" / "diagnostic_categories.json").read_text()
    )
    repair_data = json.loads(
        (SCRIPT_DIR / "data" / "diagnostics" / "repair_loop_outcomes.json").read_text()
    )

    ax = axes[0]
    diag_categories = diag_data["categories"]
    categories = [c["label"].replace(" ", "\n", 1) for c in diag_categories]
    counts = np.array([c["occurrences"] for c in diag_categories])
    y = np.arange(len(categories))[::-1]
    ax.barh(y, counts, color=[PALETTE["failure"], PALETTE["warning"], PALETTE["teal"], PALETTE["bpl"], PALETTE["gray_700"]], height=0.62)
    for ypos, value in zip(y, counts):
        ax.text(value + 4, ypos, str(value), va="center", fontsize=FONT_SIZES["small"], color=PALETTE["gray_900"])
    ax.set_yticks(y, categories)
    ax.set_xlabel("Occurrences")
    ax.set_title("Compiler diagnostic categories", pad=4)
    ax.set_xlim(0, max(counts) * 1.16)
    style_axes(ax, grid="x")

    ax = axes[1]
    panel_segments = repair_data["panel_segments_pct"]
    segments = [float(seg["pct"]) for seg in panel_segments]
    colors = [PALETTE["success"], PALETTE["teal"], PALETTE["failure"]]
    labels = [seg["label"].replace(" ", "\n") for seg in panel_segments]
    bottom = 0
    for value, color, label in zip(segments, colors, labels):
        ax.bar([0], [value], bottom=bottom, color=color, width=0.42, label=label)
        ax.text(0, bottom + value / 2, f"{value:.1f}%", ha="center", va="center", fontsize=FONT_SIZES["small"], color=PALETTE["white"] if value > 8 else PALETTE["gray_900"], fontweight="bold" if value > 8 else "normal")
        bottom += value
    ax.set_title("Compilation outcome", pad=4)
    ax.set_ylabel("Protocols (%)")
    ax.set_xticks([0], [""])
    ax.set_xlim(-0.55, 1.02)
    ax.set_ylim(0, 100)
    style_axes(ax, grid="y")
    ax.text(0.47, 41.2, "First\nattempt", ha="left", va="center", fontsize=FONT_SIZES["small"], color=PALETTE["success"], fontweight="bold")
    ax.text(0.47, 90.5, "Repair\nloop", ha="left", va="center", fontsize=FONT_SIZES["small"], color=PALETTE["teal"], fontweight="bold")
    ax.text(0.47, 99.2, "Unresolved", ha="left", va="center", fontsize=FONT_SIZES["small"], color=PALETTE["failure"], fontweight="bold")

    ax = axes[2]
    _setup_diagram_axis(ax)
    ax.set_title("Representative type diagnostic", pad=4)
    left = mpatches.FancyBboxPatch((0.02, 0.58), 0.42, 0.30, boxstyle="round,pad=0.02,rounding_size=0.02", facecolor=PALETTE["gray_100"], edgecolor=PALETTE["failure"], linewidth=0.8)
    right = mpatches.FancyBboxPatch((0.56, 0.58), 0.42, 0.30, boxstyle="round,pad=0.02,rounding_size=0.02", facecolor=PALETTE["gray_100"], edgecolor=PALETTE["success"], linewidth=0.8)
    ax.add_patch(left)
    ax.add_patch(right)
    ax.text(0.04, 0.82, "Before", fontsize=FONT_SIZES["axis_label"], fontweight="bold", color=PALETTE["failure"])
    ax.text(0.04, 0.72, "volume = 50 mg", fontsize=FONT_SIZES["small"], family="monospace", color=PALETTE["gray_900"])
    ax.text(0.58, 0.82, "After repair", fontsize=FONT_SIZES["axis_label"], fontweight="bold", color=PALETTE["success"])
    ax.text(0.58, 0.72, "mass = 50 mg", fontsize=FONT_SIZES["small"], family="monospace", color=PALETTE["gray_900"])
    _arrow(ax, 0.46, 0.73, 0.54, 0.73, PALETTE["gray_700"])
    diag = '{\n  "code": "DIMENSION_MISMATCH",\n  "expected": "volume",\n  "observed": "mass",\n  "hint": "assign to mass"\n}'
    box = mpatches.FancyBboxPatch((0.09, 0.08), 0.82, 0.35, boxstyle="round,pad=0.02,rounding_size=0.02", facecolor=PALETTE["white"], edgecolor=PALETTE["gray_400"], linewidth=0.8)
    ax.add_patch(box)
    ax.text(0.13, 0.38, diag, ha="left", va="top", fontsize=FONT_SIZES["small"], family="monospace", color=PALETTE["gray_900"], linespacing=1.12)
    for label, ax in zip("abc", axes):
        add_panel_label(ax, label, x=-0.16, y=1.05)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.88, bottom=0.18, wspace=0.46)
    save_figure(fig, str(OUT), "fig4_compiler_diagnostics")


def make_fig5_wetlab_validation() -> None:
    fig, axes = plt.subplots(2, 2, figsize=(7.1, 4.15))
    ax = axes[0, 0]
    _setup_diagram_axis(ax)
    ax.set_title("One source program, two execution modes", pad=4)
    _draw_card(ax, 0.08, 0.48, 0.28, 0.30, "BPL source", "GFP plasmid\nlibrary workflow", PALETTE["bpl"], face=PALETTE["gray_100"])
    _draw_card(ax, 0.58, 0.61, 0.32, 0.27, "Manual", "human-readable\ninstructions", PALETTE["natural_language"])
    _draw_card(ax, 0.58, 0.25, 0.32, 0.27, "Robot", "Biomek i7\nCSV worklists", PALETTE["teal"])
    _arrow(ax, 0.36, 0.63, 0.58, 0.75)
    _arrow(ax, 0.36, 0.63, 0.58, 0.39)

    ax = axes[0, 1]
    groups = ["Inserts", "Vectors\ninitial", "Vectors\nafter rescue"]
    # Read from the shipped wet-lab CSV so the panel and the
    # methods/results prose stay in sync. See
    # tools/bpl_eval/data/wetlab/pcr_amplification.csv for provenance.
    pcr_csv = SCRIPT_DIR / "data" / "wetlab" / "pcr_amplification.csv"
    pcr_rows: dict[tuple[str, str, str], int] = {}
    with pcr_csv.open() as _h:
        for _line in _h:
            _line = _line.strip()
            if not _line or _line.startswith("#"):
                continue
            if _line.startswith("fragment,"):
                continue
            _frag, _wf, _stage, _total, _succ = _line.split(",")
            pcr_rows[(_frag, _wf, _stage)] = int(_succ)
    manual = np.array(
        [
            pcr_rows[("insert", "manual", "initial")],
            pcr_rows[("vector", "manual", "initial")],
            pcr_rows[("vector", "manual", "initial")],
        ]
    )
    automated = np.array(
        [
            pcr_rows[("insert", "automated", "initial")],
            pcr_rows[("vector", "automated", "initial")],
            pcr_rows[("vector", "automated", "rescue")],
        ]
    )
    x = np.arange(len(groups))
    width = 0.34
    ax.bar(x - width / 2, manual, width, color=PALETTE["natural_language"], label="Manual")
    ax.bar(x + width / 2, automated, width, color=PALETTE["teal"], label="Automated")
    for xpos, value in zip(x - width / 2, manual):
        ax.text(xpos, value + 0.25, f"{value}/11", ha="center", fontsize=FONT_SIZES["small"])
    for xpos, value in zip(x + width / 2, automated):
        ax.text(xpos, value + 0.25, f"{value}/11", ha="center", fontsize=FONT_SIZES["small"])
    ax.set_title("PCR amplification success", pad=4)
    ax.set_ylabel("Successful fragments")
    ax.set_xticks(x, groups)
    ax.set_ylim(0, 12.8)
    style_axes(ax, grid="y")
    make_compact_legend(ax, loc="upper right", bbox_to_anchor=(1.0, 1.17), ncol=2)

    ax = axes[1, 0]
    _setup_diagram_axis(ax)
    ax.set_title("Promoter library phenotype", pad=4)
    for i in range(11):
        intensity = 0.15 + 0.07 * i
        rect = mpatches.FancyBboxPatch(
            (0.06 + i * 0.08, 0.48),
            0.055,
            0.20,
            boxstyle="round,pad=0.005,rounding_size=0.012",
            facecolor=(0.15, 0.60, 0.25, intensity),
            edgecolor=PALETTE["gray_400"],
            linewidth=0.45,
        )
        ax.add_patch(rect)
    ax.text(0.06, 0.74, "11 verified promoter constructs", fontsize=FONT_SIZES["axis_label"], fontweight="bold", color=PALETTE["gray_900"])
    ax.text(0.06, 0.31, "Induced and leaky GFP expression gradients were observed\nin both manual and automated sample sets.", fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"], linespacing=1.2)

    ax = axes[1, 1]
    labels = ["Run time\n(min)", "Solvent\nuse (%)", "Analyte order\npreserved"]
    # Read the actual HPLC→UHPLC translation result so the panel and the
    # underlying ChP 0512 scaling stay in lockstep. See
    # tools/bpl_eval/method_translation.py for the reproducer.
    method_translation = json.loads(
        (SCRIPT_DIR / "data" / "method_translation" / "hplc_to_uhplc.json").read_text()
    )
    src_run = float(method_translation["source"]["run_time_min"])
    new_run = float(method_translation["translation"]["run_time_min"])
    src_solvent_pct = 100.0
    new_solvent_pct = round(100.0 - float(method_translation["reduction"]["solvent_saving_pct"]), 1)
    before = np.array([src_run, src_solvent_pct, 100.0])
    after = np.array([new_run, new_solvent_pct, 100.0])
    x = np.arange(len(labels))
    ax.bar(x - width / 2, before, width, color=PALETTE["natural_language"], label="HPLC")
    ax.bar(x + width / 2, after, width, color=PALETTE["bpl"], label="UHPLC")
    annotations = [
        (f"{src_run:.1f}", f"{new_run:.1f}"),
        ("100", f"{new_solvent_pct:.1f}"),
        ("5/5", "5/5"),
    ]
    for i, (a, b) in enumerate(annotations):
        ax.text(i - width / 2, before[i] + 4, a, ha="center", fontsize=FONT_SIZES["small"])
        ax.text(i + width / 2, after[i] + 4, b, ha="center", fontsize=FONT_SIZES["small"])
    ax.set_title("Chromatographic method transfer", pad=4)
    ax.set_ylabel("Value")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 116)
    style_axes(ax, grid="y")
    make_compact_legend(ax, loc="upper center", ncol=2)

    for label, ax in zip("abcd", axes.flat):
        add_panel_label(ax, label, x=-0.12, y=1.05)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.93, bottom=0.10, wspace=0.34, hspace=0.50)
    save_figure(fig, str(OUT), "fig5_wetlab_validation")


def make_fig6_language_design() -> None:
    fig, ax = plt.subplots(figsize=(7.1, 2.85))
    _setup_diagram_axis(ax)
    add_panel_label(ax, "a", x=-0.02, y=1.0)
    ax.text(0.02, 0.92, "Three-phase BPL language design process", fontsize=FONT_SIZES["title"], fontweight="bold", color=PALETTE["gray_900"])
    phases = [
        ("1. Domain analysis", "operation inventory\nconstraints\nfailure modes", PALETTE["natural_language"]),
        ("2. Grammar design", "syntax rules\ncanonical blocks\nintent vocabulary", PALETTE["bpl"]),
        ("3. Compiler construction", "type system\nvalidation gates\nbackend targets", PALETTE["teal"]),
    ]
    xs = [0.06, 0.37, 0.68]
    for x, (title, body, color) in zip(xs, phases):
        _draw_card(ax, x, 0.38, 0.24, 0.32, title, body, color, face=PALETTE["gray_100"])
    _arrow(ax, 0.30, 0.54, 0.37, 0.54)
    _arrow(ax, 0.61, 0.54, 0.68, 0.54)
    ax.annotate(
        "",
        xy=(0.18, 0.34),
        xytext=(0.80, 0.34),
        arrowprops={"arrowstyle": "<|-", "lw": 0.85, "color": PALETTE["warning"], "connectionstyle": "arc3,rad=-0.30"},
    )
    ax.text(0.49, 0.18, "Compiler failures feed back into grammar and type-system refinement.", ha="center", fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"])
    fig.subplots_adjust(left=0.03, right=0.99, top=0.93, bottom=0.08)
    save_figure(fig, str(OUT), "fig6_language_design")


def make_fig7_corpus_qa() -> None:
    fig, ax = plt.subplots(figsize=(7.1, 3.15))
    _setup_diagram_axis(ax)
    add_panel_label(ax, "a", x=-0.02, y=1.0)
    ax.text(0.02, 0.93, "Four-layer quality assurance pipeline for training corpus generation", fontsize=FONT_SIZES["title"], fontweight="bold", color=PALETTE["gray_900"])
    stages = [
        ("Seed expansion", "47 SOPs -> diverse\ninstruction scenarios", PALETTE["natural_language"]),
        ("BPL generation", "candidate code\n6-point validation", PALETTE["bpl"]),
        ("LLM quality critic", "4 axes\nthreshold 80/100", PALETTE["teal"]),
        ("Evolutionary variation", "30% approved\nrecords diversified", PALETTE["warning"]),
        ("Compound filtering", "2,714 validated\npairs (~24%)", PALETTE["success"]),
    ]
    xs = [0.03, 0.22, 0.41, 0.60, 0.79]
    for x, (title, body, color) in zip(xs, stages):
        _draw_card(ax, x, 0.42, 0.155, 0.31, title, body, color, face=PALETTE["gray_100"])
    for x0 in [0.185, 0.375, 0.565, 0.755]:
        _arrow(ax, x0, 0.575, x0 + 0.035, 0.575)
    ax.annotate(
        "Refinement loop",
        xy=(0.48, 0.40),
        xytext=(0.38, 0.20),
        fontsize=FONT_SIZES["small"],
        color=PALETTE["failure"],
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": PALETTE["failure"], "connectionstyle": "arc3,rad=0.25"},
    )
    ax.text(0.50, 0.11, "Failures are routed back before inclusion in the training corpus.", ha="center", fontsize=FONT_SIZES["small"], color=PALETTE["gray_700"])
    fig.subplots_adjust(left=0.03, right=0.99, top=0.92, bottom=0.07)
    save_figure(fig, str(OUT), "fig7_corpus_quality_assurance")


def write_index() -> None:
    entries = [
        ("fig1_pipeline_architecture", "BPL-COGEN pipeline and compiler architecture"),
        ("fig2_benchmark_validation", "Benchmark validation and structural standardization"),
        ("fig2a_llm_validation_scores", "LLM-judge validation scores (single-panel companion to fig2)"),
        ("fig3_structural_determinism", "Structural determinism versus natural language"),
        ("fig4_compiler_diagnostics", "Compiler diagnostics and repair-loop performance"),
        ("fig5_wetlab_validation", "Wet-lab validation summary"),
        ("fig6_language_design", "Three-phase BPL language design process"),
        ("fig7_corpus_quality_assurance", "Training-corpus quality assurance pipeline"),
    ]
    lines = [
        "# Publication redraw figure index",
        "",
        "Eight figures ship in this directory; all regenerate offline by running",
        "`tools/bpl_eval/redraw_publication_figures.py`.",
        "",
    ]
    for stem, title in entries:
        lines.append(f"- `{stem}.pdf` / `{stem}.png`: {title}")
    (OUT / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    apply_global_matplotlib_style()
    print("Loading benchmark data...", flush=True)
    papers, _ = benchmark.load_variant_report()
    rows = benchmark.load_consistency_rows()
    text_data = benchmark.load_text_features()
    projection = benchmark.build_structural_projection(text_data)

    print("Drawing unified publication figures...", flush=True)
    make_fig1_pipeline()
    make_fig2_panel_a(papers)
    make_fig2_benchmark(papers, rows, text_data, projection)
    make_fig3_structural_determinism(rows)
    make_fig4_diagnostics()
    make_fig5_wetlab_validation()
    make_fig6_language_design()
    make_fig7_corpus_qa()
    write_index()
    print(f"Done. Figures saved to {OUT}", flush=True)


if __name__ == "__main__":
    main()
