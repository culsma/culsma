#!/usr/bin/env python3
"""
Quick local analysis of variant step-count consistency.

Uses regex to count steps from the mandatory "Step N." numbering format.
No LLM calls are required.

Usage:
    python analyze_consistency.py
"""

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from statistics import mean, stdev

_BASE = os.path.dirname(os.path.abspath(__file__))
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

from config import ANALYSIS_DIR, VARIANT_OUTPUT_DIR  # noqa: E402


def count_steps_regex(text: str) -> int:
    """Count procedural steps using regex matching the mandatory numbering format.

    Generated variants use "Step N." format. We search liberally for this pattern
    anywhere in the text, plus bare "N." at line starts.
    """
    # Primary: "Step N." anywhere in text (handles inline, bulleted, bolded)
    step_matches = re.findall(r'Step\s+(\d+)[\.\):\*]', text, re.IGNORECASE)

    # Secondary: bare "N." or "N)" at line start (handles formats without "Step" prefix)
    bare_matches = re.findall(r'(?:^|\n)\s*[•\-\*]*\s*(?:\*{0,2}\s*)?(\d+)[\.\)]', text)

    # Combine and deduplicate
    all_nums = set(int(m) for m in step_matches) | set(int(m) for m in bare_matches)

    if not all_nums:
        return 0

    # Use the highest step number as the count (since numbering is sequential 1..N)
    return max(all_nums)


def analyze():
    papers = []
    for f in sorted(Path(VARIANT_OUTPUT_DIR).glob("*.json")):
        if f.name.startswith("_"):
            continue
        try:
            with open(f, encoding='utf-8') as fh:
                data = json.load(fh)
            digest = data.get("digest", {})
            variants = data.get("variants", [])
            if not variants:
                continue

            digest_steps = len(digest.get("steps", [])) if isinstance(digest, dict) else 0

            variant_step_counts = []
            for v in variants:
                text = v.get("protocol_text", "")
                # Skip obvious refusals (no steps found AND contains refusal language)
                count = count_steps_regex(text)
                # Normalize curly quotes for refusal detection
                normalized = text.lower().replace("\u2018", "'").replace("\u2019", "'")
                is_refusal = any(phrase in normalized for phrase in [
                    "i'm sorry", "i can't help", "i cannot", "i'm unable",
                    "i can't provide", "non-operational alternatives",
                    "can't provide the requested", "can't help generate",
                ])
                if count == 0 and is_refusal:
                    continue  # Model content-moderation refusal
                variant_step_counts.append(count)
            if not variant_step_counts:
                continue

            paper_result = {
                "paper_name": f.stem,
                "digest_steps": digest_steps,
                "num_variants": len(variants),
                "variant_step_counts": variant_step_counts,
                "step_mean": mean(variant_step_counts),
                "step_min": min(variant_step_counts),
                "step_max": max(variant_step_counts),
                "step_range": max(variant_step_counts) - min(variant_step_counts),
                "step_std": stdev(variant_step_counts) if len(variant_step_counts) > 1 else 0,
                "matches_digest": sum(1 for c in variant_step_counts if c == digest_steps),
            }
            papers.append(paper_result)
        except (json.JSONDecodeError, OSError):
            continue

    return papers


def generate_report(results: list[dict]):
    if not results:
        print("No results!")
        return

    report = []
    report.append("# Variant Consistency Analysis\n")
    report.append(f"**Generated**: {datetime.now().isoformat()}")
    report.append(f"**Papers Analyzed**: {len(results)}")
    report.append("**Method**: Regex-based step counting (no LLM)\n")

    # Overall stats
    all_ranges = [r["step_range"] for r in results]
    all_stds = [r["step_std"] for r in results]
    all_match_rates = [r["matches_digest"] / r["num_variants"] * 100 for r in results]

    report.append("## Overall Consistency\n")
    report.append(f"- Average step count range (max-min): **{mean(all_ranges):.1f}**")
    report.append(f"- Average step count std dev: **{mean(all_stds):.1f}**")
    report.append(f"- Papers with step range <= 5: **{sum(1 for r in results if r['step_range'] <= 5)}** / {len(results)}")
    report.append(f"- Papers with step range <= 2: **{sum(1 for r in results if r['step_range'] <= 2)}** / {len(results)}")
    report.append(f"- Papers with step range = 0 (perfect): **{sum(1 for r in results if r['step_range'] == 0)}** / {len(results)}")
    report.append(f"- Papers with step range > 20: **{sum(1 for r in results if r['step_range'] > 20)}** / {len(results)}")
    report.append(f"- Average % variants matching digest step count: **{mean(all_match_rates):.1f}%**")
    report.append("")

    # Per-paper table
    report.append("## Per-Paper Step Count Analysis\n")
    report.append("| Paper | Digest | Mean | Min | Max | Range | Std | Match% | Variants |")
    report.append("|-------|---:|---:|---:|---:|---:|---:|---:|---:|")

    for r in sorted(results, key=lambda x: x["step_range"], reverse=True):
        name = r["paper_name"][:55]
        match_pct = r["matches_digest"] / r["num_variants"] * 100
        report.append(
            f"| {name} "
            f"| {r['digest_steps']} "
            f"| {r['step_mean']:.0f} "
            f"| {r['step_min']} "
            f"| {r['step_max']} "
            f"| {r['step_range']} "
            f"| {r['step_std']:.1f} "
            f"| {match_pct:.0f}% "
            f"| {r['num_variants']} |"
        )
    report.append("")

    # Worst 10
    worst = sorted(results, key=lambda x: x["step_range"], reverse=True)[:10]
    report.append("## Top 10 Highest Range Papers\n")
    for r in worst:
        report.append(f"- **{r['paper_name'][:60]}**: digest={r['digest_steps']}, "
                      f"counts={r['variant_step_counts']}, range={r['step_range']}")
    report.append("")

    # Best 10
    best = sorted(results, key=lambda x: x["step_range"])[:10]
    report.append("## Top 10 Most Consistent Papers\n")
    for r in best:
        report.append(f"- **{r['paper_name'][:60]}**: digest={r['digest_steps']}, "
                      f"counts={r['variant_step_counts']}, range={r['step_range']}")

    report_text = '\n'.join(report)
    os.makedirs(ANALYSIS_DIR, exist_ok=True)
    report_path = os.path.join(ANALYSIS_DIR, "consistency_report.md")
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_text)

    print(report_text)
    print(f"\nReport saved to: {report_path}")


if __name__ == "__main__":
    results = analyze()
    generate_report(results)
