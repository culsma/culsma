# Publication redraw figure index

Eight figures ship in this directory; all regenerate offline by running
`tools/bpl_eval/redraw_publication_figures.py`.

- `fig1_pipeline_architecture.pdf` / `fig1_pipeline_architecture.png`: BPL-COGEN pipeline and compiler architecture
- `fig2_benchmark_validation.pdf` / `fig2_benchmark_validation.png`: Benchmark validation and structural standardization
- `fig2a_llm_validation_scores.pdf` / `fig2a_llm_validation_scores.png`: LLM-judge validation scores (single-panel companion to fig2)
- `fig3_structural_determinism.pdf` / `fig3_structural_determinism.png`: Structural determinism versus natural language
- `fig4_compiler_diagnostics.pdf` / `fig4_compiler_diagnostics.png`: Compiler diagnostics and repair-loop performance
- `fig5_wetlab_validation.pdf` / `fig5_wetlab_validation.png`: Wet-lab validation summary
- `fig6_language_design.pdf` / `fig6_language_design.png`: Three-phase BPL language design process
- `fig7_corpus_quality_assurance.pdf` / `fig7_corpus_quality_assurance.png`: Training-corpus quality assurance pipeline
