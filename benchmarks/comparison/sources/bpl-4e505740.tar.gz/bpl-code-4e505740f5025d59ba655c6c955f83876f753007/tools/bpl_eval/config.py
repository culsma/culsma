"""Configuration for the paper-facing BPL evaluation workflow.

Path layout — everything eval-related lives under ``tools/bpl_eval/``:

* Frozen, paper-grade input artifacts (``variant_report.json``,
  ``per_paper/*.json``, ``consistency_report.md``,
  ``structural_features.json``, ``determinism_results.json``) live under
  ``tools/bpl_eval/data/``. The figure scripts read these directly so the
  publication figures can be reproduced offline without API calls or the
  raw corpus.
* Frozen, paper-grade output artifacts (``publication_redraw/fig*.{pdf,png}``)
  live under ``tools/bpl_eval/figures/publication_redraw/`` and are
  regenerated in-place by ``redraw_publication_figures.py``.
* Generated, regenerable, and corpus-derived artifacts (``digests/``,
  ``variants/``, ``bpl_input/``, ``bpl_output/``, ``protocols/``, extraction
  caches, checkpoints) live under ``tools/bpl_eval/`` and are git-ignored.
  They are produced by the LLM-driven pipeline scripts and need
  ``OPENROUTER_API_KEY`` plus the source PDF corpus to recreate.
"""

from __future__ import annotations

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.normpath(os.path.join(BASE_DIR, "..", ".."))

OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
OPENROUTER_BASE_URL = os.environ.get(
    "OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"
)

# Production runs rotated across these models. Override per-script with the
# --model flag when reproducing on a single backend.
MODELS = [
    "anthropic/claude-opus-4.6",
    "openai/gpt-5.3-codex",
    "google/gemini-3.1-pro-preview",
]

VARIANTS_PER_PAPER = 10
BATCH_SIZE = 5
MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 180

# Pipeline working directories — all git-ignored. Fresh API-driven runs land
# here; the shipped paper-grade artifacts under tools/bpl_eval/data/ are
# not overwritten.
EXTRACTED_DIR = os.path.join(BASE_DIR, "extracted")
EXTRACTED_VISION_DIR = os.path.join(BASE_DIR, "extracted_vision")
DIGEST_SOURCE_DIR = os.path.join(BASE_DIR, "digests")
VARIANT_OUTPUT_DIR = os.path.join(BASE_DIR, "variants")
CHECKPOINT_FILE = os.path.join(BASE_DIR, "checkpoint.json")
BPL_INPUT_DIR = os.path.join(BASE_DIR, "bpl_input")
BPL_OUTPUT_DIR = os.path.join(BASE_DIR, "bpl_output")
PROTOCOLS_DIR = os.path.join(BASE_DIR, "protocols")
COMPARISON_DIR = os.path.join(BASE_DIR, "variant_comparisons")
ANALYSIS_DIR = os.path.join(BASE_DIR, "comparisons", "variant_analysis")

# Frozen paper-grade artifacts shipped with the repository. Figure scripts
# read these by default so the publication figures reproduce offline.
DATA_DIR = os.path.join(BASE_DIR, "data")
FROZEN_COMPARISON_DIR = os.path.join(DATA_DIR, "variant_comparisons")
FROZEN_VARIANT_REPORT = os.path.join(
    FROZEN_COMPARISON_DIR, "variant_report.json"
)
FROZEN_PER_PAPER_DIR = os.path.join(FROZEN_COMPARISON_DIR, "per_paper")
FROZEN_CONSISTENCY_REPORT = os.path.join(DATA_DIR, "consistency_report.md")
FROZEN_STRUCTURAL_FEATURES = os.path.join(
    DATA_DIR, "structural_features.json"
)
FROZEN_DETERMINISM_RESULTS = os.path.join(DATA_DIR, "determinism_results.json")

# Figure output directories.
FIGURES_DIR = os.path.join(BASE_DIR, "figures")
PUBLICATION_REDRAW_DIR = os.path.join(FIGURES_DIR, "publication_redraw")
