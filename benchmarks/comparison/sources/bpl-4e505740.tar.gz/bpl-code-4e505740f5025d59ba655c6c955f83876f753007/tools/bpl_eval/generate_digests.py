#!/usr/bin/env python3
"""Generate structured protocol digests for the BPL evaluation workflow."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import re
import sys
from pathlib import Path

import httpx
from dotenv import load_dotenv

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if _BASE_DIR not in sys.path:
    sys.path.insert(0, _BASE_DIR)
_PROJECT_ROOT = os.path.normpath(os.path.join(_BASE_DIR, "..", ".."))
load_dotenv(os.path.join(_PROJECT_ROOT, ".env"))

from config import (  # noqa: E402
    DIGEST_SOURCE_DIR,
    EXTRACTED_DIR,
    EXTRACTED_VISION_DIR,
    MODELS,
)
from llm_client import call_llm, parse_json_response  # noqa: E402
from prompts import build_digest_prompt  # noqa: E402


def safe_stem(title: str) -> str:
    return re.sub(r"[^\w\s-]", "_", title)[:80].strip()


def load_extracted_papers(source_dir: str) -> list[dict]:
    papers = []
    for path in sorted(Path(source_dir).glob("*.json")):
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
        except (json.JSONDecodeError, OSError):
            continue
        protocol_text = data.get("protocol_text", "")
        if data.get("status") == "failed" or len(protocol_text) < 100:
            continue
        data["_file"] = str(path)
        data["title"] = data.get("title") or path.stem
        papers.append(data)
    return papers


def pick_model(index: int) -> str:
    base = MODELS[index % len(MODELS)]
    if random.random() < 0.2:
        return random.choice(MODELS)
    return base


async def digest_one(
    client: httpx.AsyncClient,
    paper: dict,
    index: int,
    out_dir: str,
    force: bool,
) -> bool:
    title = paper["title"]
    out_path = os.path.join(out_dir, f"{safe_stem(title)}.json")
    if not force and os.path.exists(out_path) and os.path.getsize(out_path) > 0:
        print(f"  [{index}] skip {title[:70]}...")
        return True

    protocol_text = paper.get("protocol_text", "")
    words = protocol_text.split()
    if len(words) > 12000:
        protocol_text = " ".join(words[:12000]) + "\n\n[... truncated for length ...]"

    messages = build_digest_prompt(title, protocol_text, paper.get("materials_text", ""))
    model = pick_model(index)
    temperature = round(random.uniform(0.3, 0.5), 2)

    print(f"  [{index}] digest {title[:70]}... ({model.split('/')[-1]})")
    raw = await call_llm(client, messages, model, temperature, max_tokens=8192)
    digest = parse_json_response(raw)
    if not isinstance(digest, dict) or not digest.get("steps"):
        raise ValueError("digest response did not contain steps")

    with open(out_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "source_title": title,
                "source_file": paper.get("_file", ""),
                "digest_model": model,
                "digest": digest,
            },
            handle,
            ensure_ascii=False,
            indent=2,
        )
    return True


async def run(papers: list[dict], out_dir: str, batch_size: int, force: bool) -> tuple[int, int]:
    os.makedirs(out_dir, exist_ok=True)
    success = 0
    failed = 0

    async with httpx.AsyncClient() as client:
        for batch_start in range(0, len(papers), batch_size):
            batch = papers[batch_start : batch_start + batch_size]
            tasks = [
                digest_one(client, paper, batch_start + i + 1, out_dir, force)
                for i, paper in enumerate(batch)
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    failed += 1
                    print(f"    failed: {result}")
                else:
                    success += 1

    print(f"\nDone. {success} succeeded, {failed} failed. Output: {out_dir}/")
    return success, failed


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate BPL protocol digests")
    parser.add_argument("--source", default=EXTRACTED_VISION_DIR, help="Extracted JSON directory")
    parser.add_argument("--out", default=DIGEST_SOURCE_DIR, help="Digest output directory")
    parser.add_argument("--batch", type=int, default=5, help="Concurrent digest requests")
    parser.add_argument("--limit", type=int, help="Limit number of papers")
    parser.add_argument("--force", action="store_true", help="Overwrite existing digests")
    args = parser.parse_args()

    source = args.source
    if not os.path.exists(source) and os.path.exists(EXTRACTED_DIR):
        source = EXTRACTED_DIR

    papers = load_extracted_papers(source)
    if args.limit:
        papers = papers[: args.limit]
    print(f"Loaded {len(papers)} extracted protocols from {source}")
    if not papers:
        return 1

    success, failed = asyncio.run(run(papers, args.out, args.batch, args.force))
    if success == 0:
        print(f"FAIL: 0/{len(papers)} digests succeeded", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
