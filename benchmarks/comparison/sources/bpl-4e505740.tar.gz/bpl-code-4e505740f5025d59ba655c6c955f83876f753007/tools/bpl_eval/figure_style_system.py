"""Shared publication figure style for the BPL paper."""

from __future__ import annotations

from typing import Literal

import matplotlib
import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure


PALETTE = {
    "bpl": "#1F4E79",
    "natural_language": "#9C5A2E",
    "success": "#4F8A3C",
    "teal": "#2E7D73",
    "warning": "#C98A2E",
    "failure": "#B54A3A",
    "gray_900": "#1F2328",
    "gray_700": "#7A7F87",
    "gray_500": "#9AA1AA",
    "gray_400": "#B8BDC6",
    "gray_200": "#E5E8ED",
    "gray_100": "#F4F6F8",
    "white": "#FFFFFF",
}

FONT_SIZES = {
    "panel_label": 8.5,
    "title": 7.0,
    "axis_label": 6.5,
    "tick": 5.8,
    "legend": 5.8,
    "annotation": 6.0,
    "small": 5.3,
}

FIGURE_SIZES = {
    "single": (3.45, 2.55),
    "double": (7.1, 5.3),
    "wide": (7.1, 3.4),
}


def apply_global_matplotlib_style() -> None:
    """Apply a restrained Nature-style matplotlib theme."""
    matplotlib.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica Neue", "DejaVu Sans"],
            "font.size": FONT_SIZES["axis_label"],
            "axes.labelsize": FONT_SIZES["axis_label"],
            "axes.titlesize": FONT_SIZES["title"],
            "axes.titleweight": "bold",
            "xtick.labelsize": FONT_SIZES["tick"],
            "ytick.labelsize": FONT_SIZES["tick"],
            "legend.fontsize": FONT_SIZES["legend"],
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.75,
            "axes.grid": False,
            "grid.color": PALETTE["gray_200"],
            "grid.linewidth": 0.45,
            "grid.alpha": 0.8,
            "lines.linewidth": 1.2,
            "patch.linewidth": 0.7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def add_panel_label(ax: Axes, label: str, x: float = -0.13, y: float = 1.06) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=FONT_SIZES["panel_label"],
        fontweight="bold",
        color=PALETTE["gray_900"],
    )


def style_axes(ax: Axes, grid: Literal["none", "x", "y", "both"] = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.75)
    ax.spines["bottom"].set_linewidth(0.75)
    ax.tick_params(axis="both", width=0.75, length=2.5, pad=2)
    ax.xaxis.label.set_size(FONT_SIZES["axis_label"])
    ax.yaxis.label.set_size(FONT_SIZES["axis_label"])
    ax.title.set_size(FONT_SIZES["title"])
    if grid == "none":
        ax.grid(False)
    elif grid == "both":
        ax.grid(True, axis="both")
    else:
        ax.grid(True, axis=grid)


def make_compact_legend(ax: Axes, **kwargs):
    defaults = {
        "frameon": False,
        "fontsize": FONT_SIZES["legend"],
        "handlelength": 1.1,
        "handletextpad": 0.4,
        "borderpad": 0.2,
        "labelspacing": 0.25,
    }
    defaults.update(kwargs)
    return ax.legend(**defaults)


def save_figure(fig: Figure, output_dir: str, stem: str) -> None:
    """Save a figure as a deterministic PDF and PNG pair.

    PDF metadata is pinned (no CreationDate, fixed Producer) so consecutive
    redraws produce byte-stable PDFs — important for reproducibility audits
    that diff the shipped figures against a fresh run.
    """
    pdf_metadata = {
        "Creator": "BPL paper evaluation pipeline",
        "Producer": "matplotlib",
        "CreationDate": None,
        "ModDate": None,
        "Title": stem,
    }
    fig.savefig(f"{output_dir}/{stem}.pdf", metadata=pdf_metadata)
    fig.savefig(f"{output_dir}/{stem}.png", metadata={"Software": "matplotlib"})
    plt.close(fig)
