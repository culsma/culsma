#!/usr/bin/env python3
"""
Preview figure set for the BPL paper.

It produces four preview figures:

1. Validation quality in a single panel
2. Inter-variant score stability in a single panel
3. Style unification PCA in a single panel
4. Before/after BPL advantage in the same structural space
"""

from __future__ import annotations

import difflib
import glob
import json
import math
import os
import re
import sys
from collections import defaultdict

import matplotlib
import matplotlib.lines as mlines
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from PIL import Image
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if _BASE_DIR not in sys.path:
    sys.path.insert(0, _BASE_DIR)


matplotlib.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica Neue", "Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.labelsize": 9,
        "axes.titlesize": 10,
        "axes.titleweight": "bold",
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.22,
        "grid.linewidth": 0.5,
        "axes.linewidth": 0.8,
    }
)


from config import (  # noqa: E402
    BASE_DIR,
    BPL_INPUT_DIR,
    FIGURES_DIR,
    FROZEN_CONSISTENCY_REPORT,
    FROZEN_STRUCTURAL_FEATURES,
    FROZEN_VARIANT_REPORT,
)

BASE = BASE_DIR
OUT = FIGURES_DIR
os.makedirs(OUT, exist_ok=True)

EXPECTED_VARIANTS = [f"v{i:02d}" for i in range(1, 11)]
BPL_FILENAME_RE = re.compile(r"^(.+)_(v\d{2})\.md$")

C = {
    "raw": "#7B3F00",
    "bpl": "#2166AC",
    "green": "#4DAC26",
    "red": "#D6604D",
    "teal": "#35978F",
    "orange": "#E08214",
    "gray": "#8C8C8C",
    "light_gray": "#D9D9D9",
    "light_blue": "#BDDCF4",
}

PANEL_LEGEND_FONTSIZE = 6.5


def count_step_patterns(content: str) -> int:
    """Count protocol steps across the markdown formats used in bpl_input."""
    step_nums = set()
    patterns = [
        r"(?:^|\n)\s*#{2,4}\s*Step\s+(\d+)\b",
        r"(?:^|\n)\s*\*{0,2}\s*Step\s+(\d+)[\.\):]?",
        r"(?:^|\n)\s*(\d+)[\.\)]\s+",
    ]
    for pattern in patterns:
        for match in re.findall(pattern, content, re.IGNORECASE):
            step_nums.add(int(match))
    if step_nums:
        return len(step_nums)
    return 0


def count_protocol_schema_markers(content: str) -> int:
    """Count how many canonical protocol markers are explicitly present."""
    patterns = [
        r"(?im)^objective(?:\s*:|\b)",
        r"(?im)^materials?(?:\s+and\s+setup)?(?:\s*:|\b)",
        r"(?im)^expected results(?:\s*:|\b)",
        r"(?im)^troubleshooting(?:\s*:|\b)",
        r"(?im)^critical step(?:\s*:|\b)|\bCRITICAL\b",
        r"(?im)^\s*(?:##+\s*)?step\s+\d+\b|^\s*\d+[\.\)]\s+",
    ]
    return sum(bool(re.search(pattern, content)) for pattern in patterns)


def extract_structural_features(content: str) -> dict[str, int]:
    """Compute structural features for one markdown file."""
    return {
        "word_count": len(content.split()),
        "line_count": len(content.splitlines()),
        "step_count": count_step_patterns(content),
        "bold_count": len(re.findall(r"\*\*[^*\n]+\*\*", content)),
        "critical_count": len(re.findall(r"\bCRITICAL\b", content)),
        "dash_bullets": len(re.findall(r"^[-]\s", content, re.MULTILINE)),
        "md_headers": len(re.findall(r"^#{2,4}[^#\n]", content, re.MULTILINE)),
        "schema_markers": count_protocol_schema_markers(content),
    }


def parse_consistency_rows(markdown: str) -> list[dict[str, float | int | str]]:
    """Parse the markdown table from the consistency report."""
    rows: list[dict[str, float | int | str]] = []
    in_table = False
    for line in markdown.splitlines():
        if line.startswith("| Paper") and "Digest" in line:
            in_table = True
            continue
        if in_table and line.startswith("|---"):
            continue
        if in_table and line.startswith("| "):
            parts = [part.strip() for part in line.strip().strip("|").split("|")]
            if len(parts) < 9:
                continue
            try:
                rows.append(
                    {
                        "paper": parts[0],
                        "digest": int(parts[1]),
                        "mean": float(parts[2]),
                        "min": int(parts[3]),
                        "max": int(parts[4]),
                        "range": int(parts[5]),
                        "std": float(parts[6]),
                        "match": float(parts[7].replace("%", "")),
                        "variants": int(parts[8]),
                    }
                )
            except ValueError:
                pass
        elif in_table and not line.startswith("|"):
            in_table = False
    return rows


def load_variant_report(path: str | None = None) -> tuple[list[dict], list[dict]]:
    """Load the LLM-judge benchmark report.

    Defaults to the frozen artifact under ``tools/bpl_eval/data/``.
    """
    report_path = path or FROZEN_VARIANT_REPORT
    with open(report_path, encoding="utf-8") as handle:
        report = json.load(handle)

    papers = report["papers"]
    flat_variants = []
    for paper in papers:
        for variant in paper.get("variants", []):
            if variant is None:
                continue
            flat_variants.append(
                {
                    "paper": paper["paper_name"],
                    "version": variant.get("version", ""),
                    "overall": variant.get("overall_score", 0),
                    "exp_match": variant.get("experiment_match", 0),
                    "validity": variant.get("protocol_validity", 0),
                    "phase": variant.get("phase_completeness", 0),
                }
            )
    return papers, flat_variants


def load_consistency_rows(path: str | None = None) -> list[dict[str, float | int | str]]:
    """Load the regex step-count consistency report.

    Defaults to the frozen artifact under ``tools/bpl_eval/data/``.
    """
    report_path = path or FROZEN_CONSISTENCY_REPORT
    with open(report_path, encoding="utf-8") as handle:
        return parse_consistency_rows(handle.read())


def load_text_features(
    bpl_input_dir: str | None = None,
    structural_features_path: str | None = None,
) -> dict[str, dict[str, dict[str, int]]]:
    """Load per-paper-version structural features.

    Preference order:

    1. Frozen ``structural_features.json`` shipped with the repo. This is a
       deterministic precomputation over the per-paper-version markdown
       corpus that is itself excluded from the public repo for size and
       copyright reasons.
    2. Live recomputation from the locally-generated ``bpl_input/*.md``
       corpus, when present.
    """
    candidate = structural_features_path or FROZEN_STRUCTURAL_FEATURES
    if os.path.exists(candidate):
        with open(candidate, encoding="utf-8") as handle:
            data = json.load(handle)
        return data["papers"]

    text_data: dict[str, dict[str, dict[str, int]]] = defaultdict(dict)
    corpus_dir = bpl_input_dir or BPL_INPUT_DIR
    all_files = sorted(glob.glob(os.path.join(corpus_dir, "*.md")))

    print(f"Loading {len(all_files)} text files from {corpus_dir}...", flush=True)
    for index, filepath in enumerate(all_files):
        if index and index % 500 == 0:
            print(f"  {index}/{len(all_files)}", flush=True)
        match = BPL_FILENAME_RE.match(os.path.basename(filepath))
        if not match:
            continue
        paper_name, version = match.group(1), match.group(2)
        if version != "v00" and version not in EXPECTED_VARIANTS:
            continue
        with open(filepath, encoding="utf-8", errors="replace") as handle:
            text_data[paper_name][version] = extract_structural_features(handle.read())

    print(f"  Done. {len(text_data)} papers loaded.", flush=True)
    return text_data


def build_structural_projection(text_data: dict[str, dict[str, dict[str, int]]]) -> dict[str, object]:
    """Project raw papers and processed variants into a shared structural space."""
    feature_names = [
        "word_count",
        "line_count",
        "step_count",
        "bold_count",
        "critical_count",
        "dash_bullets",
    ]
    records = []
    for paper_name, versions in sorted(text_data.items()):
        for version, features in sorted(versions.items()):
            records.append(
                {
                    "paper": paper_name,
                    "version": version,
                    "is_raw": version == "v00",
                    "vector": [math.log1p(features[name]) for name in feature_names],
                }
            )

    if not records:
        raise RuntimeError(
            "No structural-feature records loaded. Either ship "
            f"{FROZEN_STRUCTURAL_FEATURES} or regenerate the bpl_input/ corpus "
            "and re-run the pipeline."
        )

    matrix = np.array([record["vector"] for record in records], dtype=float)
    scaled = StandardScaler().fit_transform(matrix)
    pca = PCA(n_components=2, random_state=42)
    projected = pca.fit_transform(scaled)

    is_raw = np.array([record["is_raw"] for record in records], dtype=bool)
    if projected[is_raw, 0].mean() < projected[~is_raw, 0].mean():
        projected[:, 0] *= -1

    return {
        "records": records,
        "projected": projected,
        "pca": pca,
        "is_raw": is_raw,
    }


def has_complete_variant_panel(paper: dict) -> bool:
    versions = {
        variant.get("version")
        for variant in paper.get("variants", [])
        if variant is not None
    }
    return all(version in versions for version in EXPECTED_VARIANTS)


def select_representative_papers(papers: list[dict], n: int = 20) -> list[dict]:
    """Balanced sampling across the avg_overall distribution."""
    complete = sorted(
        (paper for paper in papers if has_complete_variant_panel(paper)),
        key=lambda paper: paper["avg_overall"],
    )
    if n >= len(complete):
        return complete

    buckets = [bucket.tolist() for bucket in np.array_split(np.array(complete, dtype=object), 5)]
    selected: list[dict] = []

    for bucket in buckets:
        if not bucket:
            continue
        need = max(1, math.ceil((n - len(selected)) / max(1, len([b for b in buckets if b]))))
        take = min(need, len(bucket))
        indices = np.linspace(0, len(bucket) - 1, num=take, dtype=int)
        for index in indices:
            selected.append(bucket[index])
            if len(selected) == n:
                break
        if len(selected) == n:
            break

    if len(selected) < n:
        chosen = {paper["paper_name"] for paper in selected}
        for paper in complete:
            if paper["paper_name"] in chosen:
                continue
            selected.append(paper)
            if len(selected) == n:
                break

    return sorted(selected, key=lambda paper: paper["avg_overall"])


def bucket_step_ranges(ranges: list[int]) -> tuple[list[str], list[int]]:
    labels = ["0", "1", "2", "3-5", "6-10", ">10"]
    counts = [
        sum(value == 0 for value in ranges),
        sum(value == 1 for value in ranges),
        sum(value == 2 for value in ranges),
        sum(3 <= value <= 5 for value in ranges),
        sum(6 <= value <= 10 for value in ranges),
        sum(value > 10 for value in ranges),
    ]
    return labels, counts


def bucket_score_stds(values: list[float]) -> tuple[list[str], list[int]]:
    labels = ["0-1", "1-2", "2-3", "3-5", "5-10", "10-20", ">20"]
    counts = [
        sum(0 <= value < 1 for value in values),
        sum(1 <= value < 2 for value in values),
        sum(2 <= value < 3 for value in values),
        sum(3 <= value < 5 for value in values),
        sum(5 <= value < 10 for value in values),
        sum(10 <= value <= 20 for value in values),
        sum(value > 20 for value in values),
    ]
    return labels, counts


def normalize_paper_title(text: str) -> str:
    text = text.lower().replace("_", " ")
    text = re.sub(r"[^a-z0-9 ]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def classify_step_stability(
    papers: list[dict], rows: list[dict[str, float | int | str]], cutoff: float = 0.45
) -> list[bool]:
    row_map = {normalize_paper_title(str(row["paper"])): row for row in rows}
    row_keys = list(row_map)
    stable: list[bool] = []

    for paper in papers:
        paper_key = normalize_paper_title(str(paper["paper_name"]))
        match = difflib.get_close_matches(paper_key, row_keys, n=1, cutoff=cutoff)
        if not match:
            stable.append(False)
            continue
        stable.append(int(row_map[match[0]]["range"]) == 0)
    return stable


def summarize_step_alignment(rows: list[dict[str, float | int | str]]) -> dict[str, float | int]:
    deltas = [float(row["mean"]) - float(row["digest"]) for row in rows]
    abs_deltas = [abs(delta) for delta in deltas]
    return {
        "n": len(rows),
        "exact_matches": sum(delta == 0 for delta in deltas),
        "within_one_step": sum(delta <= 1 for delta in abs_deltas),
        "outliers_gt10": sum(int(row["range"]) > 10 for row in rows),
        "pearson_r": float(np.corrcoef([float(row["digest"]) for row in rows], [float(row["mean"]) for row in rows])[0, 1]),
        "mean_delta": float(np.mean(deltas)),
        "mean_range": float(np.mean([int(row["range"]) for row in rows])),
        "range_zero": sum(int(row["range"]) == 0 for row in rows),
        "range_le2": sum(int(row["range"]) <= 2 for row in rows),
    }


def build_centroid_shift_rows(
    records: list[dict[str, object]], projected: np.ndarray
) -> tuple[list[dict[str, float | str]], np.ndarray]:
    """Compare each raw paper to the center of processed protocol space."""
    is_raw = np.array([bool(record["is_raw"]) for record in records], dtype=bool)
    processed_centroid = projected[~is_raw].mean(axis=0)

    per_paper: dict[str, dict[str, list[np.ndarray]]] = defaultdict(lambda: {"raw": [], "after": []})
    for record, point in zip(records, projected):
        key = "raw" if bool(record["is_raw"]) else "after"
        per_paper[str(record["paper"])][key].append(point)

    rows: list[dict[str, float | str]] = []
    for paper, slots in per_paper.items():
        if not slots["raw"] or not slots["after"]:
            continue
        raw_point = np.mean(np.vstack(slots["raw"]), axis=0)
        after_center = np.mean(np.vstack(slots["after"]), axis=0)
        rows.append(
            {
                "paper": paper,
                "raw_distance": float(np.linalg.norm(raw_point - processed_centroid)),
                "after_distance": float(np.linalg.norm(after_center - processed_centroid)),
            }
        )

    return (
        sorted(
            rows,
            key=lambda row: (float(row["raw_distance"]), float(row["after_distance"]), str(row["paper"])),
            reverse=True,
        ),
        processed_centroid,
    )


def summarize_centroid_shift(rows: list[dict[str, float | str]]) -> dict[str, float | int]:
    raw = np.array([float(row["raw_distance"]) for row in rows], dtype=float)
    after = np.array([float(row["after_distance"]) for row in rows], dtype=float)
    reduction = (raw - after) / np.maximum(raw, 1e-9)

    return {
        "n": len(rows),
        "improved": int(np.sum(after < raw)),
        "not_improved": int(np.sum(after >= raw)),
        "median_raw": float(np.median(raw)),
        "median_after": float(np.median(after)),
        "mean_raw": float(np.mean(raw)),
        "mean_after": float(np.mean(after)),
        "median_reduction_pct": float(np.median(reduction) * 100),
    }


def summarize_before_after_structure(
    text_data: dict[str, dict[str, dict[str, int]]],
    projection: dict[str, object],
) -> list[dict[str, float | str]]:
    raw_features = []
    after_features = []
    for versions in text_data.values():
        if "v00" in versions:
            raw_features.append(versions["v00"])
        for version in EXPECTED_VARIANTS:
            if version in versions:
                after_features.append(versions[version])

    projected = np.array(projection["projected"], dtype=float)
    is_raw = np.array(projection["is_raw"], dtype=bool)
    raw_points = projected[is_raw]
    after_points = projected[~is_raw]

    after_centroid = after_points.mean(axis=0)
    raw_centroid = raw_points.mean(axis=0)

    raw_to_after = np.linalg.norm(raw_points - after_centroid, axis=1)
    after_to_after = np.linalg.norm(after_points - after_centroid, axis=1)
    raw_spread = np.linalg.norm(raw_points - raw_centroid, axis=1)
    after_spread = np.linalg.norm(after_points - after_centroid, axis=1)

    max_distance = max(float(raw_to_after.max()), float(after_to_after.max()), 1e-9)
    max_spread = max(float(raw_spread.max()), float(after_spread.max()), 1e-9)

    return [
        {
            "label": "Explicit steps (%)",
            "raw": float(np.mean([feature["step_count"] > 0 for feature in raw_features]) * 100),
            "after": float(np.mean([feature["step_count"] > 0 for feature in after_features]) * 100),
        },
        {
            "label": "Schema coverage (%)",
            "raw": float(np.mean([feature["schema_markers"] >= 3 for feature in raw_features]) * 100),
            "after": float(np.mean([feature["schema_markers"] >= 3 for feature in after_features]) * 100),
        },
        {
            "label": "Protocol proximity (%)",
            "raw": float((1 - np.median(raw_to_after) / max_distance) * 100),
            "after": float((1 - np.median(after_to_after) / max_distance) * 100),
        },
        {
            "label": "Structural compactness (%)",
            "raw": float((1 - np.mean(raw_spread) / max_spread) * 100),
            "after": float((1 - np.mean(after_spread) / max_spread) * 100),
        },
    ]


def cluster_processed_variants(
    projected: np.ndarray, is_raw: np.ndarray, n_clusters: int = 4
) -> tuple[np.ndarray, np.ndarray]:
    processed_points = projected[~is_raw]
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
    labels = kmeans.fit_predict(processed_points)
    centers = kmeans.cluster_centers_

    order = np.argsort(centers[:, 1])[::-1]
    remap = {int(old): int(new) for new, old in enumerate(order)}
    labels = np.array([remap[int(label)] for label in labels], dtype=int)
    centers = centers[order]
    return labels, centers


def shorten(text: str, limit: int = 34) -> str:
    text = text.replace("_", " ")
    return text if len(text) <= limit else text[:limit] + "..."


def save_figure(fig: Figure, stem: str) -> None:
    """Save a figure as a deterministic PDF and PNG pair (see figure_style_system.save_figure)."""
    pdf_metadata = {
        "Creator": "BPL paper evaluation pipeline",
        "Producer": "matplotlib",
        "CreationDate": None,
        "ModDate": None,
        "Title": stem,
    }
    fig.savefig(os.path.join(OUT, f"{stem}.pdf"), metadata=pdf_metadata)
    fig.savefig(os.path.join(OUT, f"{stem}.png"), metadata={"Software": "matplotlib"})
    plt.close(fig)
    print(f"  saved {stem}", flush=True)


def save_text(text: str, filename: str) -> None:
    with open(os.path.join(OUT, filename), "w", encoding="utf-8") as handle:
        handle.write(text.rstrip() + "\n")
    print(f"  saved {filename}", flush=True)


def find_content_bbox(image_array: np.ndarray, threshold: int = 245) -> tuple[int, int, int, int]:
    rgb = image_array[..., :3]
    mask = np.any(rgb < threshold, axis=2)
    coords = np.argwhere(mask)
    if coords.size == 0:
        height, width = image_array.shape[:2]
        return 0, 0, width, height
    y0, x0 = coords.min(axis=0)
    y1, x1 = coords.max(axis=0) + 1
    return int(x0), int(y0), int(x1), int(y1)


def prepare_panel_tile(
    filepath: str,
    tile_size: tuple[int, int] = (1600, 1200),
    padding: int = 60,
) -> np.ndarray:
    image = Image.open(filepath).convert("RGBA")
    bbox = find_content_bbox(np.array(image))
    trimmed = image.crop(bbox)

    available_width = tile_size[0] - 2 * padding
    available_height = tile_size[1] - 2 * padding
    scale = min(available_width / trimmed.width, available_height / trimmed.height)
    resized = trimmed.resize(
        (max(1, int(trimmed.width * scale)), max(1, int(trimmed.height * scale))),
        Image.Resampling.LANCZOS,
    )

    tile = Image.new("RGBA", tile_size, (255, 255, 255, 255))
    offset_x = (tile_size[0] - resized.width) // 2
    offset_y = (tile_size[1] - resized.height) // 2
    tile.paste(resized, (offset_x, offset_y), resized)
    return np.array(tile)


def make_preview_fig1(flat_variants: list[dict]) -> None:
    raise RuntimeError("make_preview_fig1 requires per-paper averages; call with papers instead.")


def draw_fig1(ax: Axes, papers: list[dict]) -> None:
    metrics = [
        ("Overall", "avg_overall", "#2166AC"),
        ("Exp. match", "avg_experiment_match", "#4DAC26"),
        ("Validity", "avg_protocol_validity", "#1A7837"),
        ("Phase", "avg_phase_completeness", "#D6604D"),
    ]
    rng = np.random.default_rng(42)
    y_min, y_max = 74, 102

    for x_pos, (_, key, color) in enumerate(metrics):
        data = np.array([float(paper[key]) for paper in papers], dtype=float)
        q1, med, q3 = np.percentile(data, [25, 50, 75])
        x_jitter = rng.uniform(-0.18, 0.18, len(data))
        ax.scatter(
            np.full(len(data), x_pos) + x_jitter,
            data,
            s=4,
            alpha=0.30,
            color=color,
            edgecolors="none",
            rasterized=True,
            zorder=2,
        )
        box = mpatches.FancyBboxPatch(
            (x_pos - 0.14, q1),
            0.28,
            q3 - q1,
            boxstyle="square,pad=0",
            facecolor=color,
            alpha=0.22,
            edgecolor=color,
            linewidth=0.9,
            zorder=3,
        )
        ax.add_patch(box)
        ax.plot(
            [x_pos - 0.14, x_pos + 0.14],
            [med, med],
            color=color,
            linewidth=1.8,
            solid_capstyle="butt",
            zorder=4,
        )
        ax.scatter([x_pos], [data.mean()], s=24, color=color, marker="D", linewidths=0, zorder=5)
        ax.text(
            x_pos,
            y_max - 0.2,
            f"{np.mean(data):.1f}",
            ha="center",
            va="top",
            fontsize=6.5,
            color=color,
            fontweight="bold",
        )

    ax.set_xlim(-0.55, len(metrics) - 0.45)
    ax.set_ylim(y_min, y_max)
    ax.set_xticks(range(len(metrics)))
    ax.set_xticklabels([metric[0] for metric in metrics])
    ax.set_ylabel("Score (0–100)")
    ax.yaxis.set_major_locator(mticker.MultipleLocator(5))
    ax.set_title("LLM validation scores per metric", pad=4)
    ax.grid(axis="x", visible=False)
    ax.text(
        0.03,
        0.02,
        f"n = {len(papers)}",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=6,
        color=C["gray"],
    )

    legend_items = [
        mlines.Line2D([0], [0], marker="D", color="w", markerfacecolor=C["gray"], markersize=5, label="Mean"),
        mlines.Line2D([0], [0], linewidth=2.5, color=C["gray"], alpha=0.6, label="Median"),
        mpatches.Patch(facecolor=C["gray"], alpha=0.25, edgecolor=C["gray"], linewidth=0.8, label="Q1–Q3"),
    ]
    ax.legend(
        handles=legend_items,
        loc="lower right",
        handlelength=1.2,
        labelspacing=0.3,
        borderpad=0.4,
        handletextpad=0.5,
        fontsize=PANEL_LEGEND_FONTSIZE,
        frameon=False,
    )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def make_preview_fig1_from_papers(papers: list[dict]) -> None:
    fig, ax = plt.subplots(figsize=(4.0, 3.2))
    draw_fig1(ax, papers)
    fig.tight_layout()
    save_figure(fig, "preview_fig1_validation")


def draw_fig2(ax: Axes, papers: list[dict], consistency_rows: list[dict[str, float | int | str]]) -> None:
    stable = np.array(classify_step_stability(papers, consistency_rows), dtype=bool)
    x_values = np.array([float(paper["avg_overall"]) for paper in papers], dtype=float)
    y_values = np.array([float(paper["std_overall"]) for paper in papers], dtype=float)
    x_min, x_max = 48, 102
    y_min, y_max = -1, 48

    ax.scatter(
        x_values[stable],
        y_values[stable],
        s=11,
        color="#2166AC",
        alpha=0.50,
        linewidths=0,
        zorder=3,
        label=f"Step-stable (n={stable.sum()})",
    )
    ax.scatter(
        x_values[~stable],
        y_values[~stable],
        s=26,
        color="#D6604D",
        alpha=0.90,
        linewidths=0.5,
        edgecolors="white",
        zorder=4,
        marker="D",
        label=f"Step-variable (n={(~stable).sum()})",
    )

    ax.axvline(x_values.mean(), color="#2166AC", linewidth=0.7, linestyle="--", alpha=0.6, zorder=2)
    ax.axhline(y_values.mean(), color=C["gray"], linewidth=0.7, linestyle="--", alpha=0.6, zorder=2)
    ax.text(
        x_values.mean() - 0.8,
        y_max - 1,
        f"Mean = {x_values.mean():.1f}",
        fontsize=5.5,
        color="#2166AC",
        va="top",
        ha="right",
    )
    ax.text(
        x_min + 0.8,
        y_values.mean() + 0.8,
        f"Mean SD = {y_values.mean():.1f}",
        fontsize=5.5,
        color=C["gray"],
        va="bottom",
        ha="left",
    )

    ax.set_xlabel("Mean overall score")
    ax.set_ylabel("SD of overall score (across 10 variants)")
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.xaxis.set_major_locator(mticker.MultipleLocator(10))
    ax.yaxis.set_major_locator(mticker.MultipleLocator(10))
    ax.legend(
        loc="upper left",
        markerscale=1.2,
        labelspacing=0.3,
        borderpad=0.4,
        handletextpad=0.5,
        fontsize=PANEL_LEGEND_FONTSIZE,
        frameon=False,
    )

    ax.set_title("Score level vs. inter-variant consistency", pad=4)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def make_preview_fig2(papers: list[dict], consistency_rows: list[dict[str, float | int | str]]) -> None:
    fig, ax = plt.subplots(figsize=(4.8, 3.2))
    draw_fig2(ax, papers, consistency_rows)
    fig.tight_layout()
    save_figure(fig, "preview_fig2_score_consistency")


def draw_fig3(ax: Axes, projection: dict[str, object]) -> None:
    projected = np.array(projection["projected"], dtype=float)
    pca = projection["pca"]
    is_raw = np.array(projection["is_raw"], dtype=bool)
    cluster_labels, _ = cluster_processed_variants(projected, is_raw, n_clusters=4)
    cluster_colors = [C["bpl"], C["teal"], C["green"], C["orange"]]
    for cluster_id, color in enumerate(cluster_colors):
        mask = cluster_labels == cluster_id
        if not np.any(mask):
            continue
        ax.scatter(
            projected[~is_raw][mask, 0],
            projected[~is_raw][mask, 1],
            s=7,
            alpha=0.26,
            color=color,
            edgecolors="none",
            rasterized=True,
            zorder=2,
        )

    ax.scatter(
        projected[is_raw, 0],
        projected[is_raw, 1],
        s=14,
        alpha=0.50,
        color=C["raw"],
        marker="s",
        edgecolors="white",
        linewidths=0.20,
        rasterized=True,
        zorder=3,
    )

    raw_center = projected[is_raw].mean(axis=0)
    bpl_center = projected[~is_raw].mean(axis=0)
    ax.annotate(
        "Natural language\n(diverse structure)",
        xy=(raw_center[0], raw_center[1]),
        xytext=(raw_center[0] + 0.5, raw_center[1] + 1.2),
        fontsize=7,
        color=C["raw"],
        fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=C["raw"], lw=1.0),
    )
    ax.annotate(
        "Processed variants\n(unified structure)",
        xy=(bpl_center[0], bpl_center[1]),
        xytext=(bpl_center[0] - 2.2, bpl_center[1] - 1.1),
        fontsize=7,
        color=C["bpl"],
        fontweight="bold",
        arrowprops=dict(arrowstyle="->", color=C["bpl"], lw=1.0),
    )

    explained = pca.explained_variance_ratio_
    ax.set_xlabel(f"PC1 ({explained[0] * 100:.1f}% variance)")
    ax.set_ylabel(f"PC2 ({explained[1] * 100:.1f}% variance)")
    ax.set_title("Style unification in structural feature space")
    ax.legend(
        handles=[
            Line2D([0], [0], marker="s", linestyle="", color="w", markerfacecolor=C["raw"], markersize=7, label="Natural language"),
            Line2D([0], [0], marker="o", linestyle="", color="w", markerfacecolor=C["bpl"], markeredgecolor=C["bpl"], markersize=6, label="Processed variants"),
        ],
        loc="upper left",
        handletextpad=0.35,
        borderpad=0.2,
        labelspacing=0.3,
        fontsize=PANEL_LEGEND_FONTSIZE,
        frameon=False,
    )


def make_preview_fig3(projection: dict[str, object]) -> None:
    fig, ax = plt.subplots(figsize=(8.6, 6.2))
    draw_fig3(ax, projection)
    fig.tight_layout()
    save_figure(fig, "preview_fig3_style_pca")


def draw_fig4(
    ax: Axes,
    text_data: dict[str, dict[str, dict[str, int]]],
    projection: dict[str, object],
) -> None:
    metrics = summarize_before_after_structure(text_data, projection)
    x = np.arange(len(metrics))
    width = 0.34

    raw_values = [metric["raw"] for metric in metrics]
    after_values = [metric["after"] for metric in metrics]

    raw_bars = ax.bar(
        x - width / 2,
        raw_values,
        width=width,
        color=C["red"],
        edgecolor="white",
        linewidth=0.8,
        label="Natural language",
        zorder=3,
    )
    after_bars = ax.bar(
        x + width / 2,
        after_values,
        width=width,
        color=C["bpl"],
        edgecolor="white",
        linewidth=0.8,
        label="Processed variants",
        zorder=3,
    )

    for bars in (raw_bars, after_bars):
        for bar in bars:
            height = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                height + 1.4,
                f"{height:.1f}",
                ha="center",
                va="bottom",
                fontsize=8,
                fontweight="bold",
            )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [
            "Explicit\nsteps (%)",
            "Schema\ncoverage (%)",
            "Protocol\nproximity (%)",
            "Structural\ncompactness (%)",
        ]
    )
    ax.set_ylim(0, 105)
    ax.set_ylabel("Value")
    ax.set_title("BPL vs natural language: structural protocolization")
    ax.legend(
        loc="upper right",
        bbox_to_anchor=(1.03, 1.01),
        handletextpad=0.35,
        borderpad=0.2,
        labelspacing=0.3,
        fontsize=PANEL_LEGEND_FONTSIZE,
        frameon=False,
    )
    ax.grid(axis="x", visible=False)
    ax.tick_params(axis="x", pad=7)
    ax.spines["bottom"].set_zorder(10)


def make_preview_fig4(
    text_data: dict[str, dict[str, dict[str, int]]],
    projection: dict[str, object],
) -> None:
    fig, ax = plt.subplots(figsize=(8.8, 5.4))
    draw_fig4(ax, text_data, projection)
    fig.tight_layout()
    save_figure(fig, "preview_fig4_bpl_advantage")


def make_composite_abcd_figure(
    papers: list[dict],
    consistency_rows: list[dict[str, float | int | str]],
    text_data: dict[str, dict[str, dict[str, int]]],
    projection: dict[str, object],
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(8.6, 6.8))
    ax_a, ax_b, ax_c, ax_d = axes.flat

    draw_fig1(ax_a, papers)
    draw_fig2(ax_b, papers, consistency_rows)
    draw_fig3(ax_c, projection)
    draw_fig4(ax_d, text_data, projection)

    for ax, label in zip(axes.flat, ["a", "b", "c", "d"]):
        ax.text(
            -0.12,
            1.06,
            label,
            transform=ax.transAxes,
            fontsize=12,
            fontweight="bold",
            ha="left",
            va="bottom",
            color="#111111",
        )

    fig.subplots_adjust(left=0.08, right=0.985, top=0.965, bottom=0.08, wspace=0.22, hspace=0.34)
    save_figure(fig, "paper_figures_abcd")


def build_composite_caption(
    papers: list[dict],
    flat_variants: list[dict],
    text_data: dict[str, dict[str, dict[str, int]]],
    projection: dict[str, object],
    consistency_rows: list[dict[str, float | int | str]],
) -> str:
    stable = np.array(classify_step_stability(papers, consistency_rows), dtype=bool)
    structure_metrics = summarize_before_after_structure(text_data, projection)
    structure_map = {str(metric["label"]): metric for metric in structure_metrics}

    raw_docs = sum("v00" in versions for versions in text_data.values())
    processed_docs = sum(
        1
        for versions in text_data.values()
        for version in EXPECTED_VARIANTS
        if version in versions
    )

    overall_mean = np.mean([float(variant["overall"]) for variant in flat_variants])
    exp_mean = np.mean([float(variant["exp_match"]) for variant in flat_variants])
    valid_mean = np.mean([float(variant["validity"]) for variant in flat_variants])
    phase_mean = np.mean([float(variant["phase"]) for variant in flat_variants])

    return (
        "Figure X | BPL converts heterogeneous protocol papers into high-quality, structurally consistent protocol outputs.\n\n"
        "A, LLM validation scores across all processed variants. Overall score, experiment match, protocol validity, and phase completeness all remain high "
        f"(means: {overall_mean:.1f}, {exp_mean:.1f}, {valid_mean:.1f}, and {phase_mean:.1f}, respectively; n = {len(papers)} papers, {len(flat_variants)} variants).\n\n"
        "B, Inter-variant consistency at the paper level. Most papers cluster in the high-score, low-variance regime, and "
        f"{stable.sum()} of {len(papers)} papers are step-stable whereas only {(~stable).sum()} are step-variable.\n\n"
        f"C, PCA projection of structural document features for {raw_docs} raw papers and {processed_docs} BPL outputs. Raw papers occupy a diffuse region of feature space, whereas BPL outputs collapse into a much tighter protocol-like manifold.\n\n"
        "D, Quantitative summary of before-versus-after structural protocolization. Relative to raw papers, BPL outputs show higher rates of explicit step structure "
        f"({structure_map['Explicit steps (%)']['raw']:.1f}% -> {structure_map['Explicit steps (%)']['after']:.1f}%), broader canonical protocol schema coverage "
        f"({structure_map['Schema coverage (%)']['raw']:.1f}% -> {structure_map['Schema coverage (%)']['after']:.1f}%), greater proximity to the processed-protocol region in PCA space "
        f"({structure_map['Protocol proximity (%)']['raw']:.1f}% -> {structure_map['Protocol proximity (%)']['after']:.1f}%), and higher structural compactness "
        f"({structure_map['Structural compactness (%)']['raw']:.1f}% -> {structure_map['Structural compactness (%)']['after']:.1f}%)."
    )


def main() -> None:
    print("Loading variant report...", flush=True)
    papers, flat_variants = load_variant_report()
    print(f"  {len(papers)} papers, {len(flat_variants):,} variants", flush=True)

    text_data = load_text_features()
    total_files = sum(len(version_map) for version_map in text_data.values())
    print(f"Text feature records: {total_files:,}", flush=True)
    projection = build_structural_projection(text_data)

    print("Generating preview figures...", flush=True)
    consistency_rows = load_consistency_rows()
    make_preview_fig1_from_papers(papers)
    make_preview_fig2(papers, consistency_rows)
    make_preview_fig3(projection)
    make_preview_fig4(text_data, projection)
    make_composite_abcd_figure(papers, consistency_rows, text_data, projection)
    save_text(
        build_composite_caption(papers, flat_variants, text_data, projection, consistency_rows),
        "paper_figures_abcd_caption.txt",
    )

    print(f"Done. Preview figures saved in {OUT}", flush=True)


if __name__ == "__main__":
    main()
