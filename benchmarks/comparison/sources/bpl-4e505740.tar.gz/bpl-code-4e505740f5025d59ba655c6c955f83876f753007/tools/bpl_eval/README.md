# BPL Evaluation Workflow

This directory is the paper-facing evaluation pipeline. It contains the
complete workflow used in the BPL manuscript: protocol-text extraction,
constrained variant rewriting, BPL compilation, LLM-judged comparison,
local consistency analysis, and publication-figure generation.

## Glossary

* **BPL-COGEN** — the SOP-to-BPL Compiler-Guided Generation pipeline
  (`bplc sop-generate`): a natural-language SOP enters, a BPL program
  emerges, and the BPL compiler oracle is invoked to gate every
  candidate.
* **Compiler oracle** — the BPL compiler running in validate-only mode,
  used by BPL-COGEN to accept/reject candidate generations against the
  six-gate pipeline (parse → semantic → plan/DAG → experiment-parameter
  → capability → backend preflight).
* **Frozen / paper-grade artifact** — a checked-in summary input under
  `tools/bpl_eval/data/` (e.g. `variant_report.json`,
  `consistency_report.md`, `structural_features.json`) used by the
  figure scripts so the publication figures regenerate offline without
  the raw corpus or API access.
* **Consistency report** — the regex step-count consistency table
  (`data/consistency_report.md`) produced over the LLM-expanded SOP
  variants by `analyze_consistency.py`. The figure-3 panel and
  `compute_determinism.py` headline numbers derive from this table.
* **Structural-determinism summary** — the figure-3 headline metrics
  (mean step-count range, identical-runs percentage, mean
  match-vs-digest percentage) recomputed from the consistency report
  by `compute_determinism.py` and written to
  `data/determinism_results.json`.
* **Per-paper LLM-judge record** — one JSON under
  `data/variant_comparisons/per_paper/<paper>.json` containing the
  scoring across the three orthogonal axes (experiment match, protocol
  validity, phase completeness) for every generated variant of one
  Nature Protocols reference paper.

## Paper-experiment coverage

The repository's offline reproduction package re-derives the headline
LLM-validation, sensitivity, structural-determinism, and HPLC→UHPLC
method-translation numbers from shipped artifacts. Wet-lab observations
(Sanger sequencing, plate-reader fluorescence) and other figure-3 / fig-4
panel counts (compiler diagnostic categories, repair-loop outcomes, PCR
amplification counts) are encoded directly from the paper text into
checked-in JSON/CSV files and rendered by the figure scripts; running
those upstream experiments from scratch requires inputs that are not
shipped (raw Nature Protocols PDF corpus, OpenRouter API access, the
liquid-handling robot, the chromatographic instrument). The table below
states which kind of trace each claim has.

The table below maps the headline paper claims to their reproducer +
frozen artifact + paper-claim guard-rail test. It is a SUBSET of the 22
tests in `tests/eval/test_eval_pipeline.py`; the remaining tests cover
shape, schema, and release-contract checks (artifact existence, JSON
shape, byte-stable PDF re-render, etc.).

| Paper claim | Reproducer | Frozen result | Test |
|---|---|---|---|
| Fig 2 LLM-validation scores (300 papers, 2,992 variants) | `redraw_publication_figures.py` reads `data/variant_comparisons/` | `data/variant_comparisons/` | `test_load_variant_report_offline` |
| Fig 2 PCA over 6 structural features | `generate_figures.build_structural_projection` | `data/structural_features.json` | `test_structural_projection_shape_and_split` |
| Fig 3 inter-variant step stability (295/300) | `compute_determinism.py` reads `data/consistency_report.md` | `data/determinism_results.json` | `test_compute_determinism_headline_matches_paper_claim` |
| Fig 4 compiler diagnostic categories (343 across 5) | `data/diagnostics/diagnostic_categories.json` | same | `test_compiler_diagnostic_counts_match_paper` |
| Fig 4 repair-loop outcomes (panel-collapsed: 82.3 / 16.3 / 1.4 %; raw paper split: 82.3 / 12.1 / 4.2 / 1.4 %) | `data/diagnostics/repair_loop_outcomes.json` | same | `test_repair_loop_outcomes_match_paper` |
| Fig 5 PCR amplification (11/11 inserts; 11/11 vs 10→11/11 vectors) | `redraw_publication_figures.py` reads `data/wetlab/pcr_amplification.csv` | same | `test_pcr_amplification_csv_matches_paper` |
| Fig 5 HPLC→UHPLC method translation (ChP 0512) | `method_translation.py` calls `bpl/agentic/column_catalog.convert_method` | `data/method_translation/hplc_to_uhplc.json` | `test_method_translation_matches_paper` |
| Methods §103 sensitivity analysis (44-triplet weight grid; paper reports 47, see script docstring for the boundary-convention note) | `sensitivity_analysis.py` reads variant-axis scores | `data/sensitivity_results.json` | `test_sensitivity_analysis_reproduces_insensitivity_claim` |

Stages of the upstream BPL pipeline that require external inputs (the raw
PDF corpus, OpenRouter API for LLM calls, the actual liquid-handling
robot, the chromatographic instrument) are documented in the per-stage
runbook below. Their inputs are out of scope for offline reproduction.

## What Reproduces Offline

The eight publication figures
(`figures/publication_redraw/fig{1,2,2a,3,4,5,6,7}_*.{pdf,png}`) re-render
entirely from the frozen artifacts shipped under `data/`:

- `data/variant_comparisons/variant_report.json` — LLM-judge scores
  (300 papers × ~10 variants).
- `data/variant_comparisons/per_paper/*.json` — per-paper aggregated scores.
- `data/consistency_report.md` — regex step-count consistency table.
- `data/structural_features.json` — precomputed structural features for every
  per-paper-version markdown file used by the PCA panel.
- `data/determinism_results.json` — recomputed figure-3 headline summary
  (mean step-count range, identical-runs percentage, mean match-vs-digest
  percentage). Regenerable from `data/consistency_report.md` plus the
  per-paper records by `compute_determinism.py`.

> **Note on the 301 vs 300 paper count.** `consistency_report.md` covers
> 301 papers (one paper has a digest but its LLM-judge record was excluded
> from the rolled-up `variant_comparisons/`); the per-paper LLM-judge
> records and the headline-figure caption use the 300-paper subset.
> `compute_determinism.py` reports the consistency-report `n_papers` (301)
> as the figure metric and surfaces the per-paper coverage `n_papers`
> (300) and `total_scored_variants` (2,991, with three papers below the
> 10-variant target) separately so a reviewer can tell the two scopes
> apart at a glance.

To regenerate every paper figure offline (no API keys, no raw corpus):

```bash
uv run python tools/bpl_eval/redraw_publication_figures.py
```

The `scripts/reproduce_paper.py` workflow runs this stage automatically and
verifies that all expected PDFs land in
`tools/bpl_eval/figures/publication_redraw/`.

## What Requires External Inputs

The full data-generation pipeline needs `OPENROUTER_API_KEY` plus the raw
Nature Protocols corpus, which is not part of this repository (publisher
licensing). The pipeline scripts are checked in so reviewers can read the
exact prompts and parameters used in the paper.

| Stage | Script | Output | Inputs |
|---|---|---|---|
| 1 — extract Procedure sections | (vision LLM, run separately) | `extracted_vision/*.json` | Raw PDFs |
| 2 — digest | `generate_digests.py` | `digests/*.json` | `extracted_vision/` + API |
| 3 — expand to N variants | `generate_variants.py` | `variants/*.json` | `digests/` + API |
| 4 — export per-version markdown | `export_for_bpl.py` | `bpl_input/*.md` | `extracted_vision/` + `variants/` |
| 5 — compile to BPL + compose | `compile_bpl.py` | `bpl_output/*.bpl`, `protocols/*.protocol.md` | `bpl_input/` + API (`bplc sop-generate`) |
| 6 — local consistency analysis | `analyze_consistency.py` | `comparisons/variant_analysis/consistency_report.md` | `variants/` |
| 7 — LLM-judge comparison | `compare_variants.py` | `variant_comparisons/per_paper/*.json`, `variant_report.json` | `protocols/` + API |
| 8 — determinism summary | `compute_determinism.py` | `data/determinism_results.json` | `data/consistency_report.md` + `data/variant_comparisons/per_paper/*.json` |
| 9 — figures | `redraw_publication_figures.py` | `figures/publication_redraw/*.{pdf,png}` | frozen `data/*` artifacts (above) |

## Directory Layout

```
tools/bpl_eval/
├── config.py                          Path and model constants
├── llm_client.py                      Shared OpenRouter helpers
├── prompts.py                         Digest + variant-expansion prompts
├── compare_prompts.py                 LLM-judge prompts
├── generate_digests.py                Stage 2
├── generate_variants.py               Stage 3
├── export_for_bpl.py                  Stage 4
├── compile_bpl.py                     Stage 5
├── analyze_consistency.py             Stage 6
├── compare_variants.py                Stage 7
├── compute_determinism.py             Stage 8
├── figure_style_system.py             Shared matplotlib style
├── generate_figures.py                Preview figures + data loaders
├── redraw_publication_figures.py      Stage 9 — paper figures
├── sensitivity_analysis.py            Methods §103 weight-grid analysis
├── method_translation.py              Fig 5 HPLC→UHPLC ChP 0512 reproducer
├── data/                              Frozen paper-grade artifacts
│   ├── variant_comparisons/
│   │   ├── variant_report.json
│   │   ├── variant_validation_results.xlsx
│   │   └── per_paper/*.json
│   ├── consistency_report.md
│   ├── structural_features.json
│   ├── determinism_results.json
│   ├── sensitivity_results.json
│   ├── diagnostics/
│   │   ├── diagnostic_categories.json
│   │   └── repair_loop_outcomes.json
│   ├── method_translation/
│   │   ├── hplc_to_uhplc.json
│   │   └── retention_times.csv
│   └── wetlab/
│       ├── pcr_amplification.csv
│       └── promoter_library.csv
└── figures/publication_redraw/        Frozen paper figures (regenerable)
```

Working directories that the API-driven pipeline writes (`extracted/`,
`extracted_vision/`, `digests/`, `variants/`, `bpl_input/`, `bpl_output/`,
`protocols/`, `variant_comparisons/`, `comparisons/`, `checkpoint*.json`) are
git-ignored — they are recreated by re-running the relevant stage and are not
part of the public release.

## Reproduce From Scratch (Requires API + Corpus)

```bash
export OPENROUTER_API_KEY=...
uv run python tools/bpl_eval/generate_digests.py --batch 5
uv run python tools/bpl_eval/generate_variants.py --batch 5
uv run python tools/bpl_eval/export_for_bpl.py
uv run python tools/bpl_eval/compile_bpl.py --workers 4
uv run python tools/bpl_eval/analyze_consistency.py
uv run python tools/bpl_eval/compare_variants.py --resume
uv run python tools/bpl_eval/redraw_publication_figures.py
```

Smoke-testing flags by stage:

* `generate_digests.py` and `generate_variants.py` accept `--test`,
  `--test-n N`, and `--limit N`.
* `export_for_bpl.py` accepts `--dry-run` and `--limit N`.
* `compile_bpl.py`, `analyze_consistency.py`, `compute_determinism.py`,
  `redraw_publication_figures.py`, and `sensitivity_analysis.py` operate
  over the entire input directory by design and have no per-stage
  smoke-test flag — pass a smaller `--input` directory or pre-filtered
  data path to control scope.

The from-scratch runbook above is provenance documentation: stages 1-7
require external inputs (raw Nature Protocols PDF corpus, OpenRouter API
access) and are not runnable in one shot from the public release alone.

## Model provenance

To remove ambiguity about which model produced which artifact:

| Artifact / stage | Model | Source |
|---|---|---|
| Stage 2 — protocol digests (`digests/*.json`) | Rotation across `MODELS` in `config.py` (Claude Opus 4.6, GPT-5.3-codex, Gemini 3.1 Pro Preview) | Selected by `generate_digests.py` per call |
| Stage 3 — variant generation (`variants/*.json`) | Same `MODELS` rotation | Selected by `generate_variants.py` per call |
| Stage 5 — `bplc sop-generate` | Default `openrouter:google/gemini-3.1-pro-preview-customtools` (`bpl/agentic/workflow.py:_DEFAULT_MODEL`); override via `BPL_SOP_MODEL` env var | Compiled BPL outputs in `bpl_output/` |
| Stage 7 — LLM-judge comparison (`variant_comparisons/per_paper/*.json`, `variant_report.json`) | `anthropic/claude-sonnet-4-6` (recorded as `model_used` on every variant scoring record) | Set as `DEFAULT_MODEL` in `compare_variants.py` |
| Figure-3 headline metric | Derived from `data/consistency_report.md` (regex over LLM-expanded SOP step counts; no model invoked at figure time) | `compute_determinism.py` |

The eight publication figures themselves are matplotlib renderings, not LLM
outputs. Diagram-style panels (fig1, fig4, fig5, fig6, fig7) carry numbers
that summarise the manuscript's described experiments; those underlying
experiments are not part of the offline reproduction package and are not
re-derivable from this repository alone.

## Natural-language comparator

The right-hand panel of `fig3_structural_determinism` includes a
"Natural language" comparator series with values `[35.0, 45.0, 5.0, 8.5]`.
These values are illustrative estimates retained from earlier manuscript
revisions to motivate the BPL/NL contrast — they are not measurements
produced by any pipeline in this repository, and the legend labels them as
`(est.)` to make this explicit.

The BPL series in the same panel is read from
`data/determinism_results.json` at figure-render time, so the two halves
of the figure cannot drift out of sync with each other or with
`compute_determinism.py`.

## Reproduce Figures Only (Offline, No API)

```bash
uv run python tools/bpl_eval/redraw_publication_figures.py
```

This is the default branch exercised by `scripts/reproduce_paper.py`.

## Recomputing `structural_features.json`

The shipped JSON was produced by running `extract_structural_features` over
the locally-generated `bpl_input/*.md` corpus. To recompute it after
regenerating the corpus:

```bash
uv run python -c "
import os, json, glob, sys
sys.path.insert(0, 'tools/bpl_eval')
from generate_figures import extract_structural_features, BPL_FILENAME_RE, EXPECTED_VARIANTS
from collections import defaultdict
papers = defaultdict(dict)
for fp in sorted(glob.glob('tools/bpl_eval/bpl_input/*.md')):
    m = BPL_FILENAME_RE.match(os.path.basename(fp))
    if not m: continue
    paper, version = m.group(1), m.group(2)
    if version != 'v00' and version not in EXPECTED_VARIANTS:
        continue
    with open(fp, encoding='utf-8', errors='replace') as h:
        papers[paper][version] = extract_structural_features(h.read())
sorted_papers = {p: dict(sorted(versions.items())) for p, versions in sorted(papers.items())}
out = 'tools/bpl_eval/data/structural_features.json'
with open(out, 'w') as h:
    json.dump({'papers': sorted_papers, 'n_papers': len(sorted_papers)}, h, indent=2)
print('Wrote', out)
"
```

## Recomputing `determinism_results.json`

```bash
uv run python tools/bpl_eval/compute_determinism.py
```
