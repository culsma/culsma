# Examples

This directory contains small public examples that can be run without access to
the source SOP corpus or private lab inventory files.

Run the minimal protocol through the compiler:

```bash
uv run bplc check examples/minimal_protocol.bpl
uv run bplc parse examples/minimal_protocol.bpl --format json --out examples/generated/minimal.ast.json
uv run bplc lower examples/minimal_protocol.bpl --target human --out examples/generated/minimal.plan.json
uv run bplc validate examples/minimal_protocol.bpl --target human
uv run bplc graph examples/minimal_protocol.bpl --format mermaid --out examples/generated/minimal.graph.mmd
```
