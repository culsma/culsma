# Paper Reproducibility

This repository is prepared as an offline, paper-level code package for BPL.
The reproducibility workflow verifies the install, exercises the compiler CLI on
a public example protocol, recomputes the lightweight benchmark summary shipped
with the repository, and runs the code-quality checks used for release.

## Setup

```bash
uv sync --dev
```

## One-Command Workflow

```bash
uv run python scripts/reproduce_paper.py
```

The command writes generated files to `paper_artifacts/`, including:

- `paper_artifacts/example/minimal.ast.json`
- `paper_artifacts/example/minimal.plan.json`
- `paper_artifacts/example/minimal.trace.json`
- `paper_artifacts/example/minimal.worklist.csv`
- `paper_artifacts/example/minimal.graph.json`
- `paper_artifacts/benchmark/determinism_results.json`
- `paper_artifacts/reproducibility_manifest.json`
- command logs under `paper_artifacts/logs/`

It also re-renders the paper figures in place at
`tools/bpl_eval/figures/publication_redraw/fig{1,2,2a,3,4,5,6,7}_*.{pdf,png}`
(eight figures total, including the single-panel companion `fig2a`).

For a faster smoke run while editing:

```bash
uv run python scripts/reproduce_paper.py \
    --skip-tests --skip-pyright --skip-build --skip-eval-figs
```

## What This Reproduces

The workflow is fully offline and public-data safe. It reproduces:

- BPL package import and CLI execution.
- Syntax, parse, lower, validate, simulate, export, and graph generation for a
  public example BPL protocol.
- Figure-3 structural-determinism headline statistics, recomputed from
  the shipped `tools/bpl_eval/data/consistency_report.md` (regex
  step-count consistency) plus per-paper coverage stats from
  `tools/bpl_eval/data/variant_comparisons/per_paper/*.json`.
- The eight paper figures
  (`tools/bpl_eval/figures/publication_redraw/fig{1,2,2a,3,4,5,6,7}_*.{pdf,png}`)
  re-rendered from the frozen evaluation artifacts under
  `tools/bpl_eval/data/`.
- The Methods §103 score-weighting sensitivity analysis (44-triplet grid
  under the weak-ordering interpretation; the paper reports 47, see
  `tools/bpl_eval/sensitivity_analysis.py` for the boundary-convention note),
  recomputed from the per-variant LLM-judge axes; assertions confirm the
  paper's [93.9, 96.6] / [96.0, 97.3] / [97.4, 98.5]% / [2.85, 3.71]
  ranges are reproduced.
- The Fig 5 HPLC→UHPLC method translation, recomputed via the 2025
  Chinese Pharmacopoeia 0512 scaling formulae implemented in
  `bpl/agentic/column_catalog.convert_method`; assertions confirm the
  paper's 0.613 mL/min flow rate, 14.7× run-time reduction, and
  four compliance warnings.
- Full test suite, type check, and package build unless explicitly skipped.

## What This Does Not Reproduce

The public package does not include raw copyrighted source articles, private
SOP documents, large training outputs, model checkpoints, manuscript drafts,
or API response artifacts. Stages of the evaluation pipeline that require
external inputs — `bplc sop-generate`, `tools/bpl_eval/generate_digests.py`,
`tools/bpl_eval/generate_variants.py`, `tools/bpl_eval/compile_bpl.py`, and
`tools/bpl_eval/compare_variants.py` — are part of the shipped software but
are not part of the offline paper workflow because they require
user-provided API credentials and the raw PDF corpus. See
[`tools/bpl_eval/README.md`](../tools/bpl_eval/README.md) for the full
pipeline documentation.

The generated evaluation artifacts used for downstream inspection are hosted
as the Hugging Face dataset
[`BotaBio/BPL-EVAL`](https://huggingface.co/datasets/BotaBio/BPL-EVAL). See
[`BPL_EVAL_DATASET.md`](BPL_EVAL_DATASET.md) for commands that download the
dataset into `tools/bpl_eval/` and run the analysis scripts against it.
