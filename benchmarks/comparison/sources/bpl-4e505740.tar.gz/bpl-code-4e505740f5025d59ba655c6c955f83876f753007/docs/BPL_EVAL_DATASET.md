# Using The BPL-EVAL Dataset

The public code repository is the canonical source for BPL compiler code,
evaluation scripts, tests, and lightweight offline reproduction artifacts.
The full generated evaluation artifacts are published separately as a
Hugging Face dataset:

https://huggingface.co/datasets/BotaBio/BPL-EVAL

This split keeps the code repository small and reviewable while still making
the full evaluation outputs available for inspection and downstream analysis.

## What Is In The Dataset

The dataset contains generated data and result artifacts only:

```text
digests/                Structured digest JSON files
variants/               Generated protocol variants
bpl_input/              Exported markdown SOP inputs, v00-v10
bpl_output/             Compiled .bpl files and metadata
protocols/              Composed protocol markdown outputs
comparisons/            Local consistency reports and checkpoints
variant_comparisons/    LLM-judge comparison outputs
figures/                Generated paper figures
extracted/              Source extraction JSON artifacts
extracted_vision/       Vision-extraction JSON artifacts
```

The dataset intentionally does not include original article PDFs.

## Download Into This Repository

Install the code repository first:

```bash
git clone https://gitlab.com/bota-biosciences-public/bpl-code.git
cd bpl-code
uv sync --dev
```

Then download BPL-EVAL into the evaluation directory expected by the scripts:

```bash
huggingface-cli download BotaBio/BPL-EVAL \
  --repo-type dataset \
  --local-dir tools/bpl_eval \
  --local-dir-use-symlinks False
```

If your Hugging Face CLI uses the newer `hf` command, the equivalent is:

```bash
hf download BotaBio/BPL-EVAL \
  --repo-type dataset \
  --local-dir tools/bpl_eval \
  --local-dir-use-symlinks False
```

## Example Analyses

After downloading the dataset, the evaluation scripts can read the artifacts
directly:

```bash
uv run python tools/bpl_eval/analyze_consistency.py
uv run python tools/bpl_eval/compare_variants.py --report-only
uv run python tools/bpl_eval/redraw_publication_figures.py
```

For the lightweight paper-level offline reproduction path that does not require
the full dataset, run:

```bash
uv run python scripts/reproduce_paper.py
```

That command uses the small frozen artifacts already checked into
`tools/bpl_eval/data/`.
