# Column Method Conversion: Long → Short

> Source document: `RT 2.1min Method.docx`
> Conversion engine: `bpl/agentic/column_catalog.py`
> Formulas: 2025 Chinese Pharmacopoeia (中国药典) 0512
> Generated: 2026-03-20

---

## Source Column (Long)

| Parameter | Value |
|-----------|-------|
| Column | Agilent ValueLab LC C18 170A |
| Part # | 588965-902 |
| Dimensions | 4.6 × 250 mm |
| Particle size | 5.0 µm (fully porous) |
| Pore size | 170 Å |
| L/dp | 50,000 |
| Column volume | 4,154.8 µL |
| Max pressure | 400 bar |

## Source Method

| Parameter | Value |
|-----------|-------|
| Flow rate | 1.0 mL/min |
| Injection volume | 10.0 µL |
| Column temperature | 50 °C |
| Detection | DAD at 328, 382, 452, 475, 210 nm |
| Mobile phase A | Ultrapure water (超纯水) |
| Mobile phase B | Acetonitrile/Isopropanol 75:25 (乙腈/异丙醇 75/25) |
| Analytes | Retinol (视黄醇), Retinal (视黄醛), Retinyl acetate (视黄醇乙酸酯), Lycopene (番茄红素), β-Carotene (β胡萝卜素), Squalene (角鲨烯) |

### Source Gradient Table

| Time (min) | %A | %B |
|------------|-----|-----|
| 0.00 | 25 | 75 |
| 5.50 | 25 | 75 |
| 7.50 | 0 | 100 |
| 30.00 | 0 | 100 |
| 32.00 | 25 | 75 |

---

## Target Column (Short)

| Parameter | Value |
|-----------|-------|
| Column | Phenomenex Kinetex C18 100A |
| Part # | 00B-4475-AN |
| Dimensions | 2.1 × 50 mm |
| Particle size | 1.7 µm (superficially porous / core-shell) |
| Pore size | 100 Å |
| L/dp | 29,412 |
| Column volume | 173.2 µL |
| Max pressure | 1,000 bar |

---

## Converted Method

| Parameter | Long (source) | Short (converted) | Formula |
|-----------|--------------|-------------------|---------|
| Flow rate | 1.0 mL/min | **0.613 mL/min** | F2 = F1 × (dc2² × dp1) / (dc1² × dp2) |
| Injection volume | 10.0 µL | **0.42 µL** | Vinj2 = Vinj1 × (L2 × dc2²) / (L1 × dc1²) |
| Column temperature | 50 °C | **50 °C** | Unchanged (adjustable ±5 °C per ChP gradient rules) |
| Detection wavelengths | 328, 382, 452, 475, 210 nm | **Unchanged** | Cannot change per ChP 0512 |
| Run time | 32.0 min | **2.18 min** | 14.7× faster |
| Solvent saving | — | **95.8%** | — |
| Backpressure ratio | — | **~5.1×** increase | Darcy's law scaling |

### Converted Gradient Table

| Long Time (min) | Short Time (min) | %A | %B | Notes |
|-----------------|-----------------|-----|-----|-------|
| 0.00 | 0.00 | 25 | 75 | Initial condition |
| 5.50 | 0.37 | 25 | 75 | Isocratic hold |
| 7.50 | 0.51 | 0 | 100 | Ramp to 100% B |
| 30.00 | 2.04 | 0 | 100 | Hold at 100% B |
| 32.00 | 2.18 | 25 | 75 | Re-equilibrate |

---

## Compliance Warnings (ChP 0512)

| Severity | Parameter | Message |
|----------|-----------|---------|
| Warning | L/dp | Target L/dp (29,412) is 41% below source (50,000). ChP 0512 allows max −25%. May need to verify equivalent theoretical plates. |
| Warning | Packing type | Packing change: fully porous → superficially porous. Per ChP 0512, selectivity and elution order must remain unchanged. |
| Warning | Pore size | Pore category change: peptide range (170 Å) → small molecule (100 Å). May affect retention and mass transfer for larger analytes. |
| Warning | Backpressure | Estimated pressure increase: 5.1×. Target column rated to 1,000 bar. Verify instrument pressure capability. |
| Info | Column temp | Temperature: 50 °C (adjustable ±5 °C per ChP gradient rules) |
| Info | Detection | Detection wavelengths must not change per ChP 0512. |

---

## Known Retention Times (long column reference)

| Analyte | Chinese | Long RT (min) | Concentration (ppm) | Estimated Short RT (min) |
|---------|---------|--------------|--------------------|-----------------------|
| Retinol | 视黄醇 | 10.666 | 30 | ~0.73 |
| Retinal | 视黄醛 | 10.844 | 60 | ~0.74 |
| Retinyl acetate | 视黄醇乙酸酯 | 11.457 | 80 | ~0.78 |
| Lycopene | 番茄红素 | 18.647 | 20 | ~1.27 |
| β-Carotene | β胡萝卜素 | 25.107 | 20 | ~1.71 |

> Estimated short RTs are linearly scaled by the 14.68× speed factor. Actual retention times will vary due to differences in selectivity between fully porous (170 Å) and core-shell (100 Å) stationary phases.

---

## Summary

| Metric | Value |
|--------|-------|
| Speed improvement | 14.7× (32 min → 2.18 min) |
| Solvent saving | 95.8% |
| Pressure increase | 5.1× (within target column rating) |
| Gradient steps preserved | 5/5 |
| Compliance warnings | 4 (L/dp, packing, pore, pressure) |
