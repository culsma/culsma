# Column Method Conversion — Test Results for Human Review

> Generated from the RT 2.1min Method PDF reference data.
> Conversion engine: BPL `bpl/agentic/column_catalog.py`
> Formulas: 2025 Chinese Pharmacopoeia (中国药典) 0512

---

## Test Case: Short Column → Long Column

### Source Column

| Parameter | Value |
|-----------|-------|
| Column | Phenomenex Kinetex C18 100A |
| Part # | 00B-4475-AN |
| Dimensions | 2.1 × 50 mm |
| Particle size | 1.7 µm (superficially porous / core-shell) |
| Pore size | 100 Å |
| L/dp | 29,412 |
| Column volume | 173.2 µL |

### Source Method (from RT 2.1min Method PDF)

| Parameter | Value |
|-----------|-------|
| Flow rate | 0.6 mL/min |
| Injection volume | 1.0 µL |
| Column temperature | 50 °C |
| Detection | DAD at 328, 382, 452, 475, 210 nm |
| Mobile phase A | Ultrapure water (超纯水) |
| Mobile phase B | Acetonitrile/Isopropanol 75:25 (乙腈/异丙醇 75/25) |
| Analytes | Retinol (视黄醇), Retinal (视黄醛), Retinyl acetate (视黄醇乙酸酯), Lycopene (番茄红素), β-Carotene (β胡萝卜素), Squalene (角鲨烯) |

### Source Gradient Table

| Time (min) | %A | %B |
|------------|-----|-----|
| 0.00 | 25 | 75 |
| 0.40 | 25 | 75 |
| 0.50 | 0 | 100 |
| 2.00 | 0 | 100 |
| 2.10 | 25 | 75 |

---

### Target Column

| Parameter | Value |
|-----------|-------|
| Column | Agilent ValueLab LC C18 170Å |
| Part # | 588965-902 |
| Dimensions | 4.6 × 250 mm |
| Particle size | 5.0 µm (fully porous) |
| Pore size | 170 Å |
| L/dp | 50,000 |
| Column volume | 4,154.8 µL |

---

### Conversion Results

| Parameter | Source | Converted | Formula |
|-----------|--------|-----------|---------|
| Flow rate | 0.600 mL/min | **0.979 mL/min** | F2 = F1 × (dc2²×dp1)/(dc1²×dp2) |
| Injection volume | 1.0 µL | **24.0 µL** | Vinj2 = Vinj1 × (L2×dc2²)/(L1×dc1²) |
| Column temperature | 50 °C | **50 °C** | Unchanged (adjustable ±5 °C per gradient rules) |
| Detection wavelengths | 328, 382, 452, 475, 210 nm | **Unchanged** | Cannot change per ChP 0512 |
| Run time | 2.1 min | **30.9 min** | — |
| Backpressure | baseline | **~0.20x** (80% lower) | Darcy's law scaling |

### Converted Gradient Table

| Source Time (min) | Converted Time (min) | %B | Notes |
|-------------------|----------------------|-----|-------|
| 0.00 | 0.00 | 75.0 | Initial condition |
| 0.40 | 5.88 | 75.0 | Isocratic hold |
| 0.50 | 7.35 | 100.0 | Ramp to 100% B |
| 2.00 | 29.41 | 100.0 | Hold at 100% B |
| 2.10 | 30.88 | 75.0 | Re-equilibrate |

Time scaling factor: **14.71x** (each minute in the source becomes 14.71 minutes in the target)

---

### Compliance Warnings

| Severity | Parameter | Issue | ChP 0512 Rule |
|----------|-----------|-------|---------------|
| **WARNING** | L/dp ratio | Target L/dp (50,000) is **70% above** source (29,412) | Allowed range: -25% to +50% — **EXCEEDS LIMIT** |
| **WARNING** | Packing type | superficially_porous → fully_porous | Selectivity and elution order must remain unchanged |
| **WARNING** | Pore category | small_molecule (100 Å) → peptide (170 Å) | May affect retention and mass transfer |
| INFO | Temperature | 50 °C carried over | Adjustable ±5 °C (gradient mode) |
| INFO | Wavelengths | Unchanged | Cannot be changed per ChP 0512 |

---

### Reviewer Notes

**Items requiring verification before use:**

- [ ] The L/dp ratio exceeds the pharmacopoeia +50% limit. System suitability test (SST) must confirm acceptable resolution, tailing, and precision.
- [ ] Packing type change (core-shell → fully porous) may alter selectivity. Verify elution order of all 6 target analytes on the long column.
- [ ] Pore size change (100 Å → 170 Å) is acceptable for these small-molecule analytes but reduces surface area and may affect retention.
- [ ] Flow rate 0.979 mL/min is reasonable for a 4.6 mm ID column; typical range is 0.5-2.0 mL/min.
- [ ] Injection volume 24 µL is within normal range for a 4.6×250 mm column (column volume ~4.2 mL).
- [ ] The converted run time (30.9 min) is significantly shorter than the reference 60-min method in the PDF. This is because the source is a fast 2.1-min method — the gradient profile structure is different from the long column's independently developed 60-min method.
- [ ] Mobile phase composition (ultrapure water / acetonitrile-isopropanol 75:25) and detection wavelengths are preserved as required.

---

### Cross-Validation with Agilent PDF Calculator (5994-8817ZHCN)

The Agilent application note provides a method conversion calculator example:

| Parameter | Agilent Example | Our Calculator | Match |
|-----------|----------------|----------------|-------|
| Source column | 4.6×250 mm, 5 µm | 4.6×250 mm, 5 µm | ✓ |
| Target column | 3.0×100 mm, 2.7 µm | 3.0×100 mm, 2.7 µm | ✓ |
| Injection volume | 3.4 µL | 3.40 µL | ✓ exact |
| Solvent saving | 83% | 83% | ✓ exact |
| Base flow | 0.98 mL/min (with +25% adj) | 0.788 mL/min (base) | ✓ (0.788×1.25=0.985) |
| Speed factor | 5.8x (with adjusted flow) | 4.6x (base flow) | ✓ consistent |

**Note:** The Agilent calculator allows post-calculation user adjustments (the "+25%" shown next to the flow value). Our calculator returns the base geometric value. The formulas are mathematically equivalent.

---

*Generated by:* `bpl/agentic/column_catalog.py`
*Test script:* `tests/test_column_catalog.py` (61 tests, all passing)
*Reference PDFs:* RT 2.1min Method.pdf, Agilent 5994-8817ZHCN.pdf
