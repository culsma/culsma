# BPL Chromatography Column Catalog & Method Conversion Tool

> Auto-generated documentation for the analytical chromatography tools
> available to the LLM during BPL SOP-to-protocol generation.
>
> Conversion engine implements **2025 Chinese Pharmacopoeia 0512** formulas
> and **Darcy's law** backpressure estimation.
>
> Regenerate this file with: `uv run python scripts/gen_column_docs.py > docs/column_catalog.md`

## Table of Contents

1. [Overview](#overview)
2. [Conversion Formulas](#conversion-formulas)
3. [Available Tools](#available-tools)
4. [Column Catalog](#column-catalog)
5. [Stationary Phase Reference](#stationary-phase-reference)
6. [Pore Size Guidance](#pore-size-guidance)
7. [Detection Mode Compatibility](#detection-mode-compatibility)
8. [Pharmacopoeia Compliance Checks](#pharmacopoeia-compliance-checks)
9. [Conversion Examples](#conversion-examples)
10. [API Reference](#api-reference)

---

## Overview

The chromatography column catalog provides the BPL generation agent with
tools to select HPLC/UHPLC analytical columns and compute method parameters
when converting between columns of different dimensions, particle sizes,
and stationary phases.

**Key capabilities:**

- **11 pre-registered columns** spanning 8 stationary phases (C18, C8, C4, Phenyl, Biphenyl, PFP, Amide/HILIC, SCX)
- **17 supported stationary phase types** with selectivity guidance
- **8 detection modes** with compatibility checking (UV, DAD, FLD, RID, ELSD, CAD, MS, MS/MS)
- **Dynamic column creation** — the LLM can register arbitrary columns at runtime
- **Full method conversion** with geometric scaling + pharmacopoeia compliance
- **Backpressure estimation** using Darcy's law

---

## Conversion Formulas

All formulas follow the **2025 Chinese Pharmacopoeia 0512** (高效液相色谱法通则) guidelines.

### Flow Rate

```
F2 = F1 * (dc2^2 * dp1) / (dc1^2 * dp2)
```

Where:
- F1, F2 = original and converted flow rates (mL/min)
- dc1, dc2 = original and target column inner diameters (mm)
- dp1, dp2 = original and target particle sizes (um)

### Injection Volume

```
Vinj2 = Vinj1 * (L2 * dc2^2) / (L1 * dc1^2)
```

Where:
- L1, L2 = original and target column lengths (mm)

### Gradient Time

```
tG2 = tG1 * (F1 / F2) * (L2 * dc2^2) / (L1 * dc1^2)
```

### Backpressure (Darcy's Law)

```
P2/P1 = (F2/F1) * (L2/L1) * (dp1/dp2)^2 * (dc1/dc2)^2
```

### Column Volume

```
Vcol = (pi/4) * dc^2 * L
```

Void volume estimated at 65% porosity (fully porous) or 55% (core-shell).

---

## Available Tools

These tools are registered on the Pydantic AI generation agent and callable by the LLM during BPL generation.

| Tool | Description |
|------|-------------|
| `list_columns` | List all columns grouped by stationary phase |
| `get_column_method` | Detailed specs and method for a specific column |
| `get_phase_info` | Selectivity guidance for a phase (C18, HILIC, PFP, etc.) |
| `convert_column_method` | Convert method between columns with ChP 0512 compliance |
| `create_custom_column` | Register a column with arbitrary specs at runtime |
| `estimate_backpressure` | Darcy's law pressure ratio between two columns |

---

## Column Catalog

### Pre-Registered Columns

| Column ID | Name | Phase | Dimensions | Particle | Packing | Pore | L/dp | Max P |
|-----------|------|-------|------------|----------|---------|------|------|-------|
| `kinetex-c18-2.1x50-1.7um` | Phenomenex Kinetex C18 100A | C18 | 2.1x50 mm | 1.7 um (superficially porous) | 100 A (small_molecule) | 29412 | 1000 bar (2.1 min) |
| `valuelab-c18-4.6x250-5um` | Agilent ValueLab LC C18 170A | C18 | 4.6x250 mm | 5.0 um (fully porous) | 170 A (peptide) | 50000 | 400 bar (60.0 min) |
| `beh-c18-2.1x100-1.7um` | Waters BEH C18 130A | C18 | 2.1x100 mm | 1.7 um (fully porous) | 130 A (small_molecule) | 58824 | 1034 bar |
| `poroshell-c18-3.0x100-2.7um` | Agilent Poroshell 120 EC-C18 | C18 | 3.0x100 mm | 2.7 um (superficially porous) | 120 A (small_molecule) | 37037 | 600 bar |
| `kinetex-phenyl-2.1x100-2.6um` | Phenomenex Kinetex Phenyl-Hexyl | Phenyl | 2.1x100 mm | 2.6 um (superficially porous) | 100 A (small_molecule) | 38462 | 600 bar |
| `beh-amide-2.1x100-1.7um` | Waters BEH Amide 130A (HILIC) | Amide | 2.1x100 mm | 1.7 um (fully porous) | 130 A (small_molecule) | 58824 | 1034 bar |
| `kinetex-pfp-2.1x100-2.6um` | Phenomenex Kinetex PFP | PFP | 2.1x100 mm | 2.6 um (superficially porous) | 100 A (small_molecule) | 38462 | 600 bar |
| `eclipse-c8-4.6x150-5um` | Agilent Eclipse XDB-C8 | C8 | 4.6x150 mm | 5.0 um (fully porous) | 80 A (small_molecule) | 30000 | 400 bar |
| `kinetex-biphenyl-2.1x100-1.7um` | Phenomenex Kinetex Biphenyl | Biphenyl | 2.1x100 mm | 1.7 um (superficially porous) | 100 A (small_molecule) | 58824 | 1000 bar |
| `biozen-c4-2.1x100-1.7um` | Phenomenex bioZen Widepore C4 | C4 | 2.1x100 mm | 1.7 um (superficially porous) | 300 A (protein) | 58824 | 1000 bar |
| `biozen-scx-4.6x250-5um` | Agilent Bio SCX NP-5 | SCX | 4.6x250 mm | 5.0 um (fully porous) | 300 A (protein) | 50000 | 300 bar |

### Columns with Method Profiles

#### Phenomenex Kinetex C18 100A (`kinetex-c18-2.1x50-1.7um`)

- **Description:** Fast 2.1-min UHPLC method for retinoid/carotenoid analysis (core-shell C18)
- **Application:** food/nutraceutical
- **Target analytes:** Retinol, Retinal, Retinyl acetate, Lycopene, beta-Carotene, Squalene

**Column specs:**

| Parameter | Value |
|-----------|-------|
| Stationary phase | C18 |
| Dimensions | 2.1 x 50 mm |
| Particle size | 1.7 um |
| Packing type | superficially_porous |
| Pore size | 100 A (small_molecule) |
| L/dp | 29412 |
| Column volume | 173.2 uL |
| Void volume | 95.2 uL |
| Part number | 00B-4475-AN (Phenomenex) |
| Max pressure | 1000 bar |
| Max temperature | 60 C |
| pH range | 2.0-8.0 |

**Method parameters:**

| Parameter | Value |
|-----------|-------|
| Flow rate | 0.6 mL/min |
| Injection volume | 1.0 uL |
| Column temperature | 50.0 C |
| Detection | DAD at 328, 382, 452, 475, 210 nm |
| Mobile phase A | Ultrapure water |
| Mobile phase B | Acetonitrile/Isopropanol 75:25 |
| Elution mode | Gradient |
| Run time | 2.1 min |

**Gradient table:**

| Time (min) | %B |
|------------|-----|
| 0.00 | 75.0 |
| 0.40 | 75.0 |
| 0.50 | 100.0 |
| 2.00 | 100.0 |
| 2.10 | 75.0 |


#### Agilent ValueLab LC C18 170A (`valuelab-c18-4.6x250-5um`)

- **Description:** Conventional 60-min HPLC method (fully porous C18) for retinoid/carotenoid
- **Application:** food/nutraceutical
- **Target analytes:** Retinol, Retinal, Retinyl acetate, Lycopene, beta-Carotene, Squalene

**Column specs:**

| Parameter | Value |
|-----------|-------|
| Stationary phase | C18 |
| Dimensions | 4.6 x 250 mm |
| Particle size | 5.0 um |
| Packing type | fully_porous |
| Pore size | 170 A (peptide) |
| L/dp | 50000 |
| Column volume | 4154.8 uL |
| Void volume | 2700.6 uL |
| Part number | 588965-902 (Agilent) |
| Max pressure | 400 bar |
| Max temperature | 60 C |
| pH range | 2.0-8.0 |

**Method parameters:**

| Parameter | Value |
|-----------|-------|
| Flow rate | 1.0 mL/min |
| Injection volume | 20.0 uL |
| Column temperature | 35.0 C |
| Detection | DAD at 328, 382, 452, 475, 210 nm |
| Mobile phase A | Ultrapure water |
| Mobile phase B | Acetonitrile/Isopropanol 75:25 |
| Elution mode | Gradient |
| Run time | 60.0 min |

**Gradient table:**

| Time (min) | %B |
|------------|-----|
| 0.00 | 75.0 |
| 5.00 | 75.0 |
| 20.00 | 35.0 |
| 50.00 | 35.0 |
| 55.00 | 75.0 |
| 60.00 | 75.0 |


---

## Stationary Phase Reference

| Phase | Hydrophobicity | Mechanism | Best For | Mobile Phase | pH Range |
|-------|---------------|-----------|----------|--------------|----------|
| **C18** | high | reversed-phase (hydrophobic) | general-purpose, non-polar to moderately polar analytes | water/acetonitrile or water/methanol | 2-8 (silica); 1-12 (hybrid/polymer) |
| **C8** | moderate | reversed-phase (hydrophobic) | analytes with excessive C18 retention, faster elution | water/acetonitrile or water/methanol | 2-8 |
| **C4** | low-moderate | reversed-phase | proteins, peptides, very hydrophobic analytes | water/acetonitrile with TFA or formic acid | 2-8 |
| **Phenyl** | moderate | reversed-phase + pi-pi interactions | aromatic compounds, selectivity alternative to C18 | water/methanol (enhances pi-pi) or water/acetonitrile | 2-8 |
| **Biphenyl** | moderate-high | reversed-phase + strong pi-pi + shape selectivity | aromatic isomers, PAHs, steroids | water/methanol or water/acetonitrile | 1.5-9 |
| **PFP** | moderate | reversed-phase + pi-pi + dipole-dipole + H-bonding | halogenated compounds, polar aromatics, isomer separation | water/methanol preferred (enhances selectivity) | 2-8 |
| **CN** | low | normal-phase or reversed-phase (dipole interactions) | moderately polar analytes, needs less organic than C18 | RP: water/acetonitrile; NP: hexane/ethyl acetate | 2-7.5 |
| **NH2** | very low | normal-phase / weak anion exchange / HILIC | sugars, carbohydrates, polar acids | acetonitrile/water or hexane/isopropanol | 3-7 (sensitive to low pH hydrolysis) |
| **HILIC** | very low | hydrophilic interaction + partitioning | very polar analytes poorly retained on C18 | high % acetonitrile with 5-40% aqueous buffer | 2-8 (depends on substrate) |
| **Silica** | none | normal-phase adsorption | non-polar matrices, lipid class separation | hexane/ethyl acetate or hexane/isopropanol | 2-8 |
| **Amide** | very low | HILIC (amide-bonded) | glycans, polar metabolites, nucleotides | acetonitrile/ammonium formate buffer | 2-8 |
| **SCX** | none | strong cation exchange | basic analytes, cations, proteins (by charge) | aqueous buffer with salt gradient | 2-7 |
| **SAX** | none | strong anion exchange | acidic analytes, anions, nucleotides | aqueous buffer with salt gradient | 2-9 |

---

## Pore Size Guidance

| Category | Pore Range (A) | Typical (A) | Description |
|----------|---------------|-------------|-------------|
| **small_molecule** | 60-130 | 100 | 60-130 Å optimal for small molecules < 3 kDa; higher surface area |
| **peptide** | 120-200 | 150 | 120-200 Å for peptides 1-10 kDa; balances access and area |
| **protein** | 200-1000 | 300 | 200-300+ Å for proteins > 10 kDa; wide pores for mass transfer |

---

## Detection Mode Compatibility

| Mode | Gradient OK | Destructive | Notes |
|------|------------|-------------|-------|
| **UV** | Yes | No | Check solvent UV cutoff; acetonitrile cut ~190 nm, methanol ~205 nm |
| **DAD** | Yes | No | Multi-wavelength; same solvent cutoff limits as UV |
| **FLD** | Yes | No | Very sensitive; analyte must be naturally fluorescent or derivatized |
| **RID** | **No** | No | Incompatible with gradient elution; isocratic only |
| **ELSD** | Yes | Yes | Avoid volatile analytes; incompatible with non-volatile buffers/mineral acids |
| **CAD** | Yes | Yes | Requires volatile mobile phase components; better linearity than ELSD |
| **MS** | Yes | Yes | Requires volatile buffers (formic acid, ammonium acetate); 2.1mm ID columns preferred; may need flow splitting for >0.5 mL/min |
| **MS/MS** | Yes | Yes | Same as MS; narrow-bore columns strongly recommended |

---

## Pharmacopoeia Compliance Checks

The conversion engine performs the following checks per **ChP 2025 0512**:

| Check | Rule | Severity |
|-------|------|----------|
| L/dp ratio | Must stay within -25% to +50% of original | Warning |
| Stationary phase change | Selectivity and elution order must be preserved | Warning |
| Packing type change | Verify system suitability after conversion | Warning |
| Pore category change | May affect retention and mass transfer | Warning |
| Column temperature | +/-10 C (isocratic), +/-5 C (gradient) | Info |
| Detection wavelength | Cannot be changed | Info |
| pH range | Must be within target column's rated pH range | Error |
| Max temperature | Method temp must not exceed column max | Error |
| Backpressure | Estimate via Darcy's law; flag if >2x increase | Warning |
| RID + gradient | Refractive index detector incompatible with gradient | Error |
| MS flow limit | Flow >0.5 mL/min may exceed MS source capacity | Warning |
| Buffer concentration | +/-10% of original value | Info |

---

## Conversion Examples

### Example 1: UHPLC Short Column -> Conventional Long Column

**Source:** Phenomenex Kinetex C18, 2.1x50 mm, 1.7 um (core-shell)

**Target:** Agilent ValueLab LC C18, 4.6x250 mm, 5.0 um (fully porous)

| Parameter | Source | Converted |
|-----------|--------|-----------|
| Flow rate | 0.6 mL/min | 0.979 mL/min |
| Injection volume | 1.0 uL | 23.99 uL |
| Column temperature | 50.0 C | 50.0 C |
| Detection | DAD at 328, 382, 452, 475, 210 nm | unchanged |
| Run time | 2.1 min | 30.9 min |
| Speed factor | — | 0.07x |
| Solvent saving | — | -2299% |
| Pressure ratio | — | 0.20x |

**Gradient conversion:**

| Source Time (min) | Converted Time (min) | %B |
|-------------------|----------------------|-----|
| 0.00 | 0.00 | 75.0 |
| 0.40 | 5.88 | 75.0 |
| 0.50 | 7.35 | 100.0 |
| 2.00 | 29.41 | 100.0 |
| 2.10 | 30.88 | 75.0 |

**Compliance warnings:**

- **[WARNING]** `L/dp` — Target L/dp (50000) is 70% above source (29412). ChP 0512 allows max +50%.
- **[WARNING]** `packing_type` — Packing change: superficially_porous -> fully_porous. Per ChP 0512, selectivity and elution order must remain unchanged.
- **[WARNING]** `pore_size` — Pore category change: small_molecule -> peptide. May affect retention and mass transfer for large analytes.
- **[INFO]** `column_temp` — Temperature: 50.0C (adjustable +/-5.0C per ChP gradient rules)
- **[INFO]** `detection_wavelength` — Detection wavelengths must not change per ChP 0512.

### Example 2: Conventional Long Column -> UHPLC Short Column

**Source:** Agilent ValueLab LC C18, 4.6x250 mm, 5.0 um

**Target:** Phenomenex Kinetex C18, 2.1x50 mm, 1.7 um

| Parameter | Source | Converted |
|-----------|--------|-----------|
| Flow rate | 1.0 mL/min | 0.613 mL/min |
| Injection volume | 20.0 uL | 0.83 uL |
| Column temperature | 35.0 C | 35.0 C |
| Run time | 60.0 min | 4.1 min |
| Speed factor | — | 14.71x |
| Solvent saving | — | 96% |
| Pressure ratio | — | 5.09x |

**Gradient conversion:**

| Source Time (min) | Converted Time (min) | %B |
|-------------------|----------------------|-----|
| 0.00 | 0.00 | 75.0 |
| 5.00 | 0.34 | 75.0 |
| 20.00 | 1.36 | 35.0 |
| 50.00 | 3.40 | 35.0 |
| 55.00 | 3.74 | 75.0 |
| 60.00 | 4.08 | 75.0 |

**Compliance warnings:**

- **[WARNING]** `L/dp` — Target L/dp (29412) is 41% below source (50000). ChP 0512 allows max -25%.
- **[WARNING]** `packing_type` — Packing change: fully_porous -> superficially_porous. Per ChP 0512, selectivity and elution order must remain unchanged.
- **[WARNING]** `pore_size` — Pore category change: peptide -> small_molecule. May affect retention and mass transfer for large analytes.
- **[WARNING]** `backpressure` — Estimated pressure increase: 5.1x. Target column rated to 1000 bar. Verify instrument pressure capability.
- **[INFO]** `column_temp` — Temperature: 35.0C (adjustable +/-5.0C per ChP gradient rules)
- **[INFO]** `detection_wavelength` — Detection wavelengths must not change per ChP 0512.

---

## API Reference

### Python API

```python
from bpl.agentic import (
    # Data models
    ColumnSpec, MethodParams, ColumnMethodProfile, GradientStep,
    MethodConversionResult, ConversionWarning,
    # Enums
    StationaryPhase, PackingType, DetectionMode,
    # Registry
    get_all_columns, get_column, get_all_profiles, get_profile,
    register_column, register_column_profile,
    # Conversion
    convert_method,
)

# Look up a column
col = get_column("kinetex-c18-2.1x50-1.7um")

# Get a method profile
profile = get_profile("kinetex-c18-2.1x50-1.7um")

# Convert method to a different column
target = get_column("valuelab-c18-4.6x250-5um")
result = convert_method(profile, target)
print(result.converted_method.flow_rate_ml_min)
print(result.warnings)

# Register a custom column
my_col = ColumnSpec(
    column_id="my-c18",
    name="My Custom C18",
    stationary_phase=StationaryPhase.C18,
    inner_diameter_mm=3.0,
    length_mm=150,
    particle_size_um=3.5,
    pore_size_angstrom=120,
    packing_type=PackingType.FULLY_POROUS,
)
register_column(my_col)
```

### LLM Tool Signatures

```
list_columns() -> str
get_column_method(column_id: str) -> str
get_phase_info(stationary_phase: str) -> str
convert_column_method(source_column_id: str, target_column_id: str) -> str
create_custom_column(column_id, name, stationary_phase, inner_diameter_mm,
    length_mm, particle_size_um, pore_size_angstrom, packing_type,
    vendor="", part_number="", max_pressure_bar=0.0) -> str
estimate_backpressure(source_column_id, target_column_id,
    source_flow_ml_min=0.0) -> str
```

---

*Source files:* `bpl/agentic/column_catalog.py`, `bpl/agentic/workflow.py`

*Tests:* `tests/test_column_catalog.py` (61 tests)

*Formulas reference:* 2025 Chinese Pharmacopoeia 0512 (HPLC); Agilent 5994-8817ZHCN
