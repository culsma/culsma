# Code and Data Availability

This repository is the public-code staging repo for the BPL paper. It is
designed to support the manuscript Code availability and Data availability
sections without publishing raw copyrighted source papers, private SOP files,
or large training run artifacts.

## Code availability

The BPL compiler, command-line interface (`bplc`), BPL-COGEN SOP-to-BPL
generation workflow, chromatography method-conversion utilities, synthetic
corpus generation tools, the full evaluation pipeline used for the manuscript
benchmarks, the tests, and the public benchmark summary artifacts are
available in this repository under the MIT License.

Manuscript-ready wording:

> All software is available at https://gitlab.com/bota-biosciences-public/bpl-code under the MIT License, including
> the BPL compiler and CLI (`bplc`), the BPL-COGEN SOP-to-BPL generation
> workflow, chromatography method-conversion utilities, synthetic corpus
> generation tools, the evaluation pipeline (digest generation, constrained
> variant rewriting, batch BPL compilation, local step-count consistency
> analysis, LLM-judged comparison, and publication figure rendering), and the
> test suite.

## Data availability

The repository includes lightweight benchmark summary artifacts under
`tools/bpl_eval/data/` and example inputs under `examples/` and
`tests/fixtures/`. Raw Nature Protocols article text, raw institutional SOPs,
and generated training datasets are not included because they may be subject
to publisher licensing, institutional access controls, or file-size
constraints.

The full generated BPL evaluation artifacts are available as the Hugging Face
dataset [`BotaBio/BPL-EVAL`](https://huggingface.co/datasets/BotaBio/BPL-EVAL).
That dataset contains generated digest JSON, generated variants, exported
markdown inputs, compiled `.bpl` outputs, composed protocol markdown,
LLM-judge comparison outputs, local consistency reports, and generated figures.
It is a data-only artifact repository; the canonical analysis code remains in
this GitLab repository.

Shipped paper-grade artifacts (all under `tools/bpl_eval/`):

- `data/variant_comparisons/variant_report.json` and `per_paper/*.json` —
  LLM-judged scores for every paper-variant pair.
- `data/consistency_report.md` — local regex step-count consistency table.
- `data/structural_features.json` — precomputed structural features for
  every per-paper-version markdown file used by the PCA panel of the paper
  figures (no raw text included).
- `data/determinism_results.json` — recomputed figure-3 headline summary
  (mean step-count range, identical-runs percentage, mean match-vs-digest
  percentage). Regenerable from `data/consistency_report.md` plus the
  per-paper records by `tools/bpl_eval/compute_determinism.py`.
- `figures/publication_redraw/fig{1,2,2a,3,4,5,6,7}_*.{pdf,png}` — the eight
  paper figures (including the single-panel `fig2a` companion), regenerable
  in-place from the artifacts above by `redraw_publication_figures.py`.
- `data/method_translation/hplc_to_uhplc.json` — the ChP 0512 HPLC→UHPLC
  method translation reproducer output. Regenerable from
  `bpl/agentic/column_catalog.convert_method` by
  `tools/bpl_eval/method_translation.py` (no external API required).
- `data/diagnostics/{diagnostic_categories,repair_loop_outcomes}.json` —
  Fig 4 panel data. The category counts (343 diagnostics) and repair-loop
  percentages (82.3/12.1/4.2/1.4 %) are encoded directly from the paper's
  Results §41–42; recomputing from scratch requires running
  `bplc sop-generate` over the 302-protocol corpus with the BPL compiler
  oracle active and is outside the offline-reproduction envelope.
- `data/wetlab/pcr_amplification.csv` — Fig 5 panel-b PCR amplification
  counts (11/11 inserts both workflows; 11/11 vs 10→11/11 vector
  amplification with one-cycle rescue). The corresponding plate-reader
  fluorescence and Sanger sequencing raw values are paper-author data
  and are not deposited at the public-code submission stage.
- `data/wetlab/promoter_library.csv` — identifiers for the 11 Trc–T7
  hybrid promoter constructs used in Fig 5; documents what raw
  measurements are NOT deposited at this stage.
- `data/method_translation/retention_times.csv` — Fig 5 panel-d retention
  times on both HPLC and UHPLC methods for the five fat-soluble vitamins
  (paper Methods §137).
- `data/sensitivity_results.json` — Methods §103 score-weighting
  sensitivity analysis result. Regenerable from
  `data/variant_comparisons/variant_report.json` by
  `tools/bpl_eval/sensitivity_analysis.py`.
- `data/variant_comparisons/variant_validation_results.xlsx` — Excel
  workbook companion to `variant_report.json` (summary, per-protocol
  scores, all variants, score distribution, complexity analysis,
  low-scoring protocols).

Manuscript-ready wording:

> Benchmark summary artifacts needed to inspect the reported compiler and
> generation analyses are provided in the code repository, including the
> LLM-judge scoring results, the local regex consistency analysis, and the
> structural-feature precomputation that underlies the PCA panel of the
> validation figures. The full generated BPL evaluation artifacts are
> deposited at https://huggingface.co/datasets/BotaBio/BPL-EVAL. The
> publication figures regenerate offline from the shipped summary artifacts
> using the included evaluation pipeline. Raw source articles and institutional
> SOP seed documents are available from the corresponding authors upon
> reasonable request and subject to licensing and institutional approvals.
> Fine-tuned model weights are not deposited at this submission stage and are
> available from the corresponding authors upon reasonable request.

## Accessibility notes

- Install and test commands use `uv` and are documented in `README.md`.
- The repository includes `LICENSE`, `CITATION.cff`, and reproducible test
  fixtures.
- Generated command outputs and large derivative corpora are intentionally
  ignored by git and can be regenerated locally or downloaded from
  [`BotaBio/BPL-EVAL`](https://huggingface.co/datasets/BotaBio/BPL-EVAL);
  see [`docs/BPL_EVAL_DATASET.md`](BPL_EVAL_DATASET.md) and
  [`tools/bpl_eval/README.md`](../tools/bpl_eval/README.md).
- API-backed generation tools require user-provided environment variables; no
  API keys are stored in the repository.
