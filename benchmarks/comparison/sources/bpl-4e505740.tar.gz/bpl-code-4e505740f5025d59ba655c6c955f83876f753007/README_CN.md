# BPL — 生物编程语言

> 用于描述、验证与执行生物实验流程的领域特定语言（DSL）。

[English Version](README.md)

---

## 背景与动机

生命科学实验室的标准操作规程（SOP）通常以自然语言文档形式维护，这带来了几个公认的问题：

- **歧义性** — 自由文本允许多种解读。
- **无验证** — 单位错误、体积溢出、试剂不匹配只有在实验台上才会被发现。
- **可重复性差** — 在不同仪器或由不同操作人员重新执行同一流程时，会引入无声的变异。
- **可审计性弱** — 追溯执行过程中到底发生了什么，依赖人工记录。

**BPL** 通过将实验流程编码为专用语言程序来解决这些问题——具备生物学原生的类型系统、量纲分析、确定性编译和多目标执行后端。

## 论文公开仓库范围

本 clean repo 只保留论文 Code availability / Data availability 所需的公开代码与轻量 benchmark artifact。完整生成评测数据单独托管在 Hugging Face 数据集 [`BotaBio/BPL-EVAL`](https://huggingface.co/datasets/BotaBio/BPL-EVAL)。原始论文全文、内部 SOP、大型训练输出、模型 checkpoint、手稿草稿、生成图片的 API 响应等不放入本仓库。可直接放入论文的说明见 [`docs/CODE_AND_DATA_AVAILABILITY.md`](docs/CODE_AND_DATA_AVAILABILITY.md)。

## 核心能力

| 能力 | 描述 |
|---|---|
| **生物学原生类型系统** | 一等单位支持（`mL`、`g/mol`、`degC`、`mM`）、量纲分析、MW 感知的浓度转换 |
| **确定性编译器** | 源码 → AST → Plan IR → 调度 DAG — 相同输入始终产生相同执行计划 |
| **多目标执行** | 一次编译，多处运行：人工（逐步工作单）、机器人（Biomek i7）、仿真 |
| **分阶段验证** | 六道门禁：语法 → 语义 → 计划/DAG → 实验参数 → 能力 → 后端预检 |
| **审计与信任模型** | 哈希链状态历史，三级信任：声明（Declared）、校准（Calibrated）、已验证（Verified） |
| **SOP 到 BPL 生成** | 智能工作流将自然语言 SOP 翻译为经过验证的 BPL 程序 |
| **导出** | CSV/XLSX 工作单、工作流图（Mermaid/JSON/ReactFlow） |

## 架构

```
┌─────────────────────────────────────────────────────────────────┐
│                      BPL 编译器流水线                             │
├─────────┬──────────┬──────────┬──────────┬──────────┬──────────┤
│  解析   │ 语义检查  │  降级    │  调度    │  执行     │  导出    │
│         │          │          │          │          │          │
│ .bpl →  │ 单位,    │ 意图 →   │ DAG     │ 人工 /   │ CSV /   │
│   AST   │ 类型,    │ Plan IR  │ 解析    │ 机器人 / │ XLSX /  │
│         │ 状态     │ (原语)   │ + 排序  │ 仿真    │ 图      │
└─────────┴──────────┴──────────┴──────────┴──────────┴──────────┘
```

## 语言示例 — LB 培养基配制

```bpl
reagent Tryptone  { physical_form: Solid, cas: "91079-40-2" }
reagent NaCl      { physical_form: Solid, MW: 58.44 g/mol   }
reagent ROWater   { physical_form: Liquid                    }

stock LB_Base {
    reagent: Tryptone
    concentration: 10 g/L
    solvent: ROWater
}

labware Beaker1L      { footprint: Custom, well_volume: 1200 mL }
labware GlassBottle1L { footprint: Custom, well_volume: 1000 mL }

@target(human)
@expected_time(2 h)
protocol PrepareLBMedia(final_volume: Volume = 1000 mL) {
    @step(1, "加入 RO 纯水至烧杯")
    add_reagent(ROWater, volume: 800 mL, to: Beaker1L)

    @step(2, "加入胰蛋白胨")
    add_reagent(Tryptone, mass: 10 g, to: Beaker1L)

    @step(3, "加入氯化钠")
    add_reagent(NaCl, mass: 10 g, to: Beaker1L)

    @step(4, "补水至终体积")
    add_reagent(ROWater, volume: 200 mL, to: Beaker1L)

    @step(5, "转移至试剂瓶")
    transfer(from: Beaker1L, volume: final_volume, to: GlassBottle1L)

    @step(6, "高压灭菌")
    incubate(target: GlassBottle1L, temperature: 121 degC, time: 20 min)
}
```

## 仓库结构

```
bpl/                      核心实现 (约 32 000 行 Python)
├── grammar/bpl.lark        Lark 解析器语法 (v2.4)
├── parser/                 Lark → 语法树
├── transformer/            语法树 → 类型化 AST
├── ast/                    AST 节点定义
├── types/                  单位引擎、量纲、浓度逻辑
├── state/                  状态模型、信任等级、哈希链历史
├── lowering/               意图 → Plan IR（原语 DAG）
├── scheduler/              DAG 依赖解析与调度
├── simulation/             虚拟台面干运行仿真
├── validation/             实验参数与配置验证
├── runtime/
│   ├── human/              人工执行步骤生成 + 数据采集
│   └── robot/biomek/       Biomek i7 翻译与代码生成
├── export/                 CSV/XLSX 工作单导出
├── graph/                  工作流图渲染
├── audit/                  合规审计链
├── agentic/                SOP → BPL 智能生成工作流
├── cli/                    CLI 入口 (bplc)
└── orchestrator.py         统一编排层

tests/                    测试套件 (~17 000 行, 1 150+ 测试)

tools/bpl_eval/           论文配套 evaluation 流水线（digest → variant 重写
                          → 批量 BPL 编译 → LLM 评分 → 出图），所有论文级
                          artifact 都在这个文件夹内：
├── data/                    frozen 数据：variant_report.json、
│                            per_paper/*.json、consistency_report.md、
│                            structural_features.json、determinism_results.json
├── figures/publication_redraw/  8 张 frozen 论文图（含 fig2a，可原地重绘）
└── *.py                     流水线脚本

docs/BPL_EVAL_DATASET.md  如何下载 Hugging Face 上的完整评测数据集，
                          并使用本仓库脚本运行分析
```

## 快速开始

### 环境要求

- Python >= 3.13
- [uv](https://docs.astral.sh/uv/) 包管理器

### 安装

```bash
git clone https://gitlab.com/bota-biosciences-public/bpl-code.git
cd bpl-code
uv sync --dev
```

### 验证

```bash
# 论文级离线复现流程
uv run python scripts/reproduce_paper.py
```

该命令会生成编译器 artifact、重算随仓库发布的 benchmark 摘要、用 frozen evaluation
artifact 重绘 8 张论文图（写入 `tools/bpl_eval/figures/publication_redraw/fig{1,2,2a,3,4,5,6,7}_*.{pdf,png}`）、
运行完整测试/类型检查/构建，并写出 `paper_artifacts/reproducibility_manifest.json`。
开发时可用快速 smoke run：
`uv run python scripts/reproduce_paper.py --skip-tests --skip-pyright --skip-build --skip-eval-figs`。
详见 [`docs/PAPER_REPRODUCIBILITY.md`](docs/PAPER_REPRODUCIBILITY.md) 与
[`tools/bpl_eval/README.md`](tools/bpl_eval/README.md)。

完整生成评测数据托管在 Hugging Face：
[`BotaBio/BPL-EVAL`](https://huggingface.co/datasets/BotaBio/BPL-EVAL)。下载数据并用本仓库脚本分析的方法见
[`docs/BPL_EVAL_DATASET.md`](docs/BPL_EVAL_DATASET.md)。

## CLI 参考 (`bplc`)

```bash
# 语法检查
uv run bplc check protocol.bpl

# 解析为 AST
uv run bplc parse protocol.bpl --format json --out ast.json

# 降级为执行计划
uv run bplc lower protocol.bpl --target human --out plan.json

# 分阶段验证
uv run bplc validate protocol.bpl --target human

# 干运行仿真
uv run bplc simulate --input-bpl protocol.bpl --trace trace.json

# 导出工作单
uv run bplc export --input-bpl protocol.bpl --format csv --out worklist.csv

# 组合为人类可读 Markdown 协议
uv run bplc compose --input-plan plan.json --out protocol.md

# 工作流图
uv run bplc graph --input-bpl protocol.bpl --format mermaid --out graph.md

# 后端能力报告
uv run bplc capabilities --target biomek

# SOP 到 BPL 生成（需要 API 密钥）
uv run bplc sop-generate --sop docs/sop.md --out protocol.bpl
```

## 可重复快速示例

使用仓库自带的 fixture 输入：

```bash
INPUT=examples/minimal_protocol.bpl

mkdir -p examples/generated
uv run bplc parse    "$INPUT" --format json --out examples/generated/minimal.ast.json
uv run bplc lower    "$INPUT" --target human --out examples/generated/minimal.plan.json
uv run bplc validate "$INPUT" --target human
uv run bplc simulate --input-bpl "$INPUT" --trace examples/generated/minimal.trace.json
uv run bplc export   --input-bpl "$INPUT" --format csv --out examples/generated/minimal.csv
uv run bplc graph    --input-bpl "$INPUT" --format json --out examples/generated/minimal.graph.json
```

**确定性保证：** `parse`、`lower`、`validate`、`export` 和 `graph` 是确定性的——对相同输入运行同一命令两次将产生字节级完全一致的输出。`simulate --trace` 会记录 `started_at` / `completed_at` / 每步 `timestamp` 与 `duration_ms` 等真实墙钟时间字段，因此该命令的输出在不同运行之间会有差异（底层 plan 哈希依然是确定性的；见下方设计原则 5）。

## 设计原则

1. **流程即程序。** `.bpl` 文件是实验流程的完整、自包含描述——不是脚本，不是模板。
2. **意图优先于指令。** 用户编写高级意图（`transfer`、`add_reagent`、`incubate`）；编译器将其降级为后端特定原语（`aspirate`、`dispense`、`pick_tips`）。
3. **量纲安全。** 类型系统在编译时捕获 `mL + g` 的错误，而非在实验台上。
4. **人工是一等后端。** 手动步骤（离心、目视检查、操作员签名）是执行计划的一部分，不是注释。
5. **确定性编译。** 相同源码 + 相同选项 → 相同计划哈希。非确定性元数据（时间戳、UUID）被隔离。
6. **信任是显式的。** 每个状态值都携带信任等级（Declared / Calibrated / Verified）和可审计的变更历史。

## 引用

如果您在研究中使用了 BPL，请引用：

```
[待论文发表后补充]
```

## 许可证

MIT。见 [LICENSE](LICENSE)。
