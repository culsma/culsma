protocol Main {
    wait(duration: 1 s)
    transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 10 uL)
    transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 10 uL)
    transfer(from: "plate_1:A1", to: "plate_1:A2", volume: 10 uL)
}
