"""Maintainer-only: build frozen predicates from previously reviewed evidence.

Never called by the replay command. Changes require review against the audits.
"""
import json
from pathlib import Path
p=Path(__file__).resolve().parent
r=p/'results'; result={s:[] for s in ['culsma','labop','bpl']}

def row(s,c,v,scope,audit):
 x={'criterion':c,'expected_result':v,'scope':scope,'mechanism_audit':audit,'checks':[]};result[s].append(x);return x

def add(x,file,path,frozen=None,oldpath=None):
 d=json.loads((r/(frozen or file)).read_text())
 for k in (oldpath if oldpath is not None else path): d=d[k]
 x['checks'].append({'file':file,'path':path,'equals':d})

for s in result:
 if s=='culsma':
  x=row(s,'M1','Yes','Distinct named containers and separately bound references in the retained transfer procedure.','m1-mechanism-evidence.md')
  for i in [0,1]:add(x,'l1/culsma/output.json',['report','materials','final_products',i,'name'])
  x=row(s,'M2','Yes','Reject a volume in a duration field before execution.','m2-mechanism-evidence.md')
  for i in [0,1]:add(x,'duration.json',['cases',i,'accepted'],'duration-unit-check.json',[s,'cases',i,'accepted'])
  x=row(s,'M3','Yes','Dimensioned magnetic fractions and association calculations in the pinned material model.','material-evolution-evidence.md')
  add(x,'material-audit.json',['typed_quantities_and_association_passed'],'magnetic-comparison.json',['culsma','typed_quantities_and_association_passed'])
  x=row(s,'M4','Yes','Returned local references remain usable; unbound local use outside a procedure is rejected.','scope-mechanism-evidence.md')
  for i in [0,1]:add(x,'scope.json',['cases',i,'diagnostics'],'scope-mechanisms.json',[s,'cases',i,'diagnostics'])
  x=row(s,'L1','Yes','One procedure called with 10/20-uL arguments produces 10/20-uL destinations.','l1-mechanism-evidence.md')
  for i in [0,1]:
   for k in ['name','volume_uL']:add(x,'l1/culsma/output.json',['report','materials','final_products',i,k])
  add(x,'l1/culsma/summary.json',['runtime_ok'])
  x=row(s,'L2','Yes','Single returned container is bound to the next procedure; target receives 10 uL.','l2-mechanism-evidence.md')
  for k in ['name','volume_uL']:add(x,'l2/culsma/output.json',['report','materials','final_products',0,k])
  add(x,'l2/culsma/summary.json',['runtime_ok'])
  x=row(s,'L3','Yes','Counted repetition and exclusive branching on injected runtime observations; no physical measurement.','l3-mechanism-evidence.md')
  for group,keys in [('loops',['2','3']),('branches',['1250','800'])]:
   for key in keys:
    for field in ['ok','volumes_ul']:add(x,'l3/culsma/results.json',[group,key,field])
  add(x,'l3/culsma/results.json',['same_plan_used_for_both_values'])
 elif s=='labop':
  x=row(s,'M1','Yes','Distinct model objects, references and RDF round-trip; domain-specific products require defined semantics.','m1-mechanism-evidence.md')
  for field in ['before','after','passed']:add(x,'modeling/report.json',['cases',0,field])
  x=row(s,'M2','No','Standard Spin document validation accepts a volume-valued duration.','m2-mechanism-evidence.md')
  for i in [0,1]:add(x,'duration.json',['cases',i,'accepted'],'duration-unit-check.json',[s,'cases',i,'accepted'])
  x=row(s,'M3','No','Published handler inventory lacks the tested material-separation propagation; GFP extension assessed separately.','material-evolution-evidence.md')
  add(x,'material-audit.json',['default_handlers'],'magnetic-comparison.json',['labop','default_handlers'])
  x=row(s,'M4','Yes','Activity ownership enforces model-reference scope; Python helper scope is distinct.','scope-mechanism-evidence.md')
  for field in ['owner','python_helper_name_in_rdf','cross_activity_rejection']:add(x,'scope.json',[field],'scope-mechanisms.json',[s,field])
  x=row(s,'L1','No','Parameterized nested activity loses the quantity input; direct Transfer and official upstream test are controls.','l1-mechanism-evidence.md')
  for mode in ['direct','subprotocol']:
   for field in ['validation_errors','executed_transfers','latest_recorded_buffer_ul']:add(x,'l1/labop-reproduction/comparison.json',['results',mode,field])
  add(x,'l1/public-api-audit/results.json',['upstream_subprotocol_test','success'])
  add(x,'l1/public-api-audit/results.json',['counterexample_official_harness','executed_transfer_amounts_ul'])
  x=row(s,'L2','No','Nested output-to-input execution receives two sample values; direct operations work.','l2-mechanism-evidence.md')
  add(x,'l2/labop/results.json',['results','direct','latest_recorded_buffer_ul'])
  for mode in ['composition','composition_explicit_final']:
   add(x,'l2/labop/results.json',['results',mode,'validation_errors'])
   for k in ['type','message']:add(x,'l2/labop/results.json',['results',mode,'execution_error',k])
  x=row(s,'L3','No','Both guarded Transfer branches execute for either Boolean input; native cycle raises the retained MergeNode error.','l3-mechanism-evidence.md')
  for i in [4,5]:
   for k in ['runtime_values','consumed_values','volumes_ul','completed_normally']:add(x,'l3/labop/results.json',['cases',i,k])
  for i in [2,3]:add(x,'l3/labop/results.json',['cases',i,'execution_error','message'])
 else:
  x=row(s,'M1','Yes','Named labware declarations and distinct resolved endpoints; not a claim of complete local binding.','bpl-modeling-evidence.md')
  add(x,'bpl-modeling/results.json',['cases','named_entities','declaration_types'])
  add(x,'bpl-modeling/results.json',['cases','named_entities','primitives'])
  x=row(s,'M2','No','Duration and transfer lowering accept incompatible dimensions.','bpl-modeling-evidence.md')
  for case in ['duration_valid','duration_wrong_dimension','volume_wrong_dimension']:
   for field in ['diagnostics','primitives']:add(x,'bpl-modeling/results.json',['cases',case,field])
  x=row(s,'M3','No','Transfer moves liquid volume but does not propagate the seeded component into the destination.','bpl-modeling-evidence.md')
  add(x,'bpl-modeling/results.json',['transfer_simulation'])
  x=row(s,'M4','No','Local let bindings are not consumed by the inspected lowering route.','bpl-modeling-evidence.md')
  for case in ['local_binding','unbound_name','nested_local']:
   for field in ['diagnostics','primitives']:add(x,'bpl-modeling/results.json',['cases',case,field])
  x=row(s,'L1','No','Procedure bodies and argument binding are absent on the checked CLI route; direct and no-argument controls retained.','bpl-l1-evidence.md')
  for case in ['direct','function_calls','undefined_calls']:
   for target in ['human','simulation']:
    for field in ['returncode','steps']:add(x,'l1/bpl-cli/results.json',['cases',case,'lower',target,field])
  for case in ['no_parameters','no_parameters_direct']:
   add(x,'l1/bpl-endpoint-binding/results.json',['cases',case,'lower','simulation','steps'])
  x=row(s,'L2','No','Changing the callee body or return leaves plans unchanged; simulation ignores the call while direct control works.','l2-mechanism-evidence.md')
  for field in ['body_change_leaves_operations_identical','return_change_leaves_operations_identical','direct_volume_change_changes_operations']:add(x,'l2/bpl-consumption/results.json',[field])
  for case in ['base-simulate','base-strict','direct_10-simulate']:add(x,'l2/bpl-consumption/results.json',['simulations',case,'returncode'])
  x=row(s,'L3','No','Loop/conditional blocks are omitted from executable plans; direct three-transfer control remains.','l3-mechanism-evidence.md')
  for case in ['loop_2','loop_3','branch_true','branch_false','direct_3']:
   for field in ['returncode','steps']:add(x,'l3/bpl-cli/results.json',['cases',case,'lower','simulation',field])
for s in ['bpl','labop']:
 x=next(x for x in result[s] if x['criterion']=='L1')
 paths=[['runs','bpl-lower','returncode'],['runs','bpl-simulate','returncode']] if s=='bpl' else [['runs','protocol_outputs_test','summary','test','success']]
 for path in paths:add(x,'upstream-examples/results.json',path)
x=next(x for x in result['culsma'] if x['criterion']=='L2')
state=json.loads((r/'l2/culsma/run.json').read_text())['state']['artifacts']['material_state']
for identity in state['containers']:
 add(x,'l2/culsma/run.json',['state','artifacts','material_state','containers',identity,'volume_uL'])
(p/'replay_expectations.json').write_text(json.dumps(result,indent=2)+'\n')
