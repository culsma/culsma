# Material evolution and accounting: revised M3 evidence

12 November 2026. Source inspection and reinspection of retained results; no new execution. Active table: [working comparison](../../notes/comparison/comparison_table_working.md).

## Decision and scope

| Evaluated capability | Culsma 1.0.7 | LabOP 1.0a2 |
|---|---|---|
| Released material mechanisms carry the specified clarification/separation-and-transfer path from input components through product states and quantities | Yes, under the stipulated partition rules and for the inspected component ledger | No, standard Spin has no default material-state updater |

Culsma pin: `5364676bc2437b4981a00ce0133c730af243e469`. LabOP pin: `2e2bd88150c71a440771fd369f40295dfd622324`. The subsequent [BPL audit](bpl-modeling-evidence.md) assesses this criterion on its pinned transfer/simulation route.

## Culsma mechanism and retained witness

The pinned `runtime/material/ledger.py` maintains material records; `component_entries.py` stores component references, dimensioned quantities, relations, and their sources. `separation.py` applies resolved component effects to output entries, and `separation_fate.py` defines operation/output and material-fate contracts. `accounting.py` separately records input lots and movements. Their presence is source evidence, not a claim that every path or field has passed a test.

[gfp.culs](gfp.culs) uses released separation and transfer constructs without an author `transition(...)`. In [the retained run](results/culsma/run.json), event 22 records 160 uL of liquid and 100000 cellular units in the modeled pellet. Event 36 records 140 uL in the supernatant and 20 uL in A1; A2 and the remaining resuspension each have 50000 cellular units and 20 uL buffer. These are calculations under the stated complete-partition model, not predictions of measured separation efficiency. The inspected output retains a pellet relation after resuspension; this audit does not certify all subsequent physical-state meanings.

The separate magnetic run's component quantities are dimensioned, but its mixed-dimension aggregate projections have known errors. Those errors remain reported under I2. The scoped M3 Yes does not certify every aggregate or arbitrary transformation.

## LabOP mechanism and gap

In the pinned `labop/execution/behavior_dynamics.py`:

- `SampleProvenanceObserver.handlers` registers TransferByMap, Transfer, Vortex, EmptyContainer, Provision, and SerialDilution. It does not register Spin or a magnetic-separation updater.
- `update()` skips unregistered behaviors instead of calculating material changes. The execution engine invokes this observer after activity execution.
- `compute_transfer()` calculates proportions from source reagent contents, subtracts transferred quantities, and adds them to destinations. The graph retains time-indexed sample states and ancestry. Basic transfer accounting is therefore present.
- `ProvisionUpdater` uses the resource identity as a reagent key. A static SBOL complex description is not thereby expanded into a component-state evolution model.
- `labop/lib/plate_handling.py` defines Spin's location, duration, and acceleration inputs. The missing material update, rather than the missing output signature alone, grounds the native-path No.

The full source search found no alternate registration supplying the missing separation updater in the inspected execution path. This is a frozen-version/default-path finding, not an impossibility claim about LabOP extensions or all backends.

## Code added for the comparison

[fractionation.py](fractionation.py) defines ClarifyLysate and FractionationUpdater. [gfp_labop.py](gfp_labop.py) explicitly registers the latter. This extension versions fraction sample states and adds ancestry edges while leaving all original liquid in the supernatant and the pellet's liquid ledger empty until buffer is added. It does not calculate a solid-component count or protein mass. The previous successful GFP volume/ancestry comparison must not be generalized to native component-resolved separation accounting.

## Interpretation correction

`transition(...)` supplies an author-assumed state change; it is not the material ledger itself. The earlier LabOP SBOL complex probe establishes static description only. Both findings remain valid within those narrower scopes, but neither is the revised M3 capability witness.

LabOP's [2023 paper, §6](https://jakebeal.github.io/Publications/JETC23-LabOP.pdf) lists reasoning about sample contents as future work. This historical statement is background, not a substitute for the pinned source audit, which also establishes that basic transfer accounting is present.
