"""Output redirection shared by retained witnesses; upstream code is untouched."""
import os
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
RUNTIME = PACKAGE.parents[1] / "output/labop-comparison"


def result_path(relative):
    return Path(os.environ.get("COMPARISON_RESULTS_DIR", PACKAGE / "results")) / relative
