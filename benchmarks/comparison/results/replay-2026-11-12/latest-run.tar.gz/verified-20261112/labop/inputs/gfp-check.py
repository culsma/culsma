import json,sys
from pathlib import Path
from check import check, labop_result as observe
result=observe(Path(sys.argv[1]))
check(result,json.loads(Path(sys.argv[2]).read_text()))
Path(sys.argv[3]).write_text(json.dumps({"pass":True,"result":result},indent=2))
