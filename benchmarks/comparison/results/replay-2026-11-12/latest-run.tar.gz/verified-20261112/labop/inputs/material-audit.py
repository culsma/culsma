import json,sys
from pathlib import Path
from check_magnetic import audit_library
Path(sys.argv[2]).write_text(json.dumps(audit_library(Path(sys.argv[1])),indent=2))
