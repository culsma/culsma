# Comparison witness replay

Retained M1–M4/L1–L3 witnesses and inspected routes; not universal conformance.

Yes/No is shown only when the retained evidence predicates reproduce. NE requires review.

| Criterion | System | Result | Evidence reproduced | Scope |
| --- | --- | --- | --- | --- |
| M1 | labop | Yes | True | Distinct model objects, references and RDF round-trip; domain-specific products require defined semantics. |
| M2 | labop | No | True | Standard Spin document validation accepts a volume-valued duration. |
| M3 | labop | No | True | Published handler inventory lacks the tested material-separation propagation; GFP extension assessed separately. |
| M4 | labop | Yes | True | Activity ownership enforces model-reference scope; Python helper scope is distinct. |
| L1 | labop | No | True | Parameterized nested activity loses the quantity input; direct Transfer and official upstream test are controls. |
| L2 | labop | No | True | Nested output-to-input execution receives two sample values; direct operations work. |
| L3 | labop | No | True | Both guarded Transfer branches execute for either Boolean input; native cycle raises the retained MergeNode error. |
