# Comparison witness replay

Retained M1–M4/L1–L3 witnesses and inspected routes; not universal conformance.

Yes/No is shown only when the retained evidence predicates reproduce. NE requires review.

| Criterion | System | Result | Evidence reproduced | Scope |
| --- | --- | --- | --- | --- |
| M1 | culsma | Yes | True | Distinct named containers and separately bound references in the retained transfer procedure. |
| M2 | culsma | Yes | True | Reject a volume in a duration field before execution. |
| M3 | culsma | Yes | True | Dimensioned magnetic fractions and association calculations in the pinned material model. |
| M4 | culsma | Yes | True | Returned local references remain usable; unbound local use outside a procedure is rejected. |
| L1 | culsma | Yes | True | One procedure called with 10/20-uL arguments produces 10/20-uL destinations. |
| L2 | culsma | Yes | True | Single returned container is bound to the next procedure; target receives 10 uL. |
| L3 | culsma | Yes | True | Counted repetition and exclusive branching on injected runtime observations; no physical measurement. |
| M1 | labop | NE | False | Distinct model objects, references and RDF round-trip; domain-specific products require defined semantics. |
| M2 | labop | NE | False | Standard Spin document validation accepts a volume-valued duration. |
| M3 | labop | NE | False | Published handler inventory lacks the tested material-separation propagation; GFP extension assessed separately. |
| M4 | labop | NE | False | Activity ownership enforces model-reference scope; Python helper scope is distinct. |
| L1 | labop | NE | False | Parameterized nested activity loses the quantity input; direct Transfer and official upstream test are controls. |
| L2 | labop | NE | False | Nested output-to-input execution receives two sample values; direct operations work. |
| L3 | labop | NE | False | Both guarded Transfer branches execute for either Boolean input; native cycle raises the retained MergeNode error. |
| M1 | bpl | Yes | True | Named labware declarations and distinct resolved endpoints; not a claim of complete local binding. |
| M2 | bpl | No | True | Duration and transfer lowering accept incompatible dimensions. |
| M3 | bpl | No | True | Transfer moves liquid volume but does not propagate the seeded component into the destination. |
| M4 | bpl | No | True | Local let bindings are not consumed by the inspected lowering route. |
| L1 | bpl | No | True | Procedure bodies and argument binding are absent on the checked CLI route; direct and no-argument controls retained. |
| L2 | bpl | No | True | Changing the callee body or return leaves plans unchanged; simulation ignores the call while direct control works. |
| L3 | bpl | No | True | Loop/conditional blocks are omitted from executable plans; direct three-transfer control remains. |
