"""Domain-owned requirement identities and existing application rules."""
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from culsma.common.enum_registration import EnumTypeRegistry
from .checks import ColdChainRule, ConstraintContext, ConstraintViolation


@dataclass(frozen=True)
class ConstraintRequirementSpec:
    category: str
    allowed_on: frozenset[str]
    scopes: frozenset[str]
    conflicts: frozenset[str] = frozenset()
    needs_context: frozenset[str] = frozenset()
    context_checks: tuple[Callable[[ConstraintContext], ConstraintViolation | None], ...] = ()

    def __post_init__(self):
        operations = {'mutation', 'sep', 'frac', 'img', 'ecp', 'phy', 'stream', 'env_hold', 'agit'}
        if not isinstance(self.category, str) or not self.category or not self.allowed_on or not set(self.allowed_on) <= operations:
            raise ValueError('Requirement must declare supported operation families')
        if not self.scopes or not set(self.scopes) <= {'stmt', 'block'}:
            raise ValueError('Requirement must declare statement/block scopes')
        if self.needs_context:
            raise ValueError('Custom context predicates are not supported')
        if any(not isinstance(item, str) or not item for item in self.conflicts):
            raise TypeError('Requirement conflicts must name requirement spellings')
        checks = tuple(self.context_checks)
        if any(not callable(check) for check in checks):
            raise TypeError('Constraint context checks must be callable')
        object.__setattr__(self, 'context_checks', checks)
        for name in ('allowed_on', 'scopes', 'conflicts', 'needs_context'):
            object.__setattr__(self, name, frozenset(getattr(self, name)))


# Preserve existing vocabulary-extension imports.
RequirementSpec = ConstraintRequirementSpec


class ConstraintRequirementBase(StrEnum):
    def __new__(cls, wire, spec):
        if not isinstance(spec, ConstraintRequirementSpec):
            raise TypeError('Requirement members need a ConstraintRequirementSpec')
        member = str.__new__(cls, wire)
        member._value_ = wire
        member.spec = spec
        return member


class ConstraintRequirement(ConstraintRequirementBase):
    DROPWISE = ('dropwise', ConstraintRequirementSpec(
        category="delivery_mode",
        allowed_on=frozenset({"mutation"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    SPREAD = ('spread', ConstraintRequirementSpec(
        category="delivery_mode",
        allowed_on=frozenset({"mutation"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    PRESERVE_BOUNDARY = ('preserve_boundary', ConstraintRequirementSpec(
        category="structure_preservation",
        allowed_on=frozenset({"mutation", "sep", "frac"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    PRESERVE_LAYERING = ('preserve_layering', ConstraintRequirementSpec(
        category="structure_preservation",
        allowed_on=frozenset({"mutation", "sep", "frac"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    PRESERVE_FRACTION_ORDER = ('preserve_fraction_order', ConstraintRequirementSpec(
        category="structure_preservation",
        allowed_on=frozenset({"sep", "frac"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    ASEPTIC = ('aseptic', ConstraintRequirementSpec(
        category="contamination_control",
        allowed_on=frozenset({"agit", "mutation", "sep", "img", "ecp", "phy", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    LOW_CARRYOVER = ('low_carryover', ConstraintRequirementSpec(
        category="contamination_control",
        allowed_on=frozenset({"mutation", "sep", "img", "ecp", "phy", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    CROSS_CONTAM_CONTROL = ('cross_contam_control', ConstraintRequirementSpec(
        category="contamination_control",
        allowed_on=frozenset({"agit", "mutation", "sep", "img", "ecp", "phy", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    GENTLE = ('gentle', ConstraintRequirementSpec(
        category="material_integrity",
        allowed_on=frozenset({"agit", "mutation", "sep", "frac", "stream", "env_hold"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    AVOID_RESUSPENSION = ('avoid_resuspension', ConstraintRequirementSpec(
        category="material_integrity",
        allowed_on=frozenset({"mutation", "sep", "frac"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    AVOID_SHEAR = ('avoid_shear', ConstraintRequirementSpec(
        category="material_integrity",
        allowed_on=frozenset({"mutation", "sep", "frac", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    PRESERVE_VIABILITY = ('preserve_viability', ConstraintRequirementSpec(
        category="material_integrity",
        allowed_on=frozenset({"mutation", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    COLD_CHAIN = ('cold_chain', ConstraintRequirementSpec(
        category="environmental_protection",
        allowed_on=frozenset({"agit", "mutation", "sep", "frac", "img", "ecp", "phy", "stream", "env_hold"}),
        scopes=frozenset({"stmt", "block"}),
        context_checks=(ColdChainRule.validate,),
    ))
    DARK_PROTECTED = ('dark_protected', ConstraintRequirementSpec(
        category="environmental_protection",
        allowed_on=frozenset({"agit", "mutation", "img", "ecp", "phy", "stream", "env_hold"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    SEALED = ('sealed', ConstraintRequirementSpec(
        category="environmental_protection",
        allowed_on=frozenset({"env_hold"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    CONTROLLED_ATMOSPHERE = ('controlled_atmosphere', ConstraintRequirementSpec(
        category="environmental_protection",
        allowed_on=frozenset({"agit", "mutation", "img", "ecp", "phy", "stream", "env_hold"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    HIGH_PRECISION = ('high_precision', ConstraintRequirementSpec(
        category="quantitative_quality",
        allowed_on=frozenset({"mutation", "sep", "frac", "ecp", "phy"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    LOW_LOSS = ('low_loss', ConstraintRequirementSpec(
        category="quantitative_quality",
        allowed_on=frozenset({"mutation", "sep", "frac", "ecp", "phy"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    QUANTITATIVE_RECOVERY = ('quantitative_recovery', ConstraintRequirementSpec(
        category="quantitative_quality",
        allowed_on=frozenset({"mutation", "sep", "frac"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    STABILIZED_READING = ('stabilized_reading', ConstraintRequirementSpec(
        category="measurement_quality",
        allowed_on=frozenset({"img", "ecp", "phy"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    LOW_NOISE = ('low_noise', ConstraintRequirementSpec(
        category="measurement_quality",
        allowed_on=frozenset({"img", "ecp", "phy"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    NONINVASIVE = ('noninvasive', ConstraintRequirementSpec(
        category="measurement_quality",
        allowed_on=frozenset({"img", "ecp", "phy"}),
        scopes=frozenset({"stmt", "block"}),
    ))
    CUSTOMIZED = ('customized', ConstraintRequirementSpec(
        category="customized",
        allowed_on=frozenset({"mutation", "sep", "frac", "img", "ecp", "phy", "stream"}),
        scopes=frozenset({"stmt", "block"}),
    ))


@dataclass(frozen=True)
class ConstraintRequirementContract:
    registry: EnumTypeRegistry
    enum_type = ConstraintRequirementBase
    standard = ConstraintRequirement
    allow_legacy_text = False

    @property
    def standard_registry(self):
        return self.registry

    @property
    def current(self):
        return self.registry.current

    @property
    def wire_values(self):
        return tuple(member.value for member in ConstraintRequirement)

    def validate(self, value):
        if not isinstance(value, ConstraintRequirementBase):
            raise TypeError('Expected an execution requirement')
        self.current.registration(type(value))
        return value

    def decode(self, value):
        if type(value) is not str:
            raise TypeError('Expected an execution requirement spelling')
        return ConstraintRequirement(value)


STANDARD_CONSTRAINT_REQUIREMENTS = EnumTypeRegistry.create(
    ConstraintRequirementBase, ConstraintRequirement, 'constraint_requirement')
CONSTRAINT_REQUIREMENTS = ConstraintRequirementContract(STANDARD_CONSTRAINT_REQUIREMENTS)


class RequirementSpecRegistry(Mapping):
    def __getitem__(self, name):
        if type(name) is str:
            try:
                name = CONSTRAINT_REQUIREMENTS.decode(name)
            except ValueError:
                raise KeyError(name) from None
        if isinstance(name, ConstraintRequirementBase):
            CONSTRAINT_REQUIREMENTS.validate(name)
            return name.spec
        raise KeyError(name)

    def __iter__(self):
        return iter(member.value for member in ConstraintRequirement)

    def __len__(self):
        return len(ConstraintRequirement)


REQUIREMENT_REGISTRY = RequirementSpecRegistry()
