"""Runtime value and expression resolution helpers."""

from __future__ import annotations

from culsma.common.value_contracts import VALUE_CONTRACTS, UNRESOLVED_VALUE
from culsma.runtime.value_adapters import AdaptedValue, create_value_adapter_registry
from culsma.runtime.value_adapters.contracts import QuantityDisplayValue
from culsma.runtime.data_values import DataReferenceBuilder
from culsma.enum_services import PARAMETER_ENUM_TYPES
from culsma.runtime.stream_values import StreamValueBuilder
from culsma.pipeline.external_boundary import DEFAULT_EXTERNAL_ENUM_CODEC, DEFAULT_EXTERNAL_PARAMETER_NORMALIZER, RuntimeParameterError

from culsma.pipeline.expression_resolution import project_record_member, ResolutionStatus
from culsma.pipeline.container_views import is_container_contents_volume, split_member_path, is_container_target_view
from culsma.runtime.material.refs import MaterialRefResolver

from copy import deepcopy
from typing import Any

from culsma.common.content_contracts import CONTENT_ENUM_TYPES, parse_serialized_content_enum, serialize_content_enum
from culsma.common.quantity_arithmetic import QuantityArithmeticError, quantity_binary
from culsma.pipeline.plan_nodes import PlanStep
from culsma.runtime.state import RuntimeState


_LOCAL_RUNTIME_CONSTRUCTORS = {"markers", "stream", "data_ref", "data_group_ref", "data_schema"}
UNRESOLVED = UNRESOLVED_VALUE


def evaluate_content_enum(expr: Any) -> Any:
    value = parse_serialized_content_enum(expr)
    return value if value is not None else UNRESOLVED


class RuntimeValueResolver:
    def __init__(self, adapters=None) -> None:
        self.adapters = adapters if adapters is not None else create_value_adapter_registry()

    def read_adapted(self, type_id: str, value: Any, state: RuntimeState) -> Any:
        if not VALUE_CONTRACTS.resolve(type_id):
            return UNRESOLVED
        adapter = self.adapters.resolve(type_id)
        return adapter.read(type_id, value, state, self) if adapter is not None else UNRESOLVED

    def read_detection(self, value: Any, state: RuntimeState) -> Any:
        args = {arg['name']: arg['value'] for arg in value['args']}
        candidates = []
        for expr in (args['self'], args['arg0']):
            resolved = self.read_value(expr, state)
            if resolved is UNRESOLVED:
                return UNRESOLVED
            keys = [expr['name']] if isinstance(expr, dict) and expr.get('kind') == 'IRIdentifier' else []
            identity = resolved.get('id') if isinstance(resolved, dict) else None
            if isinstance(identity, str) and identity not in keys:
                keys.append(identity)
            candidates.append(keys)
        return read_detection_hits(candidates[0], candidates[1], state)

    def read_value(self, expr: Any, state: RuntimeState) -> Any:
        """Read a print operand without evaluating constructors or consuming streams."""
        if isinstance(expr, dict):
            raw_kind = expr.get("kind")
            kind = raw_kind if isinstance(raw_kind, str) else None
            if kind == "IRIdentifier":
                return self.read_identifier(expr, state)
            if kind == "IRCall":
                if 'runtime_ref' in expr:
                    return self.read_value(expr['runtime_ref'], state)
                contract = VALUE_CONTRACTS.resolve_call(expr.get('name'))
                return self.read_adapted(contract.type_id, expr, state) if contract is not None else UNRESOLVED
            if kind in {"IRList", "IRGroup"}:
                if kind == "IRGroup":
                    group = self.read_adapted('material.reference', expr, state)
                    if group is not UNRESOLVED:
                        return group
                values = [self.read_value(item, state) for item in expr.get("elements", [])]
                return UNRESOLVED if any(item is UNRESOLVED for item in values) else values
            if kind == "IRMember":
                if is_container_target_view(expr):
                    view = self.read_adapted('material.target_view', expr, state)
                    if view is not UNRESOLVED:
                        return view
                if is_container_contents_volume(expr):
                    volume = read_container_volume(expr, state)
                    if volume is not UNRESOLVED:
                        return volume
                # Qualified enum members have already been serialized to enum values.
                base = self.read_value(expr.get("base"), state)
                if isinstance(base, dict):
                    if isinstance(base, AdaptedValue) and base.type_id == "material.container" and expr.get("member") == "materials":
                        return base.get("component_entries", [])
                    return base.get(expr.get('member'), UNRESOLVED)
                return UNRESOLVED
            if kind == "IRIndex":
                base = self.read_value(expr.get('base'), state)
                index = self.read_value(expr.get('index'), state)
                members = base.get('members') if isinstance(base, AdaptedValue) and base.type_id == 'material.group' else base
                if isinstance(members, list) and isinstance(index, (int, float)) and not isinstance(index, bool):
                    if float(index).is_integer() and 0 <= index < len(members):
                        return members[int(index)]
                    return UNRESOLVED
                value = _resolve_runtime_index(expr, state)
                if value is not UNRESOLVED:
                    return value
                return self.read_adapted('material.reference', expr, state)
            if kind == "IRBinary":
                return evaluate_runtime_binary_values(expr.get("op"),
                    self.read_operand(expr.get("left"), state), self.read_operand(expr.get("right"), state))
            if kind == "IRUnary":
                operand = self.read_operand(expr.get("operand"), state)
                if expr.get("op") != "-" or operand is UNRESOLVED:
                    return UNRESOLVED
                try:
                    return quantity_binary("*", -1, operand)
                except QuantityArithmeticError:
                    return UNRESOLVED
            if kind is None:
                values = {key: self.read_value(value, state) for key, value in expr.items()}
                return UNRESOLVED if any(item is UNRESOLVED for item in values.values()) else values
        return evaluate_runtime_expression(expr, state)

    def read_operand(self, expr: Any, state: RuntimeState) -> Any:
        """Decode typed scalar operands without interpreting record fields as calls."""
        value = self.read_value(expr, state)
        if isinstance(value, dict) and set(value) == {"kind", "value", "unit"} and value.get("kind") == "IRQuantity":
            number, unit = value["value"], value["unit"]
            return number if unit is None else (number, unit)
        return value

    def read_identifier(self, expr: dict[str, Any], state: RuntimeState) -> Any:
        """Resolve existing bindings through the read-only path, never constructor evaluation."""
        name = expr.get("name")
        if not isinstance(name, str):
            return UNRESOLVED
        locals_ = state.artifacts.get("local_bindings", {})
        if name in locals_:
            value = locals_[name]
            type_id = state.artifacts.get('local_value_types', {}).get(name)
            if type_id == 'record':
                return value
            if type_id is not None and isinstance(value, dict):
                if type_id == 'material.container':
                    return self.read_adapted(type_id, value, state)
                return AdaptedValue(type_id, value)
            kind = value.get("kind") if isinstance(value, dict) else None
            if isinstance(kind, str) and (kind.startswith("IR") or kind in {
                "ContentEnum", "ExternalEnum", "DomainEnum", "ChromatographyEnum"
            }):
                return self.read_value(value, state)
            return self.project_read_value(value, state) if isinstance(value, AdaptedValue) else value
        for bindings_key, values_key in (("data_bindings", "data_objects"), ("data_group_bindings", "data_groups")):
            reference = state.artifacts.get(bindings_key, {}).get(name)
            value = state.artifacts.get(values_key, {}).get(reference)
            if isinstance(value, dict):
                return value
        return self.read_adapted('material.reference', expr, state)

    def project_read_value(self, value: Any, state: RuntimeState) -> Any:
        """Project current material references using the selection path's entry order."""
        if isinstance(value, AdaptedValue):
            if value.type_id == 'material.container':
                return self.read_adapted(value.type_id, value, state)
            return value
        return value

    def material_group_payload(self, material: Any, expr: Any) -> Any:
        return _container_group_ref_payload(material, expr)

    def material_value_payload(self, material: Any, expr: Any) -> Any:
        return _resolve_runtime_material_value(material, expr)

    def eval_expr(self, expr: Any, state: RuntimeState) -> Any:
        return evaluate_runtime_expression(expr, state)

    def eval_local_value(self, target: str, expr: Any, state: RuntimeState) -> Any:
        if VALUE_CONTRACTS.requires_capture(expr):
            return self.read_value(expr, state)
        return _eval_runtime_local_value(target, expr, state)

    def eval_method_arg(self, expr: Any, state: RuntimeState) -> Any:
        return _eval_runtime_method_arg(expr, state)

    def resolve_append_target(self, expr: Any, state: RuntimeState) -> Any:
        return _resolve_runtime_append_target(expr, state)

    def resolve_member_assign_target(self, expr: Any, state: RuntimeState) -> Any:
        return _resolve_runtime_member_assign_target(expr, state)

    def value_to_serialized(self, value: Any) -> Any:
        return serialize_runtime_value(value)

    def deep_serialize(self, value: Any) -> Any:
        return _runtime_deep_serialize(value)

    def protocol_output_serialize(self, value: Any) -> Any:
        return _runtime_protocol_output_serialize(value)

    def resolve_step_args(self, step: PlanStep, state: RuntimeState) -> PlanStep:
        return _resolve_step_runtime_args(step, state)

    def eval_repeat_items(self, expr: Any, state: RuntimeState) -> Any:
        return _eval_runtime_repeat_items(expr, state)

    def resolve_runtime_ref(self, material_state: Any, value: Any) -> str | None:
        return _resolve_runtime_ref(material_state, value)

    def resolve_runtime_ref_group(self, material_state: Any, value: Any) -> list[dict[str, Any]] | None:
        return _resolve_runtime_ref_group(material_state, value)

    def container_ref_payload(self, material_state: Any, container_id: str) -> dict[str, Any] | None:
        return _container_ref_payload(material_state, container_id)

    def eval_protocol_output_expr(self, expr: Any, state: RuntimeState) -> Any:
        # Composite members need the same material-reference fallback as a top-level return.
        if isinstance(expr, dict):
            kind = expr.get("kind")
            if not isinstance(kind, str):
                record = {}
                for key, member in expr.items():
                    value = self.eval_protocol_output_expr(member, state)
                    if value is UNRESOLVED:
                        return UNRESOLVED
                    record[key] = value
                return record
            if kind == "IRList":
                elements = expr.get("elements")
                if not isinstance(elements, list):
                    return UNRESOLVED
                values = [self.eval_protocol_output_expr(member, state) for member in elements]
                return UNRESOLVED if any(value is UNRESOLVED for value in values) else values
        value = evaluate_runtime_expression(expr, state)
        if value is not UNRESOLVED:
            return value
        material_value = _resolve_runtime_material_output_value(state.artifacts.get("material_state"), expr)
        if material_value is not None:
            return material_value
        return UNRESOLVED


def read_container_volume(expr: Any, state: RuntimeState) -> Any:
    """Read the authoritative quantity without projecting or changing material entries."""
    path = split_member_path(expr)
    material = state.artifacts.get("material_state")
    if path is None or not isinstance(material, dict):
        return UNRESOLVED
    container_id = _resolve_runtime_ref(material, path[0])
    containers = material.get("containers", {})
    container = containers.get(container_id) if isinstance(containers, dict) else None
    volume = container.get("volume_uL") if isinstance(container, dict) else None
    return (float(volume), "uL") if isinstance(volume, (int, float)) else UNRESOLVED


def evaluate_runtime_expression(expr: Any, state: RuntimeState) -> Any:
    if isinstance(expr, dict):
        kind = expr.get("kind")
        if kind in {"ExternalEnum", "ChromatographyEnum", "DomainEnum"}:
            try:
                return DEFAULT_EXTERNAL_ENUM_CODEC.decode(expr)
            except ValueError:
                return UNRESOLVED
        if kind == "ContentEnum":
            return evaluate_content_enum(expr)
        if kind == "IRBoolean":
            return expr.get("value")
        if kind == "IRString":
            return expr.get("value")
        if kind == "IRQuantity":
            unit = expr.get("unit")
            if unit is None:
                return expr.get("value")
            return (expr.get("value"), unit)
        if kind in {"IRList", "IRGroup"}:
            elements = expr.get("elements")
            if not isinstance(elements, list):
                return UNRESOLVED
            out: list[Any] = []
            for item in elements:
                resolved = evaluate_runtime_expression(item, state)
                if resolved is UNRESOLVED:
                    return UNRESOLVED
                out.append(resolved)
            return out
        if kind == "IRIdentifier":
            return _resolve_runtime_identifier(expr.get("name"), state)
        if kind == "IRIndex":
            return _resolve_runtime_index(expr, state)
        if kind == "IRMember":
            if expr.get("member") == "concentration" and VALUE_CONTRACTS.contains_read_call(expr):
                return RuntimeValueResolver().read_operand(expr, state)
            if is_container_contents_volume(expr):
                volume = read_container_volume(expr, state)
                if volume is not UNRESOLVED:
                    return volume
            base = evaluate_runtime_expression(expr.get("base"), state)
            if base is UNRESOLVED:
                return UNRESOLVED
            member = expr.get("member")
            if not isinstance(member, str):
                return UNRESOLVED
            projected = project_record_member(base, member)
            return _runtime_bound_value(projected.value, state) if projected.status is ResolutionStatus.RESOLVED else UNRESOLVED
        if kind == "IRCall":
            return _eval_runtime_call(expr, state)
        if kind == "IRUnary":
            operand = evaluate_runtime_expression(expr.get("operand"), state)
            if operand is UNRESOLVED:
                return UNRESOLVED
            if expr.get("op") == "-":
                try:
                    return quantity_binary("*", -1, operand)
                except QuantityArithmeticError:
                    return UNRESOLVED
            return UNRESOLVED
        if kind == "IRBinary":
            return evaluate_runtime_binary(expr, state)
        if kind is None or not isinstance(kind, str):
            record = {}
            for key, raw in expr.items():
                value = evaluate_runtime_expression(raw, state)
                if value is UNRESOLVED:
                    return UNRESOLVED
                record[key] = value
            return record
    if isinstance(expr, (bool, int, float, str)):
        return expr
    return UNRESOLVED


def _resolve_runtime_identifier(name: Any, state: RuntimeState) -> Any:
    if not isinstance(name, str):
        return UNRESOLVED
    local_bindings = state.artifacts.get("local_bindings", {})
    if isinstance(local_bindings, dict) and name in local_bindings:
        return _runtime_bound_value(local_bindings.get(name), state)
    data_bindings = state.artifacts.get("data_bindings", {})
    if isinstance(data_bindings, dict):
        data_id = data_bindings.get(name)
        data_objects = state.artifacts.get("data_objects", {})
        if isinstance(data_id, str) and isinstance(data_objects, dict):
            record = data_objects.get(data_id)
            if isinstance(record, dict):
                return record
    data_group_bindings = state.artifacts.get("data_group_bindings", {})
    if isinstance(data_group_bindings, dict):
        group_id = data_group_bindings.get(name)
        groups = state.artifacts.get("data_groups", {})
        if isinstance(group_id, str) and isinstance(groups, dict):
            record = groups.get(group_id)
            if isinstance(record, dict):
                return record
    return UNRESOLVED


def _eval_runtime_call(expr: dict[str, Any], state: RuntimeState) -> Any:
    name = expr.get("name")
    if not isinstance(name, str):
        return UNRESOLVED
    contract = VALUE_CONTRACTS.resolve_call(name)
    if contract is not None and contract.type_id == 'configuration.medium':
        return RuntimeValueResolver().read_adapted(contract.type_id, expr, state)
    if name == 'plate' and 'runtime_ref' in expr:
        return evaluate_runtime_expression(expr['runtime_ref'], state)
    if name in _LOCAL_RUNTIME_CONSTRUCTORS:
        return _eval_local_runtime_constructor(expr, state)
    if name == "detects":
        return _eval_runtime_detects(expr, state)
    return UNRESOLVED


def _eval_runtime_local_value(target: str, expr: Any, state: RuntimeState) -> Any:
    if isinstance(expr, dict) and expr.get("kind") == "IRCall":
        name = expr.get("name")
        if isinstance(name, str) and name in _LOCAL_RUNTIME_CONSTRUCTORS:
            return _eval_local_runtime_constructor(expr, state, target_name=target)
    return evaluate_runtime_expression(expr, state)


def _eval_local_runtime_constructor(
    expr: dict[str, Any],
    state: RuntimeState,
    *,
    target_name: str | None = None,
) -> Any:
    name = expr.get("name")
    if not isinstance(name, str):
        return UNRESOLVED
    raw_args = expr.get("args")
    if not isinstance(raw_args, list):
        raw_args = []
    kwargs: dict[str, Any] = {}
    for raw_arg in raw_args:
        if not isinstance(raw_arg, dict):
            continue
        arg_name = raw_arg.get("name")
        if not isinstance(arg_name, str):
            continue
        kwargs[arg_name] = _eval_runtime_constructor_arg(raw_arg.get("value"), state)

    try:
        kwargs = DEFAULT_EXTERNAL_PARAMETER_NORMALIZER.normalize_runtime_arguments(name, kwargs)
    except (TypeError, ValueError) as error:
        raise RuntimeParameterError(str(error)) from error

    if name == "markers":
        raw_items = kwargs.get("items")
        items = raw_items if isinstance(raw_items, list) else []
        return {
            "kind": "marker_panel_ref",
            "label": target_name,
            "items": list(items),
        }
    if name == "stream":
        return StreamValueBuilder.build(kwargs, state, target_name=target_name)
    if name in {"data_ref", "data_group_ref"}:
        return DataReferenceBuilder.build(
            name, kwargs, _merge_result_payloads(_schema_result_payload(kwargs.get("schema_ref")), {})
        )
    if name == "data_schema":
        return {
            "kind": "data_schema_ref",
            "label": kwargs.get("label"),
            "fields": kwargs.get("fields"),
        }
    return UNRESOLVED


def _eval_runtime_constructor_arg(expr: Any, state: RuntimeState) -> Any:
    if isinstance(expr, dict):
        kind = expr.get("kind")
        if kind == "IRIdentifier":
            resolved = _resolve_runtime_identifier(expr.get("name"), state)
            if resolved is not UNRESOLVED:
                return resolved
            material_ref = _resolve_runtime_ref(
                state.artifacts.get("material_state"),
                expr,
            )
            if material_ref is not None:
                return material_ref
            name = expr.get("name")
            if isinstance(name, str):
                return name
            return UNRESOLVED
        if kind in {"IRList", "IRGroup"}:
            elements = expr.get("elements")
            if not isinstance(elements, list):
                return []
            return [_eval_runtime_constructor_arg(item, state) for item in elements]
    value = evaluate_runtime_expression(expr, state)
    if value is not UNRESOLVED:
        return value
    return expr


def _eval_runtime_method_arg(expr: Any, state: RuntimeState) -> Any:
    if isinstance(expr, dict) and expr.get("kind") == "IRIdentifier":
        resolved = _resolve_runtime_identifier(expr.get("name"), state)
        if resolved is not UNRESOLVED:
            return resolved
        name = expr.get("name")
        if isinstance(name, str):
            return name
    return evaluate_runtime_expression(expr, state)


def _eval_runtime_detects(expr: dict[str, Any], state: RuntimeState) -> Any:
    raw_args = expr.get("args")
    if not isinstance(raw_args, list) or len(raw_args) < 2:
        return UNRESOLVED
    receiver_expr = raw_args[0].get("value") if isinstance(raw_args[0], dict) else None
    target_expr = raw_args[1].get("value") if isinstance(raw_args[1], dict) else None
    receiver_candidates = _runtime_detect_key_candidates(receiver_expr, state)
    target_candidates = _runtime_detect_key_candidates(target_expr, state)
    return read_detection_hits(receiver_candidates, target_candidates, state)


def read_detection_hits(receiver_candidates: list[str], target_candidates: list[str], state: RuntimeState) -> Any:
    """Read existing sensing-hook results without invoking a detector or consuming data."""
    if not receiver_candidates or not target_candidates:
        return UNRESOLVED
    detect_hits = state.artifacts.get("detect_hits", {})
    if not isinstance(detect_hits, dict):
        return False
    for receiver_key in receiver_candidates:
        hit_spec = detect_hits.get(receiver_key)
        if hit_spec is None:
            continue
        if hit_spec is True:
            return True
        if isinstance(hit_spec, (list, tuple, set)):
            hit_set = {item for item in hit_spec if isinstance(item, str)}
            if any(target_key in hit_set for target_key in target_candidates):
                return True
        if isinstance(hit_spec, dict):
            for target_key in target_candidates:
                if bool(hit_spec.get(target_key)):
                    return True
    return False


def _eval_runtime_repeat_items(expr: Any, state: RuntimeState) -> Any:
    value = evaluate_runtime_expression(expr, state)
    if value is UNRESOLVED:
        return UNRESOLVED
    if isinstance(value, list):
        return [deepcopy(item) for item in value]
    if isinstance(value, dict):
        items = value.get("items")
        if isinstance(items, list):
            return [deepcopy(item) for item in items]
    return UNRESOLVED


def _runtime_detect_key_candidates(expr: Any, state: RuntimeState) -> list[str]:
    candidates: list[str] = []
    if not isinstance(expr, dict):
        return candidates
    if expr.get("kind") == "IRIdentifier":
        name = expr.get("name")
        if isinstance(name, str):
            candidates.append(name)
        material_ref = _resolve_runtime_ref(state.artifacts.get("material_state"), expr)
        if isinstance(material_ref, str) and material_ref not in candidates:
            candidates.append(material_ref)
        local_bindings = state.artifacts.get("local_bindings", {})
        if isinstance(name, str) and isinstance(local_bindings, dict) and name in local_bindings:
            candidates.append(name)
            bound_value = local_bindings.get(name)
            if isinstance(bound_value, dict):
                bound_id = bound_value.get("id")
                if isinstance(bound_id, str) and bound_id not in candidates:
                    candidates.append(bound_id)
        return candidates
    resolved = evaluate_runtime_expression(expr, state)
    if isinstance(resolved, dict):
        ref_id = resolved.get("id")
        if isinstance(ref_id, str):
            candidates.append(ref_id)
    return candidates


def _resolve_runtime_index(expr: dict[str, Any], state: RuntimeState) -> Any:
    base = expr.get("base")
    index = expr.get("index")
    if not isinstance(base, dict) or base.get("kind") != "IRIdentifier":
        return UNRESOLVED
    group_name = base.get("name")
    if not isinstance(group_name, str):
        return UNRESOLVED
    slot = _runtime_static_index_key(index)
    if slot is None:
        return UNRESOLVED
    indexed_group_bindings = state.artifacts.get("data_group_indexed_bindings", {})
    data_objects = state.artifacts.get("data_objects", {})
    if not isinstance(indexed_group_bindings, dict) or not isinstance(data_objects, dict):
        return UNRESOLVED
    group = indexed_group_bindings.get(group_name)
    if not isinstance(group, dict):
        return UNRESOLVED
    data_id = group.get(slot)
    if not isinstance(data_id, str):
        return UNRESOLVED
    record = data_objects.get(data_id)
    if not isinstance(record, dict):
        return UNRESOLVED
    return record


def _resolve_runtime_append_target(expr: Any, state: RuntimeState) -> Any:
    if not isinstance(expr, dict):
        return UNRESOLVED
    if expr.get("kind") == "IRIdentifier":
        resolved = _resolve_runtime_identifier(expr.get("name"), state)
        return resolved if isinstance(resolved, list) else UNRESOLVED
    if expr.get("kind") != "IRMember":
        return UNRESOLVED

    base = _resolve_runtime_mutable_path(expr.get("base"), state)
    if base is UNRESOLVED or not isinstance(base, dict):
        return UNRESOLVED
    member = expr.get("member")
    if not isinstance(member, str):
        return UNRESOLVED
    current = base.get(member)
    if current is None:
        base[member] = []
        current = base[member]
    return current if isinstance(current, list) else UNRESOLVED


def _resolve_runtime_member_assign_target(expr: Any, state: RuntimeState) -> Any:
    path = _runtime_member_path(expr)
    if path is None:
        return UNRESOLVED
    root_name, members = path
    if len(members) < 2 or members[0] != "result":
        return UNRESOLVED
    root = _resolve_runtime_identifier(root_name, state)
    if root is UNRESOLVED or not isinstance(root, dict):
        return UNRESOLVED
    if root.get("kind") not in {"data_ref", "data_group_ref"}:
        return UNRESOLVED
    current = root
    for member in members[:-1]:
        next_value = current.get(member)
        if next_value is None:
            current[member] = {}
            next_value = current[member]
        if not isinstance(next_value, dict):
            return UNRESOLVED
        current = next_value
    return current, members[-1]


def _runtime_member_path(expr: Any) -> tuple[str, list[str]] | None:
    if not isinstance(expr, dict):
        return None
    members: list[str] = []
    current = expr
    while isinstance(current, dict) and current.get("kind") == "IRMember":
        member = current.get("member")
        if not isinstance(member, str):
            return None
        members.append(member)
        current = current.get("base")
    if not isinstance(current, dict) or current.get("kind") != "IRIdentifier":
        return None
    name = current.get("name")
    if not isinstance(name, str):
        return None
    members.reverse()
    return name, members


def _resolve_runtime_mutable_path(expr: Any, state: RuntimeState) -> Any:
    if not isinstance(expr, dict):
        return UNRESOLVED
    kind = expr.get("kind")
    if kind == "IRIdentifier":
        return _resolve_runtime_identifier(expr.get("name"), state)
    if kind != "IRMember":
        return UNRESOLVED
    base = _resolve_runtime_mutable_path(expr.get("base"), state)
    if base is UNRESOLVED or not isinstance(base, dict):
        return UNRESOLVED
    member = expr.get("member")
    if not isinstance(member, str):
        return UNRESOLVED
    current = base.get(member)
    if current is None:
        base[member] = {}
        current = base[member]
    return current if isinstance(current, dict) else UNRESOLVED


def evaluate_runtime_binary(expr: dict[str, Any], state: RuntimeState) -> Any:
    op = expr.get("op")
    left = evaluate_runtime_expression(expr.get("left"), state)
    right = evaluate_runtime_expression(expr.get("right"), state)
    return evaluate_runtime_binary_values(op, left, right)


def evaluate_runtime_binary_values(op: Any, left: Any, right: Any) -> Any:
    """Apply existing operators to resolved values, without evaluating code-shaped data."""
    if left is UNRESOLVED or right is UNRESOLVED:
        return UNRESOLVED
    if op == "and":
        return bool(left) and bool(right)
    if op == "or":
        return bool(left) or bool(right)
    if op in {"==", "!=", "<", ">", "<=", ">="}:
        left_cmp, right_cmp = _runtime_comparable_pair(left, right)
        if left_cmp is UNRESOLVED or right_cmp is UNRESOLVED:
            return UNRESOLVED
        try:
            if op == "==":
                return left_cmp == right_cmp
            if op == "!=":
                return left_cmp != right_cmp
            if op == "<":
                return left_cmp < right_cmp
            if op == ">":
                return left_cmp > right_cmp
            if op == "<=":
                return left_cmp <= right_cmp
            return left_cmp >= right_cmp
        except TypeError:
            return UNRESOLVED
    try:
        return quantity_binary(op, left, right)
    except QuantityArithmeticError:
        return UNRESOLVED


def _runtime_comparable_pair(left: Any, right: Any) -> tuple[Any, Any]:
    if isinstance(left, tuple) and isinstance(right, tuple):
        if len(left) == 2 and len(right) == 2 and left[1] == right[1]:
            return left[0], right[0]
        return UNRESOLVED, UNRESOLVED
    if isinstance(left, tuple) or isinstance(right, tuple):
        return UNRESOLVED, UNRESOLVED
    return left, right


def _runtime_bound_value(value: Any, state: RuntimeState) -> Any:
    if isinstance(value, dict):
        kind = value.get("kind")
        if kind == "IRQuantity":
            raw = value.get("value")
            unit = value.get("unit")
            if isinstance(raw, (int, float)):
                if unit is None:
                    return raw
                if isinstance(unit, str):
                    return (float(raw), unit)
            return UNRESOLVED
        if kind in ("ContentEnum", "ExternalEnum", "DomainEnum", "ChromatographyEnum"):
            return evaluate_runtime_expression(value, state)
        if not isinstance(kind, str) or not kind.startswith("IR"):
            return value
        return evaluate_runtime_expression(value, state)
    return value


def serialize_runtime_value(value: Any) -> Any:
    if isinstance(value, AdaptedValue):
        return {key: _runtime_deep_serialize(item) for key, item in value.items()}
    if type(value) in PARAMETER_ENUM_TYPES.values():
        return DEFAULT_EXTERNAL_ENUM_CODEC.encode(value)
    if type(value) in CONTENT_ENUM_TYPES.values():
        return serialize_content_enum(value)
    if isinstance(value, tuple) and len(value) == 2 and isinstance(value[0], (int, float)) and isinstance(value[1], str):
        return {"kind": "IRQuantity", "value": float(value[0]), "unit": value[1]}
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def _runtime_deep_serialize(value: Any) -> Any:
    if isinstance(value, QuantityDisplayValue):
        return QuantityDisplayValue(value)
    if isinstance(value, tuple) and len(value) == 2 and isinstance(value[0], (int, float)) and isinstance(value[1], str):
        return QuantityDisplayValue(serialize_runtime_value(value))
    if isinstance(value, AdaptedValue):
        return AdaptedValue(value.type_id, {key: _runtime_deep_serialize(item) for key, item in value.items()})
    if isinstance(value, list):
        return [_runtime_deep_serialize(item) for item in value]
    if isinstance(value, dict):
        return {key: _runtime_deep_serialize(item) for key, item in value.items()}
    return serialize_runtime_value(value)


def _runtime_protocol_output_serialize(value: Any) -> Any:
    if isinstance(value, list):
        return [_runtime_protocol_output_serialize(item) for item in value]
    if isinstance(value, dict):
        if value.get("kind") == "container_group_ref":
            return {
                "kind": "container_group_ref",
                "member_count": value.get("member_count", 0),
                "members": _runtime_protocol_output_serialize(value.get("members", [])),
            }
        if value.get("kind") == "container_ref":
            public_keys = {
                "kind",
                "id",
                "volume_uL",
                "mass_mg",
                "count_cells",
                "component_quantities",
                "component_concentrations",
                "component_entries",
                "unknown_quantity_dimensions",
                "aggregate_quantity_policy",
                "known_mass_subtotal_mg",
                "material_relationships",
                "container_kind",
                "label",
                "barcode",
            }
            return {
                key: _runtime_protocol_output_serialize(item)
                for key, item in value.items()
                if key in public_keys
            }
        return {key: _runtime_protocol_output_serialize(item) for key, item in value.items()}
    return serialize_runtime_value(value)


class PlateRuntimeValueResolver:
    """Keep published descriptor consumers separate from explicit carrier actions."""
    def optional_text(self, expression, state):
        value = evaluate_runtime_expression(expression, state)
        return value if isinstance(value, str) else None

    def descriptors(self, value):
        if isinstance(value, dict):
            plate = value.get('kind') == 'IRCall' and value.get('name') == 'plate'
            return {key: self.descriptors(item) for key, item in value.items()
                    if not (plate and key == 'runtime_ref')}
        if isinstance(value, list):
            return [self.descriptors(item) for item in value]
        return value

    def arguments(self, step, state):
        args = resolve_runtime_arg_value(step.args, state)
        sample = step.args.get('sample')
        if (step.op == 'agit' and isinstance(sample, dict) and sample.get('kind') == 'IRCall'
                and sample.get('name') == 'plate' and 'runtime_ref' in sample):
            from culsma.domains.agitation.contracts import AGITATION_MODE, AgitationMode
            try:
                mode = DEFAULT_EXTERNAL_PARAMETER_NORMALIZER.require_member(args.get('mode'), AGITATION_MODE)
            except (TypeError, ValueError):
                return args  # The normal argument boundary reports the invalid mode.
            if mode is AgitationMode.TAP:
                args['sample'] = resolve_runtime_arg_value(sample['runtime_ref'], state)
        return args


def _resolve_step_runtime_args(step: PlanStep, state: RuntimeState) -> PlanStep:
    from culsma.pipeline.environment_boundary import DEFAULT_ENVIRONMENT_PARAMETER_NORMALIZER

    gate = DEFAULT_ENVIRONMENT_PARAMETER_NORMALIZER.normalize_runtime_gate(
        PlateRuntimeValueResolver().descriptors(step.gate),
        resolve_environment=lambda environment: resolve_runtime_arg_value(environment, state),
        require_duration=step.op == "env_hold",
        resolve_medium_source=lambda value: resolve_medium_source(value, state),
    )
    from culsma.runtime.environment_media import validate_medium_layers
    validate_medium_layers(gate, state)
    if gate is not None and "separation_scopes" in gate:
        gate["separation_scopes"] = resolve_runtime_arg_value(gate["separation_scopes"], state)
    return PlanStep(
        step_id=step.step_id,
        op=step.op,
        args=DEFAULT_EXTERNAL_PARAMETER_NORMALIZER.normalize_runtime_arguments(step.op, PlateRuntimeValueResolver().arguments(step, state)),
        deps=list(step.deps),
        gate=gate,
        span=step.span,
    )


def resolve_medium_source(value: Any, state: RuntimeState) -> str | None:
    material_state = state.artifacts.get('material_state', {})
    if isinstance(value, dict) and value.get('kind') == 'container_ref':
        identity = value.get('id')
        return identity if isinstance(identity, str) and identity in material_state.get('containers', {}) else None
    if isinstance(value, dict) and 'runtime_ref' in value:
        value = value['runtime_ref']
    return _resolve_runtime_ref(material_state, value)


def resolve_runtime_arg_value(value: Any, state: RuntimeState) -> Any:
    if isinstance(value, dict):
        kind = value.get("kind")
        if kind == 'IRCall' and value.get('name') == 'plate':
            return {key: resolve_runtime_arg_value(item, state) for key, item in value.items()
                    if key != 'runtime_ref'}
        if isinstance(kind, str) and kind == "IRIdentifier":
            name = value.get("name")
            local_bindings = state.artifacts.get("local_bindings", {})
            if isinstance(name, str) and isinstance(local_bindings, dict) and name in local_bindings:
                return local_bindings[name]
        if isinstance(kind, str) and kind in {"IRBinary", "IRUnary", "IRMember"}:
            evaluated = evaluate_runtime_expression(value, state)
            if evaluated is not UNRESOLVED:
                return serialize_runtime_value(evaluated)
        return {key: resolve_runtime_arg_value(item, state) for key, item in value.items()}
    if isinstance(value, list):
        return [resolve_runtime_arg_value(item, state) for item in value]
    return value


def _resolve_runtime_material_output_value(material_state: Any, expr: Any) -> dict[str, Any] | None:
    group_value = _container_group_ref_payload(material_state, expr)
    if group_value is not None:
        return group_value
    return _resolve_runtime_material_value(material_state, expr)


def _resolve_runtime_material_value(material_state: Any, expr: Any) -> dict[str, Any] | None:
    container_id = _resolve_runtime_ref(material_state, expr)
    if not isinstance(container_id, str):
        return None
    return _container_ref_payload(material_state, container_id)


def _container_ref_payload(material_state: Any, container_id: str) -> dict[str, Any] | None:
    if not isinstance(material_state, dict):
        return None
    containers = material_state.get("containers")
    if not isinstance(containers, dict):
        return None
    raw = containers.get(container_id)
    if not isinstance(raw, dict):
        return None
    metadata = raw.get("metadata")
    metadata_out = deepcopy(metadata) if isinstance(metadata, dict) else {}
    components = raw.get("components")
    component_map: dict[str, Any] = {}
    if isinstance(components, dict):
        for name, amount in components.items():
            if isinstance(amount, (int, float)):
                component_map[str(name)] = round(float(amount), 6)
            elif amount is None:
                component_map[str(name)] = None
    raw_quantities = raw.get("component_quantities")
    component_quantities: dict[str, Any] = {}
    count_cells = 0.0
    if isinstance(raw_quantities, dict):
        for name, quantity in raw_quantities.items():
            if not isinstance(quantity, dict):
                continue
            record = deepcopy(quantity)
            value = record.get("value")
            if isinstance(value, (int, float)):
                record["value"] = round(float(value), 6)
                if record.get("dimension") == "count" and record.get("unit") == "cells":
                    count_cells += float(value)
            component_quantities[str(name)] = record
    payload: dict[str, Any] = {
        "kind": "container_ref",
        "id": container_id,
        "volume_uL": round(float(raw.get("volume_uL", 0.0)), 6),
        "mass_mg": round(float(raw.get("mass_mg", 0.0)), 6),
        "components": component_map,
        "metadata": metadata_out,
    }
    if raw.get("unknown_quantity_dimensions"):
        payload["known_mass_subtotal_mg"] = payload["mass_mg"]
        payload["mass_mg"] = None
        payload["unknown_quantity_dimensions"] = deepcopy(raw["unknown_quantity_dimensions"])
        payload["aggregate_quantity_policy"] = "known_subtotals_only"
        payload["component_entries"] = deepcopy(raw.get("component_entries", []))
    if count_cells > 0.0 or raw.get("unknown_quantity_dimensions"):
        payload["component_quantities"] = component_quantities
        payload["count_cells"] = round(count_cells, 6)
        relationships = raw.get("material_relationships")
        if isinstance(relationships, list):
            payload["material_relationships"] = deepcopy(relationships)
    if raw.get("component_concentrations"):
        payload["component_quantities"] = component_quantities
        payload["component_entries"] = deepcopy(raw.get("component_entries", []))
        payload["component_concentrations"] = deepcopy(raw["component_concentrations"])
    container_kind = metadata_out.get("kind")
    if isinstance(container_kind, str):
        payload["container_kind"] = container_kind
    label = metadata_out.get("label")
    if isinstance(label, str):
        payload["label"] = label
    barcode = metadata_out.get("barcode")
    if isinstance(barcode, str):
        payload["barcode"] = barcode
    return payload


def _container_group_ref_payload(material_state: Any, expr: Any) -> dict[str, Any] | None:
    container_ids = _resolve_runtime_ref_group_ids(material_state, expr)
    if container_ids is None:
        return None
    members: list[dict[str, Any]] = []
    for container_id in container_ids:
        payload = _container_ref_payload(material_state, container_id)
        if payload is None:
            return None
        members.append(payload)
    return {
        "kind": "container_group_ref",
        "member_count": len(members),
        "members": members,
    }


def _merge_result_payloads(*parts: dict[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for part in parts:
        if not isinstance(part, dict):
            continue
        for key, value in part.items():
            merged[key] = value
    return merged


def _schema_result_payload(schema_ref: Any) -> dict[str, Any]:
    if not isinstance(schema_ref, dict):
        return {}
    if schema_ref.get("kind") != "data_schema_ref":
        return {}
    fields = schema_ref.get("fields")
    if not isinstance(fields, list):
        return {}
    payload: dict[str, Any] = {}
    for field in fields:
        if isinstance(field, str):
            payload[field] = None
    return payload


def _resolve_runtime_ref(material_state: Any, value: Any) -> str | None:
    if not isinstance(material_state, dict) or not isinstance(value, dict):
        return None
    containers = material_state.get("containers")
    if not isinstance(containers, dict):
        return None

    kind = value.get("kind")
    if kind == "IRIdentifier":
        name = value.get("name")
        if not isinstance(name, str):
            return None
        bindings = material_state.get("bindings")
        if isinstance(bindings, dict):
            bound = bindings.get(name)
            if isinstance(bound, str) and bound in containers:
                return bound
        if name in containers:
            return name
        return None

    if kind != "IRIndex":
        return None

    base = value.get("base")
    index = value.get("index")
    if not isinstance(base, dict) or base.get("kind") != "IRIdentifier":
        return None
    group_name = base.get("name")
    if not isinstance(group_name, str):
        return None
    slot = _runtime_static_index_key(index)
    if slot is None:
        return None
    indexed_bindings = material_state.get("indexed_bindings")
    if not isinstance(indexed_bindings, dict):
        return None
    group = indexed_bindings.get(group_name)
    if not isinstance(group, dict):
        return None
    bound = group.get(slot)
    if isinstance(bound, str) and bound in containers:
        return bound
    return None


def _resolve_runtime_ref_group(material_state: Any, value: Any) -> list[dict[str, Any]] | None:
    if not isinstance(value, dict) or value.get("kind") != "IRGroup":
        return None
    elements = value.get("elements")
    if not isinstance(elements, list):
        return None
    resolved: list[dict[str, Any]] = []
    for item in elements:
        resolved_item = _resolve_runtime_ref(material_state, item)
        if resolved_item is None:
            return None
        resolved.append({"sample_ref": item, "resolved_sample": resolved_item})
    return resolved


def _resolve_runtime_ref_group_ids(material_state: Any, value: Any) -> list[str] | None:
    if not isinstance(material_state, dict) or not isinstance(value, dict):
        return None
    containers = material_state.get("containers")
    if not isinstance(containers, dict):
        return None

    if value.get("kind") == "IRGroup":
        elements = value.get("elements")
        if not isinstance(elements, list):
            return None
        resolved: list[str] = []
        for item in elements:
            container_id = _resolve_runtime_ref(material_state, item)
            if not isinstance(container_id, str):
                return None
            resolved.append(container_id)
        return resolved

    if value.get("kind") != "IRIdentifier":
        return None
    group_name = value.get("name")
    if not isinstance(group_name, str):
        return None
    indexed_bindings = material_state.get("indexed_bindings")
    if not isinstance(indexed_bindings, dict):
        return None
    group = indexed_bindings.get(group_name)
    if not isinstance(group, dict):
        return None
    resolved: list[str] = []
    for slot in sorted(group, key=_runtime_index_slot_sort_key):
        container_id = group.get(slot)
        if not isinstance(container_id, str) or container_id not in containers:
            return None
        resolved.append(container_id)
    return resolved


def _runtime_index_slot_sort_key(slot: Any) -> tuple[int, int | str]:
    if isinstance(slot, str) and slot.isdigit():
        return (0, int(slot))
    return (1, str(slot))


def _runtime_static_index_key(value: Any) -> str | None:
    if not isinstance(value, dict) or value.get("kind") != "IRQuantity":
        return None
    raw = value.get("value")
    unit = value.get("unit")
    if unit is not None or not isinstance(raw, (int, float)) or float(raw) < 0 or not float(raw).is_integer():
        return None
    return str(int(raw))
