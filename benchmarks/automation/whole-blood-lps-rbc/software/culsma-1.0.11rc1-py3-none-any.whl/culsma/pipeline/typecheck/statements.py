"""Statement-level type and unit checking dispatch."""

from __future__ import annotations

from culsma.pipeline.external_inputs import external_parameter_type_diagnostics, ExternalInputScope, ExternalInputResolver, ExternalInputStatus, deferred_external_bindings

from dataclasses import dataclass, fields, is_dataclass
from typing import Any, Iterable, Mapping, cast

from culsma.common.diagnostics import Diagnostic
from culsma.common.quantity_arithmetic import QuantityDimension, QuantityArithmeticError

from culsma.pipeline.content_inputs import ContentArgumentResolver, ContentInputSource, DeferredContentEnum, deferred_content_enum_bindings
from culsma.pipeline.ir_nodes import (
    IRAssign,
    IRCall,
    IRConditional,
    IRIdentifier,
    IRLet,
    IRMutation,
    IRMutationGroup,
    IRRepeat,
    IRStatement,
    IRStep,
    IRWithConstraint,
    IRWithSep,
    IRWithEnv,
)
from culsma.pipeline.program_registry import is_known_program_kind

from .context import TypecheckContext

from .expressions import DEFAULT_TYPECHECK_EXPRESSION_SERVICES, DeferredNumeric, DeferredQuantity, TypecheckExpressionServices


@dataclass
class TypecheckStatementState:
    stop: bool = False


@dataclass(frozen=True)
class ChildStatementBlock:
    statements: list[IRStatement]
    expr_bindings: dict[str, Any]


class BaseTypecheckStatementHandler:
    services: TypecheckExpressionServices = DEFAULT_TYPECHECK_EXPRESSION_SERVICES

    def handle(self, stmt: IRStatement, ctx: TypecheckContext) -> None:
        state = self.prepare(stmt, ctx)
        if state.stop:
            return

        ctx.extend(external_parameter_type_diagnostics(stmt,
            scope=ExternalInputScope(ctx.expr_bindings, ctx.parameter_names), node_id=stmt.id))
        self.validate_pre_binding_contracts(stmt, ctx, state)
        if state.stop:
            return

        self.update_or_derive_bindings(stmt, ctx, state)
        if state.stop:
            return

        self.check_child_expressions(stmt, ctx, state)
        if state.stop:
            return

        self.check_statement_specific_rules(stmt, ctx, state)
        if state.stop:
            return

        for child in self.iter_child_blocks(stmt, ctx, state):
            self.recurse(child, ctx)
        if state.stop:
            return

        self.apply_post_child_effects(stmt, ctx, state)

    def prepare(self, _stmt: IRStatement, _ctx: TypecheckContext) -> TypecheckStatementState:
        return TypecheckStatementState()

    def validate_pre_binding_contracts(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        return

    def update_or_derive_bindings(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        if isinstance(_stmt, IRRepeat):
            self.defer_assignments(_stmt, _ctx)

    def check_child_expressions(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        return

    def check_statement_specific_rules(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        return

    def iter_child_blocks(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> Iterable[ChildStatementBlock]:
        return ()

    def apply_post_child_effects(
        self,
        _stmt: IRStatement,
        _ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        if isinstance(_stmt, (IRConditional, IRRepeat, IRWithSep, IRWithEnv, IRWithConstraint)):
            self.defer_assignments(_stmt, _ctx)

    def defer_assignments(self, stmt: IRStatement, ctx: TypecheckContext) -> None:
        if ctx.scope_query is not None:
            names = [effect.name for effect in ctx.scope_query.assignment_effects(stmt.id)]
            ctx.expr_bindings.update(deferred_content_enum_bindings(names, ctx.content_scope()))
            ctx.expr_bindings.update(deferred_external_bindings(names, ExternalInputScope(ctx.expr_bindings, ctx.parameter_names)))
            for name in names:
                kind = self.services.classify_local_expr_type(ctx.expr_bindings.get(name), expr_bindings=ctx.expr_bindings)
                if kind in {"int", "quantity"}:
                    ctx.expr_bindings[name] = DeferredNumeric(kind)

    def recurse(self, child: ChildStatementBlock, ctx: TypecheckContext) -> None:
        if ctx.statement_typechecker is None:
            return
        child_ctx = ctx.derive_with_bindings(child.expr_bindings)
        ctx.statement_typechecker.typecheck_list(child.statements, child_ctx)


class LetTypecheckHandler(BaseTypecheckStatementHandler):
    def update_or_derive_bindings(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRLet, stmt)
        if stmt.value is None:
            ctx.expr_bindings.pop(stmt.name, None)
            return
        external = ExternalInputResolver.resolve(stmt.value, None, ExternalInputScope(ctx.expr_bindings, ctx.parameter_names))
        if external.status is ExternalInputStatus.RESOLVED:
            ctx.expr_bindings[stmt.name] = external.value
            return
        numeric = self.services.numeric_binding(stmt.value, ctx.expr_bindings)
        if numeric is not None:
            ctx.expr_bindings[stmt.name] = numeric
            return
        result = ContentArgumentResolver.resolve_argument(stmt.value, None, ctx.content_scope())
        ctx.expr_bindings[stmt.name] = result.value if result.source is ContentInputSource.ENUM and (result.token is not None or isinstance(result.value, DeferredContentEnum)) else stmt.value

    def check_child_expressions(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRLet, stmt)
        if stmt.value is None:
            return
        if isinstance(stmt.value, IRCall) and is_known_program_kind(stmt.value.name):
            ctx.extend(
                self.services.typecheck_let_call(
                    stmt.name,
                    stmt.value,
                    stmt.id,
                    expr_bindings=ctx.expr_bindings,
                    scope=ctx.content_scope(),
                )
            )
            return
        ctx.extend(
            self.services.typecheck_program_calls_in_expr(
                stmt.value,
                node_id=stmt.id,
                expr_bindings=ctx.expr_bindings,
            )
        )
        if isinstance(stmt.value, IRCall):
            ctx.extend(
                self.services.typecheck_let_call(
                    stmt.name,
                    stmt.value,
                    stmt.id,
                    expr_bindings=ctx.expr_bindings,
                    scope=ctx.content_scope(),
                )
            )


class AssignTypecheckHandler(BaseTypecheckStatementHandler):
    def validate_pre_binding_contracts(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRAssign, stmt)
        ctx.extend(self.services.typecheck_assignment(stmt, expr_bindings=ctx.expr_bindings))

    def check_child_expressions(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRAssign, stmt)
        ctx.extend(
            self.services.typecheck_program_calls_in_expr(
                stmt.value,
                node_id=stmt.id,
                expr_bindings=ctx.expr_bindings,
            )
        )


    def apply_post_child_effects(self, stmt: IRStatement, ctx: TypecheckContext, _state: TypecheckStatementState) -> None:
        stmt = cast(IRAssign, stmt)
        external = ExternalInputResolver.resolve(stmt.value, None, ExternalInputScope(ctx.expr_bindings, ctx.parameter_names))
        if isinstance(stmt.target, IRIdentifier) and external.status is ExternalInputStatus.RESOLVED:
            ctx.expr_bindings[stmt.target.name] = external.value
            return
        result = ContentArgumentResolver.resolve_argument(stmt.value, None, ctx.content_scope())
        if isinstance(stmt.target, IRIdentifier) and result.source is ContentInputSource.ENUM and (result.token is not None or isinstance(result.value, DeferredContentEnum)):
            ctx.expr_bindings[stmt.target.name] = result.value
        elif isinstance(stmt.target, IRIdentifier) and stmt.target.name in ctx.expr_bindings:
            kind = self.services.classify_local_expr_type(stmt.value, expr_bindings=ctx.expr_bindings)
            if kind in {"int", "quantity"}:
                numeric = self.services.numeric_binding(stmt.value, ctx.expr_bindings)
                ctx.expr_bindings[stmt.target.name] = numeric if numeric is not None else DeferredNumeric(kind)


class WithEnvTypecheckHandler(BaseTypecheckStatementHandler):
    def check_statement_specific_rules(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRWithEnv, stmt)
        ctx.extend(self.services.typecheck_with_env(stmt, expr_bindings=ctx.expr_bindings))

    def iter_child_blocks(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> Iterable[ChildStatementBlock]:
        stmt = cast(IRWithEnv, stmt)
        return (ChildStatementBlock(stmt.statements, dict(ctx.expr_bindings)),)


class WithSepTypecheckHandler(BaseTypecheckStatementHandler):
    def iter_child_blocks(self, stmt, ctx, state):
        stmt = cast(IRWithSep, stmt)
        return (ChildStatementBlock(stmt.statements, dict(ctx.expr_bindings)),)


class WithConstraintTypecheckHandler(BaseTypecheckStatementHandler):
    def iter_child_blocks(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> Iterable[ChildStatementBlock]:
        stmt = cast(IRWithConstraint, stmt)
        return (ChildStatementBlock(stmt.statements, dict(ctx.expr_bindings)),)


class RepeatTypecheckHandler(BaseTypecheckStatementHandler):
    def check_child_expressions(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRRepeat, stmt)
        ctx.extend(
            self.services.typecheck_program_calls_in_expr(
                stmt.iterable,
                node_id=stmt.id,
                expr_bindings=ctx.expr_bindings,
            )
        )

    def iter_child_blocks(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> Iterable[ChildStatementBlock]:
        stmt = cast(IRRepeat, stmt)
        nested_bindings = dict(ctx.expr_bindings)
        # A runtime loop value is deferred, not a cyclic identifier binding.
        nested_bindings[stmt.binding] = DeferredNumeric("unknown", span=stmt.span)
        return (ChildStatementBlock(stmt.statements, nested_bindings),)


class ConditionalTypecheckHandler(BaseTypecheckStatementHandler):
    def iter_child_blocks(self, stmt, ctx, _state):
        return (
            ChildStatementBlock(stmt.then_statements, dict(ctx.expr_bindings)),
            ChildStatementBlock(stmt.else_statements, dict(ctx.expr_bindings)),
        )


class MutationGroupTypecheckHandler(BaseTypecheckStatementHandler):
    def iter_child_blocks(self, stmt, ctx, state):
        return (ChildStatementBlock(stmt.members, dict(ctx.expr_bindings)),)


class MutationTypecheckHandler(BaseTypecheckStatementHandler):
    def check_statement_specific_rules(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRMutation, stmt)
        ctx.extend(self.services.typecheck_mutation(stmt, expr_bindings=ctx.expr_bindings))


@dataclass
class StepTypecheckState(TypecheckStatementState):
    op_arg_dimensions: Mapping[str, frozenset[QuantityDimension]] | None = None


class StepTypecheckHandler(BaseTypecheckStatementHandler):
    def check_print_expression(self, expr: Any, stmt: IRStep, ctx: TypecheckContext) -> None:
        try:
            self.services.evaluate_quantity(expr, ctx.expr_bindings)
        except DeferredQuantity:
            pass
        except QuantityArithmeticError as error:
            code = {"zero": "TYPE_QUANTITY_DIVISION_BY_ZERO", "unit": "TYPE_UNKNOWN_UNIT",
                    "nonfinite": "TYPE_QUANTITY_VALUE_NONFINITE", "dimension": "TYPE_DIMENSION_MISMATCH"}.get(
                        error.reason, "TYPE_UNIT_NOT_ALLOWED")
            ctx.extend([Diagnostic(code=code, message=str(error), span=getattr(expr, "span", stmt.span), node_id=stmt.id)])
            return
        if is_dataclass(expr):
            for item in fields(expr):
                if item.name != "span":
                    self.check_print_expression(getattr(expr, item.name), stmt, ctx)
        elif isinstance(expr, (list, tuple)):
            for item in expr:
                self.check_print_expression(item, stmt, ctx)
        elif isinstance(expr, dict):
            for item in expr.values():
                self.check_print_expression(item, stmt, ctx)

    def prepare(self, stmt: IRStatement, ctx: TypecheckContext) -> TypecheckStatementState:
        stmt = cast(IRStep, stmt)
        if stmt.name == "print":
            return StepTypecheckState()
        op_spec = ctx.operation_specs.get(stmt.name)
        if op_spec is None:
            return StepTypecheckState(stop=True)
        return StepTypecheckState(op_arg_dimensions=op_spec.arg_dimensions)

    def check_child_expressions(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRStep, stmt)
        state = cast(StepTypecheckState, state)
        arg_dims = state.op_arg_dimensions or {}
        for arg in stmt.args:
            if stmt.name == "print":
                self.check_print_expression(arg.value, stmt, ctx)
            ctx.extend(
                self.services.typecheck_program_calls_in_expr(
                    arg.value,
                    node_id=stmt.id,
                    expr_bindings=ctx.expr_bindings,
                )
            )
            expected = arg_dims.get(arg.name)
            if not expected:
                continue
            if isinstance(arg.value, IRIdentifier):
                continue
            ctx.extend(
                self.services.validate_quantity_dimensions(
                    arg.value,
                    expr_bindings=ctx.expr_bindings,
                    expected=list(expected),
                    non_quantity_code="TYPE_UNIT_NOT_ALLOWED",
                    mismatch_code="TYPE_DIMENSION_MISMATCH",
                    unknown_code="TYPE_UNKNOWN_UNIT",
                    label=f"Arg '{arg.name}' in step '{stmt.name}'",
                    span=arg.span or stmt.span,
                    node_id=stmt.id,
                )
            )

    def check_statement_specific_rules(
        self,
        stmt: IRStatement,
        ctx: TypecheckContext,
        _state: TypecheckStatementState,
    ) -> None:
        stmt = cast(IRStep, stmt)
        ctx.extend(self.services.typecheck_step_container_target_view_positions(stmt, expr_bindings=ctx.expr_bindings))
        ctx.extend(self.services.typecheck_content_descriptors(stmt, scope=ctx.content_scope()))


_STATEMENT_HANDLERS_BY_TYPE: dict[type[object], BaseTypecheckStatementHandler] = {
    IRLet: LetTypecheckHandler(),
    IRAssign: AssignTypecheckHandler(),
    IRWithSep: WithSepTypecheckHandler(),
    IRWithEnv: WithEnvTypecheckHandler(),
    IRWithConstraint: WithConstraintTypecheckHandler(),
    IRRepeat: RepeatTypecheckHandler(),
    IRConditional: ConditionalTypecheckHandler(),
    IRMutation: MutationTypecheckHandler(),
    IRMutationGroup: MutationGroupTypecheckHandler(),
    IRStep: StepTypecheckHandler(),
}


class StatementTypechecker:
    def __init__(
        self,
        handlers_by_type: Mapping[type[object], BaseTypecheckStatementHandler] | None = None,
    ) -> None:
        self.handlers_by_type = dict(handlers_by_type or _STATEMENT_HANDLERS_BY_TYPE)

    def typecheck_list(self, statements: list[IRStatement], ctx: TypecheckContext) -> None:
        for stmt in statements:
            self.typecheck_statement(stmt, ctx)

    def typecheck_statement(self, stmt: IRStatement, ctx: TypecheckContext) -> None:
        handler = self.handlers_by_type.get(type(stmt))
        if handler is not None:
            previous_typechecker = ctx.statement_typechecker
            ctx.statement_typechecker = self
            try:
                handler.handle(stmt, ctx)
            finally:
                ctx.statement_typechecker = previous_typechecker
