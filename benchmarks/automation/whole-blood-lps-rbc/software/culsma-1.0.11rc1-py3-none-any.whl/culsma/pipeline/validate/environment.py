"""`with env(...)` semantic contracts."""

from __future__ import annotations

from typing import Any

from culsma.common.diagnostics import Diagnostic
from culsma.domains.environment import ENVIRONMENT_MODIFIERS, SOURCE_ENVIRONMENT_KEYS, EnvironmentKey
from culsma.pipeline.ir_nodes import IRArg, IRBinary, IRCall, IRQuantity, IRStep, IRUnary, IRWithEnv

from .resolution import ExprResolver


class EnvContractValidator:
    @staticmethod
    def validate_with_env(
        stmt: IRWithEnv,
        *,
        literal_bindings: dict[str, Any],
        expr_bindings: dict[str, Any],
    ) -> list[Diagnostic]:
        diagnostics: list[Diagnostic] = []
        args_by_key: dict[EnvironmentKey, IRArg] = {}
        seen_arg_names: set[str] = set()
        duplicate_arg_names: list[str] = []
        for arg in stmt.env_args:
            key = SOURCE_ENVIRONMENT_KEYS.get(arg.name)
            if key is None:
                diagnostics.append(
                    Diagnostic(
                        code="SEM_UNKNOWN_ARG",
                        message=f"Unknown arg '{arg.name}' in with env(...)",
                        span=arg.span or stmt.span,
                        node_id=stmt.id,
                    )
                )
            else:
                args_by_key[key] = arg
            if arg.name in seen_arg_names and arg.name not in duplicate_arg_names:
                duplicate_arg_names.append(arg.name)
            seen_arg_names.add(arg.name)
        for name in duplicate_arg_names:
            dup_span = next((arg.span for arg in stmt.env_args if arg.name == name), stmt.span)
            diagnostics.append(
                Diagnostic(
                    code="SEM_DUPLICATE_ARG",
                    message=f"Duplicate arg '{name}' in with env(...)",
                    span=dup_span or stmt.span,
                    node_id=stmt.id,
                )
            )
        if diagnostics:
            return diagnostics
        if not stmt.targets:
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_TARGET_REQUIRED",
                    message="with env(...): at least one inferred target is required",
                    span=stmt.span,
                    node_id=stmt.id,
                )
            )
        if not stmt.statements and not getattr(stmt, "explicit_hold", False):
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_BODY_REQUIRED",
                    message="with env(...): at least one statement is required; use explicit hold(...) for pure env hold",
                    span=stmt.span,
                    node_id=stmt.id,
                )
            )
        thermal_arg = args_by_key.get(EnvironmentKey.THERMAL)
        field_arg = args_by_key.get(EnvironmentKey.FIELD)
        medium_arg = args_by_key.get(EnvironmentKey.MEDIUM)
        modifier_arg = next((arg for key, arg in args_by_key.items() if key in ENVIRONMENT_MODIFIERS), None)
        duration_arg = args_by_key.get(EnvironmentKey.DURATION)
        if thermal_arg is None and field_arg is None and medium_arg is None and modifier_arg is not None:
            diagnostics.append(Diagnostic(code="SEM_ENV_THERMAL_REQUIRED",
                message="with env(...): co2/o2/rh require scalar thermal",
                span=modifier_arg.span or stmt.span, node_id=stmt.id))
            return diagnostics

        if thermal_arg is None and modifier_arg is not None:
            conflict_arg = modifier_arg
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_ARG_CONFLICT",
                    message="with env(...): co2/o2/rh require scalar thermal",
                    span=(conflict_arg.span if conflict_arg is not None else stmt.span) or stmt.span,
                    node_id=stmt.id,
                )
            )

        if thermal_arg is None:
            if duration_arg is not None and medium_arg is None and field_arg is not None:
                diagnostics.append(
                    Diagnostic(
                        code="SEM_ENV_DURATION_WITHOUT_THERMAL",
                        message="with env(...): duration requires thermal",
                        span=duration_arg.span or stmt.span,
                        node_id=stmt.id,
                    )
                )
            if (medium_arg is not None or field_arg is None) and duration_arg is None and _requires_scalar_thermal_duration(stmt):
                diagnostics.append(Diagnostic(code="SEM_ENV_DURATION_REQUIRED",
                    message="Pure medium environment hold requires duration",
                    span=(medium_arg.span if medium_arg is not None else stmt.span) or stmt.span, node_id=stmt.id))
            return diagnostics

        thermal_value = ExprResolver.resolve_bound_expr(thermal_arg.value, expr_bindings)
        thermal_program = isinstance(thermal_value, IRCall) and thermal_value.name == "thermal_program"
        # An unresolved parameter may still be a thermal_program. Require the
        # scalar duration only once that distinction is decidable.
        scalar_thermal = isinstance(thermal_value, (IRQuantity, IRUnary, IRBinary))

        if thermal_program and modifier_arg is not None:
            conflict_arg = modifier_arg
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_ARG_CONFLICT",
                    message="with env(...): co2/o2/rh are forbidden when thermal uses thermal_program(...)",
                    span=(conflict_arg.span if conflict_arg is not None else stmt.span) or stmt.span,
                    node_id=stmt.id,
                )
            )

        if thermal_program and duration_arg is not None:
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_DURATION_FORBIDDEN_WITH_THERMAL_PROGRAM",
                    message="with env(...): outer duration is forbidden when thermal uses thermal_program(...)",
                    span=duration_arg.span or stmt.span,
                    node_id=stmt.id,
                )
            )
        if scalar_thermal and duration_arg is None and _requires_scalar_thermal_duration(stmt):
            diagnostics.append(
                Diagnostic(
                    code="SEM_ENV_DURATION_REQUIRED",
                    message=(
                        "with env(...): scalar thermal requires explicit duration "
                        "for pure environment hold"
                    ),
                    span=thermal_arg.span or stmt.span,
                    node_id=stmt.id,
                )
            )
        return diagnostics


def _requires_scalar_thermal_duration(stmt: IRWithEnv) -> bool:
    return bool(getattr(stmt, "explicit_hold", False)) and all(
        isinstance(child, IRStep) and child.name == "print" for child in stmt.statements)
