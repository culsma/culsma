"""Statement-level semantic validation contracts."""

from __future__ import annotations

from culsma.pipeline.external_inputs import external_parameter_resolution, ExternalInputStatus, ExternalInputIssue

from culsma.domains.agitation.validation import AGIT_MODES, validate_agit_contract
from culsma.domains.readout import READOUT_QUANTITIES

from dataclasses import dataclass
from typing import Any, Mapping

from culsma.common.diagnostics import Diagnostic
from culsma.common.content_contracts import ContentKind, ContentType
from culsma.pipeline.content_inputs import ContentArgumentResolver, ContentArgumentScope, ContentInputSource
from culsma.pipeline.expression_resolution import resolve_expression, ResolutionStatus
from culsma.common.source import Span
from culsma.pipeline.ir_nodes import (
    IRArg,
    IRAssign,
    IRCall,
    IRLet,
    IRMutation,
    IRQuantity,
    IRStatement,
    IRStep,
    IRString,
    IRWithConstraint,
    IRWithEnv,
)
from culsma.pipeline.operation_specs import OperationSpec

from culsma.domains.constraints import REQUIREMENT_REGISTRY, ConstraintRequirement
from .binding import BindingValidator
from .constructors import ConstructorValidator
from .context import _GroupBinding
from .expression_contracts import validate_expr_contracts
from .material_transition import validate_material_transitions_contract
from .operations import OperationContractValidator
from .resolution import ExprResolver
from .separation import validate_component_fates_contract
from .fractionation import validate_fraction_fates_contract

BUILTIN_METHOD_STEPS = {"append", "replace"}
CONSTRAINT_CUSTOMIZED = ConstraintRequirement.CUSTOMIZED
from culsma.domains.constraints.rules import COLD_CHAIN_MAX_C, ConstraintRules
from culsma.domains.constraints.validation import ConstraintSourceValidator

# Preserve the existing stage entry points as aliases, with no duplicated rules.
classify_constraint_action_family = ConstraintSourceValidator.classify_constraint_action_family
validate_active_constraint_compatibility = ConstraintSourceValidator.validate_active_constraint_compatibility
validate_active_env_constraint_compatibility = ConstraintSourceValidator.validate_active_env_constraint_compatibility
# Legacy consumer views derived from domain-owned contracts.
READOUT_QUANTITY_SETS = {operation: frozenset(contract.wire_values) for operation, contract in READOUT_QUANTITIES.items()}




def validate_assign_target_contract(
    stmt: IRAssign,
    *,
    expr_bindings: dict[str, Any],
    defined_names: set[str],
) -> list[Diagnostic]:
    root = BindingValidator.assign_target_root_name(stmt.target)
    if root is None:
        return [
            Diagnostic(
                code="VAL_ASSIGN_TARGET_INVALID",
                message="Assignment target must be a local name or member path rooted at a local name",
                span=stmt.span,
                node_id=stmt.id,
            )
        ]
    if root not in defined_names and root not in expr_bindings:
        return [
            Diagnostic(
                code="VAL_ASSIGN_TARGET_UNBOUND",
                message=f"Assignment target root '{root}' is not bound in the current scope",
                span=stmt.span,
                node_id=stmt.id,
            )
        ]
    return []



def defined_names_from_step(stmt: IRStep, literal_bindings: dict[str, Any], expr_bindings: dict[str, Any]) -> set[str]:
    del stmt, literal_bindings, expr_bindings
    return set()


def _find_arg_by_name(args: list[IRArg], name: str) -> IRArg | None:
    for arg in args:
        if arg.name == name:
            return arg
    return None


def validate_with_constraint_contract(
    stmt: IRWithConstraint,
    *,
    literal_bindings: dict[str, Any],
    expr_bindings: dict[str, Any],
    defined_names: set[str] | None = None,
    active_requirements: tuple[str, ...] = (),
) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    if not stmt.statements:
        diagnostics.append(
            Diagnostic(
                code="SEM_CONSTRAINT_BODY_REQUIRED",
                message="with constraint(...): at least one statement is required",
                span=stmt.span,
                node_id=stmt.id,
            )
        )
    if not stmt.requirements and not stmt.options:
        diagnostics.append(
            Diagnostic(
                code="SEM_CONSTRAINT_ITEM_REQUIRED",
                message="with constraint(...): at least one requirement or option is required",
                span=stmt.span,
                node_id=stmt.id,
            )
        )
    requirement_names = dedupe_requirement_names(stmt.requirements)
    option_names = [arg.name for arg in stmt.options]
    seen_options: set[str] = set()
    duplicate_options: list[str] = []
    for name in option_names:
        if name in seen_options and name not in duplicate_options:
            duplicate_options.append(name)
        seen_options.add(name)
    for dup in duplicate_options:
        diagnostics.append(
            Diagnostic(
                code="SEM_CONSTRAINT_DUPLICATE_OPTION",
                message=f"constraint option '{dup}' is duplicated",
                span=stmt.span,
                node_id=stmt.id,
            )
        )

    unknown_requirements = [name for name in requirement_names if name not in REQUIREMENT_REGISTRY]
    for name in unknown_requirements:
        diagnostics.append(
            Diagnostic(
                code="SEM_UNKNOWN_REQUIREMENT",
                message=f"Unknown requirement '{name}' in constraint(...)",
                span=stmt.span,
                node_id=stmt.id,
            )
        )

    for name in requirement_names:
        spec = REQUIREMENT_REGISTRY.get(name)
        if spec is None:
            continue
        if "block" not in spec.scopes:
            diagnostics.append(
                Diagnostic(
                    code="SEM_CONSTRAINT_SCOPE_INVALID",
                    message=f"Requirement '{name}' is not allowed in block constraint scope",
                    span=stmt.span,
                    node_id=stmt.id,
                )
            )
    for violation in ConstraintRules.combination_violations((*active_requirements, *requirement_names)):
        diagnostics.append(Diagnostic(
            code="SEM_CONSTRAINT_CUSTOMIZED_EXCLUSIVE" if violation.kind == "customized" else "SEM_CONSTRAINT_CONFLICT",
            message=violation.message, span=stmt.span, node_id=stmt.id))

    if CONSTRAINT_CUSTOMIZED in requirement_names:
        schema_arg = _find_arg_by_name(stmt.options, "schema_ref")
        if schema_arg is None:
            diagnostics.append(
                Diagnostic(
                    code="SEM_CONSTRAINT_CUSTOMIZED_SCHEMA_REQUIRED",
                    message="constraint(customized, ...): schema_ref is required",
                    span=stmt.span,
                    node_id=stmt.id,
                )
            )
        for arg in stmt.options:
            if arg.name != "schema_ref":
                diagnostics.append(
                    Diagnostic(
                        code="SEM_CONSTRAINT_UNKNOWN_OPTION",
                        message=f"constraint(customized, ...): unknown option '{arg.name}'",
                        span=arg.span or stmt.span,
                        node_id=stmt.id,
                    )
                )
        if schema_arg is not None:
            diagnostics.extend(
                validate_expr_contracts(
                    schema_arg.value,
                    literal_bindings=literal_bindings,
                    expr_bindings=expr_bindings,
                    group_bindings={},
                    node_id=stmt.id,
                    content_whitelist_mode="strict",
                    content_type_policy="required",
                    defined_names=defined_names,
                )
            )
    elif stmt.options:
        for arg in stmt.options:
            diagnostics.append(
                Diagnostic(
                    code="SEM_CONSTRAINT_UNKNOWN_OPTION",
                    message=f"constraint(...): option '{arg.name}' is not supported for standard requirements",
                    span=arg.span or stmt.span,
                    node_id=stmt.id,
                )
            )
    return diagnostics


def dedupe_requirement_names(names: tuple[str, ...] | list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for name in names:
        if name not in seen:
            out.append(name)
            seen.add(name)
    return out


def validate_mutation_contract(
    stmt: IRMutation,
    *,
    literal_bindings: dict[str, Any],
    expr_bindings: dict[str, Any],
    group_bindings: dict[str, _GroupBinding],
    active_requirements: tuple[str, ...] = (),
) -> list[Diagnostic]:
    del group_bindings
    diagnostics: list[Diagnostic] = []
    if "spread" in active_requirements and stmt.target is not None:
        target = ExprResolver.resolve_bound_expr(stmt.target, expr_bindings)
        if isinstance(target, IRCall) and target.name == "AllocContainer":
            kind_arg = _find_arg_by_name(target.args, "kind")
            kind = (
                ExprResolver.to_text_token(kind_arg.value, literal_bindings)
                if kind_arg is not None
                else None
            )
            if kind is not None and kind != "surface":
                diagnostics.append(
                    Diagnostic(
                        code="SEM_SPREAD_TARGET_NOT_SURFACE",
                        message="Requirement 'spread' requires a surface transfer target",
                        span=stmt.target.span or stmt.span,
                        node_id=stmt.id,
                    )
                )
    return diagnostics


def validate_let_call_contract(
    stmt: IRLet,
    *,
    literal_bindings: dict[str, Any],
    expr_bindings: dict[str, Any],
    operations: Mapping[str, OperationSpec],
    content_whitelist_mode: str,
    content_type_policy: str,
    defined_names: set[str] | None = None,
) -> list[Diagnostic]:
    value = stmt.value
    if not isinstance(value, IRCall):
        return []
    if value.name == "DefineContent":
        scope = ContentArgumentScope(literal_bindings, expr_bindings, defined_names or frozenset())
        diagnostics = ConstructorValidator.validate_define_content_call(
            value,
            literal_bindings=literal_bindings,
            node_id=stmt.id,
            content_whitelist_mode=content_whitelist_mode,
            content_type_policy=content_type_policy,
            scope=scope,
        )
        args = {arg.name: arg.value for arg in value.args}
        code = resolve_expression(args.get("code"), expr_bindings)
        code_value = code.value.value if isinstance(code.value, IRString) else code.value
        if (
            "concentration" not in args and "code" in args
            and (code.status is ResolutionStatus.DEFERRED or (isinstance(code_value, str) and code_value.strip()))
            and all(
                ContentArgumentResolver.resolve_argument(args.get(name), family, scope).source is ContentInputSource.ENUM
                for name, family in (("kind", ContentKind), ("type", ContentType))
            )
        ):
            # A typed material descriptor is a value, with no load or allocation.
            return diagnostics
        diagnostics.append(
            Diagnostic(
                code="SEM_STANDALONE_CONTENT_INIT_FORBIDDEN",
                message="standalone content constructor is not allowed in protocol execution flow",
                span=stmt.span,
                node_id=stmt.id,
            )
        )
        return diagnostics
    if value.name == "Measure":
        return [
            Diagnostic(
                code="SEM_MEASURE_STDLIB_ROUTE_UNSUPPORTED",
                message="let-bound Measure(...) is outside the current stdlib scope; use img/ecp/phy directly",
                span=stmt.span,
                node_id=stmt.id,
            )
        ]
    if value.name != "AllocContainer":
        diagnostics = OperationContractValidator.validate_call(
            value,
            node_id=stmt.id,
            operations=operations,
        )
        diagnostics.extend(
            validate_readout_schema_contract(
                value.name,
                value.args,
                expr_bindings=expr_bindings,
                defined_names=defined_names or frozenset(),
                literal_bindings=literal_bindings,
                node_id=stmt.id,
                span=value.span,
            )
        )
        if value.name == "frac":
            diagnostics.extend(validate_fraction_fates_contract(
                value.args, expr_bindings=expr_bindings,
                defined_names=defined_names or frozenset(), node_id=stmt.id, span=value.span,
            ))
        if value.name == "sep":
            diagnostics.extend(
                validate_component_fates_contract(
                    value.args,
                    defined_names=defined_names or frozenset(),
                    expr_bindings=expr_bindings,
                    node_id=stmt.id,
                    span=value.span,
                )
            )
            program_arg = _find_arg_by_name(value.args, "program")
            program = (
                ExprResolver.resolve_call_expr(program_arg.value, expr_bindings)
                if program_arg is not None
                else None
            )
            diagnostics.extend(
                validate_material_transitions_contract(
                    value.args,
                    expr_bindings=expr_bindings,
                    program_kind=(program.name if isinstance(program, IRCall) else None),
                    node_id=stmt.id,
                    span=value.span,
                )
            )
        return diagnostics
    diagnostics = OperationContractValidator.validate_call(
        value,
        node_id=stmt.id,
        operations=operations,
    )
    diagnostics.extend(
        ConstructorValidator.validate_alloc_container_call(
            value,
            literal_bindings=literal_bindings,
            expr_bindings=expr_bindings,
            node_id=stmt.id,
            content_whitelist_mode=content_whitelist_mode,
            content_type_policy=content_type_policy,
            scope=ContentArgumentScope(literal_bindings, expr_bindings, defined_names or frozenset()),
        )
    )
    return diagnostics


def validate_readout_schema_contract(
    call_name: str,
    args: list[IRArg],
    *,
    literal_bindings: dict[str, Any],
    node_id: str | None,
    span: Span | None,
    expr_bindings=None,
    defined_names=frozenset(),
) -> list[Diagnostic]:
    if call_name not in {"img", "ecp", "phy"}:
        return []
    quantity_arg = _find_arg_by_name(args, "quantity")
    if quantity_arg is None:
        return []
    resolution = external_parameter_resolution(call_name, 'quantity', quantity_arg.value,
        bindings={**(expr_bindings or {}), **literal_bindings}, defined_names=defined_names)
    if resolution.status is ExternalInputStatus.DEFERRED or resolution.issue in {ExternalInputIssue.WRONG_TYPE, ExternalInputIssue.CYCLIC_BINDING}:
        return []
    quantity_value = resolution.value
    allowed_quantities = READOUT_QUANTITY_SETS[call_name]
    if quantity_value not in allowed_quantities:
        return [
            Diagnostic(
                code="SEM_INVALID_READOUT_QUANTITY",
                message=(
                    f"Readout '{call_name}' quantity must be one of: "
                    + ", ".join(sorted(allowed_quantities))
                ),
                span=quantity_arg.span or span,
                node_id=node_id,
            )
        ]
    if quantity_value != "customized":
        return []
    if _find_arg_by_name(args, "schema_ref") is not None:
        return []
    return [
        Diagnostic(
            code="SEM_MISSING_REQUIRED_ARG",
            message=f"Missing required arg 'schema_ref' in call '{call_name}' when quantity = customized",
            span=quantity_arg.span or span,
            node_id=node_id,
        )
    ]
