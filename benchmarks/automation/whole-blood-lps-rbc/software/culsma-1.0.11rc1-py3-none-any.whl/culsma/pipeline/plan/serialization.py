"""Expression and environment serialization helpers for plan lowering."""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import StrEnum, Enum
from culsma.enum_services import PARAMETER_ENUM_TYPES, PARAMETER_CONTRACTS
from culsma.pipeline.external_boundary import DEFAULT_EXTERNAL_ENUM_CODEC
from typing import Any
from culsma.pipeline.expression_resolution import project_record_member, ResolutionStatus

from culsma.common.content_contracts import CONTENT_ENUM_TYPES, serialize_content_enum

from culsma.pipeline.ir_nodes import (
    IRArg,
    IRAssign,
    IRCall,
    IRConditional,
    IRIdentifier,
    IRIndex,
    IRMember,
    IRRecord,
    IRRepeat,
    IRString,
    IRWithConstraint,
    IRWithSep,
    IRWithEnv,
)
from culsma.pipeline.plan_nodes import PlanStep
from culsma.pipeline.program_registry import canonical_program_arg_name


class PlanExpressionSerializer:
    def contains_unresolved_identifier(self, value: Any) -> bool:
        if isinstance(value, dict):
            if value.get("kind") == "IRMember":
                base = value.get("base", {})
                family = PARAMETER_ENUM_TYPES.get(base.get("name")) if isinstance(base, dict) and base.get("kind") == "IRIdentifier" else None
                if family is not None and value.get("member") in family.__members__:
                    return False
            kind = value.get("kind")
            if kind == "IRIdentifier":
                return True
            return any(self.contains_unresolved_identifier(v) for v in value.values())
        if isinstance(value, list):
            return any(self.contains_unresolved_identifier(v) for v in value)
        return False

    def linearize_steps(self, steps: list[PlanStep]) -> list[PlanStep]:
        linearized: list[PlanStep] = []
        previous_step_id: str | None = None
        for step in steps:
            deps = [previous_step_id] if previous_step_id is not None else []
            linearized.append(
                PlanStep(
                    step_id=step.step_id,
                    op=step.op,
                    args=step.args,
                    deps=deps,
                    gate=step.gate,
                    span=step.span,
                )
            )
            previous_step_id = step.step_id
        return linearized

    def serialize_arg_list(self, args: list[IRArg], env: dict[str, Any]) -> dict[str, Any]:
        return {arg.name: self.serialize_expr(arg.value, env) for arg in args}

    def invalidate_local_env_names(self, env: dict[str, Any], statements: list[Any]) -> None:
        for name in self.assigned_local_names_ir(statements):
            env[name] = {"kind": "IRIdentifier", "name": name}

    def assigned_local_names_ir(self, statements: list[Any]) -> set[str]:
        names: set[str] = set()
        for stmt in statements:
            if isinstance(stmt, IRAssign):
                if isinstance(stmt.target, IRIdentifier):
                    names.add(stmt.target.name)
            elif isinstance(stmt, IRConditional):
                names.update(self.assigned_local_names_ir(stmt.then_statements))
                names.update(self.assigned_local_names_ir(stmt.else_statements))
            elif isinstance(stmt, (IRWithSep, IRWithEnv)):
                names.update(self.assigned_local_names_ir(stmt.statements))
            elif isinstance(stmt, IRWithConstraint):
                names.update(self.assigned_local_names_ir(stmt.statements))
            elif isinstance(stmt, IRRepeat):
                names.update(self.assigned_local_names_ir(stmt.statements))
        return names

    def find_arg_by_name(self, args: list[IRArg], name: str) -> IRArg | None:
        for arg in args:
            if arg.name == name:
                return arg
        return None

    def load_content_ref_expr(self, call: IRCall, fallback_ref: str) -> Any:
        code_arg = self.find_arg_by_name(call.args, "code")
        if code_arg is not None:
            return code_arg.value
        name_arg = self.find_arg_by_name(call.args, "name")
        if name_arg is not None:
            return name_arg.value
        return IRString(value=fallback_ref, span=call.span)

    def serialize_expr(self, value: Any, env: dict[str, Any] | None = None) -> Any:
        """Serialize IR expression dataclass into JSON-friendly structure."""
        if isinstance(value, Enum) and type(value) in PARAMETER_ENUM_TYPES.values():
            return DEFAULT_EXTERNAL_ENUM_CODEC.encode(value)
        if (isinstance(value, IRMember) and isinstance(value.base, IRIdentifier)
                and value.base.name in PARAMETER_ENUM_TYPES and value.base.name not in (env or {})
                and value.base.name != 'CentrifugeProgramOutput'):
            family = PARAMETER_ENUM_TYPES[value.base.name]
            registry = PARAMETER_ENUM_TYPES.registry_for_type(family)
            if registry is not None:
                return {**registry.encode(next(iter(family))), 'member': value.member}
            return {"kind": "ExternalEnum", "enum": value.base.name, "member": value.member}
        if isinstance(value, StrEnum) and type(value) in CONTENT_ENUM_TYPES.values():
            return serialize_content_enum(value)
        if isinstance(value, IRIdentifier) and env is not None and value.name in env:
            bound = env[value.name]
            # Every deferred binding must remain distinguishable from a legacy bare token.
            if isinstance(bound, dict) and bound.get('kind') == 'IRIdentifier':
                return {**bound, 'bound': True}
            return bound
        if (isinstance(value, IRMember) and isinstance(value.base, IRIdentifier)
                and value.base.name in CONTENT_ENUM_TYPES and value.base.name not in (env or {})):
            return {"kind": "ContentEnum", "enum": value.base.name, "member": value.member}
        if isinstance(value, IRMember) and env is not None:
            base = self.serialize_expr(value.base, env)
            projected = project_record_member(base, value.member)
            if projected.status is ResolutionStatus.RESOLVED:
                return projected.value
        if isinstance(value, IRCall):
            value = IRCall(
                name=value.name,
                args=[
                    IRArg(
                        name=canonical_program_arg_name(value.name, arg.name),
                        value=arg.value,
                        span=arg.span,
                    )
                    for arg in value.args
                ],
                span=value.span,
            )
        if isinstance(value, IRIndex) and env is not None:
            base = self.serialize_expr(value.base, env)
            index = self.serialize_expr(value.index, env)
            static_index = self.static_nonnegative_index(index)
            elements = base.get("elements") if isinstance(base, dict) and base.get("kind") == "IRGroup" else None
            if static_index is not None and isinstance(elements, list) and static_index < len(elements):
                return elements[static_index]
            return {
                "base": base,
                "index": index,
                "span": self.serialize_expr(value.span, env),
                "kind": "IRIndex",
            }
        if isinstance(value, IRRecord):
            return {
                key: self.serialize_expr(record_value, env)
                for key, record_value in value.entries.items()
            }
        if is_dataclass(value):
            payload = {field.name: getattr(value, field.name) for field in fields(value)}
            if value.__class__.__name__ != "Span":
                payload["kind"] = value.__class__.__name__
            return {k: self.serialize_expr(v, env) for k, v in payload.items()}
        if isinstance(value, list):
            return [self.serialize_expr(v, env) for v in value]
        if isinstance(value, dict):
            return {k: self.serialize_expr(v, env) for k, v in value.items()}
        return value

    @staticmethod
    def static_nonnegative_index(value: Any) -> int | None:
        if not isinstance(value, dict) or value.get("kind") != "IRQuantity" or value.get("unit") is not None:
            return None
        raw_value = value.get("value")
        if not isinstance(raw_value, (int, float)):
            return None
        numeric_value = float(raw_value)
        if not numeric_value.is_integer() or numeric_value < 0:
            return None
        return int(numeric_value)


DEFAULT_PLAN_EXPRESSION_SERIALIZER = PlanExpressionSerializer()
